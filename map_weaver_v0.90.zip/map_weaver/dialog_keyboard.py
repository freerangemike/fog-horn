# -*- coding: utf-8 -*-
"""Shared dialog keyboard helpers (Enter activates focused buttons)."""

from __future__ import annotations

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QAbstractButton, QApplication


def activate_focused_button_on_enter(dialog, event) -> bool:
    """
    If focus is on an enabled button inside ``dialog``, click it on Enter/Return.

    Returns True if the event was handled. Call from ``QDialog.keyPressEvent``
    before ``super()`` so focused buttons work even when they are not the
    dialog default (Qt normally binds Enter to the default button only; Space
    activates a focused button).
    """
    try:
        if event.key() not in (Qt.Key_Return, Qt.Key_Enter):
            return False
    except Exception:
        return False
    try:
        w = dialog.focusWidget()
    except Exception:
        w = None
    if w is None:
        try:
            w = QApplication.focusWidget()
        except Exception:
            return False
    if w is None or not isinstance(w, QAbstractButton):
        return False
    try:
        if w is not dialog and not dialog.isAncestorOf(w):
            return False
        if w.focusPolicy() == Qt.NoFocus:
            return False
        if not w.isEnabled() or not w.isVisible():
            return False
        w.click()
        event.accept()
        return True
    except Exception:
        return False
