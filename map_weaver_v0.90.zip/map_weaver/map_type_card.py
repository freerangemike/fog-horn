"""Promotable card widget for map-type selection (Qt Designer → Promote to MapTypeCard)."""

import os

from qgis.PyQt.QtCore import QPointF, Qt, pyqtSignal
from qgis.PyQt.QtGui import QColor, QPainter, QPainterPath, QPen, QPixmap
from qgis.PyQt.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)


class CardCheckBadge(QWidget):
    """Square badge with vector-drawn check (round caps/join, antialiased)."""

    _BADGE_FILL = QColor("#A54242")

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("cardCheck")

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.fillRect(self.rect(), self._BADGE_FILL)
        w, h = float(self.width()), float(self.height())
        s = min(w, h)
        inset = s * 0.28
        iw, ih = w - 2.0 * inset, h - 2.0 * inset
        pen = QPen(QColor(0xFF, 0xFF, 0xFF))
        pen.setWidthF(max(1.75, s * 0.095))
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
        painter.setPen(pen)
        path = QPainterPath()
        path.moveTo(QPointF(inset + iw * 0.06, inset + ih * 0.52))
        path.lineTo(QPointF(inset + iw * 0.40, inset + ih * 0.82))
        path.lineTo(QPointF(inset + iw * 0.88, inset + ih * 0.16))
        painter.drawPath(path)


class MapTypeCard(QWidget):
    """Selectable card: illustration band, title, description, tag badge."""

    clicked = pyqtSignal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._selected = False
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        self.setMinimumHeight(168)
        self.setProperty("cardSelected", False)

        root = QVBoxLayout(self)
        # Keep card content inset so the stylesheet border stays visible on all sides.
        root.setContentsMargins(1, 1, 1, 1)
        root.setSpacing(0)

        self._art = QFrame(self)
        self._art.setObjectName("cardArt")
        self._art.setMinimumHeight(88)
        self._art.setMaximumHeight(88)
        art_layout = QVBoxLayout(self._art)
        art_layout.setContentsMargins(3, 3, 3, 3)
        art_layout.setSpacing(0)

        self._img = QLabel(self._art)
        self._img.setObjectName("cardArtImage")
        self._img.setScaledContents(True)
        self._img.setMinimumHeight(82)
        self._img.setMaximumHeight(82)
        self._img.hide()
        art_layout.addWidget(self._img)

        body = QWidget(self)
        self._body = body
        body.setObjectName("cardBody")
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(10, 8, 10, 10)
        body_layout.setSpacing(4)

        self._title = QLabel(body)
        self._title.setObjectName("cardTitle")
        self._title.setWordWrap(True)

        self._desc = QLabel(body)
        self._desc.setObjectName("cardDesc")
        self._desc.setWordWrap(True)

        tag_row = QHBoxLayout()
        tag_row.setSpacing(0)
        self._tag = QLabel(body)
        self._tag.setObjectName("cardTag")
        self._tag.setProperty("tagRole", "points")
        tag_row.addWidget(self._tag)
        tag_row.addStretch()

        body_layout.addWidget(self._title)
        body_layout.addWidget(self._desc)
        body_layout.addLayout(tag_row)

        root.addWidget(self._art)
        root.addWidget(body)

        self._check = CardCheckBadge(self)
        self._check.hide()
        self._compact_factor = 1.0

    def apply_compact_scale(self, factor):
        """Shrink art band, image, margins, and minimum height proportionally (e.g. dock Tools grid)."""
        factor = max(0.35, min(1.0, float(factor)))
        self._compact_factor = factor
        compact = factor < 0.99
        self.setProperty("dockCompact", compact)

        h_total = max(72, int(round(168 * factor)))
        art_h = max(28, int(round(88 * factor)))
        img_h = max(22, int(round(82 * factor)))

        self.setMinimumHeight(h_total)
        self.setMaximumHeight(16777215)
        self._art.setMinimumHeight(art_h)
        self._art.setMaximumHeight(art_h)
        self._img.setMinimumHeight(img_h)
        self._img.setMaximumHeight(img_h)

        root = self.layout()
        if root is not None:
            m = max(0, int(round(1 * factor)))
            root.setContentsMargins(m, m, m, m)

        al = self._art.layout()
        if al is not None:
            am = max(0, int(round(3 * factor)))
            al.setContentsMargins(am, am, am, am)

        bl = self._body.layout()
        if bl is not None:
            bl.setContentsMargins(
                int(round(10 * factor)),
                int(round(8 * factor)),
                int(round(10 * factor)),
                int(round(8 * factor)),
            )
            bl.setSpacing(max(1, int(round(4 * factor))))
        self.updateGeometry()
        self._polish(self)

    def showEvent(self, event):
        super().showEvent(event)
        self._check.raise_()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        f = getattr(self, "_compact_factor", 1.0)
        m = max(3, int(round(8 * f)))
        sz = max(12, int(round(22 * f)))
        self._check.setFixedSize(sz, sz)
        self._check.move(self.width() - self._check.width() - m, m)
        self._check.raise_()

    def configure(
        self,
        title,
        description,
        tag_text,
        tag_role="points",
        art_variant="default",
        illustration_path=None,
    ):
        self._title.setText(title)
        self._desc.setText(description)
        self._tag.setText(tag_text)
        self._tag.setProperty("tagRole", tag_role)
        self._art.setProperty("artVariant", art_variant)

        has_image = False
        if illustration_path and os.path.isfile(illustration_path):
            pix = QPixmap(illustration_path)
            if not pix.isNull():
                self._img.setPixmap(pix)
                self._img.show()
                has_image = True
        if not has_image:
            self._img.clear()
            self._img.hide()

        self._art.setProperty("hasImage", has_image)
        self._polish(self._tag)
        self._polish(self._art)
        self._polish(self._img)
        self._polish(self)

    def _polish(self, w):
        s = w.style()
        if s is not None:
            s.unpolish(w)
            s.polish(w)

    def set_selected(self, selected):
        self._selected = bool(selected)
        self.setProperty("cardSelected", self._selected)
        self._check.setVisible(self._selected)
        self._polish(self)

    def is_selected(self):
        return self._selected

    def set_experimental_locked(self, locked):
        """Dim / forbid selection chrome while still receiving clicks (Start dialog gate)."""
        locked = bool(locked)
        self._experimental_locked = locked
        self.setProperty("experimentalLocked", locked)
        self.setCursor(Qt.ForbiddenCursor if locked else Qt.PointingHandCursor)
        self._polish(self)

    def is_experimental_locked(self):
        return bool(getattr(self, "_experimental_locked", False))

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.setFocus(Qt.MouseFocusReason)
            self.clicked.emit(self)
        super().mouseReleaseEvent(event)

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            if not self.is_experimental_locked():
                self.clicked.emit(self)
                event.accept()
                return
        super().keyPressEvent(event)

    def focusInEvent(self, event):
        super().focusInEvent(event)
        self._polish(self)

    def focusOutEvent(self, event):
        super().focusOutEvent(event)
        self._polish(self)
