# -*- coding: utf-8 -*-
"""Route Connections edit-curve fixes without changing ``vendor/route_connections``.

Runtime evidence: ``arcFeatureCount >= 1`` but ``pickedFid`` stayed null even with a
wider ``searchRadiusMU``. Distances must use the **same CRS** as the geometries:
``toMapCoordinates`` is in the canvas CRS while Route Arcs geometries are in the
layer CRS — ``QgsGeometry.distance`` across CRS is invalid. We transform for pick,
move, and rubber-band preview.
"""
import math

from qgis.core import (
    QgsCoordinateTransform,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
)
from qgis.PyQt import sip

from .vendor.route_connections.edit_curve_tool import EditCurveMapTool


def _same_crs(a, b):
    if a is None or b is None:
        return False
    try:
        if a == b:
            return True
        if hasattr(a, "hasSameCrsAs") and a.hasSameCrsAs(b):
            return True
    except Exception:
        pass
    try:
        aid_a, aid_b = a.authid(), b.authid()
        if aid_a and aid_b and aid_a == aid_b:
            return True
    except Exception:
        pass
    return False


class MapestryEditCurveMapTool(EditCurveMapTool):
    """Pick/move curve in layer CRS; widen pick radius in map units (pixels)."""

    _PIXEL_PICK_TOLERANCE = 14.0

    def _route_point_layer_alive(self):
        """Dialog's current vector layer, or None if missing / deleted / not in project."""
        dlg = getattr(self, "dialog", None)
        if dlg is None:
            return None
        cl = getattr(dlg, "current_layer", None)
        if cl is None:
            return None
        try:
            if sip.isdeleted(cl):
                return None
        except Exception:
            return None
        try:
            if QgsProject.instance().mapLayer(cl.id()) is None:
                return None
        except Exception:
            return None
        return cl

    def _arc_layer_alive(self):
        al = getattr(self, "arc_layer", None)
        if al is None:
            return None
        try:
            if sip.isdeleted(al):
                return None
        except Exception:
            return None
        try:
            if QgsProject.instance().mapLayer(al.id()) is None:
                return None
        except Exception:
            return None
        return al

    def _canvas_crs(self):
        return self.canvas.mapSettings().destinationCrs()

    def _geom_in_canvas_crs(self, geom):
        """Copy of layer geometry transformed to map/canvas CRS for distance tests."""
        cc = self._canvas_crs()
        lc = self.arc_layer.crs()
        g = QgsGeometry(geom)
        if _same_crs(lc, cc):
            return g
        tr = QgsCoordinateTransform(lc, cc, QgsProject.instance())
        try:
            g.transform(tr)
        except Exception:
            return None
        return g

    def _point_canvas_to_layer(self, map_xy):
        """Map canvas point → arc layer CRS (for curvature math vs stored vertices)."""
        cc = self._canvas_crs()
        lc = self.arc_layer.crs()
        if _same_crs(cc, lc):
            return QgsPointXY(map_xy)
        tr = QgsCoordinateTransform(cc, lc, QgsProject.instance())
        try:
            return tr.transform(map_xy)
        except Exception:
            return QgsPointXY(map_xy)

    def canvasPressEvent(self, e):
        cur = self._route_point_layer_alive()
        if cur is None:
            return

        source_crs = cur.crs()
        self.arc_layer = self.plugin.get_arc_layer(source_crs)
        al = self.arc_layer
        if al is None or sip.isdeleted(al):
            return
        try:
            if al.featureCount() == 0:
                return
        except Exception:
            return

        click_point = self.toMapCoordinates(e.pos())
        click_geom = QgsGeometry.fromPointXY(click_point)

        closest_feat = None
        min_dist = float("inf")

        search_radius = self.searchRadiusMU(self.canvas)
        try:
            ext = self.canvas.extent()
            w = max(self.canvas.width(), 1)
            h = max(self.canvas.height(), 1)
            mu_per = max(ext.width() / float(w), ext.height() / float(h))
            search_radius = max(
                float(search_radius),
                mu_per * self._PIXEL_PICK_TOLERANCE,
            )
        except Exception:
            pass

        cc = self._canvas_crs()
        lc = self.arc_layer.crs()

        for feat in self.arc_layer.getFeatures():
            geom = feat.geometry()
            g_canvas = self._geom_in_canvas_crs(geom)
            if g_canvas is None:
                continue
            dist = g_canvas.distance(click_geom)
            if dist < min_dist and dist < search_radius:
                min_dist = dist
                closest_feat = feat

        if closest_feat:
            self.active_feature = closest_feat
            geom = closest_feat.geometry()

            if geom.isMultipart():
                polyline = geom.asMultiPolyline()[0]
            else:
                polyline = geom.asPolyline()

            if polyline:
                self.start_pt = QgsPointXY(polyline[0])
                self.end_pt = QgsPointXY(polyline[-1])

    def canvasMoveEvent(self, e):
        if not self.active_feature or not self.start_pt or not self.end_pt:
            return
        al = self._arc_layer_alive()
        if al is None:
            return

        mouse_map = self.toMapCoordinates(e.pos())
        mouse_pt = self._point_canvas_to_layer(mouse_map)

        x1, y1 = self.start_pt.x(), self.start_pt.y()
        x2, y2 = self.end_pt.x(), self.end_pt.y()
        mx, my = mouse_pt.x(), mouse_pt.y()

        dx = x2 - x1
        dy = y2 - y1
        length = math.hypot(dx, dy)

        if length == 0:
            return

        cross_product = (my - y1) * dx - (mx - x1) * dy
        signed_dist = cross_product / length

        self.current_curvature = signed_dist / length
        self.current_curvature = max(-2.0, min(2.0, self.current_curvature))

        new_points = self.plugin.get_bezier_curve(
            self.start_pt, self.end_pt, curvature=self.current_curvature
        )
        new_geom = QgsGeometry.fromPolylineXY(new_points)

        self.rubber_band.setToGeometry(new_geom, self.arc_layer)

    def canvasReleaseEvent(self, e):
        if not self.active_feature:
            return
        al = self._arc_layer_alive()
        if al is None:
            self.active_feature = None
            self.start_pt = None
            self.end_pt = None
            try:
                self.rubber_band.reset()
            except Exception:
                pass
            return

        new_points = self.plugin.get_bezier_curve(
            self.start_pt, self.end_pt, curvature=self.current_curvature
        )
        new_geom = QgsGeometry.fromPolylineXY(new_points)

        if not al.isEditable():
            al.startEditing()

        al.changeGeometry(self.active_feature.id(), new_geom)
        al.triggerRepaint()

        self.rubber_band.reset()
        self.active_feature = None
        self.start_pt = None
        self.end_pt = None

    def deactivate(self):
        self.rubber_band.reset()
        super().deactivate()
