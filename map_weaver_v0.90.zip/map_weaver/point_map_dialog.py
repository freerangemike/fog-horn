# -*- coding: utf-8 -*-
"""Geocode / Add points — UI from point_map.ui."""

import os

from qgis.core import QgsProject, QgsVectorLayer
from qgis.PyQt import uic
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QGuiApplication, QColor
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QListWidgetItem,
    QMessageBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from .geocode_layer import (
    apply_geocode_layer_point_color,
    geocode_layer_address_lines,
    geocode_layer_point_color,
    list_geocode_layers,
)
from .library_basemap_list import (
    populate_library_basemap_qlist_widget,
    wire_library_basemap_qlist_widget,
)
from .route_connections_fields import preferred_display_field_name
from .route_connections_import import (
    _FILE_FILTER,
    _split_headers_and_data,
    read_tabular_file,
)
from .southneedle import CustomArrowColorButton  # noqa: F401 — promoted widget in point_map.ui

NEW_LAYER_ROLE = "new_layer"
DEFAULT_GEOCODE_POINT_COLOR = QColor(0, 255, 0)


class _ImportAddressesColumnDialog(QDialog):
    """Pick which file column holds addresses for Location Lookup import."""

    def __init__(self, raw_rows, parent=None):
        super().__init__(parent)
        self.setWindowTitle(self.tr("Import Addresses — Column Mapping"))
        self.setMinimumWidth(560)
        self.setMinimumHeight(360)
        self._raw_rows = raw_rows or []
        self._headers = []
        self._data_rows = []

        layout = QVBoxLayout(self)
        layout.addWidget(
            QLabel(
                self.tr(
                    "Choose which file column contains the addresses to geocode."
                )
            )
        )

        self.has_headers_check = QCheckBox(self.tr("First row has column headings"))
        self.has_headers_check.setChecked(True)
        self.has_headers_check.toggled.connect(self._rebuild_from_header_mode)
        layout.addWidget(self.has_headers_check)

        form = QHBoxLayout()
        self.address_combo = QComboBox()
        form.addWidget(QLabel(self.tr("Address column:")))
        form.addWidget(self.address_combo, 1)
        layout.addLayout(form)

        layout.addWidget(QLabel(self.tr("Preview (first rows):")))
        self.preview = QTableWidget(self)
        self.preview.setEditTriggers(QTableWidget.NoEditTriggers)
        self.preview.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.preview, 1)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self._rebuild_from_header_mode()

    def _rebuild_from_header_mode(self, *_args):
        has_headers = self.has_headers_check.isChecked()
        self._headers, self._data_rows = _split_headers_and_data(
            self._raw_rows, has_headers
        )
        prev = self.address_combo.currentText()

        self.address_combo.blockSignals(True)
        try:
            self.address_combo.clear()
            for header in self._headers:
                self.address_combo.addItem(header)
        finally:
            self.address_combo.blockSignals(False)

        guessed = preferred_display_field_name(self._headers)
        if guessed and self.address_combo.findText(guessed) >= 0:
            self.address_combo.setCurrentText(guessed)
        elif prev and self.address_combo.findText(prev) >= 0:
            self.address_combo.setCurrentText(prev)
        elif self.address_combo.count() > 0:
            self.address_combo.setCurrentIndex(0)

        preview_rows = self._data_rows[:8]
        cols = len(self._headers)
        self.preview.clear()
        self.preview.setColumnCount(cols)
        self.preview.setHorizontalHeaderLabels(self._headers)
        self.preview.setRowCount(len(preview_rows))
        for row_idx, row in enumerate(preview_rows):
            for col_idx in range(cols):
                value = row[col_idx] if col_idx < len(row) else ""
                self.preview.setItem(row_idx, col_idx, QTableWidgetItem(value))

    def selected_addresses(self) -> list[str]:
        col_name = self.address_combo.currentText()
        try:
            col_idx = self._headers.index(col_name)
        except ValueError:
            return []
        out = []
        for row in self._data_rows:
            if col_idx >= len(row):
                continue
            text = str(row[col_idx] or "").strip()
            if text:
                out.append(text)
        return out


class PointMapDialog(QDialog):
    """Addresses + point color + Add Points; opened from Tools → Location Lookup card."""

    def __init__(self, plugin, parent=None):
        super().__init__(parent)
        self._plugin = plugin
        self._syncing_geocode_color = False
        self._project_layers_wired = False
        ui_path = os.path.join(os.path.dirname(__file__), "point_map.ui")
        self.dlgPointMap = self
        try:
            uic.loadUi(ui_path, self)
        finally:
            try:
                del self.dlgPointMap
            except AttributeError:
                pass
        if hasattr(self, "plhLabel03"):
            self.plhLabel03.hide()
        color_btn = getattr(self, "plhQGSCB03", None)
        if color_btn is not None:
            color_btn.setColor(DEFAULT_GEOCODE_POINT_COLOR)
            color_btn.colorChanged.connect(self._on_geocode_point_color_changed)
        self.pbnAddPoints.clicked.connect(self._on_add_points)
        lst = getattr(self, "lstLibraryBasemaps", None)
        if lst is not None:
            wire_library_basemap_qlist_widget(lst, self._on_library_basemap_chosen)
        pbn_browse = getattr(self, "pbnBrowseLayer", None)
        if pbn_browse is not None:
            pbn_browse.clicked.connect(self._on_browse_layer)
        bb = getattr(self, "buttonBox", None)
        if bb is not None:
            bb.accepted.connect(self._on_wizard_finished)

        self._mode_group = None
        if hasattr(self, "rbGeocodeAdd") and hasattr(self, "rbGeocodeUpdate"):
            from qgis.PyQt.QtWidgets import QButtonGroup

            self._mode_group = QButtonGroup(self)
            self._mode_group.setExclusive(True)
            self._mode_group.addButton(self.rbGeocodeUpdate)
            self._mode_group.addButton(self.rbGeocodeAdd)
            self.rbGeocodeUpdate.toggled.connect(self._on_geocode_mode_changed)
            self.rbGeocodeAdd.toggled.connect(self._on_geocode_mode_changed)

        geo_lst = getattr(self, "lstGeocodeLayers", None)
        if geo_lst is not None:
            geo_lst.currentItemChanged.connect(self._on_geocode_layer_selection_changed)

        pbn_name = getattr(self, "pbnUpdateGeocodeLayerName", None)
        if pbn_name is not None:
            pbn_name.clicked.connect(self._on_update_layer_name_clicked)

        pbn_temp = getattr(self, "pbnOpenTempGeocodeLayers", None)
        if pbn_temp is not None:
            pbn_temp.clicked.connect(self._on_open_temp_geocode_layers)

        pbn_import = getattr(self, "pbnImportAddresses", None)
        if pbn_import is not None:
            pbn_import.clicked.connect(self._on_import_addresses)

    def new_layer_display_name(self) -> str | None:
        """Layer name from the dialog when New Layer is selected (used on create)."""
        if not self.is_new_geocode_layer_selected():
            return None
        line = getattr(self, "lineGeocodeLayerName", None)
        if line is None:
            return None
        name = line.text().strip()
        if not name or name == self.tr("New Layer"):
            return None
        return name

    def _library_folder(self):
        if self._plugin is None or not hasattr(self._plugin, "_library_folder"):
            return None
        try:
            return self._plugin._library_folder()
        except Exception:
            return None

    def _refresh_library_basemap_list(self):
        lst = getattr(self, "lstLibraryBasemaps", None)
        if lst is None:
            return
        populate_library_basemap_qlist_widget(lst, self._library_folder() or "")

    def _wire_project_layer_signals(self):
        if self._project_layers_wired:
            return
        proj = QgsProject.instance()
        try:
            proj.layersAdded.connect(self._on_project_layers_added)
            proj.layersRemoved.connect(self._on_project_layers_removed)
            self._project_layers_wired = True
        except Exception:
            pass

    def _unwire_project_layer_signals(self):
        if not self._project_layers_wired:
            return
        proj = QgsProject.instance()
        try:
            proj.layersAdded.disconnect(self._on_project_layers_added)
        except (TypeError, RuntimeError):
            pass
        try:
            proj.layersRemoved.disconnect(self._on_project_layers_removed)
        except (TypeError, RuntimeError):
            pass
        self._project_layers_wired = False

    def _on_project_layers_added(self, layers):
        select_id = self.selected_geocode_layer_id()
        try:
            from .geocode_layer import has_geocode_tag
        except Exception:
            has_geocode_tag = None
        for lyr in layers or []:
            if not isinstance(lyr, QgsVectorLayer):
                continue
            try:
                if has_geocode_tag is not None and has_geocode_tag(lyr):
                    select_id = lyr.id()
            except Exception:
                pass
        self._refresh_library_basemap_list()
        self._refresh_geocode_layer_list(select_layer_id=select_id)

    def _on_project_layers_removed(self, _layer_ids):
        self._refresh_library_basemap_list()
        self._refresh_geocode_layer_list()

    def _refresh_geocode_layer_list(
        self,
        select_layer_id: str | None = None,
        force_update_mode: bool = False,
    ):
        lst = getattr(self, "lstGeocodeLayers", None)
        if lst is None:
            return
        prev_id = select_layer_id or self.selected_geocode_layer_id()
        lst.blockSignals(True)
        try:
            lst.clear()
            new_item = QListWidgetItem(self.tr("New Layer"))
            new_item.setData(Qt.UserRole, NEW_LAYER_ROLE)
            lst.addItem(new_item)
            select_row = 0
            for row, lyr in enumerate(list_geocode_layers(), start=1):
                item = QListWidgetItem(lyr.name())
                item.setData(Qt.UserRole, lyr.id())
                lst.addItem(item)
                if prev_id and lyr.id() == prev_id:
                    select_row = row
            lst.setCurrentRow(select_row)
        finally:
            lst.blockSignals(False)
        self._sync_geocode_mode_controls(force_update_mode=force_update_mode)

    def _selected_list_item(self):
        lst = getattr(self, "lstGeocodeLayers", None)
        if lst is None:
            return None
        return lst.currentItem()

    def is_new_geocode_layer_selected(self) -> bool:
        item = self._selected_list_item()
        if item is None:
            return True
        return item.data(Qt.UserRole) == NEW_LAYER_ROLE

    def selected_geocode_layer_id(self) -> str | None:
        item = self._selected_list_item()
        if item is None:
            return None
        role = item.data(Qt.UserRole)
        if role == NEW_LAYER_ROLE:
            return None
        return str(role) if role else None

    def _selected_geocode_layer(self) -> QgsVectorLayer | None:
        """Map layer for the list selection (by QGIS layer id, not geocode heuristics)."""
        layer_id = self.selected_geocode_layer_id()
        if not layer_id:
            return None
        lyr = QgsProject.instance().mapLayer(layer_id)
        if lyr is None or not isinstance(lyr, QgsVectorLayer):
            return None
        try:
            from qgis.PyQt import sip

            if sip.isdeleted(lyr):
                return None
        except Exception:
            return None
        return lyr

    def is_update_mode(self) -> bool:
        rb = getattr(self, "rbGeocodeUpdate", None)
        return rb is not None and rb.isEnabled() and rb.isChecked()

    def is_add_mode(self) -> bool:
        return not self.is_update_mode()

    def _sync_geocode_mode_controls(self, force_update_mode: bool = False):
        is_new = self.is_new_geocode_layer_selected()
        rb_update = getattr(self, "rbGeocodeUpdate", None)
        rb_add = getattr(self, "rbGeocodeAdd", None)
        if rb_update is not None:
            rb_update.setEnabled(not is_new)
        if is_new:
            if rb_add is not None:
                rb_add.setChecked(True)
        elif force_update_mode and rb_update is not None:
            # After creating/selecting a newly added layer, land in Update with addresses.
            rb_update.setChecked(True)
        self._sync_layer_name_field()
        self._sync_color_selector()
        self._sync_address_field()

    def _geocode_job_active_for_selected_layer(self) -> bool:
        plugin = self._plugin
        if plugin is None:
            return False
        job = getattr(plugin, "_geocode_job", None)
        if not job:
            return False
        layer = job.get("layer")
        if layer is None:
            return False
        sel_id = self.selected_geocode_layer_id()
        if not sel_id:
            return False
        try:
            return layer.id() == sel_id
        except Exception:
            return False

    def _clear_address_field(self):
        ted = getattr(self, "tedAddresses", None)
        if ted is not None:
            ted.clear()

    def _sync_address_field(self):
        ted = getattr(self, "tedAddresses", None)
        if ted is None:
            return
        if self.is_update_mode() and not self.is_new_geocode_layer_selected():
            if self._geocode_job_active_for_selected_layer():
                return
            self._populate_addresses_from_selected_layer()
        else:
            self._clear_address_field()

    def refresh_addresses_for_selected_layer(self):
        """Refresh the address field after geocoding finishes."""
        if self.is_new_geocode_layer_selected():
            return
        if self.is_add_mode():
            self._clear_address_field()
            return
        self._populate_addresses_from_selected_layer()

    def _sync_layer_name_field(self):
        line = getattr(self, "lineGeocodeLayerName", None)
        btn = getattr(self, "pbnUpdateGeocodeLayerName", None)
        if line is None:
            return
        if self.is_new_geocode_layer_selected():
            line.setText(self.tr("New Layer"))
            if btn is not None:
                btn.setEnabled(False)
            return
        lyr = self._selected_geocode_layer()
        line.setText(lyr.name() if lyr is not None else "")
        if btn is not None:
            btn.setEnabled(lyr is not None)

    def _sync_color_selector(self):
        color_btn = getattr(self, "plhQGSCB03", None)
        color_lbl = getattr(self, "label_6", None)
        if color_btn is not None:
            color_btn.setEnabled(True)
            self._syncing_geocode_color = True
            try:
                if self.is_new_geocode_layer_selected():
                    color_btn.setColor(DEFAULT_GEOCODE_POINT_COLOR)
                else:
                    lyr = self._selected_geocode_layer()
                    layer_color = geocode_layer_point_color(lyr) if lyr else None
                    if layer_color is not None and layer_color.isValid():
                        color_btn.setColor(layer_color)
                    else:
                        color_btn.setColor(DEFAULT_GEOCODE_POINT_COLOR)
            finally:
                self._syncing_geocode_color = False
        if color_lbl is not None:
            color_lbl.setEnabled(True)

    def _on_geocode_point_color_changed(self, color):
        if self._syncing_geocode_color:
            return
        if self.is_new_geocode_layer_selected():
            return
        lyr = self._selected_geocode_layer()
        if lyr is None or color is None or not color.isValid():
            return
        apply_geocode_layer_point_color(lyr, color)

    def _on_update_layer_name_clicked(self):
        line = getattr(self, "lineGeocodeLayerName", None)
        if line is None:
            return
        name = line.text().strip()
        if not name:
            QMessageBox.warning(
                self,
                self.windowTitle(),
                self.tr("Enter a layer name."),
            )
            return
        if self.is_new_geocode_layer_selected():
            return

        layer_id = self.selected_geocode_layer_id()
        if not layer_id:
            return

        lyr = self._selected_geocode_layer()
        if lyr is None:
            QMessageBox.warning(
                self,
                self.windowTitle(),
                self.tr("The selected geocode layer is no longer in the project."),
            )
            self._refresh_geocode_layer_list()
            return
        if lyr.name() == name:
            return
        from .geocode_layer import set_geocode_layer_display_name

        set_geocode_layer_display_name(lyr, name)
        item = self._selected_list_item()
        if item is not None:
            item.setText(name)
        try:
            lyr.triggerRepaint()
        except Exception:
            pass

    def _on_geocode_layer_selection_changed(self, current, previous):
        if current is None:
            return
        is_new = self.is_new_geocode_layer_selected()
        was_new = (
            previous is not None
            and previous.data(Qt.UserRole) == NEW_LAYER_ROLE
        )
        rb_update = getattr(self, "rbGeocodeUpdate", None)
        rb_add = getattr(self, "rbGeocodeAdd", None)
        if rb_update is not None:
            rb_update.setEnabled(not is_new)
        if is_new:
            if rb_add is not None:
                rb_add.setChecked(True)
        elif was_new and rb_update is not None:
            rb_update.setChecked(True)
        self._sync_layer_name_field()
        self._sync_color_selector()
        self._sync_address_field()

    def _on_geocode_mode_changed(self, checked=False):
        if not checked:
            return
        self._sync_address_field()

    def _populate_addresses_from_selected_layer(self):
        ted = getattr(self, "tedAddresses", None)
        if ted is None:
            return
        lyr = self._selected_geocode_layer()
        if lyr is None:
            ted.setPlainText("")
            return
        lines = geocode_layer_address_lines(lyr)
        ted.setPlainText("\n".join(lines))

    def _on_library_basemap_chosen(self, path):
        if self._plugin is not None and hasattr(self._plugin, "loadBasemapFromFile"):
            self._plugin.loadBasemapFromFile(path, add_at_bottom=True)

    def _on_browse_layer(self):
        path, _selected = QFileDialog.getOpenFileName(
            self,
            self.tr("Add layer"),
            "",
            self.tr(
                "Vector files (*.shp *.zip *.gpkg *.geojson *.json);;"
                "All files (*.*)"
            ),
        )
        path = (path or "").strip()
        if not path:
            return
        if self._plugin is not None and hasattr(self._plugin, "loadBasemapFromFile"):
            self._plugin.loadBasemapFromFile(path, add_at_bottom=True)

    def _on_wizard_finished(self):
        if self._plugin is not None and hasattr(self._plugin, "register_completed_tool"):
            self._plugin.register_completed_tool("location_plot")

    def showEvent(self, event):
        super().showEvent(event)
        self._wire_project_layer_signals()
        self._refresh_library_basemap_list()
        self._refresh_geocode_layer_list()
        self._center_on_screen()

    def hideEvent(self, event):
        self._unwire_project_layer_signals()
        super().hideEvent(event)

    def closeEvent(self, event):
        self._unwire_project_layer_signals()
        super().closeEvent(event)

    def _center_on_screen(self):
        ref = self.parentWidget()
        center_pt = ref.frameGeometry().center() if ref is not None else None
        if center_pt is None:
            center_pt = self.frameGeometry().center()
        screen = QGuiApplication.screenAt(center_pt)
        if screen is None:
            screen = QGuiApplication.primaryScreen()
        if screen is None:
            return
        ag = screen.availableGeometry()
        geo = self.frameGeometry()
        geo.moveCenter(ag.center())
        self.move(geo.topLeft())

    def _on_import_addresses(self):
        path, _selected = QFileDialog.getOpenFileName(
            self,
            self.tr("Import Addresses"),
            "",
            _FILE_FILTER,
        )
        if not path:
            return
        try:
            raw_rows = read_tabular_file(path)
        except ImportError as exc:
            QMessageBox.warning(self, self.tr("Import Addresses"), str(exc))
            return
        except OSError as exc:
            QMessageBox.warning(
                self,
                self.tr("Import Addresses"),
                self.tr("Could not read file:\n{error}").format(error=exc),
            )
            return
        if not raw_rows:
            QMessageBox.warning(
                self,
                self.tr("Import Addresses"),
                self.tr("The selected file has no data rows."),
            )
            return

        mapping_dlg = _ImportAddressesColumnDialog(raw_rows, self)
        if mapping_dlg.exec_() != QDialog.Accepted:
            return
        addresses = mapping_dlg.selected_addresses()
        if not addresses:
            QMessageBox.warning(
                self,
                self.tr("Import Addresses"),
                self.tr("No addresses found in the selected column."),
            )
            return

        self._apply_imported_addresses(addresses)

    def _apply_imported_addresses(self, addresses: list[str]):
        """Switch to New Layer + Add and fill the address list (no geocode)."""
        lst = getattr(self, "lstGeocodeLayers", None)
        rb_add = getattr(self, "rbGeocodeAdd", None)
        ted = getattr(self, "tedAddresses", None)
        if lst is None or ted is None:
            return

        # Select New Layer first; sync clears the address field for Add mode.
        lst.blockSignals(True)
        try:
            lst.setCurrentRow(0)
        finally:
            lst.blockSignals(False)

        rb_update = getattr(self, "rbGeocodeUpdate", None)
        if rb_update is not None:
            rb_update.setEnabled(False)
        if rb_add is not None:
            rb_add.blockSignals(True)
            try:
                rb_add.setChecked(True)
            finally:
                rb_add.blockSignals(False)

        self._sync_layer_name_field()
        self._sync_color_selector()
        ted.setPlainText("\n".join(addresses))

    def _on_add_points(self):
        if self._plugin is not None:
            self._plugin.runGeocodingFromDialog(self)

    def _on_open_temp_geocode_layers(self):
        from .temp_geocode_layers_dialog import TempGeocodeLayersDialog

        dlg = TempGeocodeLayersDialog(
            self,
            on_layer_added=self._on_temp_geocode_layer_added,
        )
        dlg.exec_()

    def _on_temp_geocode_layer_added(self, layer):
        if layer is None:
            return
        try:
            layer_id = layer.id()
        except Exception:
            layer_id = None
        self._refresh_geocode_layer_list(
            select_layer_id=layer_id,
            force_update_mode=True,
        )
