# -*- coding: utf-8 -*-
"""Save Project As: duplicate project folder data and rewrite layer paths."""

from __future__ import annotations

import os
import shutil

from qgis.core import QgsMapLayer, QgsProject
from qgis.PyQt import sip

from .route_arcs_project_blob import prepare_project_for_disk_write

# Skip only the live project file at the source folder root (we write a fresh one).
_PROJECT_EXTS = (".qgz", ".qgs")


def _norm(path: str) -> str:
    return os.path.normcase(os.path.normpath(os.path.abspath(path)))


def _is_under_dir(path: str, folder: str) -> bool:
    if not path or not folder:
        return False
    try:
        return _norm(path).startswith(_norm(folder) + os.sep) or _norm(path) == _norm(
            folder
        )
    except Exception:
        return False


def _source_path_part(source: str) -> str:
    """File path portion of a QGIS layer URI (before ``|`` options)."""
    raw = str(source or "").strip()
    if not raw:
        return ""
    path = raw.split("|", 1)[0].strip().strip('"').strip("'")
    return path


def _resolve_against(path_part: str, base_folder: str) -> str:
    if not path_part:
        return ""
    if os.path.isabs(path_part):
        return os.path.normpath(path_part)
    if base_folder:
        return os.path.normpath(os.path.join(base_folder, path_part))
    return os.path.normpath(os.path.abspath(path_part))


def _rebuild_source(source: str, new_path: str) -> str:
    raw = str(source or "")
    if "|" not in raw:
        return new_path
    return new_path + "|" + raw.split("|", 1)[1]


def _commit_all_vector_edits(project: QgsProject) -> None:
    for lyr in project.mapLayers().values():
        try:
            if sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        try:
            if hasattr(lyr, "isEditable") and lyr.isEditable():
                lyr.commitChanges()
        except Exception:
            pass


def _copy_tree_excluding_project_files(
    src_dir: str, dest_dir: str, skip_basenames: set[str]
) -> list[str]:
    """
    Copy ``src_dir`` into ``dest_dir`` (files + subfolders).

    Returns a list of human-readable warnings for files that could not be copied.
    """
    warnings: list[str] = []
    src_dir = os.path.normpath(src_dir)
    dest_dir = os.path.normpath(dest_dir)
    os.makedirs(dest_dir, exist_ok=True)

    for root, dirs, files in os.walk(src_dir):
        # Do not descend into common junk.
        dirs[:] = [d for d in dirs if d not in (".git", "__pycache__", ".vs")]
        rel_root = os.path.relpath(root, src_dir)
        dest_root = dest_dir if rel_root == "." else os.path.join(dest_dir, rel_root)
        try:
            os.makedirs(dest_root, exist_ok=True)
        except OSError as exc:
            warnings.append("Could not create {}: {}".format(dest_root, exc))
            continue
        for name in files:
            if rel_root == "." and name in skip_basenames:
                continue
            if rel_root == ".":
                low = name.lower()
                if low.endswith(_PROJECT_EXTS):
                    # Always skip project files at the folder root; write a fresh one.
                    continue
            src_file = os.path.join(root, name)
            dest_file = os.path.join(dest_root, name)
            try:
                if os.path.isfile(dest_file):
                    try:
                        if os.path.getsize(dest_file) == os.path.getsize(src_file):
                            # Still refresh mtime/content for safety when sizes match.
                            pass
                    except OSError:
                        pass
                shutil.copy2(src_file, dest_file)
            except OSError as exc:
                warnings.append("Could not copy {}: {}".format(name, exc))
    return warnings


def _relink_layers_from_folder(
    project: QgsProject, old_folder: str, new_folder: str
) -> int:
    """Point layers whose data lives under ``old_folder`` at copies under ``new_folder``."""
    relinked = 0
    old_folder = os.path.normpath(old_folder)
    new_folder = os.path.normpath(new_folder)
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsMapLayer):
            continue
        try:
            if sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        try:
            provider = (lyr.providerType() or "").strip()
            source = str(lyr.source() or "")
        except Exception:
            continue
        if provider in ("memory", "wms", "wfs", "wcs", "xyz", "virtual"):
            continue
        path_part = _source_path_part(source)
        if not path_part:
            continue
        abs_path = _resolve_against(path_part, old_folder)
        if not _is_under_dir(abs_path, old_folder):
            continue
        try:
            rel = os.path.relpath(abs_path, old_folder)
        except ValueError:
            continue
        new_path = os.path.normpath(os.path.join(new_folder, rel))
        if not os.path.exists(new_path):
            # Primary file missing (copy failed); leave layer as-is.
            continue
        if os.path.normpath(abs_path) == new_path:
            continue
        new_source = _rebuild_source(source, new_path)
        try:
            name = lyr.name()
        except Exception:
            name = ""
        try:
            from qgis.core import QgsDataProvider

            opts = QgsDataProvider.ProviderOptions()
            if not hasattr(lyr, "setDataSource"):
                continue
            lyr.setDataSource(new_source, name, provider, opts)
            if not lyr.isValid():
                # Retry without provider options (older QGIS).
                lyr.setDataSource(new_source, name, provider)
            if lyr.isValid():
                relinked += 1
                try:
                    lyr.updateExtents()
                except Exception:
                    pass
                try:
                    lyr.triggerRepaint()
                except Exception:
                    pass
        except Exception:
            continue
    return relinked


def _export_vector_layer_to_path(lyr, dest_path: str) -> bool:
    """Last-resort copy for locked GPKG/SHP via QgsVectorFileWriter."""
    try:
        from qgis.core import QgsVectorFileWriter, QgsVectorLayer
    except Exception:
        return False
    if not isinstance(lyr, QgsVectorLayer):
        return False
    parent = os.path.dirname(dest_path)
    if parent:
        try:
            os.makedirs(parent, exist_ok=True)
        except OSError:
            return False
    ext = os.path.splitext(dest_path)[1].lower()
    driver = "GPKG" if ext == ".gpkg" else ("ESRI Shapefile" if ext == ".shp" else "GPKG")
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = driver
    if driver == "GPKG":
        options.layerName = os.path.splitext(os.path.basename(dest_path))[0] or "data"
    options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
    project = QgsProject.instance()
    ctx = project.transformContext() if project else None
    try:
        err, _w, _p, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
            lyr, dest_path, ctx, options
        )
        code = err[0] if isinstance(err, (tuple, list)) else err
        return code == QgsVectorFileWriter.NoError and os.path.isfile(dest_path)
    except Exception:
        try:
            err = QgsVectorFileWriter.writeAsVectorFormat(
                lyr, dest_path, "UTF-8", lyr.crs(), driver
            )
            code = err[0] if isinstance(err, (tuple, list)) else err
            return code == QgsVectorFileWriter.NoError and os.path.isfile(dest_path)
        except Exception:
            return False


def _ensure_missing_layer_files_copied(
    project: QgsProject,
    old_folder: str,
    new_folder: str,
    warnings: list[str],
) -> None:
    """Retry copy/export for layer files that the tree copy missed (e.g. locked GPKG)."""
    old_folder = os.path.normpath(old_folder)
    new_folder = os.path.normpath(new_folder)
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsMapLayer):
            continue
        try:
            if sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        try:
            provider = (lyr.providerType() or "").strip()
            source = str(lyr.source() or "")
        except Exception:
            continue
        if provider in ("memory", "wms", "wfs", "wcs", "xyz", "virtual"):
            continue
        path_part = _source_path_part(source)
        if not path_part:
            continue
        abs_path = _resolve_against(path_part, old_folder)
        if not _is_under_dir(abs_path, old_folder):
            continue
        try:
            rel = os.path.relpath(abs_path, old_folder)
        except ValueError:
            continue
        dest_path = os.path.normpath(os.path.join(new_folder, rel))
        if os.path.isfile(dest_path):
            continue
        parent = os.path.dirname(dest_path)
        if parent:
            try:
                os.makedirs(parent, exist_ok=True)
            except OSError:
                pass
        copied = False
        if os.path.isfile(abs_path):
            try:
                shutil.copy2(abs_path, dest_path)
                copied = os.path.isfile(dest_path)
            except OSError:
                copied = False
        if not copied:
            copied = _export_vector_layer_to_path(lyr, dest_path)
        if not copied:
            warnings.append(
                "Missing after copy: {}".format(os.path.basename(dest_path) or dest_path)
            )


def _prefer_relative_paths(project: QgsProject) -> None:
    try:
        from qgis.core import Qgis

        if hasattr(project, "setFilePathStorage"):
            project.setFilePathStorage(Qgis.FilePathType.Relative)
            return
    except Exception:
        pass
    try:
        # Older QGIS: Paths / Absolute is a bool entry (False = relative).
        project.writeEntryBool("Paths", "/", False)
    except Exception:
        pass


def save_project_as_complete_duplicate(
    project: QgsProject | None,
    new_project_path: str,
) -> tuple[bool, str | None]:
    """
    Save the project to ``new_project_path``, copying all files from the current
    project folder into the new folder and relinking layers that pointed there.

    Returns (ok, error_or_warning_message).
    """
    project = project or QgsProject.instance()
    new_project_path = os.path.normpath(os.path.abspath(str(new_project_path or "").strip()))
    if not new_project_path:
        return False, "Missing save path."
    low = new_project_path.lower()
    if not low.endswith(".qgz") and not low.endswith(".qgs"):
        new_project_path += ".qgz"

    new_folder = os.path.dirname(new_project_path)
    if not new_folder:
        return False, "Invalid save path."
    try:
        os.makedirs(new_folder, exist_ok=True)
    except OSError as exc:
        return False, "Could not create folder: {}".format(exc)

    old_path = ""
    try:
        old_path = (project.absoluteFilePath() or project.fileName() or "").strip()
    except Exception:
        old_path = (project.fileName() or "").strip()
    old_folder = ""
    if old_path:
        old_folder = os.path.dirname(os.path.abspath(old_path))

    _commit_all_vector_edits(project)

    copy_warnings: list[str] = []
    same_folder = bool(old_folder) and _norm(old_folder) == _norm(new_folder)

    if old_folder and os.path.isdir(old_folder) and not same_folder:
        skip = set()
        if old_path:
            skip.add(os.path.basename(old_path))
        copy_warnings = _copy_tree_excluding_project_files(
            old_folder, new_folder, skip_basenames=skip
        )
        _ensure_missing_layer_files_copied(project, old_folder, new_folder, copy_warnings)
        _relink_layers_from_folder(project, old_folder, new_folder)

    # Staging → new folder for Mapestry sidecars; also handles never-saved projects.
    prepare_project_for_disk_write(project, save_path=new_project_path)
    # Relink again in case migrate wrote new files under new_folder while sources
    # still referenced staging/old paths that were not under old_folder.
    if old_folder and os.path.isdir(old_folder) and not same_folder:
        _ensure_missing_layer_files_copied(project, old_folder, new_folder, copy_warnings)
        _relink_layers_from_folder(project, old_folder, new_folder)

    _prefer_relative_paths(project)

    try:
        ok = project.write(new_project_path)
    except TypeError:
        from qgis.PyQt.QtCore import QFileInfo

        ok = project.write(QFileInfo(new_project_path))
    except Exception as exc:
        return False, "Could not save the project: {}".format(exc)

    if not ok:
        return False, "Could not save the project."

    if copy_warnings:
        return True, (
            "Project saved, but some files could not be copied:\n"
            + "\n".join(copy_warnings[:12])
            + ("\n…" if len(copy_warnings) > 12 else "")
        )
    return True, None
