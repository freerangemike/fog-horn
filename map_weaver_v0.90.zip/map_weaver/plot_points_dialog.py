# -*- coding: utf-8 -*-
"""Plot Points tool — create a point layer from latitude/longitude columns in a tabular file."""

from __future__ import annotations

import os
import re

from qgis.core import (
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
)
from qgis.PyQt import uic
from qgis.PyQt.QtCore import QVariant, Qt
from qgis.PyQt.QtWidgets import (
    QDialog,
    QFileDialog,
    QHeaderView,
    QMessageBox,
    QTableWidgetItem,
)

from .geocode_layer import geocode_storage_directory
from .library_basemap_list import (
    populate_library_basemap_qlist_widget,
    wire_library_basemap_qlist_widget,
)
from .route_connections_import import (
    _FILE_FILTER,
    _guess_column,
    _split_headers_and_data,
    read_tabular_file,
)

_LAT_KEYS = (
    "lat",
    "latitude",
    "y",
    "ylat",
    "laty",
    "point_y",
    "pointy",
    "northing",
)
_LON_KEYS = (
    "lon",
    "lng",
    "long",
    "longitude",
    "x",
    "xlon",
    "lonx",
    "point_x",
    "pointx",
    "easting",
)

_PLOT_POINTS_GPKG_LAYER = "plotted_points"

FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "plot_points.ui")
)


def _parse_coordinate(value):
    """Parse a lat/lon cell; accepts plain numbers and comma decimals."""
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    text = text.replace(",", ".")
    # Strip degree symbols / trailing letters sometimes found in exports.
    text = re.sub(r"[°º\s]+", "", text)
    text = re.sub(r"[NnEeSsWw]$", "", text)
    try:
        return float(text)
    except ValueError:
        return None


def _safe_field_name(name, used):
    base = re.sub(r"[^A-Za-z0-9_]+", "_", str(name or "").strip()) or "field"
    if base[0].isdigit():
        base = "f_" + base
    candidate = base
    n = 2
    while candidate.lower() in used:
        candidate = "{}_{}".format(base, n)
        n += 1
    used.add(candidate.lower())
    return candidate


def _safe_file_stem(name: str) -> str:
    stem = re.sub(r"[^A-Za-z0-9_-]+", "_", str(name or "").strip()).strip("_")
    return stem or "plotted_points"


def _unique_gpkg_path(folder: str, display_name: str) -> str:
    stem = _safe_file_stem(display_name)
    path = os.path.join(folder, "{}.gpkg".format(stem))
    if not os.path.exists(path):
        return os.path.normpath(path)
    n = 2
    while True:
        path = os.path.join(folder, "{}_{}.gpkg".format(stem, n))
        if not os.path.exists(path):
            return os.path.normpath(path)
        n += 1


def _write_memory_layer_to_gpkg(memory_lyr: QgsVectorLayer, gpkg_path: str) -> bool:
    parent = os.path.dirname(gpkg_path)
    if parent:
        try:
            os.makedirs(parent, exist_ok=True)
        except OSError:
            return False
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = _PLOT_POINTS_GPKG_LAYER
    options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
    project = QgsProject.instance()
    ctx = project.transformContext() if project else None
    try:
        err, _warnings, _path, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
            memory_lyr, gpkg_path, ctx, options
        )
        if err[0] == QgsVectorFileWriter.NoError and os.path.isfile(gpkg_path):
            return True
    except Exception:
        pass
    try:
        err = QgsVectorFileWriter.writeAsVectorFormat(
            memory_lyr,
            gpkg_path,
            "UTF-8",
            memory_lyr.crs(),
            "GPKG",
        )
        if isinstance(err, tuple):
            return err[0] == QgsVectorFileWriter.NoError and os.path.isfile(gpkg_path)
        return err == QgsVectorFileWriter.NoError and os.path.isfile(gpkg_path)
    except Exception:
        return False


def _load_plot_points_gpkg(gpkg_path: str, display_name: str) -> QgsVectorLayer | None:
    if not gpkg_path or not os.path.isfile(gpkg_path):
        return None
    uri = "{}|layername={}".format(gpkg_path, _PLOT_POINTS_GPKG_LAYER)
    lyr = QgsVectorLayer(uri, display_name, "ogr")
    if lyr.isValid():
        return lyr
    lyr = QgsVectorLayer(gpkg_path, display_name, "ogr")
    if lyr.isValid():
        return lyr
    return None


class PlotPointsDialog(QDialog, FORM_CLASS):
    """Import lat/lon from Excel/CSV/text and add a point layer to the project."""

    def __init__(self, plugin, parent=None):
        mw = None
        if plugin is not None and getattr(plugin, "iface", None) is not None:
            mw = plugin.iface.mainWindow()
        super().__init__(mw if mw is not None else parent)
        self._plugin = plugin
        self.setupUi(self)
        try:
            self.setWindowFlags(self.windowFlags() | Qt.Tool)
        except Exception:
            pass

        self._raw_rows = []
        self._headers = []
        self._data_rows = []
        self._file_path = ""

        # Aliases matching former code-built widget names (logic below).
        self.path_edit = self.lineFilePath
        self.has_headers_check = self.chkHasHeaders
        self.lat_combo = self.cmbLatitude
        self.lon_combo = self.cmbLongitude
        self.layer_name_edit = self.lineLayerName
        self.preview = self.tblPreview

        self.preview.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.pbnBrowseLayer.clicked.connect(self._on_browse_layer)
        self.pbnBrowseFile.clicked.connect(self._on_browse)
        self.has_headers_check.toggled.connect(self._rebuild_columns)
        self.pbnAddLayer.setDefault(True)
        self.pbnAddLayer.clicked.connect(self._on_add_layer)
        self.pbnClose.clicked.connect(self.close)
        wire_library_basemap_qlist_widget(
            self.lstLibraryBasemaps, self._on_library_basemap_chosen
        )
        self._rebuild_columns()

    def showEvent(self, event):
        super().showEvent(event)
        self._refresh_library_basemap_list()

    def _library_folder(self):
        if self._plugin is None or not hasattr(self._plugin, "_library_folder"):
            return None
        try:
            return self._plugin._library_folder()
        except Exception:
            return None

    def _refresh_library_basemap_list(self):
        populate_library_basemap_qlist_widget(
            self.lstLibraryBasemaps, self._library_folder() or ""
        )

    def _on_library_basemap_chosen(self, path):
        if self._plugin is not None and hasattr(self._plugin, "loadBasemapFromFile"):
            self._plugin.loadBasemapFromFile(path, stack_by_geometry=True)

    def _on_browse_layer(self):
        path, _selected = QFileDialog.getOpenFileName(
            self,
            self.tr("Add layer"),
            "",
            self.tr(
                "Vector files (*.shp *.zip *.gpkg *.geojson *.json);;"
                "All files (*.*)"
            ),
        )
        path = (path or "").strip()
        if not path:
            return
        if self._plugin is not None and hasattr(self._plugin, "loadBasemapFromFile"):
            self._plugin.loadBasemapFromFile(path, stack_by_geometry=True)

    def _on_browse(self):
        path, _selected = QFileDialog.getOpenFileName(
            self,
            self.tr("Open Tabular File"),
            "",
            _FILE_FILTER,
        )
        if not path:
            return
        try:
            raw_rows = read_tabular_file(path)
        except ImportError as exc:
            QMessageBox.warning(self, self.tr("Plot Points"), str(exc))
            return
        except OSError as exc:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("Could not read file:\n{error}").format(error=exc),
            )
            return
        if not raw_rows:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("The selected file has no data rows."),
            )
            return

        self._file_path = path
        self._raw_rows = raw_rows
        self.path_edit.setText(path)
        base = os.path.splitext(os.path.basename(path))[0].strip()
        if base and not self.layer_name_edit.text().strip():
            self.layer_name_edit.setText(base)
        elif base and self.layer_name_edit.text().strip() in (
            "",
            self.tr("Plotted Points"),
            "Plotted Points",
        ):
            self.layer_name_edit.setText(base)
        self._rebuild_columns()

    def _rebuild_columns(self, *_args):
        has_headers = self.has_headers_check.isChecked()
        self._headers, self._data_rows = _split_headers_and_data(
            self._raw_rows, has_headers
        )
        prev_lat = self.lat_combo.currentText()
        prev_lon = self.lon_combo.currentText()

        self.lat_combo.blockSignals(True)
        self.lon_combo.blockSignals(True)
        try:
            self.lat_combo.clear()
            self.lon_combo.clear()
            for header in self._headers:
                self.lat_combo.addItem(header)
                self.lon_combo.addItem(header)
        finally:
            self.lat_combo.blockSignals(False)
            self.lon_combo.blockSignals(False)

        if self._headers:
            if has_headers:
                guessed_lat = _guess_column(self._headers, _LAT_KEYS)
                guessed_lon = _guess_column(self._headers, _LON_KEYS)
                if guessed_lat:
                    self.lat_combo.setCurrentText(guessed_lat)
                elif prev_lat and self.lat_combo.findText(prev_lat) >= 0:
                    self.lat_combo.setCurrentText(prev_lat)
                if guessed_lon:
                    self.lon_combo.setCurrentText(guessed_lon)
                elif prev_lon and self.lon_combo.findText(prev_lon) >= 0:
                    self.lon_combo.setCurrentText(prev_lon)
                else:
                    if self.lon_combo.count() >= 2 and not guessed_lon:
                        if guessed_lat and self.lat_combo.currentIndex() == 0:
                            self.lon_combo.setCurrentIndex(1)
            else:
                if self.lat_combo.count() >= 1:
                    self.lat_combo.setCurrentIndex(0)
                if self.lon_combo.count() >= 2:
                    self.lon_combo.setCurrentIndex(1)

        preview_rows = self._data_rows[:8]
        cols = len(self._headers)
        self.preview.clear()
        self.preview.setColumnCount(cols)
        self.preview.setHorizontalHeaderLabels(self._headers)
        self.preview.setRowCount(len(preview_rows))
        for row_idx, row in enumerate(preview_rows):
            for col_idx in range(cols):
                value = row[col_idx] if col_idx < len(row) else ""
                self.preview.setItem(row_idx, col_idx, QTableWidgetItem(value))

    def _on_add_layer(self):
        if not self._data_rows or not self._headers:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("Open a tabular file first."),
            )
            return

        lat_name = self.lat_combo.currentText()
        lon_name = self.lon_combo.currentText()
        if not lat_name or not lon_name:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("Choose latitude and longitude columns."),
            )
            return
        if lat_name == lon_name:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("Latitude and longitude must be different columns."),
            )
            return

        col_index = {name: idx for idx, name in enumerate(self._headers)}
        lat_idx = col_index.get(lat_name)
        lon_idx = col_index.get(lon_name)
        if lat_idx is None or lon_idx is None:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("Invalid column selection."),
            )
            return

        layer_name = (self.layer_name_edit.text() or "").strip() or self.tr(
            "Plotted Points"
        )

        used_names = set()
        field_specs = []
        for idx, header in enumerate(self._headers):
            fname = _safe_field_name(header, used_names)
            field_specs.append((idx, fname))

        uri = "Point?crs=EPSG:4326"
        memory_layer = QgsVectorLayer(uri, layer_name, "memory")
        if not memory_layer.isValid():
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("Could not create the point layer."),
            )
            return

        provider = memory_layer.dataProvider()
        provider.addAttributes(
            [QgsField(fname, QVariant.String) for _idx, fname in field_specs]
        )
        memory_layer.updateFields()

        features = []
        skipped = 0
        for row in self._data_rows:
            lat = _parse_coordinate(row[lat_idx] if lat_idx < len(row) else "")
            lon = _parse_coordinate(row[lon_idx] if lon_idx < len(row) else "")
            if lat is None or lon is None:
                skipped += 1
                continue
            if not (-90.0 <= lat <= 90.0) or not (-180.0 <= lon <= 180.0):
                skipped += 1
                continue
            feat = QgsFeature(memory_layer.fields())
            feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
            for src_idx, fname in field_specs:
                value = row[src_idx] if src_idx < len(row) else ""
                feat.setAttribute(fname, value)
            features.append(feat)

        if not features:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr(
                    "No valid latitude/longitude pairs were found in the selected columns."
                ),
            )
            return

        provider.addFeatures(features)
        memory_layer.updateExtents()

        folder = geocode_storage_directory(QgsProject.instance())
        if not folder:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr(
                    "Could not find a folder to save the GeoPackage. "
                    "Save the project first, or set a geocode staging folder in Settings."
                ),
            )
            return

        gpkg_path = _unique_gpkg_path(folder, layer_name)
        if not _write_memory_layer_to_gpkg(memory_layer, gpkg_path):
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("Could not write GeoPackage:\n{path}").format(path=gpkg_path),
            )
            return

        layer = _load_plot_points_gpkg(gpkg_path, layer_name)
        if layer is None:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr(
                    "GeoPackage was written but could not be loaded:\n{path}"
                ).format(path=gpkg_path),
            )
            return

        QgsProject.instance().addMapLayer(layer)
        try:
            QgsProject.instance().setDirty(True)
        except Exception:
            pass

        msg = self.tr(
            "Added {count} point(s) to layer “{name}”.\nSaved to:\n{path}"
        ).format(count=len(features), name=layer_name, path=gpkg_path)
        if skipped:
            msg += "\n" + self.tr(
                "Skipped {count} row(s) with invalid coordinates."
            ).format(count=skipped)
        QMessageBox.information(self, self.tr("Plot Points"), msg)

        iface = getattr(self._plugin, "iface", None) if self._plugin else None
        if iface is not None:
            try:
                iface.mapCanvas().refresh()
            except Exception:
                pass
