from qgis.PyQt.QtCore import QEvent, QRect, QRectF, QPoint, QSize, Qt, pyqtProperty
from qgis.PyQt.QtGui import QPainter, QPolygon, QColor, QPainterPath, QRegion, QPen, QPalette
from qgis.PyQt.QtWidgets import (
    QAbstractButton,
    QAbstractSpinBox,
    QHBoxLayout,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)
from qgis.gui import QgsColorButton
from qgis.PyQt.QtCore import QRect, QPoint
from qgis.PyQt.QtGui import QPainter, QPolygon, QPen

from .map_weaver_stylesheet import arrow_chrome_stylesheet


def _step_spin_quarter(spin, direction: int) -> bool:
    """
    Step a double spinbox by 0.25.

    If the current value is not on a 0.25 grid, snap to the next grid point in the
    spin direction (up → ceil to next quarter; down → floor to previous quarter).
    Returns True if handled.
    """
    if spin is None or direction == 0:
        return False
    try:
        import math

        step = 0.25
        val = float(spin.value())
        lo = float(spin.minimum())
        hi = float(spin.maximum())
        # Marker-size empty sentinel (-1): first up goes to 0.25; down stays empty.
        if val < -0.5:
            if direction > 0:
                spin.setValue(min(hi, step))
            return True
        nearest = round(val / step) * step
        on_grid = abs(val - nearest) < 1e-9
        if on_grid:
            new_val = val + (step if direction > 0 else -step)
        elif direction > 0:
            # Next quarter at or above val; if already past a grid by epsilon, still go up.
            new_val = math.ceil(val / step - 1e-12) * step
            if new_val <= val + 1e-12:
                new_val = val + step
                new_val = math.ceil(new_val / step - 1e-12) * step
        else:
            new_val = math.floor(val / step + 1e-12) * step
            if new_val >= val - 1e-12:
                new_val = val - step
                new_val = math.floor(new_val / step + 1e-12) * step
        new_val = max(lo, min(hi, new_val))
        spin.setValue(new_val)
        return True
    except Exception:
        return False


class CustomArrowColorButton(QgsColorButton):
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self._arrowAreaWidth = 30
        self._arrowColor = QColor("#000000")
        self._arrowSize = 8
        self._swatchCornerRadius = 5.0
        self._radius = 11
        self._dividerColor = QColor()
        self._frameBorderColor = QColor("#913a3a")
        self._outlineRadius = 11.0
        self._frameFillColor = QColor("#ffffff")

        # Ensure default behavior for color menu
        self.setShowMenu(True)
        self.setShowNoColor(True)
        #self.setStyleSheet("")
        #self.setStyleSheet(self.styleSheet() + """ 
            #border: 1px solid #00aa00;
            #border-radius: 13px;
            #background: white;
        #""")

        # Keep Designer objectName (plhQWcolorbutton, …); forcing one name breaks QSS targeting.

        # QgsColorButton often enables auto-fill — Qt paints a full RECTANGLE before paintEvent, which leaves
        # gray wedges outside our rounded pill. All chrome comes from paintEvent + qproperties.
        self.setAutoFillBackground(False)
        self.setAttribute(Qt.WA_StyledBackground, False)
        self.setAllowOpacity(True)
        self.clearMask()
        # Designer often sets native="true"; native-backed widgets frequently skip inherited QSS borders.
        try:
            self.setAttribute(Qt.WA_NativeWindow, False)
        except Exception:
            pass

        self.setAttribute(Qt.WA_NoSystemBackground, False)

        self._sync_arrow_disabled_property()
        self._apply_arrow_stylesheet()

    def _sync_arrow_disabled_property(self):
        """Drive “disabled chrome” QSS — :disabled does not match QgsColorButton reliably; use dynamic property."""
        self.setProperty("arrowChromeDisabled", "true" if not self.isEnabled() else "false")

    def _apply_arrow_stylesheet(self):
        frag = arrow_chrome_stylesheet()
        if frag:
            self.setStyleSheet(frag)

    def getDividerColor(self):
        return self._dividerColor

    def setDividerColor(self, color):
        qc = QColor(color)
        self._dividerColor = qc if qc.isValid() else QColor()
        self.update()

    dividerColor = pyqtProperty(
        QColor, fget=getDividerColor, fset=setDividerColor, designable=True
    )

    def getFrameBorderColor(self):
        return self._frameBorderColor

    def setFrameBorderColor(self, color):
        qc = QColor(color)
        # Invalid QColor from style polish must not revert to maroon (would defeat :disabled qproperty).
        if qc.isValid():
            self._frameBorderColor = qc
            self.update()

    frameBorderColor = pyqtProperty(
        QColor, fget=getFrameBorderColor, fset=setFrameBorderColor, designable=True
    )

    def getSwatchCornerRadius(self):
        return self._swatchCornerRadius

    def setSwatchCornerRadius(self, value):
        try:
            self._swatchCornerRadius = max(0.0, float(value))
        except (TypeError, ValueError):
            self._swatchCornerRadius = 28.0
        self.update()

    swatchCornerRadius = pyqtProperty(
        float, fget=getSwatchCornerRadius, fset=setSwatchCornerRadius, designable=True
    )

    def getOutlineRadius(self):
        return self._outlineRadius

    def setOutlineRadius(self, value):
        try:
            self._outlineRadius = float(value)
        except (TypeError, ValueError):
            self._outlineRadius = 23.0
        self.update()

    outlineRadius = pyqtProperty(
        float, fget=getOutlineRadius, fset=setOutlineRadius, designable=True
    )

    def getFrameFillColor(self):
        return self._frameFillColor

    def setFrameFillColor(self, color):
        qc = QColor(color)
        if qc.isValid():
            self._frameFillColor = qc
            self.update()

    frameFillColor = pyqtProperty(
        QColor, fget=getFrameFillColor, fset=setFrameFillColor, designable=True
    )

    def resizeEvent(self, event):
        # Keep rounded mask so widget shape is rounded
        r = QRectF(self.rect())
        path = QPainterPath()
        path.addRoundedRect(r, self._radius, self._radius)
        region = QRegion(path.toFillPolygon().toPolygon())
        #self.setMask(region)
        super().resizeEvent(event)

    def changeEvent(self, event):
        super().changeEvent(event)
        if event.type() == QEvent.EnabledChange:
            self._sync_arrow_disabled_property()
            self._apply_arrow_stylesheet()
            self._polishInheritedStyleSheet()
            self._polishInheritedStyleSheet()
            self.update()

    def _polishInheritedStyleSheet(self):
        st = self.style()
        if st is None:
            return
        try:
            st.unpolish(self)
            st.polish(self)
        except Exception:
            pass
        
    def polishEvent(self, event):
        super().polishEvent(event)
        self.update()

    def paintEvent(self, event):
        self.ensurePolished()
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Belt-and-suspenders: QgsColorButton / theme code can toggle auto-fill again at runtime.
        if self.autoFillBackground():
            self.setAutoFillBackground(False)

        w = self.width()
        h = self.height()
        arrow_w = self._arrowAreaWidth
        pal = self.palette()

        # Single geometry for fill + stroke so corners stay clean (PE_Widget + manual stroke used two radii).
        rr = min(float(self._outlineRadius), min(w, h) / 2.0 - 0.5)
        rr = max(1.0, rr)
        outer_rf = QRectF(self.rect())
        # Chrome from woolywidget.qss qproperty-frameFillColor / frameBorderColor / outlineRadius (enabled + :disabled).
        if self._frameFillColor.isValid():
            fill_col = self._frameFillColor
        elif self.isEnabled():
            fill_col = pal.color(QPalette.Window)
        else:
            fill_col = pal.color(QPalette.Disabled, QPalette.Button)
        painter.setPen(Qt.NoPen)
        painter.setBrush(fill_col)
        painter.drawRoundedRect(outer_rf, rr, rr)

        # Swatch clipped to inner rounded rect (parallel to outer arc).
        inset = 2.0
        inner_rf = QRectF(self.rect()).adjusted(inset, inset, -inset, -inset)
        rx_inner = max(1.0, rr - inset)
        clip_sw = QPainterPath()
        clip_sw.addRoundedRect(inner_rf, rx_inner, rx_inner)

        col = self.color()
        if col.isValid():
            swatch_rect = QRect(8, 4, w - arrow_w - 12, h - 8)
            painter.save()
            painter.setClipPath(clip_sw)
            painter.setPen(Qt.NoPen)
            swatch_col = QColor(col)
            if not self.isEnabled():
                swatch_col.setAlpha(min(swatch_col.alpha(), 130))
            painter.setBrush(swatch_col)
            sr = QRectF(swatch_rect)
            scr = float(self._swatchCornerRadius)
            if scr <= 0:
                painter.drawRect(swatch_rect)
            else:
                cap = max(1.0, min(sr.width(), sr.height()) / 2.0 - 0.5)
                painter.drawRoundedRect(sr, min(scr, cap), min(scr, cap))
            painter.restore()

        # divider — honor qproperty-dividerColor from QSS (:disabled rule updates _dividerColor)
        if self._dividerColor.isValid():
            divider_color = self._dividerColor
        elif self.isEnabled():
            divider_color = pal.mid().color().darker(110)
        else:
            divider_color = pal.color(QPalette.Disabled, QPalette.Mid)
        div_pen = QPen(divider_color, 1)
        div_pen.setCosmetic(True)
        painter.setPen(div_pen)
        margin = 4
        painter.drawLine(w - arrow_w, margin, w - arrow_w, h - margin)

        # arrow
        size = self._arrowSize
        x = w - arrow_w + (arrow_w - size) // 2
        y = (h - size) // 2
        arrow = QPolygon([
            QPoint(x, y),
            QPoint(x + size, y),
            QPoint(x + size // 2, y + size)
        ])

        arrow_fill = (
            self._arrowColor
            if self.isEnabled()
            else pal.color(QPalette.Disabled, QPalette.WindowText)
        )
        painter.setBrush(arrow_fill)
        painter.setPen(Qt.NoPen)
        painter.drawPolygon(arrow)

        # Outline last — same rr as fill so arcs coincide (no white wedges at corners).
        if self._frameBorderColor.isValid():
            bc = self._frameBorderColor
        elif self.isEnabled():
            bc = pal.color(QPalette.Mid).darker(115)
        else:
            bc = pal.color(QPalette.Disabled, QPalette.Mid)
        pen = QPen(bc, 1)
        pen.setCosmetic(True)
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        painter.drawRoundedRect(QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5), rr, rr)







    def mousePressEvent(self, event):
        w = self.width()
        h = self.height()
        arrow_rect = QRect(w - self._arrowAreaWidth, 0, self._arrowAreaWidth, h)
        if arrow_rect.contains(event.pos()):
            menu = self.menu()
            if menu:
                menu.exec_(self.mapToGlobal(event.pos()))
            return
        super().mousePressEvent(event)

    def showEvent(self, event):
        super().showEvent(event)

        self.setAutoFillBackground(False)
        self._sync_arrow_disabled_property()
        self._apply_arrow_stylesheet()
        self._polishInheritedStyleSheet()

        # Final runtime sanitization: clear text and accessible props
        try:
            self.setText("")
            self.setAccessibleName("")
            self.setAccessibleDescription("")
        except Exception:
            pass


class SpinArrowButton(QAbstractButton):
    """Filled triangle steppers — wide isoceles pair; up/down are exact vertical mirrors."""

    # Wide triangles (base wider than height), same bbox for both directions — avoids up/down size mismatch.
    _ARROW_BASE = 9
    _ARROW_HEIGHT = 4
    _ROW_PAD_V = 1
    # Extra vertical space inside the widget (hitbox) while keeping the glyph biased toward the sibling.
    _HIT_EXTRA_V = 8

    def __init__(self, direction="down", parent=None):
        super().__init__(parent)
        self._direction = direction if direction in ("up", "down") else "down"
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.NoFocus)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.setAutoFillBackground(False)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setFixedWidth(20)
        inner = self._ARROW_HEIGHT + 2 * self._ROW_PAD_V
        self.setFixedHeight(inner + self._HIT_EXTRA_V)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        w = self.width()
        h = self.height()
        pal = self.palette()
        bw = self._ARROW_BASE
        ah = self._ARROW_HEIGHT
        left = (w - bw) // 2
        pv = self._ROW_PAD_V
        if self._direction == "down":
            top = pv
        else:
            top = h - ah - pv
        if self._direction == "down":
            poly = QPolygon(
                [
                    QPoint(left, top),
                    QPoint(left + bw, top),
                    QPoint(left + bw // 2, top + ah),
                ]
            )
        else:
            poly = QPolygon(
                [
                    QPoint(left, top + ah),
                    QPoint(left + bw, top + ah),
                    QPoint(left + bw // 2, top),
                ]
            )
        arrow_fill = (
            QColor("#000000")
            if self.isEnabled()
            else pal.color(QPalette.Disabled, QPalette.WindowText)
        )
        painter.setBrush(arrow_fill)
        painter.setPen(Qt.NoPen)
        painter.drawPolygon(poly)

    def sizeHint(self):
        inner = self._ARROW_HEIGHT + 2 * self._ROW_PAD_V
        return QSize(20, inner + self._HIT_EXTRA_V)


class ArrowStepColumn(QWidget):
    """Column with stretches for vertical centering; stretch areas are this widget's surface so clicks count."""

    def __init__(self, pill, parent=None):
        super().__init__(parent)
        self._pill = pill
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.MinimumExpanding)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and self._pill is not None:
            y = event.pos().y()
            if y < self.height() / 2.0:
                self._pill._on_step_up()
            else:
                self._pill._on_step_down()
            event.accept()
            return
        super().mousePressEvent(event)


class PillDoubleSpinBox(QWidget):
    """Rounded chrome + painted arrow buttons; inner spin uses QAbstractSpinBox.NoButtons."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._spin = None
        self._btn_up = SpinArrowButton("up", self)
        self._btn_down = SpinArrowButton("down", self)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setAutoFillBackground(True)
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        self._btn_up.clicked.connect(self._on_step_up)
        self._btn_down.clicked.connect(self._on_step_down)

    def embed_spin(self, spin):
        if spin is None:
            return
        self._spin = spin
        spin.setParent(self)
        spin.setButtonSymbols(QAbstractSpinBox.NoButtons)
        spin.setFrame(False)
        spin.installEventFilter(self)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(spin, 1)
        self._arrow_col = ArrowStepColumn(self, self)
        self._arrow_col.setFixedWidth(20)
        col = QVBoxLayout(self._arrow_col)
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(2)
        col.addStretch(1)
        self._btn_up.setParent(self._arrow_col)
        self._btn_down.setParent(self._arrow_col)
        col.addWidget(self._btn_up, 0, Qt.AlignHCenter)
        col.addWidget(self._btn_down, 0, Qt.AlignHCenter)
        col.addStretch(1)
        lay.addWidget(self._arrow_col, 0)
        self.setFocusProxy(spin)
        self._sync_arrow_enabled()
        self._configure_quarter_steps(spin)
        le = spin.lineEdit() if hasattr(spin, "lineEdit") else None
        if le is not None:
            le.installEventFilter(self)

    @staticmethod
    def _configure_quarter_steps(spin):
        """Weight / mark-size pills: 0.25 step, snap off-grid values to nearest quarter."""
        if spin is None:
            return
        try:
            spin.setSingleStep(0.25)
            if hasattr(spin, "setDecimals") and int(spin.decimals()) < 2:
                spin.setDecimals(2)
        except Exception:
            pass
        # Wheel / keyboard stepBy — snap like the painted arrows.
        if getattr(spin, "_map_weaver_quarter_step", False):
            return

        def _step_by(steps):
            if not steps:
                return
            direction = 1 if int(steps) > 0 else -1
            for _ in range(abs(int(steps))):
                if not _step_spin_quarter(spin, direction):
                    break

        try:
            spin.stepBy = _step_by
            spin._map_weaver_quarter_step = True
        except Exception:
            pass

    def blockSignals(self, b):
        if self._spin is not None:
            return self._spin.blockSignals(b)
        return super().blockSignals(b)

    def eventFilter(self, obj, event):
        le = None
        if self._spin is not None and hasattr(self._spin, "lineEdit"):
            try:
                le = self._spin.lineEdit()
            except Exception:
                le = None
        is_spin_or_editor = self._spin is not None and (
            obj is self._spin or (le is not None and obj is le)
        )
        if self._spin is not None and event.type() == QEvent.MouseButtonPress and is_spin_or_editor:
            self._clear_other_pills_selection_and_focus()
            self._spin.setFocus(Qt.MouseFocusReason)
        if self._spin is not None and event.type() == QEvent.FocusIn and is_spin_or_editor:
            # Tab / programmatic focus: sibling can still show selected text without mouse press.
            self._clear_other_pills_selection_and_focus()
        if obj is self._spin and event.type() == QEvent.EnabledChange:
            self._sync_arrow_enabled()
        return super().eventFilter(obj, event)

    def mousePressEvent(self, event):
        """Clicks on pill chrome (outside inner spin) still take focus and clear other pills' selection."""
        self._clear_other_pills_selection_and_focus()
        if self._spin is not None:
            self._spin.setFocus(Qt.MouseFocusReason)
        super().mousePressEvent(event)

    def _pill_peers(self):
        """Ancestors until we find a subtree with ≥2 pills (Weight + Mark Size live in different layout cells)."""
        w = self.parentWidget()
        for _ in range(30):
            if w is None:
                break
            pills = w.findChildren(PillDoubleSpinBox)
            if len(pills) >= 2 and self in pills:
                return pills
            w = w.parentWidget()
        win = self.window()
        return win.findChildren(PillDoubleSpinBox) if win is not None else []

    def _clear_other_pills_selection_and_focus(self):
        for w in self._pill_peers():
            if w is self or getattr(w, "_spin", None) is None:
                continue
            oth_spin = w._spin
            oth_spin.clearFocus()
            if not hasattr(oth_spin, "lineEdit"):
                continue
            try:
                oth_le = oth_spin.lineEdit()
            except Exception:
                oth_le = None
            if oth_le is None:
                continue
            oth_le.deselect()
            c = oth_le.cursorPosition()
            oth_le.setSelection(c, c)

    def _sync_arrow_enabled(self):
        s = self._spin
        if s is None:
            return
        en = s.isEnabled() and not s.isReadOnly()
        self._btn_up.setEnabled(en)
        self._btn_down.setEnabled(en)

    def _on_step_up(self):
        if self._spin is not None:
            self._clear_other_pills_selection_and_focus()
            self._spin.setFocus(Qt.MouseFocusReason)
            if not _step_spin_quarter(self._spin, +1):
                self._spin.stepUp()

    def _on_step_down(self):
        if self._spin is not None:
            self._clear_other_pills_selection_and_focus()
            self._spin.setFocus(Qt.MouseFocusReason)
            if not _step_spin_quarter(self._spin, -1):
                self._spin.stepDown()

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        if self._spin is None:
            raise AttributeError(name)
        return getattr(self._spin, name)

