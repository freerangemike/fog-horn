# -*- coding: utf-8 -*-
"""Save Project — edit project name / author, then save the QGIS project."""

import os

from qgis.core import QgsProject
from qgis.PyQt import uic
from qgis.PyQt.QtCore import QFileInfo
from qgis.PyQt.QtWidgets import QDialog, QFileDialog, QMessageBox

from .project_save_as_copy import save_project_as_complete_duplicate
from .route_arcs_project_blob import MAP_WEAVER_PROJECT_SCOPE, prepare_project_for_disk_write

FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), "save_project.ui"))


class SaveProjectDialog(QDialog, FORM_CLASS):
    """Modal dialog: Project name + Author, then Save / Save As."""

    def __init__(self, parent=None, plugin=None, save_as: bool = False):
        super().__init__(parent)
        self._plugin = plugin
        self._save_as = bool(save_as)
        self.setupUi(self)
        if self._save_as:
            self.setWindowTitle(self.tr("Save Project As"))
        self.lineProjectName.setPlaceholderText("e.g. Acme Corp Q2 Locations")
        self.lineAuthor.setPlaceholderText("e.g. Jane Smith")
        self._load_identity_from_project()
        # Designer connects accept(); we handle save ourselves.
        try:
            self.buttonBox.accepted.disconnect()
        except (TypeError, RuntimeError):
            pass
        self.buttonBox.accepted.connect(self._on_save_clicked)

    def _load_identity_from_project(self):
        from . import map_weaver as _mw

        name, author = _mw._mapestry_project_title_meta()
        self.lineProjectName.setText(name or "")
        self.lineAuthor.setText(author or "")

    def _persist_identity(self):
        from . import map_weaver as _mw

        proj = QgsProject.instance()
        name = self.lineProjectName.text().strip()
        author = self.lineAuthor.text().strip()
        proj.writeEntry(MAP_WEAVER_PROJECT_SCOPE, _mw.MAPESTRY_PROJECT_FLAG_ENTRY, "1")
        proj.writeEntry(MAP_WEAVER_PROJECT_SCOPE, _mw.MAPESTRY_PROJECT_NAME_ENTRY, name)
        proj.writeEntry(MAP_WEAVER_PROJECT_SCOPE, _mw.MAPESTRY_PROJECT_AUTHOR_ENTRY, author)

    def _suggested_save_path(self) -> str:
        proj = QgsProject.instance()
        start_dir = ""
        try:
            path = (proj.absoluteFilePath() or proj.fileName() or "").strip()
            if path:
                start_dir = os.path.dirname(os.path.abspath(path))
        except Exception:
            start_dir = ""
        if not start_dir:
            try:
                start_dir = proj.homePath() or ""
            except Exception:
                start_dir = ""
        if not start_dir:
            start_dir = os.path.expanduser("~")
        suggested = self.lineProjectName.text().strip() or "project"
        safe = "".join(
            c if c.isalnum() or c in "-_" else "_" for c in suggested
        ).strip("_")
        return os.path.join(start_dir, (safe or "project") + ".qgz")

    def _pick_save_path(self, title: str) -> str | None:
        path, _ = QFileDialog.getSaveFileName(
            self,
            title,
            self._suggested_save_path(),
            self.tr("QGIS Projects (*.qgz *.qgs);;All files (*.*)"),
        )
        path = (path or "").strip()
        if not path:
            return None
        low = path.lower()
        if not low.endswith(".qgz") and not low.endswith(".qgs"):
            path += ".qgz"
        return path

    def _write_project(self) -> bool:
        proj = QgsProject.instance()
        path = (proj.fileName() or "").strip()
        if not path:
            path = self._pick_save_path(self.tr("Save Project"))
            if not path:
                return False

        prepare_project_for_disk_write(proj, save_path=path)
        try:
            if (proj.fileName() or "").strip() == path:
                ok = proj.write()
            else:
                ok = proj.write(path)
        except TypeError:
            ok = proj.write(QFileInfo(path))
        if not ok:
            QMessageBox.warning(
                self,
                self.windowTitle(),
                self.tr("Could not save the project."),
            )
        return bool(ok)

    def _save_as_complete_copy(self) -> bool:
        path = self._pick_save_path(self.tr("Save Project As"))
        if not path:
            return False
        ok, message = save_project_as_complete_duplicate(QgsProject.instance(), path)
        if not ok:
            QMessageBox.warning(
                self.parent() or self,
                self.tr("Save Project As"),
                message or self.tr("Could not save the project."),
            )
            return False
        if message:
            QMessageBox.warning(
                self.parent() or self,
                self.tr("Save Project As"),
                message,
            )
        if self._plugin is not None:
            try:
                self._plugin.syncDockMapestryMeta()
            except Exception:
                pass
        return True

    def _on_save_clicked(self):
        if not self.lineProjectName.text().strip():
            QMessageBox.warning(
                self,
                self.windowTitle(),
                self.tr("Enter a project name before saving."),
            )
            return
        self._persist_identity()
        if self._plugin is not None:
            try:
                self._plugin.syncDockMapestryMeta()
            except Exception:
                pass
        if self._save_as:
            self.accept()
            self._save_as_complete_copy()
            return
        if not self._write_project():
            return
        self.accept()
