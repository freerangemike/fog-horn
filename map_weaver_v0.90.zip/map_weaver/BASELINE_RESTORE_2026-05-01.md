# Baseline Restore - 2026-05-01 (restore point 2 of 2)

This file marks the New Map dialog refactor: styling lives in QSS only (`new_map_dialog.qss`), with no custom paint or masks in `new_map_dialog.py`.

**Other restore point:** `BASELINE_RESTORE_2026-04-30.md` (globe / dock baseline).

## Baseline definition

- Frameless dialog shell; appearance driven solely by the loaded stylesheet.
- Primary button and chrome visible correctly on Windows (flat-style controls + QSS).

## Intent for future work

- Prefer extending `new_map_dialog.qss` for visual changes rather than painting or inline styles in Python.
- Keep dialog behavior (segment toggle, cards, filename preview) unchanged unless intentionally redesigned.

## Files to treat as baseline-critical for this checkpoint

- `new_map_dialog.py`
- `new_map_dialog.qss`
- `start_dialog.ui`
