# -*- coding: utf-8 -*-
"""Route Connections arc sync without closing the dialog (vendor ``sync_arcs`` calls ``dialog.close()``)."""

from __future__ import annotations

import math
import re

from qgis.PyQt.QtCore import Qt
from qgis.core import QgsFeature, QgsGeometry, QgsPointXY, QgsWkbTypes

MAX_ROUTE_LINES = 20
_CONN_CHILD_RE = re.compile(r"^(.*):(\d+)$")


def clamp_line_count(value, default: int = 1) -> int:
    try:
        n = int(float(str(value).strip()))
    except (TypeError, ValueError):
        n = default
    if n < 1:
        return 1
    if n > MAX_ROUTE_LINES:
        return MAX_ROUTE_LINES
    return n


def parse_conn_id_base_index(conn_id) -> tuple[str | None, int]:
    """Split ``base`` / ``base:i`` ConnIDs. Legacy plain UUIDs are index 0."""
    text = _coerce_conn_id(conn_id)
    if not text:
        return None, 0
    match = _CONN_CHILD_RE.match(text)
    if match and match.group(1):
        return match.group(1), int(match.group(2))
    return text, 0


def child_conn_id(base_conn_id: str, index: int) -> str:
    return f"{base_conn_id}:{int(index)}"


def child_conn_ids(base_conn_id: str, line_count: int) -> list[str]:
    n = clamp_line_count(line_count)
    return [child_conn_id(base_conn_id, i) for i in range(n)]


def pair_key(start_text, end_text) -> str:
    from .route_connections_import import normalize_match_text

    return "{}||{}".format(
        normalize_match_text(start_text),
        normalize_match_text(end_text),
    )


def _coerce_feature_id(value):
    if value is None:
        return None
    try:
        from qgis.PyQt.QtCore import QVariant

        if isinstance(value, QVariant):
            if not value.isValid() or value.isNull():
                return None
            value = value.value()
    except Exception:
        pass
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return value


def _coerce_conn_id(value):
    if value is None:
        return None
    try:
        from qgis.PyQt.QtCore import QVariant

        if isinstance(value, QVariant):
            if not value.isValid() or value.isNull():
                return None
            value = value.value()
    except Exception:
        pass
    text = "" if value is None else str(value).strip()
    return text or None


def _feature_by_id(layer, fid):
    fid = _coerce_feature_id(fid)
    if layer is None or fid is None:
        return None
    try:
        feat = layer.getFeature(fid)
        if feat is not None and feat.isValid():
            return feat
    except Exception:
        pass
    try:
        for feat in layer.getFeatures():
            try:
                if _coerce_feature_id(feat.id()) == fid:
                    return feat
            except Exception:
                continue
    except Exception:
        pass
    return None


def _point_xy_from_feature(feat):
    if feat is None or not feat.isValid():
        return None
    geom = feat.geometry()
    if geom is None or geom.isEmpty():
        return None
    try:
        if geom.isMultipart():
            multi = geom.asMultiPoint()
            if multi:
                return multi[0]
        return geom.asPoint()
    except Exception:
        pass
    try:
        c = geom.centroid()
        if c and not c.isEmpty():
            return c.asPoint()
    except Exception:
        pass
    return None


def _curvature_for_lane(lane_index: int, lane_count: int) -> float:
    """Spread parallel bows so duplicate / multi-line routes stay visible."""
    n = max(1, int(lane_count))
    i = int(lane_index)
    if n <= 1:
        return 0.3
    center = (n - 1) / 2.0
    lane = i - center
    return 0.3 + lane * 0.25


def _arc_points_for_lane(host, p1, p2, obstacle_points, lane_index, lane_count):
    n = max(1, int(lane_count))
    if n <= 1:
        points = host.get_best_bezier_curve(p1, p2, obstacle_points, tolerance=0.5)
        if points:
            return points
        return [QgsPointXY(p1), QgsPointXY(p2)]

    curvature = _curvature_for_lane(lane_index, n)
    try:
        points = host.get_bezier_curve(p1, p2, curvature=curvature)
    except Exception:
        points = None
    if points:
        return points
    # Fallback: slight perpendicular offset of a straight segment.
    dx = p2.x() - p1.x()
    dy = p2.y() - p1.y()
    dist = math.hypot(dx, dy)
    if dist <= 0:
        return [QgsPointXY(p1), QgsPointXY(p2)]
    nx, ny = -dy / dist, dx / dist
    center = (n - 1) / 2.0
    offset = (lane_index - center) * (dist * 0.04)
    mid = QgsPointXY(
        (p1.x() + p2.x()) / 2.0 + nx * offset,
        (p1.y() + p2.y()) / 2.0 + ny * offset,
    )
    return [QgsPointXY(p1), mid, QgsPointXY(p2)]


def draw_route_arc(
    host,
    start_fid,
    end_fid,
    start_text,
    end_text,
    conn_id,
    source_layer,
    arc_layer,
    lane_index: int = 0,
    lane_count: int = 1,
):
    """Draw one connection arc; tolerant of Qt UserRole / geometry quirks."""
    start_fid = _coerce_feature_id(start_fid)
    end_fid = _coerce_feature_id(end_fid)
    conn_id = _coerce_conn_id(conn_id)
    if start_fid is None or end_fid is None or not conn_id:
        return False

    start_feat = _feature_by_id(source_layer, start_fid)
    end_feat = _feature_by_id(source_layer, end_fid)
    if start_feat is None or end_feat is None:
        return False

    p1 = _point_xy_from_feature(start_feat)
    p2 = _point_xy_from_feature(end_feat)
    if p1 is None or p2 is None:
        return False

    obstacle_points = []
    for feat in source_layer.getFeatures():
        fid = _coerce_feature_id(feat.id())
        if fid in (start_fid, end_fid):
            continue
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            continue
        if geom.type() != QgsWkbTypes.PointGeometry:
            continue
        pt = _point_xy_from_feature(feat)
        if pt is not None:
            obstacle_points.append(pt)

    arc_points = _arc_points_for_lane(
        host, p1, p2, obstacle_points, lane_index, lane_count
    )
    line_geom = QgsGeometry.fromPolylineXY(arc_points)
    new_feat = QgsFeature(arc_layer.fields())
    new_feat.setGeometry(line_geom)
    new_feat.setAttribute("Start", start_text)
    new_feat.setAttribute("End", end_text)
    new_feat.setAttribute("ConnID", conn_id)

    ok = arc_layer.addFeature(new_feat)
    return bool(ok)


def _read_table_line_count(dlg, row: int) -> int:
    table = dlg.mConnectionsTable
    if table.columnCount() >= 3:
        item = table.item(row, 2)
        if item is not None:
            return clamp_line_count(item.text(), default=1)
    return 1


def sync_route_arcs_without_close(host):
    """
    Same behavior as ``vendor.route_connections.route_connections.RouteConnections.sync_arcs``,
    but does **not** close the dialog so users can add more routes and Apply again.

    Each table row may request multiple lines (Lines column). Duplicate Start/End
    pairs across rows are also drawn as separated parallel arcs.
    """
    self = host
    dlg = self.dialog
    if dlg is None:
        return
    source_layer = dlg.current_layer
    if not source_layer:
        return

    # Snapshot the connections table before get_arc_layer / layer-create side
    # effects. Creating Route Arcs can emit layersAdded and (previously) rebuild
    # the dialog, wiping the table before we read it.
    pending = []
    table_bases = set()
    expected_child_ids = set()
    row_count = dlg.mConnectionsTable.rowCount()
    for row in range(row_count):
        start_item = dlg.mConnectionsTable.item(row, 0)
        end_item = dlg.mConnectionsTable.item(row, 1)
        if start_item is None or end_item is None:
            continue
        base_id = _coerce_conn_id(start_item.data(Qt.UserRole + 1))
        if not base_id:
            continue
        line_count = _read_table_line_count(dlg, row)
        table_bases.add(base_id)
        for child in child_conn_ids(base_id, line_count):
            expected_child_ids.add(child)
        pending.append(
            {
                "start_fid": start_item.data(Qt.UserRole),
                "end_fid": end_item.data(Qt.UserRole),
                "start_text": start_item.text(),
                "end_text": end_item.text(),
                "base_id": base_id,
                "line_count": line_count,
                "pair": pair_key(start_item.text(), end_item.text()),
            }
        )

    # Expand rows into draw jobs, then assign global lane slots per Start/End pair
    # so duplicate pairs and multi-line rows share one separated fan.
    draw_jobs = []
    for item in pending:
        for local_i in range(item["line_count"]):
            draw_jobs.append(
                {
                    **item,
                    "child_id": child_conn_id(item["base_id"], local_i),
                    "local_index": local_i,
                }
            )

    pair_groups = {}
    for job in draw_jobs:
        pair_groups.setdefault(job["pair"], []).append(job)
    for jobs in pair_groups.values():
        n = len(jobs)
        for lane_i, job in enumerate(jobs):
            job["lane_index"] = lane_i
            job["lane_count"] = n

    dlg._suppress_layer_list_refresh = True
    try:
        arc_layer = self.get_arc_layer(source_layer)
        if arc_layer is None:
            return
        try:
            from .route_arcs_layer import (
                mark_route_arcs_layer,
                set_route_arcs_source_layer_id,
            )

            mark_route_arcs_layer(arc_layer)
            set_route_arcs_source_layer_id(arc_layer, str(source_layer.id()))
        except Exception:
            pass
        if not arc_layer.isEditable():
            if not arc_layer.startEditing():
                return

        map_uuids = set()
        features_to_delete = []
        for feat in arc_layer.getFeatures():
            conn_id = _coerce_conn_id(feat.attribute("ConnID"))
            if not conn_id:
                features_to_delete.append(feat.id())
                continue
            map_uuids.add(conn_id)
            base, _idx = parse_conn_id_base_index(conn_id)
            keep = False
            if conn_id in expected_child_ids:
                keep = True
            elif base in table_bases and conn_id == base and child_conn_id(base, 0) in expected_child_ids:
                # Legacy single-arc ConnID (no ":index") — keep only when Lines==1
                # and treat as child 0 after we may replace it.
                keep = False
            if not keep:
                features_to_delete.append(feat.id())

        if features_to_delete:
            arc_layer.deleteFeatures(features_to_delete)
            for fid in features_to_delete:
                # map_uuids may still list deleted ids' conn strings; rebuild below
                pass
            map_uuids = set()
            for feat in arc_layer.getFeatures():
                cid = _coerce_conn_id(feat.attribute("ConnID"))
                if cid:
                    map_uuids.add(cid)

        drawn = 0
        for job in draw_jobs:
            child_id = job["child_id"]
            if child_id in map_uuids:
                continue
            if draw_route_arc(
                self,
                job["start_fid"],
                job["end_fid"],
                job["start_text"],
                job["end_text"],
                child_id,
                source_layer,
                arc_layer,
                lane_index=job["lane_index"],
                lane_count=job["lane_count"],
            ):
                drawn += 1
                map_uuids.add(child_id)

        try:
            arc_layer.updateExtents()
        except Exception:
            pass
        try:
            if arc_layer.isEditable() and arc_layer.commitChanges():
                arc_layer.startEditing()
        except Exception:
            try:
                if not arc_layer.isEditable():
                    arc_layer.startEditing()
            except Exception:
                pass

        try:
            from .route_arcs_layer import ensure_route_arcs_layer_persisted

            arc_layer = ensure_route_arcs_layer_persisted(arc_layer)
        except Exception:
            pass

        try:
            arc_layer.triggerRepaint()
        except Exception:
            pass
        try:
            canvas = getattr(getattr(self, "iface", None), "mapCanvas", lambda: None)()
            if canvas is not None:
                canvas.refresh()
        except Exception:
            pass

        return drawn
    finally:
        try:
            dlg._suppress_layer_list_refresh = False
        except Exception:
            pass
