from qgis.PyQt.QtWidgets import QCheckBox
from qgis.PyQt.QtGui import QPainter, QPen, QBrush, QColor
from qgis.PyQt.QtCore import QRect, QSize, QPointF, Qt

class CheckBoxWhiteMark(QCheckBox):
    BOX_SIZE = 30   # <‑‑‑ change this to control height AND width

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # This is the missing piece: force the widget to be tall enough
        self.setMinimumHeight(self.BOX_SIZE + 4)
        self.setMaximumHeight(self.BOX_SIZE + 4)

    def sizeHint(self):
        text_w = self.fontMetrics().width(self.text())
        return QSize(text_w + self.BOX_SIZE + 8, self.BOX_SIZE + 4)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        box = self.BOX_SIZE
        y = (self.height() - box) // 2
        box_rect = QRect(0, y, box, box)

        # draw red box
        painter.setBrush(QBrush(QColor("#a24146")))
        painter.setPen(QPen(QColor("#a24146")))
        painter.drawRect(box_rect)

        # draw white tick
        if self.isChecked():
            painter.setPen(QPen(QColor("white"), 3))
            p1 = QPointF(box_rect.left() + box*0.2, box_rect.top() + box*0.55)
            p2 = QPointF(box_rect.left() + box*0.45, box_rect.bottom() - box*0.25)
            p3 = QPointF(box_rect.right() - box*0.2, box_rect.top() + box*0.3)
            painter.drawLine(p1, p2)
            painter.drawLine(p2, p3)

        # draw text
        text_rect = QRect(box + 8, 0, self.width() - (box + 8), self.height())
        painter.setPen(self.palette().color(self.foregroundRole()))
        painter.drawText(text_rect, Qt.AlignVCenter | Qt.AlignLeft, self.text())
