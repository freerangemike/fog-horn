# -*- coding: utf-8 -*-
"""Populate / wire Library basemap file lists (dock Tools tab and point_map dialog)."""

from __future__ import annotations

import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QListWidget, QListWidgetItem


def library_basemap_is_listable(filename: str) -> bool:
    low = (filename or "").lower()
    return (
        low.endswith(".shp")
        or low.endswith(".zip")
        or low.endswith(".gpkg")
        or low.endswith(".geojson")
    )


def collect_library_basemap_entries(
    library_dir: str,
) -> tuple[list[tuple[str, str]] | None, int, str | None]:
    """
    Scan ``library_dir`` for OGR-loadable vector files.

    Returns (entries, skipped_other_count, hint_text_or_none).
    ``entries`` is None if the directory could not be scanned (OSError).
    Each entry is (display_name, absolute_path).
    """
    if not library_dir or not os.path.isdir(library_dir):
        return [], 0, None

    entries = []
    skipped_files = 0
    try:
        for root, _dirs, files in os.walk(library_dir):
            for name in files:
                full = os.path.normpath(os.path.join(root, name))
                if not os.path.isfile(full):
                    continue
                if library_basemap_is_listable(name):
                    rel_disp = os.path.relpath(full, library_dir).replace("\\", "/")
                    entries.append((rel_disp, full))
                else:
                    skipped_files += 1
    except OSError:
        return None, skipped_files, None

    entries.sort(key=lambda t: t[0].lower())
    if entries:
        return entries, skipped_files, None

    hint_text = (
        "(No datasets in Library folder)\n\n"
        "This list shows files OGR can load as vectors:\n"
        ".shp, .zip (shapefile archive), .gpkg, .geojson.\n\n"
        "Put those files here:\n{}\n"
    ).format(library_dir)
    if skipped_files:
        hint_text += "\n{} other file(s) here were skipped.".format(skipped_files)
    return [], skipped_files, hint_text


def populate_library_basemap_qlist_widget(list_widget: QListWidget, library_dir: str) -> int:
    """Fill a QListWidget like the dock Library tab. Returns row count."""
    entries, _skipped, hint_text = collect_library_basemap_entries(library_dir)
    list_widget.clear()
    if entries:
        for display, full in entries:
            it = QListWidgetItem(display)
            it.setData(Qt.UserRole, full)
            it.setToolTip(full)
            list_widget.addItem(it)
    elif hint_text:
        it = QListWidgetItem(hint_text)
        it.setToolTip(hint_text)
        it.setFlags(Qt.ItemIsEnabled)
        list_widget.addItem(it)
    return int(list_widget.count())


def wire_library_basemap_qlist_widget(list_widget: QListWidget, on_path_chosen) -> None:
    """Double-click loads via callback(absolute_path). Idempotent per widget instance."""

    wired = getattr(list_widget, "_mw_library_double_click_wired", False)
    if wired:
        return

    def _on_item(item):
        if item is None:
            return
        path = item.data(Qt.UserRole)
        if path:
            on_path_chosen(str(path))

    list_widget.itemDoubleClicked.connect(_on_item)
    list_widget._mw_library_double_click_wired = True
