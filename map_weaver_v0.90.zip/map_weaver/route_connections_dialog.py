import os
import uuid

from qgis.PyQt import uic
from qgis.PyQt.QtCore import Qt, QPoint, QSize, QEvent, pyqtSignal
from qgis.PyQt.QtGui import QCursor, QFont
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QFileDialog,
    QFrame,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)
from qgis.core import QgsProject, QgsVectorLayer, QgsWkbTypes
from qgis.gui import QgsMapToolIdentify, QgsMapToolPan

from .library_basemap_list import (
    populate_library_basemap_qlist_widget,
    wire_library_basemap_qlist_widget,
)
from .route_connections_fields import (
    default_visible_field_names,
    preferred_display_field_name,
)
from .route_connections_import import RouteConnectionsImporter, normalize_match_text
from .route_connections_sync import (
    clamp_line_count,
    parse_conn_id_base_index,
)

FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "route_connections_dialog_base.ui")
)


class _RoutePointPickMapTool(QgsMapToolIdentify):
    """Left-click → start point; right-click → end point."""

    featurePicked = pyqtSignal(object, str)

    def __init__(self, canvas, layer):
        super().__init__(canvas)
        self._layer = layer
        try:
            self.setCursor(QCursor(Qt.CrossCursor))
        except Exception:
            pass

    def canvasReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            role = "start"
        elif event.button() == Qt.RightButton:
            role = "end"
        else:
            return
        results = []
        try:
            results = self.identify(
                event.x(),
                event.y(),
                [self._layer],
                QgsMapToolIdentify.TopDownAll,
            )
        except TypeError:
            try:
                results = self.identify(
                    event.x(),
                    event.y(),
                    QgsMapToolIdentify.TopDownStopAtFirst,
                    [self._layer],
                    QgsMapToolIdentify.VectorLayer,
                )
            except Exception:
                results = []
        except Exception:
            results = []
        if not results:
            return
        feature = None
        try:
            feature = results[0].mFeature
        except Exception:
            try:
                feature = results[0].feature()
            except Exception:
                feature = None
        if feature is None:
            return
        self.featurePicked.emit(feature, role)

    def canvasPressEvent(self, event):
        # Swallow right-press so the canvas context menu does not appear.
        if event.button() in (Qt.LeftButton, Qt.RightButton):
            return
        super().canvasPressEvent(event)


class _ColumnsPickerPopup(QFrame):
    """Scrollable checkable field list with a filter box."""

    def __init__(self, parent=None):
        super().__init__(parent, Qt.Popup)
        self.setFrameShape(QFrame.StyledPanel)
        self.setMinimumWidth(260)
        self.setMaximumHeight(360)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(6)

        self.filter_edit = QLineEdit(self)
        self.filter_edit.setPlaceholderText(self.tr("Filter fields…"))
        self.filter_edit.setClearButtonEnabled(True)
        lay.addWidget(self.filter_edit)

        self.list_widget = QListWidget(self)
        self.list_widget.setUniformItemSizes(True)
        lay.addWidget(self.list_widget, 1)

        self.filter_edit.textChanged.connect(self._apply_filter)

    def set_fields(self, field_names, checked_names):
        self.list_widget.clear()
        checked = set(checked_names or [])
        for name in field_names:
            item = QListWidgetItem(name)
            item.setFlags(
                Qt.ItemIsEnabled | Qt.ItemIsUserCheckable | Qt.ItemIsSelectable
            )
            item.setCheckState(Qt.Checked if name in checked else Qt.Unchecked)
            self.list_widget.addItem(item)
        self.filter_edit.clear()
        self._apply_filter("")

    def checked_field_names(self):
        out = []
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item is not None and item.checkState() == Qt.Checked:
                out.append(item.text())
        return out

    def _apply_filter(self, text):
        needle = (text or "").strip().lower()
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item is None:
                continue
            visible = (not needle) or (needle in item.text().lower())
            item.setHidden(not visible)

    def sizeHint(self):
        return QSize(280, 300)


class RouteConnectionsDialog(QDialog, FORM_CLASS):
    def __init__(self, plugin, parent=None):
        mw = None
        if plugin is not None and getattr(plugin, "iface", None) is not None:
            mw = plugin.iface.mainWindow()
        super(RouteConnectionsDialog, self).__init__(mw if mw is not None else parent)
        self.plugin = plugin
        self.iface = plugin.iface
        self.setupUi(self)
        self._apply_dialog_font_bump()
        try:
            self.setWindowFlags(self.windowFlags() | Qt.Tool)
        except Exception:
            pass

        self.current_layer = None
        self._visible_field_names = []
        self._columns_popup = None
        self.map_tool = None

        self.mLayerComboBox.currentIndexChanged.connect(self.on_layer_changed)
        self.mDataPreviewTable.setContextMenuPolicy(Qt.NoContextMenu)
        self.mDataPreviewTable.viewport().installEventFilter(self)
        self.mAddButton.clicked.connect(self.add_connection)
        self.mRemoveButton.clicked.connect(self.remove_connection)
        self.mSelectFromMapButton.clicked.connect(self.select_from_map)
        self.mEditCurveButton.clicked.connect(self._on_edit_curve_clicked)
        self.mCloseButton.clicked.connect(self.close)
        if hasattr(self, "mColumnsButton") and self.mColumnsButton is not None:
            self.mColumnsButton.clicked.connect(self._on_columns_button_clicked)
        if hasattr(self, "mImportButton") and self.mImportButton is not None:
            self.mImportButton.clicked.connect(self._on_import_button_clicked)

        self._connections_importer = RouteConnectionsImporter(self)

        self.mStartLineEdit.textChanged.connect(self.on_start_text_changed)
        self.mEndLineEdit.textChanged.connect(self.on_end_text_changed)

        self.current_start_fid = None
        self.current_end_fid = None

        self._edit_curve_canvas_tool_signal = None
        self._cached_pan_tool = None
        self._project_layers_wired = False
        self._setup_edit_curve_canvas_watch()
        self._ensure_connections_table_columns()
        self.mConnectionsTable.itemChanged.connect(self._on_connections_item_changed)

        lst = getattr(self, "lstLibraryBasemaps", None)
        if lst is not None:
            wire_library_basemap_qlist_widget(lst, self._on_library_basemap_chosen)
        pbn_browse = getattr(self, "pbnBrowseLayer", None)
        if pbn_browse is not None:
            pbn_browse.clicked.connect(self._on_browse_layer)

    def _apply_dialog_font_bump(self):
        """Increase dialog fonts by 2pt; keep Supporting Layers label / Browse at 12."""
        keep_at_12 = {"lblSupportingLayers", "pbnBrowseLayer"}
        for widget in self.findChildren(QWidget):
            name = widget.objectName()
            if name in keep_at_12:
                self._set_widget_point_size(widget, 12)
                continue
            self._bump_widget_font(widget, 2)
            if hasattr(widget, "horizontalHeader"):
                try:
                    self._bump_widget_font(widget.horizontalHeader(), 2)
                except Exception:
                    pass
            if hasattr(widget, "verticalHeader"):
                try:
                    self._bump_widget_font(widget.verticalHeader(), 2)
                except Exception:
                    pass

    @staticmethod
    def _bump_widget_font(widget, delta):
        if widget is None:
            return
        font = QFont(widget.font())
        point_size = font.pointSize()
        if point_size > 0:
            font.setPointSize(point_size + delta)
        else:
            pixel_size = font.pixelSize()
            if pixel_size > 0:
                font.setPixelSize(pixel_size + delta)
        widget.setFont(font)

    @staticmethod
    def _set_widget_point_size(widget, point_size):
        if widget is None:
            return
        font = QFont(widget.font())
        font.setPointSize(point_size)
        widget.setFont(font)

    def _mapestry_plugin(self):
        """``self.plugin`` is the Route Connections host; Mapestry is attached as ``_mapestry``."""
        host = self.plugin
        if host is None:
            return None
        if hasattr(host, "loadBasemapFromFile") and hasattr(host, "_library_folder"):
            return host
        mw = getattr(host, "_mapestry", None)
        if mw is not None and hasattr(mw, "loadBasemapFromFile"):
            return mw
        return None

    def _library_folder(self):
        mw = self._mapestry_plugin()
        if mw is not None and hasattr(mw, "_library_folder"):
            try:
                return mw._library_folder()
            except Exception:
                pass
        try:
            from .plugin_settings_dialog import read_library_folder

            return read_library_folder()
        except Exception:
            return None

    def _refresh_library_basemap_list(self):
        lst = getattr(self, "lstLibraryBasemaps", None)
        if lst is None:
            return
        populate_library_basemap_qlist_widget(lst, self._library_folder() or "")

    def _on_library_basemap_chosen(self, path):
        mw = self._mapestry_plugin()
        if mw is not None and hasattr(mw, "loadBasemapFromFile"):
            mw.loadBasemapFromFile(path, stack_by_geometry=True)

    def _on_browse_layer(self):
        path, _selected = QFileDialog.getOpenFileName(
            self,
            self.tr("Add layer"),
            "",
            self.tr(
                "Vector files (*.shp *.zip *.gpkg *.geojson *.json);;"
                "All files (*.*)"
            ),
        )
        path = (path or "").strip()
        if not path:
            return
        mw = self._mapestry_plugin()
        if mw is not None and hasattr(mw, "loadBasemapFromFile"):
            mw.loadBasemapFromFile(path, stack_by_geometry=True)

    def _ensure_connections_table_columns(self):
        table = self.mConnectionsTable
        table.setColumnCount(3)
        table.setHorizontalHeaderLabels(
            [self.tr("Start"), self.tr("End"), self.tr("Lines")]
        )
        table.setEditTriggers(
            QAbstractItemView.DoubleClicked
            | QAbstractItemView.EditKeyPressed
            | QAbstractItemView.AnyKeyPressed
        )

    def _make_lines_item(self, line_count=1):
        n = clamp_line_count(line_count, default=1)
        item = QTableWidgetItem(str(n))
        item.setTextAlignment(Qt.AlignCenter)
        item.setFlags(
            Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable
        )
        item.setData(Qt.UserRole, n)
        return item

    def _on_connections_item_changed(self, item):
        if item is None or item.column() != 2:
            return
        table = self.mConnectionsTable
        table.blockSignals(True)
        try:
            n = clamp_line_count(item.text(), default=1)
            item.setText(str(n))
            item.setData(Qt.UserRole, n)
        finally:
            table.blockSignals(False)

    def _raise_above_main_window(self, take_focus=False):
        """Raise stacking order; optional keyboard focus (avoid when map canvas must receive clicks)."""
        try:
            self.raise_()
            if take_focus:
                self.activateWindow()
        except Exception:
            pass

    def _route_connections_pan_tool(self):
        if self._cached_pan_tool is None:
            self._cached_pan_tool = QgsMapToolPan(self.iface.mapCanvas())
        return self._cached_pan_tool

    def _setup_edit_curve_canvas_watch(self):
        canvas = self.iface.mapCanvas()
        if canvas is None or self._edit_curve_canvas_tool_signal is not None:
            return
        handler = self._on_edit_curve_canvas_tool_changed
        if hasattr(canvas, "mapToolSet"):
            canvas.mapToolSet.connect(handler)
            self._edit_curve_canvas_tool_signal = "mapToolSet"
        elif hasattr(canvas, "mapToolChanged"):
            canvas.mapToolChanged.connect(handler)
            self._edit_curve_canvas_tool_signal = "mapToolChanged"
        else:
            return
        self._on_edit_curve_canvas_tool_changed()

    def _teardown_edit_curve_canvas_watch(self):
        canvas = self.iface.mapCanvas()
        sig = self._edit_curve_canvas_tool_signal
        if canvas is None or sig is None:
            self._edit_curve_canvas_tool_signal = None
            return
        handler = self._on_edit_curve_canvas_tool_changed
        try:
            getattr(canvas, sig).disconnect(handler)
        except (TypeError, RuntimeError):
            pass
        self._edit_curve_canvas_tool_signal = None

    def _sync_edit_curve_button_from_canvas(self):
        canvas = self.iface.mapCanvas()
        tool = getattr(self.plugin, "edit_curve_tool", None)
        if canvas is None or tool is None:
            return
        try:
            active = canvas.mapTool() is tool
        except Exception:
            active = False
        self.mEditCurveButton.blockSignals(True)
        self.mEditCurveButton.setChecked(active)
        self.mEditCurveButton.blockSignals(False)

    def _on_edit_curve_canvas_tool_changed(self, *args):
        new_tool = args[0] if args else None
        canvas = self.iface.mapCanvas()
        if new_tool is None and canvas is not None:
            try:
                new_tool = canvas.mapTool()
            except Exception:
                new_tool = None
        curve_tool = getattr(self.plugin, "edit_curve_tool", None)
        try:
            active = curve_tool is not None and new_tool is curve_tool
        except Exception:
            active = False
        self.mEditCurveButton.blockSignals(True)
        self.mEditCurveButton.setChecked(active)
        self.mEditCurveButton.blockSignals(False)
        if active:
            self._raise_above_main_window(take_focus=False)

    def _on_edit_curve_clicked(self, checked=False):
        tool = getattr(self.plugin, "edit_curve_tool", None)
        canvas = self.iface.mapCanvas()
        if tool is None or canvas is None:
            return
        if checked:
            canvas.setMapTool(tool)
            self._raise_above_main_window(take_focus=False)
        else:
            canvas.setMapTool(self._route_connections_pan_tool())

    def showEvent(self, event):
        super(RouteConnectionsDialog, self).showEvent(event)
        self._wire_project_layer_signals()
        self._refresh_library_basemap_list()
        if self._edit_curve_canvas_tool_signal is None:
            self._setup_edit_curve_canvas_watch()
        else:
            self._sync_edit_curve_button_from_canvas()
        self._raise_above_main_window(take_focus=True)

    def hideEvent(self, event):
        self._unwire_project_layer_signals()
        super(RouteConnectionsDialog, self).hideEvent(event)

    def closeEvent(self, event):
        self._unwire_project_layer_signals()
        self._teardown_edit_curve_canvas_watch()
        self._close_columns_popup()
        canvas = self.iface.mapCanvas()
        tool = getattr(self.plugin, "edit_curve_tool", None)
        if canvas is not None and tool is not None:
            try:
                if canvas.mapTool() is tool:
                    canvas.setMapTool(self._route_connections_pan_tool())
            except Exception:
                pass
        self.mEditCurveButton.blockSignals(True)
        self.mEditCurveButton.setChecked(False)
        self.mEditCurveButton.blockSignals(False)
        super(RouteConnectionsDialog, self).closeEvent(event)

    def _wire_project_layer_signals(self):
        if self._project_layers_wired:
            return
        proj = QgsProject.instance()
        try:
            proj.layersAdded.connect(self._on_project_layers_added)
            proj.layersRemoved.connect(self._on_project_layers_removed)
            self._project_layers_wired = True
        except Exception:
            pass

    def _unwire_project_layer_signals(self):
        if not self._project_layers_wired:
            return
        proj = QgsProject.instance()
        try:
            proj.layersAdded.disconnect(self._on_project_layers_added)
        except (TypeError, RuntimeError):
            pass
        try:
            proj.layersRemoved.disconnect(self._on_project_layers_removed)
        except (TypeError, RuntimeError):
            pass
        self._project_layers_wired = False

    def _on_project_layers_added(self, layers):
        # Ignore non-point adds (e.g. Route Arcs lines created during Apply).
        # Refreshing here used to rebuild the combo and clear the connections
        # table mid-sync before arcs were drawn.
        if getattr(self, "_suppress_layer_list_refresh", False):
            return
        point_added = False
        select_id = None
        try:
            if self.current_layer is not None:
                select_id = self.current_layer.id()
        except Exception:
            select_id = None
        for lyr in layers or []:
            if not isinstance(lyr, QgsVectorLayer):
                continue
            try:
                if lyr.geometryType() != QgsWkbTypes.PointGeometry:
                    continue
            except Exception:
                continue
            point_added = True
            try:
                select_id = lyr.id()
            except Exception:
                pass
        if not point_added:
            return
        self.populate_layers(
            preferred_layer_id=select_id, reload_current_layer=False
        )

    def _on_project_layers_removed(self, layer_ids):
        if getattr(self, "_suppress_layer_list_refresh", False):
            return
        ids = {str(i) for i in (layer_ids or []) if i is not None}
        if not ids:
            return
        # Only refresh when a known point layer left (ignore Route Arcs, etc.).
        preferred = None
        affected = False
        try:
            if self.current_layer is not None:
                preferred = str(self.current_layer.id())
                if preferred in ids:
                    affected = True
                    preferred = None
        except Exception:
            preferred = None
            affected = True
        if not affected:
            for lyr in getattr(self, "point_layers", None) or []:
                try:
                    if str(lyr.id()) in ids:
                        affected = True
                        break
                except Exception:
                    continue
        if not affected:
            return
        self.populate_layers(
            preferred_layer_id=preferred, reload_current_layer=False
        )

    def on_start_text_changed(self, text):
        self.current_start_fid = None

    def on_end_text_changed(self, text):
        self.current_end_fid = None

    def _layer_field_names(self):
        if self.current_layer is None:
            return []
        try:
            return [f.name() for f in self.current_layer.fields()]
        except Exception:
            return []

    def _display_field_name(self):
        """Field used for map-pick labels and text lookup preference."""
        names = self._visible_field_names or self._layer_field_names()
        if not names:
            return None
        preferred = preferred_display_field_name(names)
        if preferred in names:
            return preferred
        return names[0]

    def _feature_display_text(self, feature):
        field_name = self._display_field_name()
        if feature is None:
            return ""
        if field_name:
            try:
                val = feature.attribute(field_name)
                if val is not None and str(val).strip() != "":
                    return str(val)
            except Exception:
                pass
        try:
            attrs = feature.attributes()
            if attrs:
                return str(attrs[0])
        except Exception:
            pass
        try:
            return "Feature {}".format(feature.id())
        except Exception:
            return "Feature"

    def find_feature_by_text(self, text, all_fields=False):
        if not self.current_layer:
            return None
        text = "" if text is None else str(text)
        needle = normalize_match_text(text)
        if not needle:
            return None
        if all_fields:
            search_fields = list(self._layer_field_names())
        else:
            search_fields = list(self._visible_field_names or self._layer_field_names())
        preferred = self._display_field_name()
        if preferred and preferred in search_fields:
            search_fields = [preferred] + [f for f in search_fields if f != preferred]
        # Also search remaining layer fields so restore works if the visible
        # column set no longer includes the field used when the route was made.
        if not all_fields:
            extras = [n for n in self._layer_field_names() if n not in set(search_fields)]
            search_fields = search_fields + extras
        for feat in self.current_layer.getFeatures():
            for field_name in search_fields:
                try:
                    if normalize_match_text(feat.attribute(field_name)) == needle:
                        return feat.id()
                except Exception:
                    continue
        return None

    def find_features_by_field_text(self, field_name, text):
        """Return [(feature_id, label), ...] for import ambiguous-match prompts."""
        if not self.current_layer or not field_name:
            return []
        needle = normalize_match_text(text)
        if not needle:
            return []

        extra_fields = [
            n
            for n in (self._visible_field_names or self._layer_field_names())
            if n != field_name
        ][:2]
        matches = []
        for feat in self.current_layer.getFeatures():
            try:
                value = feat.attribute(field_name)
            except Exception:
                continue
            if normalize_match_text(value) != needle:
                continue
            parts = ["ID {}".format(feat.id()), str(value).strip()]
            for extra in extra_fields:
                try:
                    extra_val = feat.attribute(extra)
                except Exception:
                    continue
                if extra_val is not None and str(extra_val).strip():
                    parts.append("{}: {}".format(extra, extra_val))
            matches.append((feat.id(), " — ".join(parts)))
        return matches

    def find_connection_row_by_pair(self, start_text, end_text):
        start_key = normalize_match_text(start_text)
        end_key = normalize_match_text(end_text)
        for row in range(self.mConnectionsTable.rowCount()):
            start_item = self.mConnectionsTable.item(row, 0)
            end_item = self.mConnectionsTable.item(row, 1)
            if start_item is None or end_item is None:
                continue
            if (
                normalize_match_text(start_item.text()) == start_key
                and normalize_match_text(end_item.text()) == end_key
            ):
                return row
        return None

    def insert_connection_row(
        self,
        start_text,
        end_text,
        start_fid,
        end_fid,
        replace_existing=False,
        line_count=1,
    ):
        self._ensure_connections_table_columns()

        if replace_existing:
            existing_row = self.find_connection_row_by_pair(start_text, end_text)
            if existing_row is not None:
                self.mConnectionsTable.removeRow(existing_row)

        try:
            start_fid = int(start_fid)
        except (TypeError, ValueError):
            pass
        try:
            end_fid = int(end_fid)
        except (TypeError, ValueError):
            pass

        conn_id = str(uuid.uuid4())
        row_position = self.mConnectionsTable.rowCount()
        self.mConnectionsTable.insertRow(row_position)

        start_item = QTableWidgetItem(str(start_text))
        start_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
        start_item.setData(Qt.UserRole, start_fid)
        start_item.setData(Qt.UserRole + 1, conn_id)

        end_item = QTableWidgetItem(str(end_text))
        end_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
        end_item.setData(Qt.UserRole, end_fid)

        self.mConnectionsTable.blockSignals(True)
        try:
            self.mConnectionsTable.setItem(row_position, 0, start_item)
            self.mConnectionsTable.setItem(row_position, 1, end_item)
            self.mConnectionsTable.setItem(
                row_position, 2, self._make_lines_item(line_count)
            )
        finally:
            self.mConnectionsTable.blockSignals(False)

    def _on_import_button_clicked(self):
        self._connections_importer.run()

    def _close_columns_popup(self):
        popup = self._columns_popup
        if popup is None:
            return
        try:
            popup.hide()
        except Exception:
            pass

    def _ensure_columns_popup(self):
        if self._columns_popup is not None:
            return self._columns_popup
        popup = _ColumnsPickerPopup(self)
        popup.list_widget.itemChanged.connect(self._on_columns_item_changed)
        self._bump_widget_font(popup, 2)
        self._bump_widget_font(popup.filter_edit, 2)
        self._bump_widget_font(popup.list_widget, 2)
        self._columns_popup = popup
        return popup

    def _on_columns_button_clicked(self):
        if self.current_layer is None:
            return
        popup = self._ensure_columns_popup()
        if popup.isVisible():
            popup.hide()
            return
        names = self._layer_field_names()
        checked = [
            n for n in (self._visible_field_names or []) if n in names
        ] or default_visible_field_names(names)
        popup.list_widget.blockSignals(True)
        try:
            popup.set_fields(names, checked)
        finally:
            popup.list_widget.blockSignals(False)
        btn = self.mColumnsButton
        pos = btn.mapToGlobal(QPoint(0, btn.height()))
        popup.move(pos)
        popup.show()
        popup.raise_()
        popup.filter_edit.setFocus()

    def _on_columns_item_changed(self, item):
        popup = self._columns_popup
        if popup is None:
            return
        checked = popup.checked_field_names()
        if not checked:
            # Keep at least one column visible.
            popup.list_widget.blockSignals(True)
            try:
                item.setCheckState(Qt.Checked)
            finally:
                popup.list_widget.blockSignals(False)
            checked = popup.checked_field_names()
        # Preserve layer field order.
        order = self._layer_field_names()
        self._visible_field_names = [n for n in order if n in set(checked)]
        self.populate_preview_table()

    def populate_layers(self, preferred_layer_id=None, reload_current_layer=True):
        previous_id = preferred_layer_id
        if previous_id is None:
            try:
                if self.current_layer is not None:
                    previous_id = self.current_layer.id()
            except Exception:
                previous_id = None
        if previous_id is None and self.mLayerComboBox.count():
            previous_id = self.mLayerComboBox.currentData()

        self.mLayerComboBox.blockSignals(True)
        try:
            self.mLayerComboBox.clear()
            layers = QgsProject.instance().mapLayers().values()

            self.point_layers = []
            for layer in layers:
                if (
                    isinstance(layer, QgsVectorLayer)
                    and layer.geometryType() == QgsWkbTypes.PointGeometry
                ):
                    self.point_layers.append(layer)

            labels = self._disambiguated_layer_labels(self.point_layers)
            for layer in self.point_layers:
                self.mLayerComboBox.addItem(
                    labels.get(layer.id(), layer.name()),
                    layer.id(),
                )
        finally:
            self.mLayerComboBox.blockSignals(False)

        target = 0
        if previous_id is not None:
            for i in range(self.mLayerComboBox.count()):
                if self.mLayerComboBox.itemData(i) == previous_id:
                    target = i
                    break
        if self.mLayerComboBox.count() > 0:
            self.mLayerComboBox.setCurrentIndex(target)
            new_id = self.mLayerComboBox.itemData(target)
            try:
                cur_id = (
                    self.current_layer.id() if self.current_layer is not None else None
                )
            except Exception:
                cur_id = None
            same_layer = (
                previous_id is not None
                and new_id == previous_id
                and cur_id == new_id
            )
            if reload_current_layer or not same_layer:
                self.on_layer_changed(target)
        else:
            self.on_layer_changed(-1)

    @staticmethod
    def _disambiguated_layer_labels(layers) -> dict:
        """Suffix duplicate layer names so identical names are distinguishable in lists."""
        name_totals = {}
        for lyr in layers:
            key = lyr.name().lower()
            name_totals[key] = name_totals.get(key, 0) + 1
        name_seen = {}
        labels = {}
        for lyr in layers:
            name = lyr.name()
            key = name.lower()
            if name_totals.get(key, 0) > 1:
                name_seen[key] = name_seen.get(key, 0) + 1
                labels[lyr.id()] = "{} ({})".format(name, name_seen[key])
            else:
                labels[lyr.id()] = name
        return labels

    def on_layer_changed(self, index):
        self._close_columns_popup()
        if index < 0:
            self.current_layer = None
            self._visible_field_names = []
            self.mDataPreviewTable.setRowCount(0)
            self.mDataPreviewTable.setColumnCount(0)
            self.mConnectionsTable.setRowCount(0)
            return

        layer_id = self.mLayerComboBox.itemData(index)
        self.current_layer = QgsProject.instance().mapLayer(layer_id)

        if not self.current_layer:
            return

        self._visible_field_names = default_visible_field_names(self._layer_field_names())
        self.populate_preview_table()

        self.mStartLineEdit.clear()
        self.mEndLineEdit.clear()
        self.current_start_fid = None
        self.current_end_fid = None

        self.restore_connections_from_route_arcs()

    def restore_connections_from_route_arcs(self):
        """Rebuild the connections table from the Route Arcs layer for this point layer only."""
        from .route_arcs_layer import find_route_arcs_layer_for_point_layer

        self._ensure_connections_table_columns()
        self.mConnectionsTable.setRowCount(0)
        if self.current_layer is None:
            return
        try:
            # Name-based repair is allowed; do not claim an unbound shared CRS
            # layer just by selecting a point layer (adopt_legacy=False).
            arc = find_route_arcs_layer_for_point_layer(
                self.current_layer, adopt_legacy=False, match_by_content=True
            )
        except Exception:
            arc = None
        if arc is None:
            return

        try:
            features = list(arc.getFeatures())
        except Exception:
            features = []

        # Group child arcs (base:index) into one table row per base ConnID.
        groups = {}
        order = []
        for feat in features:
            try:
                start_txt = feat.attribute("Start")
                end_txt = feat.attribute("End")
                conn_id = feat.attribute("ConnID")
            except Exception:
                continue
            start_txt = "" if start_txt is None else str(start_txt)
            end_txt = "" if end_txt is None else str(end_txt)
            base, index = parse_conn_id_base_index(conn_id)
            if not base:
                continue
            if base not in groups:
                groups[base] = {
                    "start": start_txt,
                    "end": end_txt,
                    "indices": set(),
                }
                order.append(base)
            groups[base]["indices"].add(index)
            if start_txt:
                groups[base]["start"] = start_txt
            if end_txt:
                groups[base]["end"] = end_txt

        self.mConnectionsTable.blockSignals(True)
        try:
            for base in order:
                info = groups[base]
                start_txt = info["start"]
                end_txt = info["end"]
                line_count = clamp_line_count(
                    len(info["indices"]) if info["indices"] else 1
                )
                start_fid = self.find_feature_by_text(start_txt, all_fields=True)
                end_fid = self.find_feature_by_text(end_txt, all_fields=True)
                if start_fid is None:
                    start_fid = -1
                if end_fid is None:
                    end_fid = -1
                row = self.mConnectionsTable.rowCount()
                self.mConnectionsTable.insertRow(row)
                start_item = QTableWidgetItem(start_txt)
                start_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
                start_item.setData(Qt.UserRole, int(start_fid))
                start_item.setData(Qt.UserRole + 1, base)
                end_item = QTableWidgetItem(end_txt)
                end_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
                end_item.setData(Qt.UserRole, int(end_fid))
                self.mConnectionsTable.setItem(row, 0, start_item)
                self.mConnectionsTable.setItem(row, 1, end_item)
                self.mConnectionsTable.setItem(row, 2, self._make_lines_item(line_count))
        finally:
            self.mConnectionsTable.blockSignals(False)

    def populate_preview_table(self):
        self.mDataPreviewTable.clear()

        if not self.current_layer:
            return

        all_names = self._layer_field_names()
        visible = [n for n in (self._visible_field_names or []) if n in all_names]
        if not visible:
            visible = default_visible_field_names(all_names)
            self._visible_field_names = list(visible)

        self.mDataPreviewTable.setColumnCount(len(visible))
        self.mDataPreviewTable.setHorizontalHeaderLabels(visible)

        features = list(self.current_layer.getFeatures())
        self.mDataPreviewTable.setRowCount(len(features))

        for row, feat in enumerate(features):
            for col, field_name in enumerate(visible):
                try:
                    val = feat.attribute(field_name)
                except Exception:
                    val = None
                item = QTableWidgetItem("" if val is None else str(val))
                item.setData(Qt.UserRole, feat.id())
                self.mDataPreviewTable.setItem(row, col, item)

        self.mDataPreviewTable.resizeColumnsToContents()

    def eventFilter(self, obj, event):
        table = getattr(self, "mDataPreviewTable", None)
        if (
            table is not None
            and obj is table.viewport()
            and event.type() == QEvent.MouseButtonRelease
        ):
            if event.button() == Qt.LeftButton:
                role = "start"
            elif event.button() == Qt.RightButton:
                role = "end"
            else:
                return False
            pos = event.pos()
            index = table.indexAt(pos)
            if not index.isValid():
                return True
            self._apply_preview_cell(index.row(), index.column(), role)
            return True
        return super(RouteConnectionsDialog, self).eventFilter(obj, event)

    def _apply_preview_cell(self, row, column, role):
        item = self.mDataPreviewTable.item(row, column)
        if not item:
            return
        cell_text = item.text()
        fid = item.data(Qt.UserRole)
        if role == "start":
            self.mStartLineEdit.setText(cell_text)
            self.current_start_fid = fid
        else:
            self.mEndLineEdit.setText(cell_text)
            self.current_end_fid = fid

    def select_from_map(self):
        if not self.current_layer:
            return

        self.hide()

        canvas = self.iface.mapCanvas()
        self.map_tool = _RoutePointPickMapTool(canvas, self.current_layer)
        self.map_tool.featurePicked.connect(self.on_feature_identified)
        canvas.setMapTool(self.map_tool)

    def on_feature_identified(self, feature, role="start"):
        canvas = self.iface.mapCanvas()
        if self.map_tool is not None:
            try:
                canvas.unsetMapTool(self.map_tool)
            except Exception:
                pass
        self.show()
        self._raise_above_main_window(take_focus=True)

        fid = feature.id()
        display_text = self._feature_display_text(feature)

        if role == "end":
            self.mEndLineEdit.setText(display_text)
            self.current_end_fid = fid
        else:
            self.mStartLineEdit.setText(display_text)
            self.current_start_fid = fid

    def add_connection(self):
        start_text = self.mStartLineEdit.text()
        end_text = self.mEndLineEdit.text()

        if not start_text or not end_text:
            return

        start_fid = self.current_start_fid
        if start_fid is None:
            start_fid = self.find_feature_by_text(start_text)
            if start_fid is None:
                QMessageBox.warning(
                    self,
                    "Location Not Found",
                    f"Could not find start location: '{start_text}' in the selected layer.",
                )
                return

        end_fid = self.current_end_fid
        if end_fid is None:
            end_fid = self.find_feature_by_text(end_text)
            if end_fid is None:
                QMessageBox.warning(
                    self,
                    "Location Not Found",
                    f"Could not find end location: '{end_text}' in the selected layer.",
                )
                return

        self.insert_connection_row(
            start_text, end_text, start_fid, end_fid, replace_existing=False
        )

        self.mStartLineEdit.clear()
        self.mEndLineEdit.clear()
        self.current_start_fid = None
        self.current_end_fid = None

    def remove_connection(self):
        selected_rows = self.mConnectionsTable.selectionModel().selectedRows()
        for index in sorted(selected_rows, reverse=True):
            self.mConnectionsTable.removeRow(index.row())
