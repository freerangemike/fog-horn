# -*- coding: utf-8 -*-
"""Radius Buffer tool — geometry-generator rings on point layers."""

import os
import re

from qgis.core import QgsProject, QgsVectorLayer, QgsWkbTypes
from qgis.PyQt import uic
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QGuiApplication
from qgis.PyQt.QtWidgets import (
    QButtonGroup,
    QDialog,
    QFileDialog,
    QListWidgetItem,
    QMessageBox,
)

from .library_basemap_list import (
    populate_library_basemap_qlist_widget,
    wire_library_basemap_qlist_widget,
)
from .point_buffer_layer import (
    DEFAULT_BUFFER_FILL_COLOR,
    DEFAULT_BUFFER_OUTLINE_COLOR,
    DEFAULT_BUFFER_TRANSPARENCY,
    DEFAULT_BUFFER_UNITS,
    add_point_buffer_circle,
    combo_index_for_unit_key,
    convert_map_units_to_display,
    crs_allows_metric_buffer,
    default_radius_for_units,
    find_point_buffer_circle,
    is_point_buffer_layer,
    list_point_buffer_circles,
    list_point_buffer_layers,
    list_project_point_layers,
    remove_point_buffer_circle,
    reproject_point_layer_to_gpkg,
    suggest_projected_crs_for_layer,
    unit_key_from_combo_index,
    unit_labels_for_combo,
    update_point_buffer_circle,
)

_APPLY_MODE_CREATE = "create"
_APPLY_MODE_EDIT = "edit"
_CIRCLE_REF_ROLE = Qt.UserRole
_CIRCLE_LAYER_ROLE = Qt.UserRole + 1


class RadiusBufferDialog(QDialog):
    """Manage radius buffers on point layers (symbology + custom properties)."""

    def __init__(self, plugin, parent=None):
        super().__init__(parent)
        self._plugin = plugin
        self._syncing_controls = False
        self._project_layers_wired = False
        ui_path = os.path.join(os.path.dirname(__file__), "radius_buffer.ui")
        self.dlgRadiusBuffer = self
        try:
            uic.loadUi(ui_path, self)
        finally:
            try:
                del self.dlgRadiusBuffer
            except AttributeError:
                pass

        cmb_units = getattr(self, "cmbRadiusUnits", None)
        if cmb_units is not None:
            cmb_units.clear()
            cmb_units.addItems(unit_labels_for_combo())
            cmb_units.setCurrentIndex(combo_index_for_unit_key(DEFAULT_BUFFER_UNITS))
            cmb_units.currentIndexChanged.connect(self._on_radius_units_changed)

        spn = getattr(self, "spnRadius", None)
        if spn is not None:
            spn.setValue(default_radius_for_units(DEFAULT_BUFFER_UNITS))
        sld_trans = getattr(self, "sldTransparency", None)
        spn_trans = getattr(self, "spnTransparency", None)
        if sld_trans is not None:
            sld_trans.valueChanged.connect(self._on_transparency_slider_changed)
        if spn_trans is not None:
            spn_trans.valueChanged.connect(self._on_transparency_spin_changed)
        self._set_transparency_value(DEFAULT_BUFFER_TRANSPARENCY)

        fill_btn = getattr(self, "plhBufferFillColor", None)
        if fill_btn is not None:
            fill_btn.setColor(DEFAULT_BUFFER_FILL_COLOR)
        outline_btn = getattr(self, "plhBufferOutlineColor", None)
        if outline_btn is not None:
            outline_btn.setColor(DEFAULT_BUFFER_OUTLINE_COLOR)

        self.pbnApplyBuffer.clicked.connect(self._on_apply_buffer)
        self.pbnRemoveBuffer.clicked.connect(self._on_remove_buffer)
        self._init_buffer_apply_mode_radios()
        bb = getattr(self, "buttonBox", None)
        if bb is not None:
            bb.accepted.connect(self._on_dialog_finished)

        lst = getattr(self, "lstBufferLayers", None)
        if lst is not None:
            lst.currentItemChanged.connect(self._on_buffer_layer_selection_changed)

        cmb = getattr(self, "cmbPointLayers", None)
        if cmb is not None:
            cmb.currentIndexChanged.connect(self._on_point_layer_combo_changed)

        lst_lib = getattr(self, "lstLibraryBasemaps", None)
        if lst_lib is not None:
            wire_library_basemap_qlist_widget(lst_lib, self._on_library_basemap_chosen)

        pbn_browse = getattr(self, "pbnBrowseLayer", None)
        if pbn_browse is not None:
            pbn_browse.clicked.connect(self._on_browse_layer)

    def _library_folder(self):
        if self._plugin is None or not hasattr(self._plugin, "_library_folder"):
            return None
        try:
            return self._plugin._library_folder()
        except Exception:
            return None

    def _refresh_library_basemap_list(self):
        lst = getattr(self, "lstLibraryBasemaps", None)
        if lst is None:
            return
        populate_library_basemap_qlist_widget(lst, self._library_folder() or "")

    def _wire_project_layer_signals(self):
        if self._project_layers_wired:
            return
        proj = QgsProject.instance()
        try:
            proj.layersAdded.connect(self._on_project_layers_added)
            proj.layersRemoved.connect(self._on_project_layers_removed)
            self._project_layers_wired = True
        except Exception:
            pass

    def _unwire_project_layer_signals(self):
        if not self._project_layers_wired:
            return
        proj = QgsProject.instance()
        try:
            proj.layersAdded.disconnect(self._on_project_layers_added)
        except (TypeError, RuntimeError):
            pass
        try:
            proj.layersRemoved.disconnect(self._on_project_layers_removed)
        except (TypeError, RuntimeError):
            pass
        self._project_layers_wired = False

    @staticmethod
    def _is_point_layer(lyr) -> bool:
        if lyr is None or not isinstance(lyr, QgsVectorLayer):
            return False
        try:
            from qgis.PyQt import sip

            if sip.isdeleted(lyr):
                return False
        except Exception:
            return False
        try:
            return lyr.geometryType() == QgsWkbTypes.PointGeometry
        except Exception:
            return False

    def _on_project_layers_added(self, layers):
        select_id = self._selected_point_layer_id()
        for lyr in layers or []:
            if self._is_point_layer(lyr):
                try:
                    select_id = lyr.id()
                except Exception:
                    pass
        self._refresh_library_basemap_list()
        self._refresh_lists(select_layer_id=select_id)

    def _on_project_layers_removed(self, _layer_ids):
        self._refresh_lists(select_layer_id=self._selected_point_layer_id())

    def _on_library_basemap_chosen(self, path):
        if self._plugin is not None and hasattr(self._plugin, "loadBasemapFromFile"):
            self._plugin.loadBasemapFromFile(path, stack_by_geometry=True)

    def _on_browse_layer(self):
        path, _selected = QFileDialog.getOpenFileName(
            self,
            self.tr("Add layer"),
            "",
            self.tr(
                "Vector files (*.shp *.zip *.gpkg *.geojson *.json);;"
                "All files (*.*)"
            ),
        )
        path = (path or "").strip()
        if not path:
            return
        if self._plugin is not None and hasattr(self._plugin, "loadBasemapFromFile"):
            self._plugin.loadBasemapFromFile(path, stack_by_geometry=True)

    def _current_unit_key(self) -> str:
        cmb_units = getattr(self, "cmbRadiusUnits", None)
        if cmb_units is None:
            return DEFAULT_BUFFER_UNITS
        return unit_key_from_combo_index(cmb_units.currentIndex())

    def _on_transparency_slider_changed(self, value):
        spn = getattr(self, "spnTransparency", None)
        if spn is None or spn.value() == value:
            return
        spn.blockSignals(True)
        try:
            spn.setValue(value)
        finally:
            spn.blockSignals(False)

    def _on_transparency_spin_changed(self, value):
        sld = getattr(self, "sldTransparency", None)
        if sld is None or sld.value() == value:
            return
        sld.blockSignals(True)
        try:
            sld.setValue(value)
        finally:
            sld.blockSignals(False)

    def _set_transparency_value(self, value):
        pct = max(0, min(100, int(round(float(value)))))
        sld = getattr(self, "sldTransparency", None)
        spn = getattr(self, "spnTransparency", None)
        if sld is not None:
            sld.blockSignals(True)
            try:
                sld.setValue(pct)
            finally:
                sld.blockSignals(False)
        if spn is not None:
            spn.blockSignals(True)
            try:
                spn.setValue(pct)
            finally:
                spn.blockSignals(False)

    def _current_transparency(self) -> float:
        spn_trans = getattr(self, "spnTransparency", None)
        if spn_trans is not None:
            return float(spn_trans.value())
        sld_trans = getattr(self, "sldTransparency", None)
        if sld_trans is None:
            return DEFAULT_BUFFER_TRANSPARENCY
        return float(sld_trans.value())

    def _current_fill_color(self):
        btn = getattr(self, "plhBufferFillColor", None)
        if btn is None:
            return DEFAULT_BUFFER_FILL_COLOR
        try:
            return btn.color()
        except Exception:
            return DEFAULT_BUFFER_FILL_COLOR

    def _current_outline_color(self):
        btn = getattr(self, "plhBufferOutlineColor", None)
        if btn is None:
            return DEFAULT_BUFFER_OUTLINE_COLOR
        try:
            return btn.color()
        except Exception:
            return DEFAULT_BUFFER_OUTLINE_COLOR

    def _set_color_buttons(self, fill_color, outline_color):
        fill_btn = getattr(self, "plhBufferFillColor", None)
        if fill_btn is not None:
            fill_btn.setColor(fill_color)
        outline_btn = getattr(self, "plhBufferOutlineColor", None)
        if outline_btn is not None:
            outline_btn.setColor(outline_color)

    def _apply_default_controls(self):
        cmb_units = getattr(self, "cmbRadiusUnits", None)
        spn = getattr(self, "spnRadius", None)
        unit_key = DEFAULT_BUFFER_UNITS
        if cmb_units is not None:
            cmb_units.blockSignals(True)
            try:
                cmb_units.setCurrentIndex(combo_index_for_unit_key(unit_key))
            finally:
                cmb_units.blockSignals(False)
        if spn is not None:
            spn.setValue(default_radius_for_units(unit_key))
        self._set_transparency_value(DEFAULT_BUFFER_TRANSPARENCY)
        self._set_color_buttons(DEFAULT_BUFFER_FILL_COLOR, DEFAULT_BUFFER_OUTLINE_COLOR)

    def _init_buffer_apply_mode_radios(self):
        rb_create = getattr(self, "rbCreateCircle", None)
        rb_edit = getattr(self, "rbEditCircle", None)
        if rb_create is None or rb_edit is None:
            return
        self._apply_mode_group = QButtonGroup(self)
        self._apply_mode_group.setExclusive(True)
        self._apply_mode_group.addButton(rb_create)
        self._apply_mode_group.addButton(rb_edit)
        rb_create.setChecked(True)
        rb_create.toggled.connect(self._on_buffer_apply_mode_changed)
        rb_edit.toggled.connect(self._on_buffer_apply_mode_changed)

    def _buffer_apply_mode(self) -> str:
        rb_edit = getattr(self, "rbEditCircle", None)
        if rb_edit is not None and rb_edit.isChecked():
            return _APPLY_MODE_EDIT
        return _APPLY_MODE_CREATE

    def _is_create_buffer_mode(self) -> bool:
        return self._buffer_apply_mode() == _APPLY_MODE_CREATE

    def _set_buffer_apply_mode(self, mode: str):
        rb_create = getattr(self, "rbCreateCircle", None)
        rb_edit = getattr(self, "rbEditCircle", None)
        if rb_create is None or rb_edit is None:
            return
        want_edit = mode == _APPLY_MODE_EDIT
        if rb_edit.isChecked() == want_edit and rb_create.isChecked() == (not want_edit):
            return
        rb_create.blockSignals(True)
        rb_edit.blockSignals(True)
        try:
            rb_edit.setChecked(want_edit)
            rb_create.setChecked(not want_edit)
        finally:
            rb_create.blockSignals(False)
            rb_edit.blockSignals(False)

    def _sync_buffer_apply_mode_enabled(self):
        """Disable Edit when there are no circles; force Create if list is empty."""
        rb_edit = getattr(self, "rbEditCircle", None)
        if rb_edit is None:
            return
        has_circles = False
        lst = getattr(self, "lstBufferLayers", None)
        if lst is not None and lst.count() > 0:
            has_circles = True
        else:
            has_circles = bool(list_point_buffer_circles())
        rb_edit.setEnabled(has_circles)
        if not has_circles and not self._is_create_buffer_mode():
            self._set_buffer_apply_mode(_APPLY_MODE_CREATE)

    def _on_buffer_apply_mode_changed(self, checked=False):
        if self._syncing_controls:
            return
        # Only react when a radio becomes checked (toggled fires for both).
        sender = self.sender()
        if sender is not None and hasattr(sender, "isChecked") and not sender.isChecked():
            return
        if not self._is_create_buffer_mode():
            if self._selected_circle_id() is None:
                lst = getattr(self, "lstBufferLayers", None)
                if lst is not None and lst.count() > 0:
                    lst.setCurrentRow(0)
        self._sync_radius_controls()

    def _on_radius_units_changed(self, index):
        if self._syncing_controls:
            return
        if not self._is_create_buffer_mode() and self._selected_circle_id():
            return
        spn = getattr(self, "spnRadius", None)
        if spn is None:
            return
        unit_key = unit_key_from_combo_index(index)
        spn.setValue(default_radius_for_units(unit_key))

    def _on_dialog_finished(self):
        if self._plugin is not None and hasattr(self._plugin, "register_completed_tool"):
            self._plugin.register_completed_tool("radius_buffer")

    def showEvent(self, event):
        super().showEvent(event)
        self._wire_project_layer_signals()
        self._refresh_library_basemap_list()
        self._refresh_lists()
        self._center_on_screen()

    def hideEvent(self, event):
        self._unwire_project_layer_signals()
        super().hideEvent(event)

    def closeEvent(self, event):
        self._unwire_project_layer_signals()
        super().closeEvent(event)

    def _center_on_screen(self):
        ref = self.parentWidget()
        center_pt = ref.frameGeometry().center() if ref is not None else None
        if center_pt is None:
            center_pt = self.frameGeometry().center()
        screen = QGuiApplication.screenAt(center_pt)
        if screen is None:
            screen = QGuiApplication.primaryScreen()
        if screen is None:
            return
        ag = screen.availableGeometry()
        geo = self.frameGeometry()
        geo.moveCenter(ag.center())
        self.move(geo.topLeft())

    def _refresh_lists(
        self,
        select_layer_id: str | None = None,
        select_circle_id: str | None = None,
    ):
        self._refresh_buffer_layer_list(
            select_layer_id=select_layer_id,
            select_circle_id=select_circle_id,
        )
        self._refresh_point_layer_combo(select_layer_id=select_layer_id)
        self._sync_radius_controls()

    def _refresh_buffer_layer_list(
        self,
        select_layer_id: str | None = None,
        select_circle_id: str | None = None,
    ):
        lst = getattr(self, "lstBufferLayers", None)
        if lst is None:
            return
        prev_layer = select_layer_id
        prev_circle = select_circle_id
        if prev_circle is None:
            prev_layer, prev_circle = self._selected_circle_ref()
        lst.blockSignals(True)
        try:
            lst.clear()
            select_row = -1
            rows = list_point_buffer_circles()
            layer_ids = [r.get("layer_id") for r in rows]
            # Disambiguate layer names among layers that appear in the circle list.
            name_layers = []
            for lid in dict.fromkeys(layer_ids):
                lyr = self._layer_by_id(lid)
                if lyr is not None:
                    name_layers.append(lyr)
            labels = self._disambiguated_layer_labels(name_layers)
            for row, entry in enumerate(rows):
                lyr_id = entry.get("layer_id")
                circle = entry.get("circle") or {}
                circle_id = circle.get("id")
                lyr = self._layer_by_id(lyr_id)
                units = str(circle.get("units") or DEFAULT_BUFFER_UNITS)
                map_r = circle.get("radius_map")
                detail = ""
                if map_r is not None and lyr is not None:
                    display_r = convert_map_units_to_display(float(map_r), units, lyr)
                    detail = self.tr("{0} {1}").format(
                        self._format_radius(display_r),
                        units,
                    )
                elif map_r is not None:
                    detail = self.tr("{0} map units").format(self._format_radius(float(map_r)))
                layer_label = labels.get(lyr_id, entry.get("layer_name") or lyr_id)
                if detail:
                    label = self.tr("{0} — {1}").format(layer_label, detail)
                else:
                    label = layer_label
                item = QListWidgetItem(label)
                item.setData(_CIRCLE_LAYER_ROLE, lyr_id)
                item.setData(_CIRCLE_REF_ROLE, circle_id)
                lst.addItem(item)
                if (
                    prev_layer
                    and prev_circle
                    and lyr_id == prev_layer
                    and circle_id == prev_circle
                ):
                    select_row = row
            if select_row >= 0:
                lst.setCurrentRow(select_row)
        finally:
            lst.blockSignals(False)
        self._sync_buffer_apply_mode_enabled()

    def _refresh_point_layer_combo(self, select_layer_id: str | None = None):
        cmb = getattr(self, "cmbPointLayers", None)
        if cmb is None:
            return
        prev_id = select_layer_id or self._selected_point_layer_id()
        layers = list_project_point_layers()
        cmb.blockSignals(True)
        try:
            cmb.clear()
            if not layers:
                cmb.addItem(
                    self.tr("(No point layers — add from library or Browse)"),
                    "",
                )
                cmb.setEnabled(False)
                return
            cmb.setEnabled(True)
            select_idx = -1
            labels = self._disambiguated_layer_labels(layers)
            for idx, lyr in enumerate(layers):
                cmb.addItem(labels.get(lyr.id(), lyr.name()), lyr.id())
                if prev_id and lyr.id() == prev_id:
                    select_idx = idx
            if select_idx >= 0:
                cmb.setCurrentIndex(select_idx)
            elif cmb.count() > 0:
                cmb.setCurrentIndex(0)
        finally:
            cmb.blockSignals(False)

    @staticmethod
    def _format_radius(value: float) -> str:
        try:
            v = float(value)
        except (TypeError, ValueError):
            return "0"
        if abs(v - round(v)) < 0.0005:
            return str(int(round(v)))
        return "{:.2f}".format(v)

    def _selected_circle_ref(self) -> tuple[str | None, str | None]:
        lst = getattr(self, "lstBufferLayers", None)
        if lst is None:
            return None, None
        item = lst.currentItem()
        if item is None:
            return None, None
        layer_id = item.data(_CIRCLE_LAYER_ROLE)
        circle_id = item.data(_CIRCLE_REF_ROLE)
        return (
            str(layer_id) if layer_id else None,
            str(circle_id) if circle_id else None,
        )

    def _selected_circle_id(self) -> str | None:
        _layer_id, circle_id = self._selected_circle_ref()
        return circle_id

    def _selected_buffer_layer_id(self) -> str | None:
        layer_id, _circle_id = self._selected_circle_ref()
        return layer_id

    @staticmethod
    def _color_from_circle_rgb(raw, default: QColor) -> QColor:
        try:
            parts = [int(p.strip()) for p in str(raw or "").split(",")]
        except (TypeError, ValueError):
            return QColor(default)
        if len(parts) != 3:
            return QColor(default)
        return QColor(
            max(0, min(255, parts[0])),
            max(0, min(255, parts[1])),
            max(0, min(255, parts[2])),
        )

    def _selected_point_layer_id(self) -> str | None:
        cmb = getattr(self, "cmbPointLayers", None)
        if cmb is None or cmb.currentIndex() < 0:
            return None
        role = cmb.currentData()
        return str(role) if role else None

    def _layer_by_id(self, layer_id: str | None) -> QgsVectorLayer | None:
        if not layer_id:
            return None
        lyr = QgsProject.instance().mapLayer(layer_id)
        if lyr is None or not isinstance(lyr, QgsVectorLayer):
            return None
        try:
            from qgis.PyQt import sip

            if sip.isdeleted(lyr):
                return None
        except Exception:
            return None
        return lyr

    @staticmethod
    def _disambiguated_layer_labels(layers) -> dict[str, str]:
        """Suffix duplicate layer names so identical names are distinguishable in lists."""
        name_totals: dict[str, int] = {}
        for lyr in layers:
            key = lyr.name().lower()
            name_totals[key] = name_totals.get(key, 0) + 1
        name_seen: dict[str, int] = {}
        labels: dict[str, str] = {}
        for lyr in layers:
            name = lyr.name()
            key = name.lower()
            if name_totals.get(key, 0) > 1:
                name_seen[key] = name_seen.get(key, 0) + 1
                labels[lyr.id()] = "{} ({})".format(name, name_seen[key])
            else:
                labels[lyr.id()] = name
        return labels

    def _selected_editing_layer(self) -> QgsVectorLayer | None:
        """Layer for controls / remove: edit mode uses circle list; create uses point combo."""
        if not self._is_create_buffer_mode():
            lyr = self._layer_by_id(self._selected_buffer_layer_id())
            if lyr is not None:
                return lyr
        lyr = self._layer_by_id(self._selected_point_layer_id())
        if lyr is not None:
            return lyr
        return self._layer_by_id(self._selected_buffer_layer_id())

    def _sync_radius_controls(self):
        if self._syncing_controls:
            return
        self._syncing_controls = True
        try:
            self._sync_buffer_apply_mode_enabled()
            lyr = self._selected_editing_layer()
            spn = getattr(self, "spnRadius", None)
            cmb_units = getattr(self, "cmbRadiusUnits", None)
            layer_id, circle_id = self._selected_circle_ref()
            circle = None
            if layer_id and circle_id:
                _lyr, circle = find_point_buffer_circle(layer_id, circle_id)
            if lyr is None:
                self._apply_default_controls()
                if self.pbnRemoveBuffer is not None:
                    self.pbnRemoveBuffer.setEnabled(False)
                if self.pbnApplyBuffer is not None:
                    if self._is_create_buffer_mode():
                        self.pbnApplyBuffer.setEnabled(
                            self._layer_by_id(self._selected_point_layer_id()) is not None
                        )
                    else:
                        self.pbnApplyBuffer.setEnabled(False)
                return
            if (not self._is_create_buffer_mode()) and circle is not None:
                units = str(circle.get("units") or DEFAULT_BUFFER_UNITS)
                if cmb_units is not None:
                    cmb_units.setCurrentIndex(combo_index_for_unit_key(units))
                map_r = circle.get("radius_map")
                if map_r is not None and spn is not None:
                    spn.setValue(convert_map_units_to_display(float(map_r), units, lyr))
                try:
                    self._set_transparency_value(float(circle.get("transparency")))
                except (TypeError, ValueError):
                    self._set_transparency_value(DEFAULT_BUFFER_TRANSPARENCY)
                self._set_color_buttons(
                    self._color_from_circle_rgb(
                        circle.get("fill"), DEFAULT_BUFFER_FILL_COLOR
                    ),
                    self._color_from_circle_rgb(
                        circle.get("outline"), DEFAULT_BUFFER_OUTLINE_COLOR
                    ),
                )
            if self.pbnRemoveBuffer is not None:
                self.pbnRemoveBuffer.setEnabled(circle is not None)
            if self.pbnApplyBuffer is not None:
                if self._is_create_buffer_mode():
                    self.pbnApplyBuffer.setEnabled(
                        self._layer_by_id(self._selected_point_layer_id()) is not None
                    )
                else:
                    self.pbnApplyBuffer.setEnabled(circle is not None)
        finally:
            self._syncing_controls = False

    def _on_buffer_layer_selection_changed(self, current, previous):
        if current is None:
            self._sync_buffer_apply_mode_enabled()
            self._sync_radius_controls()
            return
        layer_id = current.data(_CIRCLE_LAYER_ROLE)
        circle_id = current.data(_CIRCLE_REF_ROLE)
        if layer_id and circle_id and list_point_buffer_circles():
            self._set_buffer_apply_mode(_APPLY_MODE_EDIT)
        cmb = getattr(self, "cmbPointLayers", None)
        if cmb is not None and layer_id:
            idx = cmb.findData(layer_id)
            if idx >= 0:
                cmb.blockSignals(True)
                try:
                    cmb.setCurrentIndex(idx)
                finally:
                    cmb.blockSignals(False)
        self._sync_radius_controls()

    def _on_point_layer_combo_changed(self, index):
        if self._syncing_controls:
            return
        if self._is_create_buffer_mode():
            lst = getattr(self, "lstBufferLayers", None)
            if lst is not None:
                lst.blockSignals(True)
                try:
                    lst.clearSelection()
                finally:
                    lst.blockSignals(False)
        self._sync_radius_controls()

    def _ensure_projected_layer_for_buffer(
        self, lyr: QgsVectorLayer
    ) -> tuple[QgsVectorLayer | None, str | None]:
        """
        Return a layer suitable for buffering.

        If ``lyr`` is already projected, returns (lyr, None).
        If geographic, prompts for CRS and saves a projected GeoPackage copy.
        Returns (None, None) when the user cancels CRS selection.
        """
        ok, _msg = crs_allows_metric_buffer(lyr)
        if ok:
            return lyr, None

        suggested = suggest_projected_crs_for_layer(lyr)
        dest_crs = suggested
        try:
            from qgis.gui import QgsProjectionSelectionDialog

            dlg = QgsProjectionSelectionDialog(self)
            dlg.setCrs(suggested)
            dlg.setWindowTitle(self.tr("Choose projected CRS for buffering"))
            if dlg.exec_() != QDialog.Accepted:
                return None, None
            dest_crs = dlg.crs()
        except Exception:
            # Fallback: use suggested UTM without a picker.
            pass

        if dest_crs is None or not dest_crs.isValid():
            return None, self.tr("Choose a valid projected CRS.")
        try:
            if dest_crs.isGeographic():
                return None, self.tr(
                    "Pick a projected CRS (meters/feet), not a geographic one (degrees)."
                )
        except Exception:
            pass

        from .geocode_layer import geocode_storage_directory

        folder = geocode_storage_directory(QgsProject.instance())
        if not folder:
            return None, self.tr(
                "Could not find a folder to save the GeoPackage. "
                "Save the project first, or set a geocode staging folder in Settings."
            )

        base_name = (lyr.name() or "points").strip() or "points"
        safe = re.sub(r"[^A-Za-z0-9_-]+", "_", base_name).strip("_") or "points"
        display_name = "{} (projected)".format(base_name)
        gpkg_path = os.path.join(folder, "{}_projected.gpkg".format(safe))
        n = 2
        while os.path.exists(gpkg_path):
            gpkg_path = os.path.join(folder, "{}_projected_{}.gpkg".format(safe, n))
            n += 1

        out_lyr, err = reproject_point_layer_to_gpkg(
            lyr, dest_crs, gpkg_path, display_name=display_name
        )
        if out_lyr is None:
            return None, err or self.tr("Reproject failed.")

        QgsProject.instance().addMapLayer(out_lyr)
        try:
            QgsProject.instance().setDirty(True)
        except Exception:
            pass

        self._refresh_lists(select_layer_id=out_lyr.id())
        return out_lyr, None

    def _on_apply_buffer(self):
        create_mode = self._is_create_buffer_mode()
        circle_id = None
        if create_mode:
            lyr = self._layer_by_id(self._selected_point_layer_id())
            if lyr is None:
                QMessageBox.warning(
                    self,
                    self.windowTitle(),
                    self.tr("Select a point layer."),
                )
                return
        else:
            layer_id, circle_id = self._selected_circle_ref()
            lyr, circle = find_point_buffer_circle(layer_id, circle_id)
            if lyr is None or circle is None:
                QMessageBox.warning(
                    self,
                    self.windowTitle(),
                    self.tr("Select a circle in the list to edit."),
                )
                return
        spn = getattr(self, "spnRadius", None)
        cmb_units = getattr(self, "cmbRadiusUnits", None)
        if spn is None or cmb_units is None:
            return
        # Capture UI values before any reproject refresh (that resets defaults).
        radius = float(spn.value())
        unit_key = self._current_unit_key()
        transparency = self._current_transparency()
        fill_color = self._current_fill_color()
        outline_color = self._current_outline_color()
        ok_crs, _msg = crs_allows_metric_buffer(lyr)
        if not ok_crs:
            lyr, reproj_err = self._ensure_projected_layer_for_buffer(lyr)
            if lyr is None:
                if reproj_err:
                    QMessageBox.warning(
                        self,
                        self.windowTitle(),
                        reproj_err,
                    )
                return

        if create_mode:
            ok, err, circle_id = add_point_buffer_circle(
                lyr,
                radius,
                unit_key,
                transparency_pct=transparency,
                fill_color=fill_color,
                outline_color=outline_color,
            )
        else:
            ok, err = update_point_buffer_circle(
                lyr,
                circle_id,
                radius,
                unit_key=unit_key,
                transparency_pct=transparency,
                fill_color=fill_color,
                outline_color=outline_color,
            )
        if not ok:
            QMessageBox.warning(
                self,
                self.windowTitle(),
                err or self.tr("Could not apply the circle."),
            )
            return
        try:
            layer_id = lyr.id()
        except Exception:
            layer_id = None
        self._refresh_lists(select_layer_id=layer_id, select_circle_id=circle_id)
        if create_mode:
            self._set_buffer_apply_mode(_APPLY_MODE_CREATE)
            self._sync_radius_controls()
        if self._plugin is not None and hasattr(self._plugin, "register_completed_tool"):
            self._plugin.register_completed_tool("radius_buffer")

    def _on_remove_buffer(self):
        layer_id, circle_id = self._selected_circle_ref()
        lyr, circle = find_point_buffer_circle(layer_id, circle_id)
        if lyr is None or circle is None:
            QMessageBox.information(
                self,
                self.windowTitle(),
                self.tr("Select a circle in the list to remove."),
            )
            return
        units = str(circle.get("units") or DEFAULT_BUFFER_UNITS)
        map_r = circle.get("radius_map")
        detail = ""
        if map_r is not None:
            display_r = convert_map_units_to_display(float(map_r), units, lyr)
            detail = self.tr("{0} {1}").format(self._format_radius(display_r), units)
        label = lyr.name()
        if detail:
            label = self.tr("{0} — {1}").format(label, detail)
        if (
            QMessageBox.question(
                self,
                self.windowTitle(),
                self.tr(
                    'Remove buffer circle "{0}"? Point markers are kept.'
                ).format(label),
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            != QMessageBox.Yes
        ):
            return
        ok, err = remove_point_buffer_circle(lyr, circle_id)
        if not ok:
            QMessageBox.warning(
                self,
                self.windowTitle(),
                err or self.tr("Could not remove the circle."),
            )
            return
        self._refresh_lists()
        self._sync_buffer_apply_mode_enabled()
        if not list_point_buffer_layers():
            dw = getattr(self._plugin, "dockwidget", None)
            if dw is not None and hasattr(dw, "unregister_completed_tool"):
                dw.unregister_completed_tool("radius_buffer")
