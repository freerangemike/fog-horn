import math

from qgis.PyQt.QtCore import Qt
from qgis.core import QgsGeometry, QgsPointXY, QgsWkbTypes
from qgis.gui import QgsMapTool, QgsRubberBand


class EditCurveMapTool(QgsMapTool):
    def __init__(self, canvas, plugin, dialog):
        super().__init__(canvas)
        self.canvas = canvas
        self.plugin = plugin
        self.dialog = dialog

        self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rubber_band.setColor(Qt.red)
        self.rubber_band.setWidth(2)

        self.active_feature = None
        self.arc_layer = None
        self.start_pt = None
        self.end_pt = None
        self.current_curvature = 0.3

    def canvasPressEvent(self, e):
        if not self.dialog.current_layer:
            return

        source_crs = self.dialog.current_layer.crs()
        self.arc_layer = self.plugin.get_arc_layer(source_crs)

        if not self.arc_layer or self.arc_layer.featureCount() == 0:
            return

        click_point = self.toMapCoordinates(e.pos())
        click_geom = QgsGeometry.fromPointXY(click_point)

        closest_feat = None
        min_dist = float("inf")

        search_radius = self.searchRadiusMU(self.canvas)

        for feat in self.arc_layer.getFeatures():
            geom = feat.geometry()
            dist = geom.distance(click_geom)
            if dist < min_dist and dist < search_radius:
                min_dist = dist
                closest_feat = feat

        if closest_feat:
            self.active_feature = closest_feat
            geom = closest_feat.geometry()

            if geom.isMultipart():
                polyline = geom.asMultiPolyline()[0]
            else:
                polyline = geom.asPolyline()

            if polyline:
                self.start_pt = QgsPointXY(polyline[0])
                self.end_pt = QgsPointXY(polyline[-1])

    def canvasMoveEvent(self, e):
        if not self.active_feature or not self.start_pt or not self.end_pt:
            return

        mouse_pt = self.toMapCoordinates(e.pos())

        x1, y1 = self.start_pt.x(), self.start_pt.y()
        x2, y2 = self.end_pt.x(), self.end_pt.y()
        mx, my = mouse_pt.x(), mouse_pt.y()

        dx = x2 - x1
        dy = y2 - y1
        length = math.hypot(dx, dy)

        if length == 0:
            return

        cross_product = (my - y1) * dx - (mx - x1) * dy
        signed_dist = cross_product / length

        self.current_curvature = signed_dist / length
        self.current_curvature = max(-2.0, min(2.0, self.current_curvature))

        new_points = self.plugin.get_bezier_curve(self.start_pt, self.end_pt, curvature=self.current_curvature)
        new_geom = QgsGeometry.fromPolylineXY(new_points)

        self.rubber_band.setToGeometry(new_geom, self.arc_layer)

    def canvasReleaseEvent(self, e):
        if self.active_feature:
            new_points = self.plugin.get_bezier_curve(self.start_pt, self.end_pt, curvature=self.current_curvature)
            new_geom = QgsGeometry.fromPolylineXY(new_points)

            if not self.arc_layer.isEditable():
                self.arc_layer.startEditing()

            self.arc_layer.changeGeometry(self.active_feature.id(), new_geom)
            self.arc_layer.triggerRepaint()

            self.rubber_band.reset()
            self.active_feature = None
            self.start_pt = None
            self.end_pt = None

    def deactivate(self):
        self.rubber_band.reset()
        super().deactivate()
