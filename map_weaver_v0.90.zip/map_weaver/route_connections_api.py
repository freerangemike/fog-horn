"""Entry points for Route Connections embedded in Mapestry.

Wire buttons later, for example from map_weaver_dockwidget:

    from qgis.utils import iface
    from .route_connections_api import open_route_connections
    open_route_connections(iface)

Or keep a controller on your plugin class and call ``controller.run()``.
"""

_controllers = {}


def open_route_connections(iface):
    """Show the Route Connections dialog (one controller per iface instance)."""
    if iface is None:
        return
    key = id(iface)
    if key not in _controllers:
        from .route_connections_controller import RouteConnectionsController

        _controllers[key] = RouteConnectionsController(iface)
    _controllers[key].run()


def get_route_connections_controller(iface):
    """Return the shared controller for ``iface`` (creates if needed)."""
    if iface is None:
        return None
    key = id(iface)
    if key not in _controllers:
        from .route_connections_controller import RouteConnectionsController

        _controllers[key] = RouteConnectionsController(iface)
    return _controllers[key]
