from qgis.PyQt.QtCore import QObject, QUrl, pyqtSignal
from qgis.PyQt.QtNetwork import QNetworkAccessManager, QNetworkRequest
import json
import urllib.parse


class MapTilerGeocoder(QObject):
    resultReady = pyqtSignal(str, float, float)   # address, lon, lat
    errorOccurred = pyqtSignal(str, str)          # address, error message

    def __init__(self, api_key, parent=None):
        super().__init__(parent)
        self.api_key = api_key
        self.manager = QNetworkAccessManager(self)

    def geocode(self, address):
        encoded = urllib.parse.quote(address)
        url = (
            f"https://api.maptiler.com/geocoding/{encoded}.json"
            f"?key={self.api_key}"
        )

        request = QNetworkRequest(QUrl(url))
        reply = self.manager.get(request)
        # Bind reply/address per invocation so the slot always sees the matching QNetworkReply
        # (and avoid callbacks after the loop variable would otherwise drift).
        reply.finished.connect(lambda r=reply, a=address: self._handleReply(a, r))

    def _handleReply(self, address, reply):
        if reply.error():
            self.errorOccurred.emit(address, reply.errorString())
            reply.deleteLater()
            return

        data = reply.readAll().data()
        reply.deleteLater()

        try:
            js = json.loads(data)
            features = js.get("features", [])
            if not features:
                self.errorOccurred.emit(address, "No results found")
                return

            # MapTiler returns [lon, lat]
            lon, lat = features[0]["center"]
            self.resultReady.emit(address, lon, lat)

        except Exception as e:
            self.errorOccurred.emit(address, str(e))


class GoogleGeocoder(QObject):
    """Google Geocoding API. Same signals as MapTilerGeocoder (address, lon, lat)."""

    resultReady = pyqtSignal(str, float, float)
    errorOccurred = pyqtSignal(str, str)

    def __init__(self, api_key, parent=None):
        super().__init__(parent)
        self.api_key = api_key
        self.manager = QNetworkAccessManager(self)

    def geocode(self, address):
        encoded = urllib.parse.quote(address)
        url = (
            "https://maps.googleapis.com/maps/api/geocode/json"
            f"?address={encoded}&key={self.api_key}"
        )
        request = QNetworkRequest(QUrl(url))
        reply = self.manager.get(request)
        reply.finished.connect(lambda r=reply, a=address: self._handleReply(a, r))

    def _handleReply(self, address, reply):
        if reply.error():
            self.errorOccurred.emit(address, reply.errorString())
            reply.deleteLater()
            return

        data = reply.readAll().data()
        reply.deleteLater()

        try:
            js = json.loads(data)
            status = js.get("status") or ""
            if status != "OK":
                message = js.get("error_message") or status or "No results found"
                if status == "ZERO_RESULTS":
                    message = "No results found"
                self.errorOccurred.emit(address, message)
                return

            results = js.get("results") or []
            if not results:
                self.errorOccurred.emit(address, "No results found")
                return

            loc = (results[0].get("geometry") or {}).get("location") or {}
            lat = loc.get("lat")
            lon = loc.get("lng")
            if lat is None or lon is None:
                self.errorOccurred.emit(address, "No results found")
                return
            self.resultReady.emit(address, float(lon), float(lat))

        except Exception as e:
            self.errorOccurred.emit(address, str(e))
