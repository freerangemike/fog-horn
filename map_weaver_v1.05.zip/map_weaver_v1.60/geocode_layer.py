# -*- coding: utf-8 -*-
"""Persistent geocoded points layer (GeoPackage beside the QGIS project file)."""

from __future__ import annotations

import os
import shutil
import tempfile
import time
import uuid

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsDataProvider,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.PyQt import sip
from qgis.PyQt.QtCore import QSettings, QVariant
from qgis.PyQt.QtGui import QColor

from .route_arcs_project_blob import MAP_WEAVER_PROJECT_SCOPE

GEOCODE_LAYER_CUSTOM_PROPERTY = "map_weaver/is_geocode_points_layer"
GEOCODE_LAYER_CUSTOM_VALUE = "1"
GEOCODE_LAYER_DISPLAY_NAME = "Geocoded Points"
GEOCODE_GPKG_BASENAME = "geocoded_points.gpkg"
GEOCODE_GPKG_LAYER_NAME = "geocoded_points"
GEOCODE_POINTS_REL_PATH_ENTRY = "geocode_points_gpkg_relpath"
GEOCODE_STAGING_ID_ENTRY = "geocode_staging_id"
GEOCODE_STAGING_ROOT_SETTINGS_KEY = "geocode_staging_root"
GEOCODE_STAGING_ROOT_BASENAME = "map_weaver_geocode"
GEOCODE_LAYER_GPKG_FILE_PROP = "map_weaver/geocode_gpkg_file"
GEOCODE_LAYER_DISPLAY_NAME_PROP = "map_weaver/geocode_display_name"
# Written on project save when a geocode layer is present (survives layer rename).
GEOCODE_LAYER_PRESENT_ENTRY = "geocode_layer_present"
GEOCODE_CRS_AUTHID = "EPSG:4326"


def mark_geocode_layer(lyr: QgsVectorLayer) -> None:
    if lyr is None:
        return
    try:
        lyr.setCustomProperty(
            GEOCODE_LAYER_CUSTOM_PROPERTY, GEOCODE_LAYER_CUSTOM_VALUE
        )
    except Exception:
        pass


def set_geocode_layer_gpkg_file(lyr: QgsVectorLayer, gpkg_path: str) -> None:
    """Remember which sidecar GPKG this layer uses (supports multiple geocode layers)."""
    if lyr is None or not gpkg_path:
        return
    try:
        lyr.setCustomProperty(
            GEOCODE_LAYER_GPKG_FILE_PROP,
            os.path.basename(os.path.normpath(gpkg_path)),
        )
    except Exception:
        pass


def read_geocode_layer_display_name(lyr: QgsVectorLayer) -> str | None:
    if lyr is None:
        return None
    try:
        saved = str(lyr.customProperty(GEOCODE_LAYER_DISPLAY_NAME_PROP, "") or "").strip()
        if saved:
            return saved
    except Exception:
        pass
    try:
        name = (lyr.name() or "").strip()
        if name and name != GEOCODE_GPKG_LAYER_NAME:
            return name
    except Exception:
        pass
    return None


def set_geocode_layer_display_name(lyr: QgsVectorLayer, name: str | None) -> None:
    """Persist the user-visible layer name (survives relink/reopen)."""
    if lyr is None:
        return
    clean = (name or "").strip()
    if not clean or clean == GEOCODE_GPKG_LAYER_NAME:
        clean = GEOCODE_LAYER_DISPLAY_NAME
    try:
        lyr.setName(clean)
        lyr.setCustomProperty(GEOCODE_LAYER_DISPLAY_NAME_PROP, clean)
    except Exception:
        pass


def restore_geocode_layer_display_name(lyr: QgsVectorLayer) -> None:
    saved = read_geocode_layer_display_name(lyr)
    if not saved:
        return
    try:
        if lyr.name() != saved:
            lyr.setName(saved)
    except Exception:
        pass


def has_geocode_tag(lyr: QgsVectorLayer) -> bool:
    try:
        return (
            str(lyr.customProperty(GEOCODE_LAYER_CUSTOM_PROPERTY, "") or "")
            == GEOCODE_LAYER_CUSTOM_VALUE
        )
    except Exception:
        return False


def is_geocode_points_layer(lyr) -> bool:
    if lyr is None or not isinstance(lyr, QgsVectorLayer):
        return False
    try:
        if sip.isdeleted(lyr):
            return False
    except Exception:
        return False
    try:
        if lyr.geometryType() != QgsWkbTypes.PointGeometry:
            return False
    except Exception:
        return False
    if has_geocode_tag(lyr):
        return True
    try:
        if lyr.name() == GEOCODE_LAYER_DISPLAY_NAME:
            return True
    except Exception:
        pass
    return False


def project_data_directory(project=None) -> str | None:
    """Folder containing the .qgz/.qgs, else QgsProject.homePath() when set."""
    project = project or QgsProject.instance()
    try:
        path = project.absoluteFilePath()
        if path:
            d = os.path.dirname(os.path.abspath(path))
            if d and os.path.isdir(d):
                return d
    except Exception:
        pass
    try:
        hp = project.homePath()
        if hp:
            d = os.path.abspath(hp)
            if os.path.isdir(d):
                return d
    except Exception:
        pass
    return None


def default_geocode_staging_root() -> str:
    return os.path.normpath(
        os.path.join(tempfile.gettempdir(), GEOCODE_STAGING_ROOT_BASENAME)
    )


def read_geocode_staging_root_setting() -> str:
    """Configured staging root, or default when unset/invalid."""
    try:
        s = QSettings()
        s.beginGroup(MAP_WEAVER_PROJECT_SCOPE)
        raw = s.value(GEOCODE_STAGING_ROOT_SETTINGS_KEY, "", type=str)
    except Exception:
        raw = ""
    path = str(raw or "").strip()
    if path:
        return os.path.normpath(path)
    return default_geocode_staging_root()


def read_geocode_staging_root_override() -> str | None:
    """Custom staging root from settings, or None when using the default."""
    try:
        s = QSettings()
        s.beginGroup(MAP_WEAVER_PROJECT_SCOPE)
        raw = s.value(GEOCODE_STAGING_ROOT_SETTINGS_KEY, "", type=str)
    except Exception:
        raw = ""
    path = str(raw or "").strip()
    if not path:
        return None
    return os.path.normpath(path)


def write_geocode_staging_root_setting(path: str | None) -> None:
    """Persist custom staging root; empty/None clears to default."""
    try:
        s = QSettings()
        s.beginGroup(MAP_WEAVER_PROJECT_SCOPE)
        cleaned = str(path or "").strip()
        if cleaned:
            s.setValue(
                GEOCODE_STAGING_ROOT_SETTINGS_KEY, os.path.normpath(cleaned)
            )
        else:
            s.remove(GEOCODE_STAGING_ROOT_SETTINGS_KEY)
    except Exception:
        pass


def validate_geocode_staging_root(path: str) -> str | None:
    """Return an error message, or None when the folder can be used."""
    cleaned = str(path or "").strip()
    if not cleaned:
        return None
    norm = os.path.normpath(cleaned)
    if not os.path.isabs(norm):
        return "The staging folder must be an absolute path."
    try:
        os.makedirs(norm, exist_ok=True)
    except OSError as exc:
        return "Could not create the staging folder: {}".format(exc)
    probe = os.path.join(norm, ".map_weaver_write_test")
    try:
        with open(probe, "w", encoding="utf-8") as handle:
            handle.write("ok")
        os.remove(probe)
    except OSError as exc:
        return "The staging folder is not writable: {}".format(exc)
    return None


def _geocode_staging_root() -> str:
    return read_geocode_staging_root_setting()


def _read_geocode_staging_id(project=None) -> str:
    project = project or QgsProject.instance()
    try:
        raw, ok = project.readEntry(
            MAP_WEAVER_PROJECT_SCOPE, GEOCODE_STAGING_ID_ENTRY, ""
        )
        if ok and str(raw or "").strip():
            return str(raw).strip()
    except Exception:
        pass
    return ""


def _geocode_staging_id(project=None) -> str:
    """Stable per unsaved-project session id (stored in project entries)."""
    project = project or QgsProject.instance()
    sid = _read_geocode_staging_id(project)
    if sid:
        return sid
    sid = uuid.uuid4().hex
    try:
        project.writeEntry(MAP_WEAVER_PROJECT_SCOPE, GEOCODE_STAGING_ID_ENTRY, sid)
    except Exception:
        pass
    return sid


def geocode_staging_directory(project=None) -> str:
    """Temp folder for geocode GPKG when the project has not been saved yet."""
    _geocode_staging_id(project)
    return _geocode_staging_directory_path(project, create=True)


def _geocode_staging_directory_path(project=None, create: bool = False) -> str:
    project = project or QgsProject.instance()
    sid = _read_geocode_staging_id(project)
    if not sid:
        return ""
    base = os.path.join(_geocode_staging_root(), sid)
    if create:
        os.makedirs(base, exist_ok=True)
    return base


def _layer_source_gpkg_path(lyr: QgsVectorLayer) -> str | None:
    try:
        src = str(lyr.source() or "").split("|")[0]
        return os.path.normpath(src) if src else None
    except Exception:
        return None


def _resolve_gpkg_path(
    path: str | None,
    project: QgsProject | None = None,
    project_folder: str | None = None,
) -> str | None:
    """Resolve a project-relative or absolute GPKG path to an existing file."""
    if not path:
        return None
    raw = str(path).split("|")[0].strip()
    if not raw:
        return None
    project = project or QgsProject.instance()
    if not project_folder:
        project_folder = project_data_directory(project)

    if os.path.isabs(raw):
        norm = os.path.normpath(raw)
        return norm if os.path.isfile(norm) else None

    try:
        read = project.readPath(raw)
        if read:
            norm = os.path.normpath(read)
            if os.path.isfile(norm):
                return norm
    except Exception:
        pass

    rel = raw.lstrip("./\\")
    basename = os.path.basename(rel)
    if project_folder:
        for name in (rel, basename):
            candidate = os.path.normpath(os.path.join(project_folder, name))
            if os.path.isfile(candidate):
                return candidate
    return None


def _is_path_under_dir(path: str, directory: str) -> bool:
    try:
        path = os.path.normpath(path)
        directory = os.path.normpath(directory)
        return os.path.commonpath([path, directory]) == directory
    except (ValueError, TypeError):
        return False


def _project_gpkg_basename_for_layer(lyr: QgsVectorLayer) -> str | None:
    if lyr is None:
        return None
    # Custom prop is authoritative for multi-layer projects — QGIS often stores the
    # same relative datasource (./geocoded_points.gpkg) on every geocode layer.
    try:
        basename = str(lyr.customProperty(GEOCODE_LAYER_GPKG_FILE_PROP, "") or "").strip()
        if basename:
            return os.path.basename(basename)
    except Exception:
        pass
    src = _layer_source_gpkg_path(lyr)
    if src:
        base = os.path.basename(src)
        if _is_geocode_sidecar_filename(base):
            return base
    return None


def _project_gpkg_path_for_layer(lyr: QgsVectorLayer, project_folder: str) -> str | None:
    basename = _project_gpkg_basename_for_layer(lyr)
    if not basename:
        return None
    return os.path.normpath(os.path.join(project_folder, basename))


def _resolved_layer_gpkg_path(
    lyr: QgsVectorLayer,
    project: QgsProject | None = None,
    project_folder: str | None = None,
) -> str | None:
    """Best-effort absolute path to the GPKG backing a geocode layer."""
    project = project or QgsProject.instance()
    if not project_folder:
        project_folder = project_data_directory(project)

    prop_basename = None
    try:
        prop_basename = str(
            lyr.customProperty(GEOCODE_LAYER_GPKG_FILE_PROP, "") or ""
        ).strip()
        if prop_basename:
            prop_basename = os.path.basename(prop_basename)
    except Exception:
        prop_basename = None

    raw = _layer_source_gpkg_path(lyr)
    source_resolved = (
        _resolve_gpkg_path(raw, project, project_folder) if raw else None
    )
    source_base = os.path.basename(raw) if raw else None
    if source_base:
        source_base = os.path.basename(str(source_base).split("|")[0])

    # When source basename matches the layer's sidecar id, trust the live source.
    if source_resolved and os.path.isfile(source_resolved):
        resolved_base = os.path.basename(source_resolved)
        if (
            not prop_basename
            or resolved_base == prop_basename
            or source_base == prop_basename
        ):
            return os.path.normpath(source_resolved)

    # Otherwise prefer the unique sidecar beside the project (prop / basename).
    if project_folder and prop_basename:
        prop_path = os.path.normpath(os.path.join(project_folder, prop_basename))
        if os.path.isfile(prop_path):
            return prop_path

    if source_resolved and os.path.isfile(source_resolved):
        return os.path.normpath(source_resolved)
    return None


def _layer_already_linked_to_gpkg(lyr: QgsVectorLayer, gpkg_path: str) -> bool:
    """True when the map layer is valid and already reading this GPKG file."""
    if lyr is None or not gpkg_path or not os.path.isfile(gpkg_path):
        return False
    try:
        if not lyr.isValid():
            return False
    except Exception:
        return False
    target = os.path.normpath(gpkg_path)
    src = _layer_source_gpkg_path(lyr)
    if src and os.path.normpath(src) == target:
        return True
    try:
        source = (lyr.source() or "").replace("\\", "/")
        if target.replace("\\", "/") in source:
            return True
        uri = _gpkg_layer_uri(gpkg_path).replace("\\", "/")
        if uri in source:
            return True
    except Exception:
        pass
    return False


def _active_geocode_gpkg_basenames(project=None) -> set[str]:
    project = project or QgsProject.instance()
    basenames: set[str] = set()
    for lyr in geocode_layers_for_project_io(project):
        try:
            prop = str(lyr.customProperty(GEOCODE_LAYER_GPKG_FILE_PROP, "") or "").strip()
            if prop:
                basenames.add(os.path.basename(prop))
        except Exception:
            pass
        src = _layer_source_gpkg_path(lyr)
        if src:
            base = os.path.basename(src)
            if _is_geocode_sidecar_filename(base):
                basenames.add(base)
        basename = _project_gpkg_basename_for_layer(lyr)
        if basename:
            basenames.add(basename)
    return basenames


def find_geocode_sidecar_by_basename(basename: str, project=None) -> str | None:
    """Locate a geocode GPKG by basename beside the project or under staging."""
    if not basename or not _is_geocode_sidecar_filename(basename):
        return None
    project = project or QgsProject.instance()
    folder = project_data_directory(project)
    if folder:
        candidate = os.path.normpath(os.path.join(folder, basename))
        if os.path.isfile(candidate):
            return candidate

    roots: list[str] = []
    for root in (
        read_geocode_staging_root_setting(),
        default_geocode_staging_root(),
    ):
        norm = os.path.normpath(root)
        if norm not in roots:
            roots.append(norm)

    matches: list[tuple[float, str]] = []
    for root in roots:
        if not os.path.isdir(root):
            continue
        try:
            sessions = os.listdir(root)
        except OSError:
            continue
        for session_id in sessions:
            path = os.path.normpath(os.path.join(root, session_id, basename))
            if not os.path.isfile(path):
                continue
            try:
                mtime = os.path.getmtime(path)
            except OSError:
                mtime = 0
            matches.append((mtime, path))
    if not matches:
        return None
    matches.sort(key=lambda item: item[0], reverse=True)
    return matches[0][1]


def ensure_geocode_sidecar_beside_project(
    basename: str, project=None, project_folder: str | None = None
) -> str | None:
    """Return project-folder path for basename, copying from staging when needed."""
    if not basename or not _is_geocode_sidecar_filename(basename):
        return None
    project = project or QgsProject.instance()
    if not project_folder:
        project_folder = project_data_directory(project)
    if not project_folder:
        return None
    dest = os.path.normpath(os.path.join(project_folder, basename))
    if os.path.isfile(dest):
        return dest
    found = find_geocode_sidecar_by_basename(basename, project)
    if not found or os.path.normpath(found) == dest:
        return dest if os.path.isfile(dest) else None
    try:
        os.makedirs(project_folder, exist_ok=True)
        shutil.copy2(found, dest)
    except Exception:
        return None
    return dest if os.path.isfile(dest) else None


def _active_geocode_gpkg_paths(
    project=None, project_folder: str | None = None
) -> set[str]:
    project = project or QgsProject.instance()
    if not project_folder:
        project_folder = project_data_directory(project)
    paths: set[str] = set()
    for lyr in geocode_layers_for_project_io(project):
        src = _resolved_layer_gpkg_path(lyr, project, project_folder)
        if src:
            paths.add(os.path.normpath(src))
        if project_folder:
            dest = _project_gpkg_path_for_layer(lyr, project_folder)
            if dest:
                paths.add(os.path.normpath(dest))
    return paths


def _is_geocode_sidecar_filename(name: str) -> bool:
    low = (name or "").lower()
    return low.startswith("geocoded_points") and low.endswith(".gpkg")


def cleanup_unreferenced_geocode_gpkg_files(
    project=None, folders: list[str] | None = None
) -> None:
    """Delete geocode GPKG sidecars not referenced by any layer currently on the map."""
    project = project or QgsProject.instance()
    project_folder = project_data_directory(project)
    active_basenames = _active_geocode_gpkg_basenames(project)

    scan: set[str] = set()
    if folders:
        for folder in folders:
            if folder:
                scan.add(os.path.normpath(folder))
    if project_folder:
        scan.add(os.path.normpath(project_folder))

    for folder in scan:
        if not folder or not os.path.isdir(folder):
            continue
        try:
            names = os.listdir(folder)
        except Exception:
            continue
        for name in names:
            if not _is_geocode_sidecar_filename(name):
                continue
            if name in active_basenames:
                continue
            path = os.path.normpath(os.path.join(folder, name))
            try:
                os.remove(path)
            except Exception:
                pass


def _layers_still_using_staging(
    project: QgsProject, project_folder: str | None, staging_norm: str
) -> bool:
    for lyr in geocode_layers_for_project_io(project):
        src = _resolved_layer_gpkg_path(lyr, project, project_folder)
        if src and _is_path_under_dir(src, staging_norm):
            return True
    return False


def clear_geocode_staging_for_project(project=None) -> None:
    """Remove temp staging folder/id after layers have been copied beside the project."""
    project = project or QgsProject.instance()
    sid = _read_geocode_staging_id(project)
    try:
        project.writeEntry(MAP_WEAVER_PROJECT_SCOPE, GEOCODE_STAGING_ID_ENTRY, "")
    except Exception:
        pass
    if not sid:
        return
    staging = os.path.join(_geocode_staging_root(), sid)
    if os.path.isdir(staging):
        shutil.rmtree(staging, ignore_errors=True)


def cleanup_stale_geocode_staging_directories(
    max_age_days: int = 30, project=None
) -> None:
    """On startup, drop abandoned temp staging folders older than ``max_age_days``."""
    root = _geocode_staging_root()
    if not os.path.isdir(root):
        return
    try:
        max_age_s = max(1, int(max_age_days)) * 86400
    except (TypeError, ValueError):
        max_age_s = 30 * 86400
    cutoff = time.time() - max_age_s
    keep_id = _read_geocode_staging_id(project)
    try:
        names = os.listdir(root)
    except Exception:
        return
    for name in names:
        if keep_id and name == keep_id:
            continue
        path = os.path.join(root, name)
        if not os.path.isdir(path):
            continue
        try:
            mtime = os.path.getmtime(path)
        except Exception:
            continue
        if mtime > cutoff:
            continue
        shutil.rmtree(path, ignore_errors=True)


def geocode_storage_directory(project=None) -> str | None:
    """Project folder when saved; otherwise temp staging until first save."""
    folder = project_data_directory(project)
    if folder:
        return folder
    try:
        return geocode_staging_directory(project)
    except Exception:
        return None


def default_geocode_gpkg_relpath() -> str:
    return GEOCODE_GPKG_BASENAME


def read_geocode_gpkg_relpath(project=None) -> str:
    project = project or QgsProject.instance()
    try:
        raw, ok = project.readEntry(
            MAP_WEAVER_PROJECT_SCOPE, GEOCODE_POINTS_REL_PATH_ENTRY, ""
        )
        if ok and str(raw or "").strip():
            return str(raw).strip().replace("\\", "/")
    except Exception:
        pass
    return default_geocode_gpkg_relpath()


def write_geocode_gpkg_relpath(project, relpath: str) -> None:
    if project is None:
        return
    rel = str(relpath or default_geocode_gpkg_relpath()).strip().replace("\\", "/")
    try:
        project.writeEntry(MAP_WEAVER_PROJECT_SCOPE, GEOCODE_POINTS_REL_PATH_ENTRY, rel)
    except Exception:
        pass


def read_geocode_layer_present_stamp(project=None) -> bool:
    project = project or QgsProject.instance()
    try:
        raw, ok = project.readEntry(
            MAP_WEAVER_PROJECT_SCOPE, GEOCODE_LAYER_PRESENT_ENTRY, ""
        )
        if ok and str(raw or "").strip().lower() in ("1", "true", "yes", "on"):
            return True
    except Exception:
        pass
    return False


def write_geocode_layer_present_stamp(project, present: bool) -> None:
    if project is None:
        return
    try:
        project.writeEntry(
            MAP_WEAVER_PROJECT_SCOPE,
            GEOCODE_LAYER_PRESENT_ENTRY,
            "1" if present else "",
        )
    except Exception:
        pass


def _geocode_schema_ok(lyr: QgsVectorLayer) -> bool:
    try:
        return lyr.fields().lookupField("address") >= 0
    except Exception:
        return False


def _layer_source_matches_geocode_gpkg(lyr: QgsVectorLayer, gpkg_path: str | None) -> bool:
    if not gpkg_path or lyr is None:
        return False
    try:
        src = os.path.normpath(lyr.source()).lower()
        gpkg = os.path.normpath(gpkg_path).lower()
        if gpkg in src:
            return True
        base = os.path.basename(gpkg)
        if base and base in src:
            return True
    except Exception:
        pass
    return False


def adopt_geocode_layers_in_project(project=None) -> None:
    """Tag point layers that use a Mapestry geocode GeoPackage (e.g. after open/rename)."""
    project = project or QgsProject.instance()
    gpkg = geocode_gpkg_absolute_path(project)
    folder = project_data_directory(project)
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer):
            continue
        try:
            if sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        try:
            if lyr.geometryType() != QgsWkbTypes.PointGeometry:
                continue
        except Exception:
            continue
        if has_geocode_tag(lyr):
            continue
        basename = str(lyr.customProperty(GEOCODE_LAYER_GPKG_FILE_PROP, "") or "").strip()
        if basename and folder:
            candidate = os.path.normpath(os.path.join(folder, basename))
            if _layer_source_matches_geocode_gpkg(lyr, candidate):
                mark_geocode_layer(lyr)
                continue
        if _layer_source_matches_geocode_gpkg(lyr, gpkg):
            mark_geocode_layer(lyr)
            continue
        if _geocode_schema_ok(lyr):
            src = _layer_source_gpkg_path(lyr)
            if src:
                base = os.path.basename(src).lower()
                if base.startswith("geocoded_points") and base.endswith(".gpkg"):
                    mark_geocode_layer(lyr)
                    set_geocode_layer_gpkg_file(lyr, src)
                    continue
            if gpkg:
                try:
                    if GEOCODE_GPKG_BASENAME.lower() in lyr.source().lower():
                        mark_geocode_layer(lyr)
                except Exception:
                    pass


def project_has_geocode_points_layer(project=None) -> bool:
    """
    True only when a geocode layer is in the current project (tag on map layer).
    Does not treat an on-disk GeoPackage or save stamp as “present” after the user
    removed the layer from the map.
    """
    project = project or QgsProject.instance()
    adopt_geocode_layers_in_project(project)
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer):
            continue
        try:
            if sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        if has_geocode_tag(lyr):
            return True
    return False


def note_geocode_layer_removed_from_project(project=None) -> None:
    """User removed the geocode layer from the project; do not resurrect on save/load."""
    write_geocode_layer_present_stamp(project, False)


def geocode_gpkg_absolute_path(project=None) -> str | None:
    project = project or QgsProject.instance()
    folder = geocode_storage_directory(project)
    if not folder:
        return None
    rel = read_geocode_gpkg_relpath(project)
    return os.path.normpath(os.path.join(folder, rel))


def _gpkg_layer_uri(gpkg_path: str) -> str:
    return f"{gpkg_path}|layername={GEOCODE_GPKG_LAYER_NAME}"


def _load_gpkg_layer(gpkg_path: str, display_name: str | None = None) -> QgsVectorLayer | None:
    if not gpkg_path or not os.path.isfile(gpkg_path):
        return None
    layer_title = display_name or GEOCODE_LAYER_DISPLAY_NAME
    lyr = QgsVectorLayer(
        _gpkg_layer_uri(gpkg_path), layer_title, "ogr"
    )
    if lyr.isValid():
        return lyr
    lyr = QgsVectorLayer(gpkg_path, layer_title, "ogr")
    if lyr.isValid():
        return lyr
    return None


def _iter_map_layers_top_to_bottom(project=None) -> list:
    """Map layers in legend order (top → bottom), including nested groups."""
    project = project or QgsProject.instance()
    ordered: list = []

    def walk(node) -> None:
        for child in node.children():
            try:
                if hasattr(child, "layer"):
                    lyr = child.layer()
                    if lyr is not None:
                        ordered.append(lyr)
                        continue
            except Exception:
                pass
            try:
                walk(child)
            except Exception:
                pass

    try:
        walk(project.layerTreeRoot())
    except Exception:
        return list(project.mapLayers().values())
    return ordered


def resolve_geocode_target_crs(project=None) -> QgsCoordinateReferenceSystem:
    """
    CRS for a newly created geocode layer:
      1) project CRS, if valid (keeps map + layer aligned; avoids reopen prompts)
      2) topmost point layer CRS, if any
      3) else bottommost layer CRS, if any
      4) else geocoder default (EPSG:4326)
    """
    project = project or QgsProject.instance()
    default = QgsCoordinateReferenceSystem(GEOCODE_CRS_AUTHID)
    try:
        proj_crs = project.crs()
        if proj_crs is not None and proj_crs.isValid():
            return proj_crs
    except Exception:
        pass
    layers = _iter_map_layers_top_to_bottom(project)
    for lyr in layers:
        try:
            if sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        try:
            if lyr.geometryType() != QgsWkbTypes.PointGeometry:
                continue
        except Exception:
            continue
        try:
            crs = lyr.crs()
            if crs is not None and crs.isValid():
                return crs
        except Exception:
            continue
    if layers:
        try:
            crs = layers[-1].crs()
            if crs is not None and crs.isValid():
                return crs
        except Exception:
            pass
    return default


def _autopick_transformations_enabled() -> bool:
    try:
        from .plugin_settings_dialog import read_autopick_transformations

        return bool(read_autopick_transformations())
    except Exception:
        return True


def _crs_pair_needs_transform(
    source_crs: QgsCoordinateReferenceSystem | None,
    dest_crs: QgsCoordinateReferenceSystem | None,
) -> bool:
    if source_crs is None or dest_crs is None:
        return False
    try:
        if not source_crs.isValid() or not dest_crs.isValid():
            return False
    except Exception:
        return False
    try:
        if source_crs == dest_crs:
            return False
    except Exception:
        pass
    try:
        a = (source_crs.authid() or "").strip().upper()
        b = (dest_crs.authid() or "").strip().upper()
        if a and b and a == b:
            return False
    except Exception:
        pass
    return True


def _first_available_operation(source_crs, dest_crs):
    """
    Same choice users get when they click OK on the first row of Select Transformation.
    Returns (proj_string, allow_fallback) or ("", True).
    """
    try:
        from qgis.gui import QgsCoordinateOperationWidget

        w = QgsCoordinateOperationWidget()
        w.setSourceCrs(source_crs)
        w.setDestinationCrs(dest_crs)
        ops = w.availableOperations()
        if not ops:
            return "", True
        op = ops[0]
        proj = getattr(op, "proj", None) or ""
        allow = True
        try:
            allow = bool(getattr(op, "allowFallback", True))
        except Exception:
            allow = True
        return str(proj or ""), allow
    except Exception:
        return "", True


def _context_missing_pair(ctx, src, dst) -> bool:
    try:
        if hasattr(ctx, "hasTransform") and ctx.hasTransform(src, dst):
            return False
    except Exception:
        pass
    return True


def _register_pair_on_context(ctx, source_crs, dest_crs) -> bool:
    """Add default ops both directions. Returns True if context was modified."""
    if not _crs_pair_needs_transform(source_crs, dest_crs):
        return False
    changed = False
    for src, dst in ((source_crs, dest_crs), (dest_crs, source_crs)):
        if not _context_missing_pair(ctx, src, dst):
            continue
        proj, allow = _first_available_operation(src, dst)
        try:
            if ctx.addCoordinateOperation(src, dst, proj, allow):
                changed = True
        except Exception:
            try:
                if ctx.addCoordinateOperation(src, dst, "", True):
                    changed = True
            except Exception:
                pass
    return changed


def ensure_default_datum_transform(
    source_crs: QgsCoordinateReferenceSystem | None,
    dest_crs: QgsCoordinateReferenceSystem | None,
    project=None,
) -> None:
    """
    Register the default PROJ operation for ``source_crs`` ↔ ``dest_crs`` on the
    project so QGIS does not show “Select Transformation” later (e.g. on reopen).
    """
    if not _autopick_transformations_enabled():
        return
    if not _crs_pair_needs_transform(source_crs, dest_crs):
        return
    project = project or QgsProject.instance()
    try:
        ctx = project.transformContext()
    except Exception:
        return
    if not _register_pair_on_context(ctx, source_crs, dest_crs):
        return
    try:
        project.setTransformContext(ctx)
    except Exception:
        pass


def ensure_geocode_layer_transforms(lyr: QgsVectorLayer, project=None) -> None:
    """Register transforms between geocoder WGS84, the layer CRS, and the project CRS."""
    if lyr is None:
        return
    if not _autopick_transformations_enabled():
        return
    project = project or QgsProject.instance()
    try:
        layer_crs = lyr.crs()
    except Exception:
        layer_crs = None
    wgs = QgsCoordinateReferenceSystem(GEOCODE_CRS_AUTHID)
    ensure_default_datum_transform(wgs, layer_crs, project=project)
    try:
        ensure_default_datum_transform(layer_crs, project.crs(), project=project)
    except Exception:
        pass


def ensure_layers_project_transforms(layers, project=None) -> None:
    """Register default transforms for newly added layers vs the project CRS."""
    if not layers:
        return
    if not _autopick_transformations_enabled():
        return
    project = project or QgsProject.instance()
    try:
        dest = project.crs()
    except Exception:
        return
    if dest is None or not dest.isValid():
        return
    try:
        ctx = project.transformContext()
    except Exception:
        return
    changed = False
    for lyr in layers:
        try:
            if lyr is None or sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        try:
            if _register_pair_on_context(ctx, lyr.crs(), dest):
                changed = True
        except Exception:
            continue
    if changed:
        try:
            project.setTransformContext(ctx)
        except Exception:
            pass


def ensure_project_layer_transforms(project=None) -> None:
    """
    Register default PROJ operations between every map layer CRS and the project CRS.

    Prevents QGIS “Select Transformation” prompts on reopen when layers (Route Arcs,
    geocode, projected buffers, etc.) do not match the project CRS. Equivalent to
    users always accepting the first (default) transformation choice.
    """
    if not _autopick_transformations_enabled():
        return
    project = project or QgsProject.instance()
    try:
        dest = project.crs()
    except Exception:
        return
    if dest is None or not dest.isValid():
        return
    try:
        ctx = project.transformContext()
    except Exception:
        return
    changed = False
    for lyr in project.mapLayers().values():
        try:
            if sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        try:
            if _register_pair_on_context(ctx, lyr.crs(), dest):
                changed = True
        except Exception:
            continue
    if changed:
        try:
            project.setTransformContext(ctx)
        except Exception:
            pass


def _crs_authid_or_default(crs: QgsCoordinateReferenceSystem | None) -> str:
    if crs is not None:
        try:
            if crs.isValid():
                auth = (crs.authid() or "").strip()
                if auth:
                    return auth
        except Exception:
            pass
    return GEOCODE_CRS_AUTHID


def transform_geocode_lonlat_to_layer_xy(
    layer: QgsVectorLayer, lon: float, lat: float
) -> tuple[float, float] | None:
    """Map geocoder WGS84 lon/lat into the layer's CRS. None on failure."""
    if layer is None:
        return None
    try:
        dst = layer.crs()
    except Exception:
        dst = None
    src = QgsCoordinateReferenceSystem(GEOCODE_CRS_AUTHID)
    if dst is None or not dst.isValid() or dst == src:
        return (float(lon), float(lat))
    try:
        if (dst.authid() or "").strip().upper() == GEOCODE_CRS_AUTHID.upper():
            return (float(lon), float(lat))
    except Exception:
        pass
    ensure_default_datum_transform(src, dst)
    try:
        xform = QgsCoordinateTransform(
            src, dst, QgsProject.instance().transformContext()
        )
        pt = xform.transform(QgsPointXY(float(lon), float(lat)))
        return (pt.x(), pt.y())
    except Exception:
        return None


def transform_layer_xy_to_geocode_lonlat(
    layer: QgsVectorLayer, x: float, y: float
) -> tuple[float, float] | None:
    """Map a point in the layer's CRS back to WGS84 lon/lat."""
    if layer is None:
        return None
    try:
        src = layer.crs()
    except Exception:
        src = None
    dst = QgsCoordinateReferenceSystem(GEOCODE_CRS_AUTHID)
    if src is None or not src.isValid() or src == dst:
        return (float(x), float(y))
    try:
        if (src.authid() or "").strip().upper() == GEOCODE_CRS_AUTHID.upper():
            return (float(x), float(y))
    except Exception:
        pass
    ensure_default_datum_transform(src, dst)
    try:
        xform = QgsCoordinateTransform(
            src, dst, QgsProject.instance().transformContext()
        )
        pt = xform.transform(QgsPointXY(float(x), float(y)))
        return (pt.x(), pt.y())
    except Exception:
        return None


def _create_empty_geocode_gpkg(
    gpkg_path: str, crs: QgsCoordinateReferenceSystem | None = None
) -> bool:
    parent = os.path.dirname(gpkg_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    crs_auth = _crs_authid_or_default(crs)
    target_crs = (
        crs
        if crs is not None and crs.isValid()
        else QgsCoordinateReferenceSystem(GEOCODE_CRS_AUTHID)
    )
    mem = QgsVectorLayer(
        f"Point?crs={crs_auth}", GEOCODE_GPKG_LAYER_NAME, "memory"
    )
    pr = mem.dataProvider()
    pr.addAttributes([QgsField("address", QVariant.String)])
    mem.updateFields()
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = GEOCODE_GPKG_LAYER_NAME
    options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
    project = QgsProject.instance()
    ctx = project.transformContext() if project else None
    try:
        err, _warnings, _path, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
            mem, gpkg_path, ctx, options
        )
        if err[0] == QgsVectorFileWriter.NoError:
            return True
    except Exception:
        pass
    try:
        err = QgsVectorFileWriter.writeAsVectorFormat(
            mem,
            gpkg_path,
            "UTF-8",
            target_crs,
            "GPKG",
        )
        return err[0] == QgsVectorFileWriter.NoError
    except Exception:
        return False


def apply_geocode_layer_point_color(lyr: QgsVectorLayer, color: QColor) -> None:
    if lyr is None or color is None or not color.isValid():
        return
    try:
        sym = lyr.renderer().symbol()
        if sym is not None:
            sym.setColor(color)
            lyr.triggerRepaint()
    except Exception:
        pass


def geocode_layer_point_color(lyr: QgsVectorLayer) -> QColor | None:
    """Current point/marker color for a geocode layer, if readable."""
    if lyr is None:
        return None
    try:
        sym = lyr.renderer().symbol()
        if sym is None:
            return None
        c = sym.color()
        if c is not None and c.isValid():
            return c
        if sym.symbolLayerCount() > 0:
            sl = sym.symbolLayer(0)
            c = sl.color()
            if c is not None and c.isValid():
                return c
            stroke = sl.strokeColor()
            if stroke is not None and stroke.isValid():
                return stroke
    except Exception:
        pass
    return None


def _apply_point_symbol_color(lyr: QgsVectorLayer, color: QColor) -> None:
    apply_geocode_layer_point_color(lyr, color)


def _copy_features_to_layer(src: QgsVectorLayer, dest: QgsVectorLayer) -> None:
    if src is None or dest is None:
        return
    try:
        if src.featureCount() <= 0:
            return
    except Exception:
        return
    dest.startEditing()
    pr = dest.dataProvider()
    for feat in src.getFeatures():
        nf = QgsFeature(dest.fields())
        nf.setGeometry(feat.geometry())
        if "address" in nf.fields().names():
            try:
                nf["address"] = feat["address"]
            except Exception:
                pass
        pr.addFeature(nf)
    dest.commitChanges()


def _layer_looks_like_geocode_persisted(lyr: QgsVectorLayer) -> bool:
    if lyr is None:
        return False
    if has_geocode_tag(lyr):
        return True
    try:
        if lyr.customProperty(GEOCODE_LAYER_GPKG_FILE_PROP):
            return True
        if lyr.customProperty(GEOCODE_LAYER_DISPLAY_NAME_PROP):
            return True
    except Exception:
        pass
    if is_geocode_points_layer(lyr):
        return True
    src = _layer_source_gpkg_path(lyr)
    if src:
        base = os.path.basename(src).lower()
        if base.startswith("geocoded_points") and base.endswith(".gpkg"):
            return True
    return False


def geocode_layers_for_project_io(project=None) -> list[QgsVectorLayer]:
    """Geocode layers for save/migrate/repair (includes invalid/unavailable layers)."""
    project = project or QgsProject.instance()
    adopt_geocode_layers_in_project(project)
    ordered: list[QgsVectorLayer] = []
    seen: set[str] = set()

    def consider(lyr) -> None:
        if lyr is None or not isinstance(lyr, QgsVectorLayer):
            return
        if lyr.id() in seen:
            return
        if not _layer_looks_like_geocode_persisted(lyr):
            return
        mark_geocode_layer(lyr)
        seen.add(lyr.id())
        ordered.append(lyr)

    def walk(node) -> None:
        try:
            if hasattr(node, "layer"):
                consider(node.layer())
        except Exception:
            pass
        for child in node.children():
            walk(child)

    walk(project.layerTreeRoot())
    if ordered:
        return ordered
    for lyr in project.mapLayers().values():
        consider(lyr)
    return ordered


def _add_layer_to_project(lyr: QgsVectorLayer, project=None) -> QgsVectorLayer:
    project = project or QgsProject.instance()
    mark_geocode_layer(lyr)
    src = _layer_source_gpkg_path(lyr)
    if src:
        set_geocode_layer_gpkg_file(lyr, src)
    set_geocode_layer_display_name(lyr, lyr.name())
    ensure_geocode_layer_transforms(lyr, project=project)
    project.addMapLayer(lyr)
    return lyr


def list_geocode_layers_in_tree_order(project=None) -> list[QgsVectorLayer]:
    """Geocode layers in layer-tree order (top to bottom)."""
    project = project or QgsProject.instance()
    adopt_geocode_layers_in_project(project)
    ordered = []
    seen = set()

    def walk(node):
        try:
            if hasattr(node, "layer"):
                lyr = node.layer()
                if (
                    lyr is not None
                    and lyr.id() not in seen
                    and is_geocode_points_layer(lyr)
                    and has_geocode_tag(lyr)
                ):
                    mark_geocode_layer(lyr)
                    ordered.append(lyr)
                    seen.add(lyr.id())
        except Exception:
            pass
        for child in node.children():
            walk(child)

    walk(project.layerTreeRoot())
    return ordered


def find_geocode_points_layer(project=None) -> QgsVectorLayer | None:
    """Return one geocode layer (legacy). Prefer list_geocode_layers when multiple exist."""
    layers = list_geocode_layers(project)
    if not layers:
        return None
    if len(layers) == 1:
        return layers[0]
    layers.sort(key=lambda L: L.featureCount() if L else 0, reverse=True)
    return layers[0]


def list_geocode_layers(project=None) -> list[QgsVectorLayer]:
    """All tagged geocode point layers in the project (layer-tree order)."""
    return list_geocode_layers_in_tree_order(project)


def geocode_layer_by_id(layer_id: str, project=None) -> QgsVectorLayer | None:
    project = project or QgsProject.instance()
    if not layer_id:
        return None
    lyr = project.mapLayer(layer_id)
    if lyr is None or not isinstance(lyr, QgsVectorLayer):
        return None
    try:
        if sip.isdeleted(lyr):
            return None
    except Exception:
        return None
    if not is_geocode_points_layer(lyr):
        return None
    return lyr


def _geocode_address_field_name(lyr: QgsVectorLayer) -> str | None:
    idx = lyr.fields().lookupField("address")
    if idx >= 0:
        return lyr.fields().field(idx).name()
    for name in lyr.fields().names():
        if str(name).lower() == "address":
            return name
    return None


def _feature_address(feat: QgsFeature, field_name: str | None) -> str:
    if not field_name:
        return ""
    try:
        val = feat[field_name]
        return str(val if val is not None else "").strip()
    except Exception:
        try:
            val = feat.attribute(field_name)
            return str(val if val is not None else "").strip()
        except Exception:
            return ""


def geocode_layer_address_lines(lyr: QgsVectorLayer) -> list[str]:
    """Address field values for all features, in feature order."""
    if lyr is None:
        return []
    field_name = _geocode_address_field_name(lyr)
    lines = []
    for feat in lyr.getFeatures():
        lines.append(_feature_address(feat, field_name))
    return lines


def geocode_layer_address_coordinate_map(lyr: QgsVectorLayer) -> dict[str, tuple[float, float]]:
    """First feature per exact address string -> WGS84 (lon, lat)."""
    if lyr is None:
        return {}
    field_name = _geocode_address_field_name(lyr)
    if not field_name:
        return {}
    out: dict[str, tuple[float, float]] = {}
    for feat in lyr.getFeatures():
        addr = _feature_address(feat, field_name)
        if not addr or addr in out:
            continue
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            continue
        try:
            pt = geom.asPoint()
            lonlat = transform_layer_xy_to_geocode_lonlat(lyr, pt.x(), pt.y())
            if lonlat is None:
                continue
            out[addr] = lonlat
        except Exception:
            continue
    return out


def plan_geocode_layer_update(
    lyr: QgsVectorLayer, desired_addresses: list[str]
) -> tuple[list[tuple[str, float, float] | None], list[str]]:
    """
    Compare dialog addresses to the layer attribute table.

    Returns:
      preset: one entry per desired row — (address, lon, lat) when the exact
              address already exists on the layer, else None (needs geocoding)
      to_geocode: distinct addresses that require an API call, in first-seen order
    """
    existing = geocode_layer_address_coordinate_map(lyr)
    preset: list[tuple[str, float, float] | None] = []
    to_geocode: list[str] = []
    queued: set[str] = set()
    for addr in desired_addresses:
        key = (addr or "").strip()
        if not key:
            preset.append(None)
            continue
        coords = existing.get(key)
        if coords is not None:
            preset.append((key, coords[0], coords[1]))
        else:
            preset.append(None)
            if key not in queued:
                to_geocode.append(key)
                queued.add(key)
    return preset, to_geocode


def merge_geocode_update_results(
    desired_addresses: list[str],
    preset: list[tuple[str, float, float] | None],
    geocoded: dict[str, tuple[float, float]],
) -> list[tuple[str, float, float]]:
    """Build final point rows in dialog order from reused + newly geocoded addresses."""
    final: list[tuple[str, float, float]] = []
    for addr, slot in zip(desired_addresses, preset):
        key = (addr or "").strip()
        if not key:
            continue
        if slot is not None:
            final.append(slot)
            continue
        coords = geocoded.get(key)
        if coords is not None:
            final.append((key, coords[0], coords[1]))
    return final


def _used_geocode_gpkg_paths(project=None) -> set[str]:
    return _active_geocode_gpkg_paths(project)


def _next_geocode_gpkg_path(project=None) -> str | None:
    folder = geocode_storage_directory(project)
    if not folder:
        return None
    project = project or QgsProject.instance()
    cleanup_unreferenced_geocode_gpkg_files(project, [folder])
    active = _active_geocode_gpkg_basenames(project)
    for i in range(1, 1000):
        basename = GEOCODE_GPKG_BASENAME if i == 1 else f"geocoded_points_{i}.gpkg"
        if basename in active:
            continue
        return os.path.normpath(os.path.join(folder, basename))
    return None


def _next_geocode_display_name(project=None) -> str:
    project = project or QgsProject.instance()
    names = {lyr.name() for lyr in list_geocode_layers(project)}
    if GEOCODE_LAYER_DISPLAY_NAME not in names:
        return GEOCODE_LAYER_DISPLAY_NAME
    n = 2
    while f"{GEOCODE_LAYER_DISPLAY_NAME} {n}" in names:
        n += 1
    return f"{GEOCODE_LAYER_DISPLAY_NAME} {n}"


def create_new_geocode_points_layer(
    project=None, symbol_color: QColor | None = None, display_name: str | None = None
) -> tuple[QgsVectorLayer | None, str | None]:
    """Create a new geocode GPKG + map layer (does not reuse the default single-layer path)."""
    project = project or QgsProject.instance()
    gpkg_path = _next_geocode_gpkg_path(project)
    if not gpkg_path:
        return None, "create_failed"
    target_crs = resolve_geocode_target_crs(project)
    if not _create_empty_geocode_gpkg(gpkg_path, crs=target_crs):
        return None, "create_failed"
    name = (display_name or "").strip() or _next_geocode_display_name(project)
    lyr = _load_gpkg_layer(gpkg_path, display_name=name)
    if lyr is None:
        return None, "create_failed"
    if symbol_color is not None:
        _apply_point_symbol_color(lyr, symbol_color)
    return _add_layer_to_project(lyr, project), None


def replace_geocode_layer_points(
    layer: QgsVectorLayer, points: list[tuple[str, float, float]]
) -> bool:
    """Replace all features with geocoded points (update mode). Does not change layer CRS."""
    if layer is None:
        return False
    try:
        if sip.isdeleted(layer):
            return False
    except Exception:
        return False
    layer.startEditing()
    try:
        ids = [f.id() for f in layer.getFeatures()]
        if ids:
            layer.deleteFeatures(ids)
        for address, lon, lat in points:
            xy = transform_geocode_lonlat_to_layer_xy(layer, lon, lat)
            if xy is None:
                layer.rollBack()
                return False
            feat = QgsFeature(layer.fields())
            feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(xy[0], xy[1])))
            if "address" in feat.fields().names():
                feat["address"] = address
            if not layer.dataProvider().addFeature(feat):
                layer.rollBack()
                return False
        if not layer.commitChanges():
            layer.rollBack()
            return False
    except Exception:
        try:
            layer.rollBack()
        except Exception:
            pass
        return False
    layer.triggerRepaint()
    return True


def layers_being_removed_include_geocode(layers) -> bool:
    """True if any layer in a layersWillBeRemoved payload is a Mapestry geocode layer."""
    for lyr in layers or []:
        if is_geocode_points_layer(lyr) or has_geocode_tag(lyr):
            return True
    return False


def _migrate_memory_layer_to_gpkg(
    memory_lyr: QgsVectorLayer, gpkg_path: str, project=None
) -> QgsVectorLayer | None:
    project = project or QgsProject.instance()
    crs = None
    try:
        crs = memory_lyr.crs() if memory_lyr is not None else None
    except Exception:
        crs = None
    if crs is None or not crs.isValid():
        crs = resolve_geocode_target_crs(project)
    if not _create_empty_geocode_gpkg(gpkg_path, crs=crs):
        return None
    gpkg_lyr = _load_gpkg_layer(gpkg_path)
    if gpkg_lyr is None:
        return None
    _copy_features_to_layer(memory_lyr, gpkg_lyr)
    try:
        project.removeMapLayer(memory_lyr.id())
    except Exception:
        pass
    write_geocode_gpkg_relpath(project, read_geocode_gpkg_relpath(project))
    return _add_layer_to_project(gpkg_lyr, project)


def _export_geocode_layer_to_gpkg(lyr: QgsVectorLayer, gpkg_path: str) -> bool:
    """Write an open geocode layer to a GPKG (safe while the source GPKG is locked)."""
    if lyr is None or not gpkg_path:
        return False
    parent = os.path.dirname(gpkg_path)
    if parent:
        try:
            os.makedirs(parent, exist_ok=True)
        except Exception:
            return False
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = GEOCODE_GPKG_LAYER_NAME
    options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
    project = QgsProject.instance()
    ctx = project.transformContext() if project else None
    try:
        err, _warnings, _path, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
            lyr, gpkg_path, ctx, options
        )
        if err[0] == QgsVectorFileWriter.NoError:
            return os.path.isfile(gpkg_path)
    except Exception:
        pass
    try:
        err = QgsVectorFileWriter.writeAsVectorFormat(
            lyr,
            gpkg_path,
            "UTF-8",
            lyr.crs() if lyr.crs().isValid() else QgsCoordinateReferenceSystem(GEOCODE_CRS_AUTHID),
            "GPKG",
        )
        return err[0] == QgsVectorFileWriter.NoError and os.path.isfile(gpkg_path)
    except Exception:
        return False


def _relink_geocode_layer_to_gpkg(lyr: QgsVectorLayer, gpkg_path: str) -> bool:
    """Point an existing map layer at a GPKG (keeps layer id, tree position, symbology)."""
    if lyr is None or not gpkg_path or not os.path.isfile(gpkg_path):
        return False
    if _layer_already_linked_to_gpkg(lyr, gpkg_path):
        return True
    try:
        prev_source = str(lyr.source() or "")
        prev_name = (lyr.name() or "").strip() or GEOCODE_LAYER_DISPLAY_NAME
    except Exception:
        prev_source = ""
        prev_name = GEOCODE_LAYER_DISPLAY_NAME
    display_name = read_geocode_layer_display_name(lyr)
    if not display_name:
        if prev_name and prev_name != GEOCODE_GPKG_LAYER_NAME:
            display_name = prev_name
        else:
            display_name = GEOCODE_LAYER_DISPLAY_NAME
    uri = _gpkg_layer_uri(gpkg_path)
    opts = QgsDataProvider.ProviderOptions()
    try:
        if not hasattr(lyr, "setDataSource"):
            return False
        lyr.setDataSource(uri, display_name, "ogr", opts)
        # QGIS may return False even when the provider switched; trust validity.
        if not lyr.isValid():
            lyr.setDataSource(gpkg_path, display_name, "ogr", opts)
        if not lyr.isValid():
            if prev_source:
                try:
                    lyr.setDataSource(prev_source, prev_name, "ogr", opts)
                except Exception:
                    pass
            return False
        try:
            lyr.updateExtents()
        except Exception:
            pass
        mark_geocode_layer(lyr)
        set_geocode_layer_gpkg_file(lyr, gpkg_path)
        set_geocode_layer_display_name(lyr, display_name)
        try:
            lyr.triggerRepaint()
        except Exception:
            pass
        return True
    except Exception:
        if prev_source:
            try:
                lyr.setDataSource(prev_source, prev_name, "ogr", opts)
            except Exception:
                pass
        return False


def _migrate_copy_layer_gpkg(
    lyr: QgsVectorLayer, src: str, dest: str
) -> bool:
    """Copy geocode data to dest without shutil-copying an open SQLite/GPKG."""
    if os.path.normpath(src) == os.path.normpath(dest):
        return os.path.isfile(dest)
    # Prefer exporting from the live layer (avoids corrupt copies of locked GPKGs).
    if lyr is not None and lyr.isValid():
        if _export_geocode_layer_to_gpkg(lyr, dest):
            return True
    try:
        if os.path.isfile(dest):
            os.remove(dest)
        shutil.copy2(src, dest)
        return os.path.isfile(dest)
    except Exception:
        return False


def migrate_geocode_gpkg_to_project_folder_if_needed(
    project=None, project_folder: str | None = None
) -> None:
    """Copy only map-linked geocode GPKGs beside the project and relink layers."""
    project = project or QgsProject.instance()
    if not project_folder:
        project_folder = project_data_directory(project)
    if not project_folder:
        return

    project_folder = os.path.normpath(project_folder)
    try:
        os.makedirs(project_folder, exist_ok=True)
    except Exception:
        return

    layers = geocode_layers_for_project_io(project)
    staging_folder = _geocode_staging_directory_path(project, create=False)
    staging_norm = (
        os.path.normpath(staging_folder)
        if staging_folder and os.path.isdir(staging_folder)
        else None
    )

    for lyr in layers:
        try:
            if lyr.isEditable():
                lyr.commitChanges()
        except Exception:
            pass
        # Keep a unique sidecar basename. Do not overwrite a good prop with a
        # collapsed relative source that points at geocoded_points.gpkg for every layer.
        raw = _layer_source_gpkg_path(lyr)
        src = _resolve_gpkg_path(raw, project, project_folder) if raw else None
        existing_prop = str(
            lyr.customProperty(GEOCODE_LAYER_GPKG_FILE_PROP, "") or ""
        ).strip()
        existing_base = os.path.basename(existing_prop) if existing_prop else ""
        if src:
            src_base = os.path.basename(src)
            if (
                not existing_base
                or src_base == existing_base
                or not os.path.isfile(
                    os.path.join(project_folder, existing_base)
                )
            ):
                set_geocode_layer_gpkg_file(lyr, src)
        elif not existing_base and raw:
            base = os.path.basename(str(raw).split("|")[0])
            if _is_geocode_sidecar_filename(base):
                set_geocode_layer_gpkg_file(lyr, base)

    for lyr in layers:
        dest = _project_gpkg_path_for_layer(lyr, project_folder)
        if not dest:
            continue

        src = None
        raw = _layer_source_gpkg_path(lyr)
        if raw:
            src = _resolve_gpkg_path(raw, project, project_folder)
        if not src:
            src = _resolved_layer_gpkg_path(lyr, project, project_folder)

        if src and os.path.normpath(src) == os.path.normpath(dest):
            if not _layer_already_linked_to_gpkg(lyr, dest):
                _relink_geocode_layer_to_gpkg(lyr, dest)
            restore_geocode_layer_display_name(lyr)
            continue

        if src and _is_path_under_dir(src, project_folder):
            if os.path.normpath(src) != os.path.normpath(dest):
                _migrate_copy_layer_gpkg(lyr, src, dest)
            if os.path.isfile(dest):
                if not _layer_already_linked_to_gpkg(lyr, dest):
                    _relink_geocode_layer_to_gpkg(lyr, dest)
                restore_geocode_layer_display_name(lyr)
            continue

        if src and os.path.isfile(src):
            if not _migrate_copy_layer_gpkg(lyr, src, dest):
                continue
            if not os.path.isfile(dest):
                continue
            if not _layer_already_linked_to_gpkg(lyr, dest):
                _relink_geocode_layer_to_gpkg(lyr, dest)
            restore_geocode_layer_display_name(lyr)
            continue

        # Source missing: try recover from staging by basename, then relink.
        basename = os.path.basename(dest)
        recovered = ensure_geocode_sidecar_beside_project(
            basename, project, project_folder
        )
        if recovered and os.path.isfile(recovered):
            if not _layer_already_linked_to_gpkg(lyr, recovered):
                _relink_geocode_layer_to_gpkg(lyr, recovered)
            restore_geocode_layer_display_name(lyr)
            continue

        if os.path.isfile(dest):
            if not _layer_already_linked_to_gpkg(lyr, dest):
                _relink_geocode_layer_to_gpkg(lyr, dest)
            restore_geocode_layer_display_name(lyr)

    cleanup_unreferenced_geocode_gpkg_files(project, [project_folder])
    if staging_norm and not _layers_still_using_staging(
        project, project_folder, staging_norm
    ):
        clear_geocode_staging_for_project(project)
    write_geocode_gpkg_relpath(project, default_geocode_gpkg_relpath())


def get_or_create_geocode_points_layer(
    project=None, symbol_color: QColor | None = None
) -> tuple[QgsVectorLayer | None, str | None]:
    """
    Return (layer, error_message). Uses temp staging when the project is unsaved.
    """
    project = project or QgsProject.instance()
    existing = find_geocode_points_layer(project)
    if existing is not None:
        src = existing.source()
        gpkg = geocode_gpkg_absolute_path(project)
        if gpkg and os.path.isfile(gpkg) and gpkg.replace("\\", "/") in src.replace(
            "\\", "/"
        ):
            return existing, None
        if existing.providerType() == "memory":
            folder = geocode_storage_directory(project)
            if not folder:
                return None, "create_failed"
            gpkg_path = geocode_gpkg_absolute_path(project)
            if not gpkg_path:
                return None, "create_failed"
            migrated = _migrate_memory_layer_to_gpkg(existing, gpkg_path, project)
            if migrated is not None:
                return migrated, None

    folder = geocode_storage_directory(project)
    if not folder:
        return None, "create_failed"

    gpkg_path = geocode_gpkg_absolute_path(project)
    if not gpkg_path:
        return None, "create_failed"

    write_geocode_gpkg_relpath(project, default_geocode_gpkg_relpath())

    if os.path.isfile(gpkg_path):
        lyr = _load_gpkg_layer(gpkg_path)
        if lyr is not None:
            mark_geocode_layer(lyr)
            project.addMapLayer(lyr)
            return lyr, None

    if not _create_empty_geocode_gpkg(
        gpkg_path, crs=resolve_geocode_target_crs(project)
    ):
        return None, "create_failed"

    lyr = _load_gpkg_layer(gpkg_path)
    if lyr is None:
        return None, "create_failed"

    if symbol_color is not None:
        _apply_point_symbol_color(lyr, symbol_color)

    return _add_layer_to_project(lyr, project), None


def append_geocode_points(
    layer: QgsVectorLayer, points: list[tuple[str, float, float]]
) -> bool:
    """Append geocoded points in one edit session. Lon/lat are WGS84."""
    if layer is None or not points:
        return False
    try:
        if sip.isdeleted(layer):
            return False
    except Exception:
        return False
    feats = []
    fields = layer.fields()
    has_address = "address" in fields.names()
    for address, lon, lat in points:
        xy = transform_geocode_lonlat_to_layer_xy(layer, lon, lat)
        if xy is None:
            return False
        feat = QgsFeature(fields)
        feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(xy[0], xy[1])))
        if has_address:
            feat["address"] = address
        feats.append(feat)
    layer.startEditing()
    try:
        ok, _added = layer.dataProvider().addFeatures(feats)
        if not ok:
            layer.rollBack()
            return False
        if not layer.commitChanges():
            layer.rollBack()
            return False
    except Exception:
        try:
            layer.rollBack()
        except Exception:
            pass
        return False
    layer.triggerRepaint()
    return True


def append_geocode_point(
    layer: QgsVectorLayer, address: str, lon: float, lat: float
) -> bool:
    """Append one geocoded point. Lon/lat are WGS84; written in the layer's CRS."""
    return append_geocode_points(layer, [(address, lon, lat)])


def commit_geocode_layer_before_project_write(project=None) -> None:
    """Commit open geocode edits only (safe during writeProject signal)."""
    project = project or QgsProject.instance()
    for lyr in geocode_layers_for_project_io(project):
        try:
            if lyr.isEditable():
                lyr.commitChanges()
        except Exception:
            pass


def _is_geocode_sidecar_basename(name: str) -> bool:
    lower = (name or "").lower()
    return lower.startswith("geocoded_points") and lower.endswith(".gpkg")


def list_all_temp_geocode_gpkgs() -> list[dict]:
    """All geocode sidecar GPKGs under the configured staging root (every session)."""
    root = _geocode_staging_root()
    if not os.path.isdir(root):
        return []
    entries: list[dict] = []
    try:
        session_names = os.listdir(root)
    except OSError:
        return []
    for session_id in session_names:
        session_dir = os.path.join(root, session_id)
        if not os.path.isdir(session_dir):
            continue
        try:
            names = os.listdir(session_dir)
        except OSError:
            continue
        for name in names:
            if not _is_geocode_sidecar_basename(name):
                continue
            path = os.path.normpath(os.path.join(session_dir, name))
            if not os.path.isfile(path):
                continue
            count = None
            probe = _load_gpkg_layer(path, display_name="_probe")
            if probe is not None and probe.isValid():
                try:
                    count = probe.featureCount()
                except Exception:
                    count = None
            try:
                mtime = os.path.getmtime(path)
            except OSError:
                mtime = 0
            entries.append(
                {
                    "path": path,
                    "basename": name,
                    "session_id": session_id,
                    "feature_count": count,
                    "mtime": mtime,
                }
            )
    entries.sort(key=lambda e: e.get("mtime") or 0, reverse=True)
    return entries


def read_geocode_gpkg_address_lines(gpkg_path: str) -> list[str]:
    """Read address field values from a GPKG without adding it to the map."""
    lyr = _load_gpkg_layer(gpkg_path, display_name="_read")
    if lyr is None or not lyr.isValid():
        return []
    return geocode_layer_address_lines(lyr)


def map_layer_for_gpkg_path(gpkg_path: str, project=None) -> QgsVectorLayer | None:
    """Return the map layer already using this GPKG path, if any."""
    if not gpkg_path:
        return None
    project = project or QgsProject.instance()
    target = os.path.normpath(gpkg_path)
    for lyr in geocode_layers_for_project_io(project):
        resolved = _resolved_layer_gpkg_path(lyr, project)
        if resolved and os.path.normpath(resolved) == target:
            return lyr
        src = _layer_source_gpkg_path(lyr)
        if src and os.path.normpath(src) == target:
            return lyr
    return None


def add_temp_geocode_gpkg_to_map(
    gpkg_path: str, project=None
) -> tuple[QgsVectorLayer | None, str | None]:
    """
    Add a temp (or other) geocode GPKG to the current project.

    Copies into project geocode storage when the file is outside that folder.
    Returns (layer, error_code). error_code is None on success.
    """
    project = project or QgsProject.instance()
    src = os.path.normpath(gpkg_path)
    if not os.path.isfile(src):
        return None, "load_failed"

    existing = map_layer_for_gpkg_path(src, project)
    if existing is not None:
        return existing, "already_on_map"

    folder = geocode_storage_directory(project)
    if not folder:
        return None, "no_storage"

    dest = src
    folder_norm = os.path.normpath(folder)
    if not _is_path_under_dir(src, folder_norm):
        dest_path = _next_geocode_gpkg_path(project)
        if not dest_path:
            return None, "copy_failed"
        dest = dest_path
        try:
            if os.path.isfile(dest):
                os.remove(dest)
            shutil.copy2(src, dest)
        except Exception:
            return None, "copy_failed"

    name = _next_geocode_display_name(project)
    lyr = _load_gpkg_layer(dest, display_name=name)
    if lyr is None:
        return None, "load_failed"
    return _add_layer_to_project(lyr, project), None


def repair_geocode_layer_sources_beside_project(project=None) -> None:
    """After opening a project, relink geocode layers to GPKG files beside the .qgz/.qgs."""
    project = project or QgsProject.instance()
    folder = project_data_directory(project)
    if not folder:
        return
    adopt_geocode_layers_in_project(project)
    for lyr in geocode_layers_for_project_io(project):
        ensure_geocode_layer_transforms(lyr, project=project)
        basename = str(lyr.customProperty(GEOCODE_LAYER_GPKG_FILE_PROP, "") or "").strip()
        if not basename:
            src = _layer_source_gpkg_path(lyr)
            if src:
                basename = os.path.basename(src)
        basename = os.path.basename(basename) if basename else ""
        if basename:
            set_geocode_layer_gpkg_file(lyr, os.path.join(folder, basename))
        candidate = None
        if basename:
            candidate = ensure_geocode_sidecar_beside_project(
                basename, project, folder
            )
        if not candidate:
            candidate = _project_gpkg_path_for_layer(lyr, folder)
        if not candidate or not os.path.isfile(candidate):
            continue
        current = _resolved_layer_gpkg_path(lyr, project, folder)
        needs_relink = (
            not lyr.isValid()
            or not current
            or os.path.normpath(current) != os.path.normpath(candidate)
        )
        if needs_relink:
            _relink_geocode_layer_to_gpkg(lyr, candidate)
        restore_geocode_layer_display_name(lyr)
        try:
            lyr.triggerRepaint()
        except Exception:
            pass


def _geocode_basename_from_datasource(datasource: str) -> str | None:
    raw = str(datasource or "").split("|")[0].strip()
    if not raw:
        return None
    base = os.path.basename(raw.lstrip("./\\"))
    if _is_geocode_sidecar_filename(base):
        return base
    return None


def _dom_custom_property(layer_node, key: str) -> str:
    try:
        props = layer_node.namedItem("customproperties")
        if props.isNull():
            props = layer_node.namedItem("custom-properties")
        if props.isNull():
            return ""
        children = props.childNodes()
        for i in range(children.count()):
            child = children.at(i)
            if child.nodeName() not in ("property", "Option"):
                # QGIS 3 often uses nested Option elements
                pass
            el = child.toElement()
            if el.isNull():
                continue
            name = el.attribute("key") or el.attribute("name")
            if name == key:
                return str(el.attribute("value") or el.text() or "").strip()
            # Nested map Option (QGIS 3 style)
            if el.attribute("type") == "Map" or child.nodeName() == "Option":
                nested = child.childNodes()
                for j in range(nested.count()):
                    n = nested.at(j).toElement()
                    if n.isNull():
                        continue
                    if (n.attribute("name") or n.attribute("key")) == key:
                        return str(n.attribute("value") or n.text() or "").strip()
    except Exception:
        pass
    return ""


class GeocodeBadLayerHandler:
    """Installed via install_geocode_bad_layer_handler(); holds previous handler."""

    def __init__(self, previous_handler=None):
        from qgis.core import QgsProjectBadLayerHandler

        previous = previous_handler

        class _Handler(QgsProjectBadLayerHandler):
            def handleBadLayers(self, layers):  # noqa: N802 — QGIS API
                remaining = []
                project = QgsProject.instance()
                for node in layers:
                    try:
                        if _try_fix_geocode_bad_layer_node(self, project, node):
                            continue
                    except Exception:
                        pass
                    remaining.append(node)
                if not remaining:
                    return
                if previous is not None and hasattr(previous, "handleBadLayers"):
                    try:
                        previous.handleBadLayers(remaining)
                        return
                    except Exception:
                        pass
                try:
                    QgsProjectBadLayerHandler.handleBadLayers(self, remaining)
                except Exception:
                    pass

        self._previous = previous_handler
        self.qgis_handler = _Handler()


def _try_fix_geocode_bad_layer_node(handler, project, node) -> bool:
    try:
        datasource = handler.dataSource(node)
    except Exception:
        datasource = ""
    basename = _geocode_basename_from_datasource(datasource)
    if not basename:
        prop = _dom_custom_property(node, GEOCODE_LAYER_GPKG_FILE_PROP)
        if prop:
            basename = os.path.basename(prop)
    if not basename or not _is_geocode_sidecar_filename(basename):
        tag = _dom_custom_property(node, GEOCODE_LAYER_CUSTOM_PROPERTY)
        if tag != GEOCODE_LAYER_CUSTOM_VALUE:
            return False
        if not basename:
            return False

    folder = project_data_directory(project)
    if not folder:
        return False
    candidate = ensure_geocode_sidecar_beside_project(basename, project, folder)
    if not candidate or not os.path.isfile(candidate):
        return False

    uri = _gpkg_layer_uri(candidate)
    try:
        handler.setDataSource(node, uri)
    except Exception:
        return False
    try:
        return bool(project.readLayer(node))
    except Exception:
        return False


def install_geocode_bad_layer_handler(project=None) -> None:
    """Install (once) a bad-layer handler that recovers geocode sidecars on open."""
    project = project or QgsProject.instance()
    existing = getattr(project, "_map_weaver_geocode_bad_layer_handler", None)
    if existing is not None:
        return
    try:
        previous = project.badLayerHandler()
    except Exception:
        previous = None
    wrapper = GeocodeBadLayerHandler(previous_handler=previous)
    try:
        project.setBadLayerHandler(wrapper.qgis_handler)
        project._map_weaver_geocode_bad_layer_handler = wrapper
    except Exception:
        pass


def uninstall_geocode_bad_layer_handler(project=None) -> None:
    project = project or QgsProject.instance()
    wrapper = getattr(project, "_map_weaver_geocode_bad_layer_handler", None)
    if wrapper is None:
        return
    try:
        previous = getattr(wrapper, "_previous", None)
        if previous is not None:
            project.setBadLayerHandler(previous)
    except Exception:
        pass
    try:
        delattr(project, "_map_weaver_geocode_bad_layer_handler")
    except Exception:
        pass
