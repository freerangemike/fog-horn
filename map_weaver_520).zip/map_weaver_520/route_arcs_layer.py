# -*- coding: utf-8 -*-
"""Identify Route Arcs layers without relying on display name; tag layers Mapestry creates."""

from __future__ import annotations

from qgis.core import (
    QgsField,
    QgsProject,
    QgsSimpleLineSymbolLayer,
    QgsSingleSymbolRenderer,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import Qt, QVariant
from qgis.PyQt import sip

# Set on layers created or adopted by Route Connections (survives rename).
ROUTE_ARCS_LAYER_CUSTOM_PROPERTY = "map_weaver/is_route_arcs_layer"
ROUTE_ARCS_LAYER_CUSTOM_VALUE = "1"


def _route_arcs_crs_matches(crs_layer, crs_other):
    if crs_layer is None or crs_other is None:
        return False
    try:
        if crs_layer == crs_other:
            return True
    except Exception:
        pass
    try:
        if hasattr(crs_layer, "hasSameCrsAs") and crs_layer.hasSameCrsAs(crs_other):
            return True
    except Exception:
        pass
    try:
        a, b = crs_layer.authid(), crs_other.authid()
        if a and b and a == b:
            return True
    except Exception:
        pass
    return False


def route_arcs_field_schema_ok(lyr: QgsVectorLayer) -> bool:
    """Vendor Route Arcs memory layer: line geometry + Start, End, ConnID string fields."""
    if lyr is None:
        return False
    try:
        if sip.isdeleted(lyr):
            return False
    except Exception:
        return False
    try:
        if lyr.geometryType() != QgsWkbTypes.LineGeometry:
            return False
    except Exception:
        return False
    try:
        names = {f.name() for f in lyr.fields()}
    except Exception:
        return False
    return {"Start", "End", "ConnID"}.issubset(names)


def has_route_arcs_tag(lyr: QgsVectorLayer) -> bool:
    try:
        return str(lyr.customProperty(ROUTE_ARCS_LAYER_CUSTOM_PROPERTY, "") or "") == ROUTE_ARCS_LAYER_CUSTOM_VALUE
    except Exception:
        return False


def mark_route_arcs_layer(lyr: QgsVectorLayer) -> None:
    """Tag a layer as Mapestry Route Arcs (call after create or when adopting a unique candidate)."""
    if lyr is None:
        return
    try:
        lyr.setCustomProperty(ROUTE_ARCS_LAYER_CUSTOM_PROPERTY, ROUTE_ARCS_LAYER_CUSTOM_VALUE)
    except Exception:
        pass


def ensure_route_arcs_line_round_caps(lyr: QgsVectorLayer) -> None:
    """Round line caps and joins on simple-line symbol layers (Route Arcs appearance)."""
    if lyr is None:
        return
    try:
        if sip.isdeleted(lyr):
            return
    except Exception:
        return
    try:
        r = lyr.renderer()
        if not isinstance(r, QgsSingleSymbolRenderer):
            return
        sym = r.symbol()
        if sym is None:
            return
        changed = False
        for i in range(sym.symbolLayerCount()):
            sl = sym.symbolLayer(i)
            if isinstance(sl, QgsSimpleLineSymbolLayer):
                sl.setPenCapStyle(Qt.RoundCap)
                sl.setPenJoinStyle(Qt.RoundJoin)
                changed = True
        if changed:
            lyr.triggerRepaint()
    except Exception:
        pass


def is_route_arcs_layer(lyr) -> bool:
    """True if this layer is treated as Route Arcs (tag, or legacy name + schema)."""
    if lyr is None or not isinstance(lyr, QgsVectorLayer):
        return False
    try:
        if sip.isdeleted(lyr):
            return False
    except Exception:
        return False
    if not route_arcs_field_schema_ok(lyr):
        return False
    if has_route_arcs_tag(lyr):
        return True
    try:
        if lyr.name() == "Route Arcs":
            mark_route_arcs_layer(lyr)
            return True
    except Exception:
        pass
    return False


def iter_route_arcs_layers(project=None):
    project = project or QgsProject.instance()
    for lyr in project.mapLayers().values():
        if is_route_arcs_layer(lyr):
            yield lyr


def project_has_route_arcs_with_features(project=None) -> bool:
    """True if the project has a Route Arcs–like layer worth surfacing (tagged, or schema + data)."""
    project = project or QgsProject.instance()
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer):
            continue
        try:
            if sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        if not route_arcs_field_schema_ok(lyr):
            continue
        if has_route_arcs_tag(lyr):
            return True
        try:
            if lyr.featureCount() > 0:
                return True
        except Exception:
            continue
    return False


def _schema_candidates_for_crs(crs, project=None):
    project = project or QgsProject.instance()
    out = []
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer):
            continue
        try:
            if sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        if not route_arcs_field_schema_ok(lyr):
            continue
        if not _route_arcs_crs_matches(lyr.crs(), crs):
            continue
        out.append(lyr)
    return out


def find_route_arcs_layer_for_crs(crs, project=None):
    """
    Return the Route Arcs layer for ``crs`` without creating one.

    Preference: tagged layer(s) for that CRS; else a single untagged schema match (then tag);
    else legacy name ``Route Arcs`` among candidates; else None if ambiguous.
    """
    project = project or QgsProject.instance()
    candidates = _schema_candidates_for_crs(crs, project)
    if not candidates:
        return None
    tagged = [lyr for lyr in candidates if has_route_arcs_tag(lyr)]
    if len(tagged) == 1:
        return tagged[0]
    if len(tagged) > 1:
        tagged.sort(key=lambda L: (L.featureCount() if L else 0), reverse=True)
        return tagged[0]
    untagged = [lyr for lyr in candidates if not has_route_arcs_tag(lyr)]
    if len(untagged) == 1:
        mark_route_arcs_layer(untagged[0])
        return untagged[0]
    legacy = [lyr for lyr in untagged if lyr.name() == "Route Arcs"]
    if len(legacy) == 1:
        mark_route_arcs_layer(legacy[0])
        return legacy[0]
    return None


def _create_memory_route_arcs_layer(crs, display_name, project):
    """In-memory Route Arcs layer (persisted via project blob on save)."""
    uri = f"LineString?crs={crs.authid()}"
    arc_layer = QgsVectorLayer(uri, display_name, "memory")
    pr = arc_layer.dataProvider()
    pr.addAttributes(
        [
            QgsField("Start", QVariant.String),
            QgsField("End", QVariant.String),
            QgsField("ConnID", QVariant.String),
        ]
    )
    arc_layer.updateFields()
    arc_layer.startEditing()
    project.addMapLayer(arc_layer)
    mark_route_arcs_layer(arc_layer)
    ensure_route_arcs_line_round_caps(arc_layer)
    return arc_layer


def create_route_arcs_layer(crs, display_name="Route Arcs", project=None):
    """Create a new in-memory Route Arcs layer (serialized into the project file on save)."""
    project = project or QgsProject.instance()
    return _create_memory_route_arcs_layer(crs, display_name, project)
