# -*- coding: utf-8 -*-
"""Geocode / Add points — UI from point_map.ui."""

import os

from qgis.PyQt import uic
from qgis.PyQt.QtGui import QGuiApplication
from qgis.PyQt.QtWidgets import QDialog

from .library_basemap_list import (
    populate_library_basemap_qlist_widget,
    wire_library_basemap_qlist_widget,
)
from .southneedle import CustomArrowColorButton  # noqa: F401 — promoted widget in point_map.ui


class PointMapDialog(QDialog):
    """Addresses + point color + Add Points; opened from Tools → Location Plot card."""

    def __init__(self, plugin, parent=None):
        super().__init__(parent)
        self._plugin = plugin
        ui_path = os.path.join(os.path.dirname(__file__), "point_map.ui")
        # Designer <connections> use receiver dlgPointMap (root objectName). loadUi(..., self)
        # resolves that with getattr(self, "dlgPointMap"); the top-level widget IS self, so alias
        # for the duration of load only:
        self.dlgPointMap = self
        try:
            uic.loadUi(ui_path, self)
        finally:
            try:
                del self.dlgPointMap
            except AttributeError:
                pass
        if hasattr(self, "plhLabel03"):
            self.plhLabel03.hide()
        self.pbnAddPoints.clicked.connect(self._on_add_points)
        lst = getattr(self, "lstLibraryBasemaps", None)
        if lst is not None:
            wire_library_basemap_qlist_widget(lst, self._on_library_basemap_chosen)
        bb = getattr(self, "buttonBox", None)
        if bb is not None:
            bb.accepted.connect(self._on_wizard_finished)

    def _library_folder(self):
        if self._plugin is None or not hasattr(self._plugin, "_library_folder"):
            return None
        try:
            return self._plugin._library_folder()
        except Exception:
            return None

    def _refresh_library_basemap_list(self):
        lst = getattr(self, "lstLibraryBasemaps", None)
        if lst is None:
            return
        populate_library_basemap_qlist_widget(lst, self._library_folder() or "")

    def _on_library_basemap_chosen(self, path):
        if self._plugin is not None and hasattr(self._plugin, "loadBasemapFromFile"):
            self._plugin.loadBasemapFromFile(path)

    def _on_wizard_finished(self):
        if self._plugin is not None and hasattr(self._plugin, "register_completed_tool"):
            self._plugin.register_completed_tool("location_plot")

    def showEvent(self, event):
        super().showEvent(event)
        self._refresh_library_basemap_list()
        self._center_on_screen()

    def _center_on_screen(self):
        """Place the dialog in the center of the screen that holds the parent (QGIS main window)."""
        ref = self.parentWidget()
        center_pt = ref.frameGeometry().center() if ref is not None else None
        if center_pt is None:
            center_pt = self.frameGeometry().center()
        screen = QGuiApplication.screenAt(center_pt)
        if screen is None:
            screen = QGuiApplication.primaryScreen()
        if screen is None:
            return
        ag = screen.availableGeometry()
        geo = self.frameGeometry()
        geo.moveCenter(ag.center())
        self.move(geo.topLeft())

    def _on_add_points(self):
        if self._plugin is not None:
            self._plugin.runGeocodingFromDialog(self)
