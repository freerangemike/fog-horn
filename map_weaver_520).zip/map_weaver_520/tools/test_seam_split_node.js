/**
 * Offline check: mirror globe_poly_tools.splitPolyAtLonSeam / QML _splitPolyByViewSeam
 * (centerLon = wrap(-yaw)). Run: node tools/test_seam_split_node.js
 *
 * Debug columns:
 *   signedArea — planar shoelace in lon×lat (degrees²); sign = winding vs parent (rough).
 *   closureGap — distance between ring[0] and ring[last] (expect ~0 if ring duplicates closing vertex).
 *   dupAdj — duplicate consecutive vertices on that part.
 */
const fs = require("fs");
const path = require("path");

function wrapLon(lon) {
    let t = lon;
    while (t > 180.0) t -= 360.0;
    while (t < -180.0) t += 360.0;
    return t;
}

function splitPolyAtLonSeam(poly, centerLon) {
    if (!poly || poly.length < 3) return [];
    const seamSplitDeg = 180.0;
    const parts = [];
    let cur = [[poly[0][0], poly[0][1]]];

    function pushPartIfValid(p) {
        if (p && p.length >= 3) parts.push(p);
    }

    for (let i = 1; i <= poly.length; i++) {
        const a = poly[(i - 1) % poly.length];
        const b = poly[i % poly.length];
        const aLon = a[0];
        const aLat = a[1];
        const bLon = b[0];
        const bLat = b[1];
        const aRel = wrapLon(aLon - centerLon);
        const bRel = wrapLon(bLon - centerLon);
        const d = bRel - aRel;
        if (d > seamSplitDeg || d < -seamSplitDeg) {
            const seamRel = d > 0.0 ? -180.0 : 180.0;
            const bAdj = bRel + (d > 0.0 ? -360.0 : 360.0);
            let denom = bAdj - aRel;
            if (Math.abs(denom) < 0.000001) denom = denom >= 0 ? 0.000001 : -0.000001;
            let t = (seamRel - aRel) / denom;
            t = Math.max(0.0, Math.min(1.0, t));
            const seamLat = aLat + (bLat - aLat) * t;
            const seamLonA = wrapLon(seamRel + centerLon);
            const seamLonB = wrapLon((seamRel > 0.0 ? -180.0 : 180.0) + centerLon);
            cur.push([seamLonA, seamLat]);
            pushPartIfValid(cur);
            cur = [[seamLonB, seamLat]];
            if (i < poly.length) cur.push([bLon, bLat]);
        } else if (i < poly.length) {
            cur.push([bLon, bLat]);
        }
    }
    pushPartIfValid(cur);
    if (parts.length === 0) return [poly];
    return parts;
}

/** Planar shoelace in (lon, lat) degrees; sign = winding (not true geodesic area). */
function signedAreaLonLatDeg(ring) {
    if (!ring || ring.length < 3) return 0;
    let a = 0;
    const n = ring.length;
    for (let i = 0; i < n; i++) {
        const j = (i + 1) % n;
        a += ring[i][0] * ring[j][1] - ring[j][0] * ring[i][1];
    }
    return a * 0.5;
}

function countDuplicateConsecutive(ring) {
    let d = 0;
    const n = ring.length;
    for (let i = 0; i < n; i++) {
        const j = (i + 1) % n;
        if (ring[i][0] === ring[j][0] && ring[i][1] === ring[j][1]) d++;
    }
    return d;
}

function seamClosureGap(ring) {
    if (!ring || ring.length < 2) return 0;
    const a = ring[0];
    const b = ring[ring.length - 1];
    const dLon = Math.abs(wrapLon(b[0] - a[0]));
    const dLat = Math.abs(b[1] - a[1]);
    return Math.hypot(dLon, dLat);
}

const root = path.join(__dirname, "..", "globe_continents.js");
let code = fs.readFileSync(root, "utf8");
code = code.replace(/^\s*\.pragma\s+library\s*\n?/m, "");
eval(code);

const yaw = -124.95;
const centerLon = wrapLon(-yaw);

const idx = 233;
const entry = WorldPolyData[idx];
if (!entry || !entry.p) {
    console.error("missing poly", idx);
    process.exit(1);
}

const parts = splitPolyAtLonSeam(entry.p, centerLon);
const parentArea = signedAreaLonLatDeg(entry.p);
console.log("polyIndex=%d c=%s vertices=%d", idx, entry.c, entry.p.length);
console.log("yaw=%s centerLon=%s (wrap(-yaw))", yaw, centerLon.toFixed(4));
console.log("maxViewSeamParts=%d", parts.length);
console.log(
    "\n--- winding / closure (planar lon×lat shoelace; compare signs to parent) ---"
);
console.log(
    "parent ring: signedArea=%s dupAdjEdges=%d",
    parentArea.toExponential(4),
    countDuplicateConsecutive(entry.p)
);

let mixedWind = false;
let firstSign = null;
const areaEps = Math.max(5.0, Math.abs(parentArea) * 0.002);
parts.forEach((ring, i) => {
    let minL = Infinity,
        maxL = -Infinity;
    for (const v of ring) {
        minL = Math.min(minL, v[0]);
        maxL = Math.max(maxL, v[0]);
    }
    const sa = signedAreaLonLatDeg(ring);
    const sgn = Math.abs(sa) < areaEps ? 0 : sa > 0 ? 1 : -1;
    if (firstSign === null && sgn !== 0) firstSign = sgn;
    if (firstSign !== null && sgn !== 0 && sgn !== firstSign) mixedWind = true;
    console.log(
        "  part %d: verts=%d lon [%s, %s] signedArea=%s closureGap=%s dupAdj=%d",
        i,
        ring.length,
        minL.toFixed(2),
        maxL.toFixed(2),
        sa.toExponential(4),
        seamClosureGap(ring).toExponential(4),
        countDuplicateConsecutive(ring)
    );
});
if (mixedWind) {
    console.log(
        "\n  NOTE: parts disagree in planar winding sign — worth checking fill/tesselation."
    );
} else if (firstSign !== null && parentArea !== 0) {
    const ps = parentArea > 0 ? 1 : -1;
    if (firstSign !== ps) {
        console.log(
            "\n  NOTE: part winding sign differs from parent — map to sphere may still match; flag only."
        );
    }
}

// Antarctica i=8 at same view
const ant = WorldPolyData[8];
const ap = splitPolyAtLonSeam(ant.p, centerLon);
console.log("\npolyIndex=8 c=%s verts=%d parts=%d", ant.c, ant.p.length, ap.length);
if (ap.length > 1) {
    const pa = signedAreaLonLatDeg(ant.p);
    console.log("  parent signedArea=%s", pa.toExponential(4));
    ap.forEach((ring, i) => {
        console.log(
            "  ant part %d: signedArea=%s closureGap=%s",
            i,
            signedAreaLonLatDeg(ring).toExponential(4),
            seamClosureGap(ring).toExponential(4)
        );
    });
}
