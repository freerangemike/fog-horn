import QtQuick 2.12

Rectangle {
    width: 64
    height: 64
    color: "#ffffff"
}
