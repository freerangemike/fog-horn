@echo off
REM Map Weaver globe geo debug — launches QGIS with env vars this plugin reads at globe load.
REM Double-click this file, or run it from cmd.

REM Required for validate + MapWeaver Globe log category.
set "MAP_WEAVER_GLOBE_GEO_DEBUG=1"


REM Seam snapshots while you change view (throttled) + 45s idle timer — needed to see spin_probe when rotating.
set "MAP_WEAVER_GLOBE_GEO_SPIN_PROBE=1"

REM Optional: wider polygon sample when validate finds no “issue” rows:
REM set "MAP_WEAVER_GLOBE_GEO_DEBUG_HEARTBEAT=1"

REM Validate-only session (no spin_probe on rotation): comment out the SPIN_PROBE line above.

REM Optional: restore per-camera lon/lat splitting (many coast fragments; can show “seams”):
REM set "MAP_WEAVER_GLOBE_VIEW_SEAM_SPLIT=1"

REM --- Point this at YOUR QGIS launcher under bin\ (name varies by release): ------------
REM   qgis-ltr-bin.exe   (common for LTR)
REM   qgis-bin.exe       (some installs)
set "QGIS_EXE=C:\Program Files\QGIS 3.44.8\bin\qgis-ltr-bin.exe"

if not exist "%QGIS_EXE%" (
  echo Edit QGIS_EXE inside:
  echo   %~f0
  echo Set it to the full path of bin\qgis-ltr-bin.exe or bin\qgis-bin.exe on your PC.
  pause
  exit /b 1
)

start "" "%QGIS_EXE%"
