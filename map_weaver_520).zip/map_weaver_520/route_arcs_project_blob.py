# -*- coding: utf-8 -*-
"""Serialize Route Arcs memory layers into the QGIS project file (no sidecar GeoPackage)."""

from __future__ import annotations

import json

from qgis.core import (
    Qgis,
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsMapLayerStyle,
    QgsProject,
    QgsSimpleLineSymbolLayer,
    QgsSingleSymbolRenderer,
    QgsSymbol,
    QgsUnitTypes,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.PyQt import sip
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor

from .route_arcs_layer import (
    ensure_route_arcs_line_round_caps,
    has_route_arcs_tag,
    iter_route_arcs_layers,
    mark_route_arcs_layer,
    route_arcs_field_schema_ok,
)

MAP_WEAVER_PROJECT_SCOPE = "map_weaver"
ROUTE_ARCS_BLOB_ENTRY_KEY = "route_arcs_state_v1"
BLOB_VERSION = 2


def coerce_snapping_config_for_safe_project_write(project: QgsProject) -> None:
    """
    Reduce snapping-related access violations on project save (Windows / some projects).

    Do not call ``QgsSnappingConfig.individualLayerSettings()`` from Python: it can AV.

    If snapping mode is Advanced, switch to All Layers first and persist, then clear
    per-layer settings on a fresh config object, then persist again.

    Note: ``QgsProject`` writes snapping in ``writeProjectFile`` *before* emitting the
    ``writeProject`` signal. Call this (or ``prepare_project_for_disk_write``) **before**
    ``QgsProject.write()`` or before triggering the main-window Save action, not only
    from a ``writeProject`` slot.
    """
    try:
        cfg = project.snappingConfig()
        m_before = cfg.mode()
        if m_before == Qgis.SnappingMode.AdvancedConfiguration:
            cfg.setMode(Qgis.SnappingMode.AllLayers)
            project.setSnappingConfig(cfg)
            cfg = project.snappingConfig()
        cfg.clearIndividualLayerSettings()
        project.setSnappingConfig(cfg)
    except Exception:
        pass


def commit_route_arcs_layers_before_project_write(project: QgsProject | None = None) -> None:
    """Commit pending edits on Route Arcs layers so project save/snapping write sees stable state."""
    project = project or QgsProject.instance()
    for lyr in iter_route_arcs_layers(project):
        try:
            if lyr.isEditable():
                lyr.commitChanges()
        except Exception:
            pass


def prepare_project_for_disk_write(project: QgsProject | None = None) -> None:
    """
    Commit Route Arcs edits and normalize snapping so ``QgsProject::write`` can serialize
    snapping without hitting known Windows AV paths.

    Must run before ``QgsProject.write(...)`` or before ``iface.actionSaveProject().trigger()``:
    snapping is written to the project XML before the ``writeProject`` signal is emitted.
    """
    project = project or QgsProject.instance()
    commit_route_arcs_layers_before_project_write(project)
    try:
        from .geocode_layer import commit_geocode_layer_before_project_write

        commit_geocode_layer_before_project_write(project)
    except Exception:
        pass
    coerce_snapping_config_for_safe_project_write(project)


def _serialize_line_appearance(lyr: QgsVectorLayer) -> dict | None:
    """Persist basic line color/width for QgsSingleSymbolRenderer + QgsSimpleLineSymbolLayer."""
    try:
        r = lyr.renderer()
        if r is None or not hasattr(r, "symbol"):
            return None
        sym = r.symbol()
        if sym is None or sym.symbolLayerCount() < 1:
            return None
        sl0 = sym.symbolLayer(0)
        if not isinstance(sl0, QgsSimpleLineSymbolLayer):
            return None
        return {
            "rgba": int(sl0.color().rgba()),
            "width": float(sl0.width()),
            "unit": int(sl0.widthUnit()),
        }
    except Exception:
        return None


def _apply_simple_line_appearance(lyr: QgsVectorLayer, payload: dict) -> bool:
    if not isinstance(payload, dict) or "rgba" not in payload:
        return False
    try:
        sym = QgsSymbol.defaultSymbol(QgsWkbTypes.LineGeometry)
        sl0 = sym.symbolLayer(0)
        if not isinstance(sl0, QgsSimpleLineSymbolLayer):
            return False
        rgba = int(payload.get("rgba", 4278190080))
        sl0.setColor(QColor.fromRgba(rgba))
        sl0.setWidth(float(payload.get("width", 0.6)))
        sl0.setWidthUnit(QgsUnitTypes.RenderUnit(int(payload.get("unit", QgsUnitTypes.RenderMillimeters))))
        lyr.setRenderer(QgsSingleSymbolRenderer(sym))
        return True
    except Exception:
        return False


def _remove_existing_route_arcs_layers(project: QgsProject) -> None:
    """Drop Route Arcs layers Mapestry owns so they can be rebuilt from the blob."""
    to_remove = []
    for lid, lyr in project.mapLayers().items():
        if not isinstance(lyr, QgsVectorLayer):
            continue
        try:
            if sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        if has_route_arcs_tag(lyr) or (
            route_arcs_field_schema_ok(lyr) and lyr.name() == "Route Arcs"
        ):
            to_remove.append(lid)
    for lid in to_remove:
        try:
            project.removeMapLayer(lid)
        except Exception:
            pass


def _serialize_layer(lyr: QgsVectorLayer) -> dict:
    crs_auth = lyr.crs().authid() or ""
    feats_out = []
    for f in lyr.getFeatures():
        try:
            g = f.geometry()
            wkt = g.asWkt() if g is not None and not g.isEmpty() else ""
        except Exception:
            wkt = ""
        try:
            feats_out.append(
                {
                    "wkt": wkt,
                    "Start": str(f.attribute("Start") or ""),
                    "End": str(f.attribute("End") or ""),
                    "ConnID": str(f.attribute("ConnID") or ""),
                }
            )
        except Exception:
            continue
    simple_line = _serialize_line_appearance(lyr)
    return {
        "name": lyr.name(),
        "crs": crs_auth,
        "features": feats_out,
        "simple_line": simple_line or {},
        "style_xml": "",
    }


def flush_route_arcs_layers_to_project(project: QgsProject | None = None) -> None:
    """Called from QgsProject.writeProject — snapshot current Route Arcs layers into the project."""
    project = project or QgsProject.instance()
    prepare_project_for_disk_write(project)
    try:
        layers = [_serialize_layer(lyr) for lyr in iter_route_arcs_layers(project)]
        blob = json.dumps({"version": BLOB_VERSION, "layers": layers}, separators=(",", ":"))
    except (TypeError, ValueError):
        return
    try:
        project.writeEntry(MAP_WEAVER_PROJECT_SCOPE, ROUTE_ARCS_BLOB_ENTRY_KEY, blob)
    except Exception:
        pass


def _layer_from_spec(spec: dict, project: QgsProject) -> QgsVectorLayer | None:
    crs_auth = (spec.get("crs") or "").strip()
    if not crs_auth:
        return None
    crs = QgsCoordinateReferenceSystem(crs_auth)
    if not crs.isValid():
        return None
    name = spec.get("name") or "Route Arcs"
    vl = QgsVectorLayer(f"LineString?crs={crs_auth}", name, "memory")
    if not vl.isValid():
        return None
    pr = vl.dataProvider()
    pr.addAttributes(
        [
            QgsField("Start", QVariant.String),
            QgsField("End", QVariant.String),
            QgsField("ConnID", QVariant.String),
        ]
    )
    vl.updateFields()

    feats = []
    for row in spec.get("features") or []:
        wkt = row.get("wkt") or ""
        g = QgsGeometry.fromWkt(wkt) if wkt else QgsGeometry()
        if g.isEmpty() or g.type() != QgsWkbTypes.LineGeometry:
            continue
        f = QgsFeature(vl.fields())
        f.setGeometry(g)
        f.setAttribute("Start", row.get("Start") or "")
        f.setAttribute("End", row.get("End") or "")
        f.setAttribute("ConnID", row.get("ConnID") or "")
        feats.append(f)
    if feats:
        if not vl.startEditing():
            return None
        if not pr.addFeatures(feats):
            vl.rollBack()
            return None
        vl.commitChanges()
    mark_route_arcs_layer(vl)
    project.addMapLayer(vl)
    vl.startEditing()
    simple_line = spec.get("simple_line")
    if isinstance(simple_line, dict) and simple_line.get("rgba") is not None:
        if not _apply_simple_line_appearance(vl, simple_line):
            style_xml = spec.get("style_xml") or ""
            if style_xml:
                try:
                    st = QgsMapLayerStyle()
                    if st.readFromString(style_xml):
                        st.writeToLayer(vl)
                except Exception:
                    pass
    else:
        style_xml = spec.get("style_xml") or ""
        if style_xml:
            try:
                st = QgsMapLayerStyle()
                if st.readFromString(style_xml):
                    st.writeToLayer(vl)
            except Exception:
                pass
    ensure_route_arcs_line_round_caps(vl)
    return vl


def restore_route_arcs_layers_from_project_blob(project: QgsProject | None = None) -> None:
    """Rebuild Route Arcs memory layers from the project blob (after readProject)."""
    project = project or QgsProject.instance()
    try:
        raw, ok = project.readEntry(MAP_WEAVER_PROJECT_SCOPE, ROUTE_ARCS_BLOB_ENTRY_KEY, "")
    except Exception:
        return
    if not ok:
        return
    text = (raw or "").strip()
    if not text:
        return
    try:
        data = json.loads(text)
    except (TypeError, ValueError):
        return
    ver = int(data.get("version") or 0)
    if ver not in (1, 2):
        return
    layers = data.get("layers")
    if not isinstance(layers, list):
        return
    _remove_existing_route_arcs_layers(project)
    for spec in layers:
        if not isinstance(spec, dict):
            continue
        _layer_from_spec(spec, project)


def maybe_restore_route_arcs_blob_on_plugin_load(project: QgsProject | None = None) -> None:
    """
    If the project was opened before the plugin loaded, readProject may not have run our handler.
    Restore when a non-empty blob exists but no tagged Route Arcs layers are present.
    """
    project = project or QgsProject.instance()
    try:
        raw, ok = project.readEntry(MAP_WEAVER_PROJECT_SCOPE, ROUTE_ARCS_BLOB_ENTRY_KEY, "")
    except Exception:
        return
    if not ok or not (raw or "").strip():
        return
    try:
        data = json.loads(raw)
    except (TypeError, ValueError):
        return
    if int(data.get("version") or 0) not in (1, 2):
        return
    layers = data.get("layers") or []
    if not layers:
        return
    has_tagged = any(has_route_arcs_tag(lyr) for lyr in iter_route_arcs_layers(project))
    if has_tagged:
        return
    restore_route_arcs_layers_from_project_blob(project)
