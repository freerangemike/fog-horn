# -*- coding: utf-8 -*-
"""Persistent geocoded points layer (GeoPackage beside the QGIS project file)."""

from __future__ import annotations

import os

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.PyQt import sip
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor

from .route_arcs_project_blob import MAP_WEAVER_PROJECT_SCOPE

GEOCODE_LAYER_CUSTOM_PROPERTY = "map_weaver/is_geocode_points_layer"
GEOCODE_LAYER_CUSTOM_VALUE = "1"
GEOCODE_LAYER_DISPLAY_NAME = "Geocoded Points"
GEOCODE_GPKG_BASENAME = "geocoded_points.gpkg"
GEOCODE_GPKG_LAYER_NAME = "geocoded_points"
GEOCODE_POINTS_REL_PATH_ENTRY = "geocode_points_gpkg_relpath"
# Written on project save when a geocode layer is present (survives layer rename).
GEOCODE_LAYER_PRESENT_ENTRY = "geocode_layer_present"
GEOCODE_CRS_AUTHID = "EPSG:4326"


def mark_geocode_layer(lyr: QgsVectorLayer) -> None:
    if lyr is None:
        return
    try:
        lyr.setCustomProperty(
            GEOCODE_LAYER_CUSTOM_PROPERTY, GEOCODE_LAYER_CUSTOM_VALUE
        )
    except Exception:
        pass


def has_geocode_tag(lyr: QgsVectorLayer) -> bool:
    try:
        return (
            str(lyr.customProperty(GEOCODE_LAYER_CUSTOM_PROPERTY, "") or "")
            == GEOCODE_LAYER_CUSTOM_VALUE
        )
    except Exception:
        return False


def is_geocode_points_layer(lyr) -> bool:
    if lyr is None or not isinstance(lyr, QgsVectorLayer):
        return False
    try:
        if sip.isdeleted(lyr):
            return False
    except Exception:
        return False
    try:
        if lyr.geometryType() != QgsWkbTypes.PointGeometry:
            return False
    except Exception:
        return False
    if has_geocode_tag(lyr):
        return True
    try:
        if lyr.name() == GEOCODE_LAYER_DISPLAY_NAME:
            return True
    except Exception:
        pass
    return False


def project_data_directory(project=None) -> str | None:
    """Folder containing the .qgz/.qgs, else QgsProject.homePath() when set."""
    project = project or QgsProject.instance()
    try:
        path = project.absoluteFilePath()
        if path:
            d = os.path.dirname(os.path.abspath(path))
            if d and os.path.isdir(d):
                return d
    except Exception:
        pass
    try:
        hp = project.homePath()
        if hp:
            d = os.path.abspath(hp)
            if os.path.isdir(d):
                return d
    except Exception:
        pass
    return None


def default_geocode_gpkg_relpath() -> str:
    return GEOCODE_GPKG_BASENAME


def read_geocode_gpkg_relpath(project=None) -> str:
    project = project or QgsProject.instance()
    try:
        raw, ok = project.readEntry(
            MAP_WEAVER_PROJECT_SCOPE, GEOCODE_POINTS_REL_PATH_ENTRY, ""
        )
        if ok and str(raw or "").strip():
            return str(raw).strip().replace("\\", "/")
    except Exception:
        pass
    return default_geocode_gpkg_relpath()


def write_geocode_gpkg_relpath(project, relpath: str) -> None:
    if project is None:
        return
    rel = str(relpath or default_geocode_gpkg_relpath()).strip().replace("\\", "/")
    try:
        project.writeEntry(MAP_WEAVER_PROJECT_SCOPE, GEOCODE_POINTS_REL_PATH_ENTRY, rel)
    except Exception:
        pass


def read_geocode_layer_present_stamp(project=None) -> bool:
    project = project or QgsProject.instance()
    try:
        raw, ok = project.readEntry(
            MAP_WEAVER_PROJECT_SCOPE, GEOCODE_LAYER_PRESENT_ENTRY, ""
        )
        if ok and str(raw or "").strip().lower() in ("1", "true", "yes", "on"):
            return True
    except Exception:
        pass
    return False


def write_geocode_layer_present_stamp(project, present: bool) -> None:
    if project is None:
        return
    try:
        project.writeEntry(
            MAP_WEAVER_PROJECT_SCOPE,
            GEOCODE_LAYER_PRESENT_ENTRY,
            "1" if present else "",
        )
    except Exception:
        pass


def _geocode_schema_ok(lyr: QgsVectorLayer) -> bool:
    try:
        return lyr.fields().lookupField("address") >= 0
    except Exception:
        return False


def _layer_source_matches_geocode_gpkg(lyr: QgsVectorLayer, gpkg_path: str | None) -> bool:
    if not gpkg_path or lyr is None:
        return False
    try:
        src = os.path.normpath(lyr.source()).lower()
        gpkg = os.path.normpath(gpkg_path).lower()
        if gpkg in src:
            return True
        base = os.path.basename(gpkg)
        if base and base in src:
            return True
    except Exception:
        pass
    return False


def adopt_geocode_layers_in_project(project=None) -> None:
    """Tag point layers that use the project geocode GeoPackage (e.g. after rename)."""
    project = project or QgsProject.instance()
    gpkg = geocode_gpkg_absolute_path(project)
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer):
            continue
        try:
            if sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        try:
            if lyr.geometryType() != QgsWkbTypes.PointGeometry:
                continue
        except Exception:
            continue
        if has_geocode_tag(lyr):
            continue
        if _layer_source_matches_geocode_gpkg(lyr, gpkg):
            mark_geocode_layer(lyr)
            continue
        if _geocode_schema_ok(lyr) and gpkg:
            try:
                if GEOCODE_GPKG_BASENAME.lower() in lyr.source().lower():
                    mark_geocode_layer(lyr)
            except Exception:
                pass


def project_has_geocode_points_layer(project=None) -> bool:
    """
    True only when a geocode layer is in the current project (tag on map layer).
    Does not treat an on-disk GeoPackage or save stamp as “present” after the user
    removed the layer from the map.
    """
    project = project or QgsProject.instance()
    adopt_geocode_layers_in_project(project)
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer):
            continue
        try:
            if sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        if has_geocode_tag(lyr):
            return True
    return False


def note_geocode_layer_removed_from_project(project=None) -> None:
    """User removed the geocode layer from the project; do not resurrect on save/load."""
    write_geocode_layer_present_stamp(project, False)


def geocode_gpkg_absolute_path(project=None) -> str | None:
    project = project or QgsProject.instance()
    folder = project_data_directory(project)
    if not folder:
        return None
    rel = read_geocode_gpkg_relpath(project)
    return os.path.normpath(os.path.join(folder, rel))


def _gpkg_layer_uri(gpkg_path: str) -> str:
    return f"{gpkg_path}|layername={GEOCODE_GPKG_LAYER_NAME}"


def _load_gpkg_layer(gpkg_path: str) -> QgsVectorLayer | None:
    if not gpkg_path or not os.path.isfile(gpkg_path):
        return None
    lyr = QgsVectorLayer(
        _gpkg_layer_uri(gpkg_path), GEOCODE_LAYER_DISPLAY_NAME, "ogr"
    )
    if lyr.isValid():
        return lyr
    lyr = QgsVectorLayer(gpkg_path, GEOCODE_LAYER_DISPLAY_NAME, "ogr")
    if lyr.isValid():
        return lyr
    return None


def _create_empty_geocode_gpkg(gpkg_path: str) -> bool:
    parent = os.path.dirname(gpkg_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    mem = QgsVectorLayer(
        f"Point?crs={GEOCODE_CRS_AUTHID}", GEOCODE_GPKG_LAYER_NAME, "memory"
    )
    pr = mem.dataProvider()
    pr.addAttributes([QgsField("address", QVariant.String)])
    mem.updateFields()
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = GEOCODE_GPKG_LAYER_NAME
    options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
    project = QgsProject.instance()
    ctx = project.transformContext() if project else None
    try:
        err, _warnings, _path, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
            mem, gpkg_path, ctx, options
        )
        if err[0] == QgsVectorFileWriter.NoError:
            return True
    except Exception:
        pass
    try:
        err = QgsVectorFileWriter.writeAsVectorFormat(
            mem,
            gpkg_path,
            "UTF-8",
            QgsCoordinateReferenceSystem(GEOCODE_CRS_AUTHID),
            "GPKG",
        )
        return err[0] == QgsVectorFileWriter.NoError
    except Exception:
        return False


def _apply_point_symbol_color(lyr: QgsVectorLayer, color: QColor) -> None:
    if lyr is None or color is None:
        return
    try:
        sym = lyr.renderer().symbol()
        if sym is not None:
            sym.setColor(color)
            lyr.triggerRepaint()
    except Exception:
        pass


def _copy_features_to_layer(src: QgsVectorLayer, dest: QgsVectorLayer) -> None:
    if src is None or dest is None:
        return
    try:
        if src.featureCount() <= 0:
            return
    except Exception:
        return
    dest.startEditing()
    pr = dest.dataProvider()
    for feat in src.getFeatures():
        nf = QgsFeature(dest.fields())
        nf.setGeometry(feat.geometry())
        if "address" in nf.fields().names():
            try:
                nf["address"] = feat["address"]
            except Exception:
                pass
        pr.addFeature(nf)
    dest.commitChanges()


def _add_layer_to_project(lyr: QgsVectorLayer, project=None) -> QgsVectorLayer:
    project = project or QgsProject.instance()
    mark_geocode_layer(lyr)
    project.addMapLayer(lyr)
    return lyr


def find_geocode_points_layer(project=None) -> QgsVectorLayer | None:
    """Return the geocode layer if it is already in the project (never loads from disk)."""
    project = project or QgsProject.instance()
    tagged = []
    for lyr in project.mapLayers().values():
        if is_geocode_points_layer(lyr):
            if has_geocode_tag(lyr):
                tagged.append(lyr)
            elif lyr.name() == GEOCODE_LAYER_DISPLAY_NAME:
                tagged.append(lyr)
    if len(tagged) == 1:
        mark_geocode_layer(tagged[0])
        return tagged[0]
    if len(tagged) > 1:
        tagged.sort(key=lambda L: L.featureCount() if L else 0, reverse=True)
        mark_geocode_layer(tagged[0])
        return tagged[0]
    return None


def layers_being_removed_include_geocode(layers) -> bool:
    """True if any layer in a layersWillBeRemoved payload is a Mapestry geocode layer."""
    for lyr in layers or []:
        if is_geocode_points_layer(lyr) or has_geocode_tag(lyr):
            return True
    return False


def _migrate_memory_layer_to_gpkg(
    memory_lyr: QgsVectorLayer, gpkg_path: str, project=None
) -> QgsVectorLayer | None:
    project = project or QgsProject.instance()
    if not _create_empty_geocode_gpkg(gpkg_path):
        return None
    gpkg_lyr = _load_gpkg_layer(gpkg_path)
    if gpkg_lyr is None:
        return None
    _copy_features_to_layer(memory_lyr, gpkg_lyr)
    try:
        project.removeMapLayer(memory_lyr.id())
    except Exception:
        pass
    write_geocode_gpkg_relpath(project, read_geocode_gpkg_relpath(project))
    return _add_layer_to_project(gpkg_lyr, project)


def get_or_create_geocode_points_layer(
    project=None, symbol_color: QColor | None = None
) -> tuple[QgsVectorLayer | None, str | None]:
    """
    Return (layer, error_message). error_message is set when the project has no folder yet.
    """
    project = project or QgsProject.instance()
    existing = find_geocode_points_layer(project)
    if existing is not None:
        src = existing.source()
        gpkg = geocode_gpkg_absolute_path(project)
        if gpkg and os.path.isfile(gpkg) and gpkg.replace("\\", "/") in src.replace(
            "\\", "/"
        ):
            return existing, None
        if existing.providerType() == "memory":
            folder = project_data_directory(project)
            if not folder:
                return None, "save_project_first"
            gpkg_path = geocode_gpkg_absolute_path(project)
            if not gpkg_path:
                return None, "save_project_first"
            migrated = _migrate_memory_layer_to_gpkg(existing, gpkg_path, project)
            if migrated is not None:
                return migrated, None

    folder = project_data_directory(project)
    if not folder:
        return None, "save_project_first"

    gpkg_path = geocode_gpkg_absolute_path(project)
    if not gpkg_path:
        return None, "save_project_first"

    write_geocode_gpkg_relpath(project, default_geocode_gpkg_relpath())

    if os.path.isfile(gpkg_path):
        lyr = _load_gpkg_layer(gpkg_path)
        if lyr is not None:
            mark_geocode_layer(lyr)
            project.addMapLayer(lyr)
            return lyr, None

    if not _create_empty_geocode_gpkg(gpkg_path):
        return None, "create_failed"

    lyr = _load_gpkg_layer(gpkg_path)
    if lyr is None:
        return None, "create_failed"

    if symbol_color is not None:
        _apply_point_symbol_color(lyr, symbol_color)

    return _add_layer_to_project(lyr, project), None


def append_geocode_point(
    layer: QgsVectorLayer, address: str, lon: float, lat: float
) -> bool:
    if layer is None:
        return False
    try:
        if sip.isdeleted(layer):
            return False
    except Exception:
        return False
    feat = QgsFeature(layer.fields())
    feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
    if "address" in feat.fields().names():
        feat["address"] = address
    layer.startEditing()
    ok = layer.dataProvider().addFeature(feat)
    if not ok:
        layer.rollBack()
        return False
    if not layer.commitChanges():
        layer.rollBack()
        return False
    layer.triggerRepaint()
    return True


def commit_geocode_layer_before_project_write(project=None) -> None:
    project = project or QgsProject.instance()
    lyr = find_geocode_points_layer(project)
    if lyr is None:
        return
    try:
        if lyr.isEditable():
            lyr.commitChanges()
    except Exception:
        pass
