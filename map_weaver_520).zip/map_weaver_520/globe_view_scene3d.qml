import QtQuick 2.12
import "globe_continents.js" as GlobeData
import "globe_poly_tools.js" as PolyTools

Rectangle {
    id: root
    width: 360
    height: 220
    color: "#ffffff"

    // One image, two states. This is a true single-surface morph parameter.
    property real unfoldProgress: 0.0
    property real globeYaw: 0.0
    property real globePitch: 0.0
    property real spinVX: 0.0
    property real spinVY: 0.0
    property real mapCenterLon: 0.0
    property string targetProjection: "mercator"
    // 0=mercator, 1=equirect, 2=miller (int mode avoids hot-path string comparisons in QV4)
    property int projectionMode: 0
    readonly property real maxMerc: 2.438  // mercator at about +/-85 deg
    // Direct positioning/sizing controls for the idle globe view.
    property real globeCenterXFactor: 0.50
    property real globeCenterYFactor: 0.50
    property real globeRadiusFactor: 0.46
    property real oceanCenterShiftScale: 1.00
    property real oceanRadiusScale: 2.00
    readonly property real globeRadiusPx: Math.min(width, height) * globeRadiusFactor
    property bool interacting: false
    readonly property int colorOptionCount: 5
    property int oceanColorIndex: 0
    property int landColorIndex: 0
    property bool oceanDropdownOpen: false
    property bool landDropdownOpen: false
    readonly property bool colorMenuOpen: oceanDropdownOpen || landDropdownOpen
    // Stability mode: keep drag + morph, avoid timer-based inertial spin churn.
    property bool globeInertialSpinEnabled: false
    property bool morphAnimating: false
    property real morphTarget: 0.0
    property real morphStart: 0.0
    property int morphStepIndex: 0
    property int morphSteps: 3
    property int morphIntervalMs: 60
    property int morphCooldownMs: 180
    property real morphLastEndMs: 0
    property int morphVertexStride: 2
    property bool _morphPaintQueued: false
    property bool _deferredPaintPending: false
    property bool backToGlobePending: false
    property int dragRepaintStride: 2
    property int _dragMoveTick: 0

    property int spinSampleStep: 3
    property int morphSampleStep: 4

    // Set true via QML edits, or MAP_WEAVER_GLOBE_GEO_DEBUG=1 env (see map_weaver_dockwidget.py).
    property bool globeGeoDebug: false
    // Expands validate hot indices when no issues found (MAP_WEAVER_GLOBE_GEO_DEBUG_HEARTBEAT).
    property bool globeGeoDebugHeartbeat: false
    // Opt-in seam snapshot: MAP_WEAVER_GLOBE_GEO_SPIN_PROBE=1 — throttled on yaw/pitch change + 45s timer.
    property bool globeGeoSpinProbeEnabled: false
    // Extra lon/lat splits per camera (many fragments → visible “seams”). Default off; set
    // MAP_WEAVER_GLOBE_VIEW_SEAM_SPLIT=1 to restore legacy. Hemisphere clip still applies.
    property bool globeGeoViewSeamSplitEnabled: false
    property var globeGeoHotRawIndices: []
    property real globeGeoSpinProbeThrottleMs: 0

    // Spin-probe-on-yaw/pitch was useful for diagnostics, but it executes on every spin tick.
    // Keep idle timer probes only to reduce QV4 churn during continuous rotation.
    onTargetProjectionChanged: {
        if (root.targetProjection === "equirect")
            root.projectionMode = 1
        else if (root.targetProjection === "miller")
            root.projectionMode = 2
        else
            root.projectionMode = 0
        // Current morph path is only stable in Mercator; force safe globe mode for others.
        if (root.projectionMode !== 0) {
            morphStepTimer.stop()
            root.morphAnimating = false
            root.unfoldProgress = 0.0
            root.oceanDropdownOpen = false
            root.landDropdownOpen = false
            root.requestMorphPaint()
        }
    }
    onColorMenuOpenChanged: {
        if (root.colorMenuOpen) {
            spinTimer.stop()
            root.spinVX = 0
            root.spinVY = 0
            root.interacting = false
        }
    }

    function _globeGeoLog(line) {
        // Do not also console.log: Qt forwards that to Log Messages and bypasses Python-side
        // throttling/dedup on globeGeoLogger (duplicate lines every probe tick).
        if (typeof globeGeoLogger !== "undefined")
            globeGeoLogger.log(line)
        else
            console.log(line)
    }

    // Log noise: most rings only report duplicate_consecutive_points; seam work needs other flags.
    function _globeGeoIssueRowInteresting(issue) {
        if (!issue || !issue.msgs || issue.msgs.length === 0)
            return false
        for (var m = 0; m < issue.msgs.length; m++) {
            if (issue.msgs[m] !== "duplicate_consecutive_points")
                return true
        }
        return false
    }

    function _deg2rad(v) { return v * Math.PI / 180.0 }
    function _rad2deg(v) { return v * 180.0 / Math.PI }
    function _wrapLon(lon) {
        var t = lon
        while (t > 180) t -= 360
        while (t < -180) t += 360
        return t
    }

    function _oceanColorAt(i) {
        var k = ((i % root.colorOptionCount) + root.colorOptionCount) % root.colorOptionCount
        if (k === 0) return "#1e88e5"
        if (k === 1) return "#00acc1"
        if (k === 2) return "#3949ab"
        if (k === 3) return "#8e24aa"
        return "#43a047"
    }

    function _landColorAt(i) {
        var k = ((i % root.colorOptionCount) + root.colorOptionCount) % root.colorOptionCount
        if (k === 0) return "#a2331d" // original default
        if (k === 1) return "#fb8c00"
        if (k === 2) return "#7cb342"
        if (k === 3) return "#e53935"
        return "#546e7a"
    }

    // |planar shoelace| in lon×lat degree² — seam splits can emit needle slivers (bad fills / “straight” cuts).
    function _globeGeoAbsPlanarAreaDeg2(ring) {
        if (!ring || ring.length < 3)
            return 0
        var a = 0
        var n = ring.length
        for (var i = 0; i < n; i++) {
            var j = (i + 1) % n
            a += ring[i][0] * ring[j][1] - ring[j][0] * ring[i][1]
        }
        return Math.abs(a * 0.5)
    }

    // Rescale (x,y) so x²+y² = 1−z² — stays on the unit sphere; steadies the orthographic limb
    // (reduces jagged rim / vertical “cuts” where float drift leaves chords off the disc).
    function _globeSnapToLimb3(v) {
        var x = v.x
        var y = v.y
        var z = v.z
        var h = x * x + y * y
        if (h < 1e-14)
            return v
        var t = Math.max(0.0, 1.0 - z * z)
        if (t < 1e-10)
            return Qt.vector3d(x / Math.sqrt(h), y / Math.sqrt(h), 0.0)
        var inv = Math.sqrt(t / h)
        if (Math.abs(inv - 1.0) < 0.0005)
            return v
        return Qt.vector3d(x * inv, y * inv, z)
    }

    // Root-level path builders (no nested functions — QV4 can crash on inner closures during load/GC).
    function _globeBuildFragScreenPath(ctx, frag, cx, cy, r) {
        if (!frag || frag.length < 3)
            return
        var first = root._globeSnapToLimb3(frag[0])
        var last = root._globeSnapToLimb3(frag[frag.length - 1])
        var onHorizon = 0.000001
        var useArc = Math.abs(frag[0].z) <= onHorizon && Math.abs(frag[frag.length - 1].z) <= onHorizon
        ctx.beginPath()
        var p0 = root._globeSnapToLimb3(frag[0])
        ctx.moveTo(cx + p0.x * r, cy - p0.y * r)
        for (var i = 1; i < frag.length; i++) {
            var pi = root._globeSnapToLimb3(frag[i])
            ctx.lineTo(cx + pi.x * r, cy - pi.y * r)
        }
        if (useArc) {
            // Must match vertex convention: screen (cx + x*r, cy - y*r) with unit (x,y) on limb.
            // (Old code mixed atan2(-y,x) and cy+sin*r — caused spike + vertical seam vs ocean.)
            var aStart = Math.atan2(last.y, last.x)
            var aEnd = Math.atan2(first.y, first.x)
            var dArc = aEnd - aStart
            while (dArc > Math.PI) dArc -= Math.PI * 2.0
            while (dArc < -Math.PI) dArc += Math.PI * 2.0
            var steps = Math.max(6, Math.ceil(Math.abs(dArc) / 0.20))
            for (var si = 1; si <= steps; si++) {
                var a = aStart + dArc * (si / steps)
                ctx.lineTo(cx + Math.cos(a) * r, cy - Math.sin(a) * r)
            }
        }
        ctx.closePath()
    }

    function _globeBuildProjectedRingScreenPath(ctx, points, cx, cy, r) {
        ctx.beginPath()
        var q0 = root._globeSnapToLimb3(points[0])
        ctx.moveTo(cx + q0.x * r, cy - q0.y * r)
        for (var ia = 1; ia < points.length; ia++) {
            var qi = root._globeSnapToLimb3(points[ia])
            ctx.lineTo(cx + qi.x * r, cy - qi.y * r)
        }
        ctx.closePath()
    }

    function _rotateY(v, deg) {
        var a = _deg2rad(deg)
        var c = Math.cos(a), s = Math.sin(a)
        return Qt.vector3d(v.x * c + v.z * s, v.y, -v.x * s + v.z * c)
    }
    function _rotateX(v, deg) {
        var a = _deg2rad(deg)
        var c = Math.cos(a), s = Math.sin(a)
        return Qt.vector3d(v.x, v.y * c - v.z * s, v.y * s + v.z * c)
    }
    function _applyRot(v) {
        var t = _rotateY(v, globeYaw)
        t = _rotateX(t, globePitch)
        return t
    }
    function _inverseRot(v) {
        var t = _rotateX(v, -globePitch)
        t = _rotateY(t, -globeYaw)
        return t
    }

    // Pre-split rings at ±180° in dataset lon so bbox / clipping stay consistent at the antimeridian.
    property var worldPolyData: PolyTools.preprocessWorldPolyData(GlobeData.WorldPolyData)
    function _extractPolys(entries) {
        var out = []
        for (var i = 0; i < entries.length; i++) {
            out.push(entries[i].p)
        }
        return out
    }

    property var landPolys: _extractPolys(worldPolyData)
    function _buildPolyIndex(polys) {
        var out = []
        for (var i = 0; i < polys.length; i++) {
            var p = polys[i]
            if (!p || p.length < 3)
                continue
            var minLon = 9999, maxLon = -9999, minLat = 9999, maxLat = -9999
            for (var j = 0; j < p.length; j++) {
                var lon = p[j][0]
                var lat = p[j][1]
                if (lon < minLon) minLon = lon
                if (lon > maxLon) maxLon = lon
                if (lat < minLat) minLat = lat
                if (lat > maxLat) maxLat = lat
            }
            out.push({
                p: p,
                minLon: minLon,
                maxLon: maxLon,
                minLat: minLat,
                maxLat: maxLat
            })
        }
        return out
    }
    property var landPolyIndex: _buildPolyIndex(landPolys)

    function _unitFromLonLat(lonDeg, latDeg) {
        var lon = _deg2rad(lonDeg)
        var lat = _deg2rad(latDeg)
        var cl = Math.cos(lat)
        return Qt.vector3d(cl * Math.sin(lon), Math.sin(lat), cl * Math.cos(lon))
    }

    function _mercY(latDeg, h, cy) {
        var lat = _deg2rad(latDeg)
        var mLat = Math.max(-root.maxMerc, Math.min(root.maxMerc, Math.log(Math.tan(Math.PI * 0.25 + lat * 0.5))))
        return cy - (mLat / root.maxMerc) * (h * 0.47)
    }

    function _projectY(latDeg, h, cy) {
        if (root.projectionMode === 1)
            return cy - (Math.max(-90.0, Math.min(90.0, latDeg)) / 90.0) * (h * 0.47)
        if (root.projectionMode === 2) {
            var latM = Math.max(-85.0, Math.min(85.0, latDeg))
            var latRad = _deg2rad(latM)
            var miller = 1.25 * Math.log(Math.tan(Math.PI * 0.25 + 0.4 * latRad))
            var maxM = 1.25 * Math.log(Math.tan(Math.PI * 0.25 + 0.4 * _deg2rad(85.0)))
            return cy - (miller / maxM) * (h * 0.47)
        }
        return _mercY(latDeg, h, cy)
    }

    function _drawFlatPolygon(ctx, poly, cx, cy, w, h) {
        if (!poly || poly.length < 3)
            return
        for (var wrap = -1; wrap <= 1; wrap++) {
            var started = false
            var prevLonAdj = 0
            var hasPrevLonAdj = false
            for (var i = 0; i < poly.length; i++) {
                var lonRel = _wrapLon(poly[i][0] - root.mapCenterLon)
                var lonAdj = lonRel
                if (hasPrevLonAdj) {
                    while (lonAdj - prevLonAdj > 180.0) lonAdj -= 360.0
                    while (lonAdj - prevLonAdj < -180.0) lonAdj += 360.0
                }
                prevLonAdj = lonAdj
                hasPrevLonAdj = true
                var x = cx + ((lonAdj + 360.0 * wrap) / 180.0) * (w * 0.5)
                var y = _projectY(poly[i][1], h, cy)
                if (!started) {
                    ctx.beginPath()
                    ctx.moveTo(x, y)
                    started = true
                } else {
                    ctx.lineTo(x, y)
                }
            }
            if (started) {
                ctx.closePath()
                ctx.fill()
            }
        }
    }

    function _drawMorphPolygon(ctx, poly, p, cx, cy, r, w, h, isAntarctica) {
        var started = false
        // Globe idle: front hemisphere only. Unfold progressively reveals all.
        var zThresh = 0.0 - p
        var prevLonAdj = 0
        var hasPrevLonAdj = false
        var prevXM = 0
        var hasPrevXM = false
        for (var i = 0; i < poly.length; i++) {
            var lonDeg = poly[i][0]
            var latDeg = poly[i][1]
            var v = _applyRot(_unitFromLonLat(lonDeg, latDeg))
            if (v.z < zThresh) {
                if (started) {
                    ctx.closePath()
                    ctx.fill()
                    started = false
                }
                hasPrevLonAdj = false
                hasPrevXM = false
                continue
            }

            var xG = cx + v.x * r
            var yG = cy - v.y * r
            var lonRel = _wrapLon(lonDeg - root.mapCenterLon)
            var lonAdj = lonRel
            if (hasPrevLonAdj) {
                while (lonAdj - prevLonAdj > 180.0) lonAdj -= 360.0
                while (lonAdj - prevLonAdj < -180.0) lonAdj += 360.0
            }
            prevLonAdj = lonAdj
            hasPrevLonAdj = true
            var xM = cx + (lonAdj / 180.0) * (w * 0.5)
            if (p > 0.8 && hasPrevXM) {
                while (xM - prevXM > w * 0.5) xM -= w
                while (xM - prevXM < -w * 0.5) xM += w
            }
            prevXM = xM
            hasPrevXM = true
            var yM = _projectY(latDeg, h, cy)
            var x = xG * (1.0 - p) + xM * p
            var y = yG * (1.0 - p) + yM * p

            if (!started) {
                ctx.beginPath()
                ctx.moveTo(x, y)
                started = true
            } else {
                ctx.lineTo(x, y)
            }
        }
        if (started) {
            ctx.closePath()
            ctx.fill()
        }
    }

    function _downsampleClosedPoly(poly, step) {
        if (!poly || poly.length < 3 || step <= 1)
            return poly
        var out = []
        for (var i = 0; i < poly.length; i += step)
            out.push(poly[i])
        var last = poly[poly.length - 1]
        if (out.length === 0 || out[out.length - 1] !== last)
            out.push(last)
        return out
    }

    function _fillGlobeFrag(ctx, frag, cx, cy, r) {
        if (!frag || frag.length < 3)
            return
        root._globeBuildFragScreenPath(ctx, frag, cx, cy, r)
        ctx.fill()
    }

    function _splitPolyByViewSeam(poly) {
        if (!poly || poly.length < 3)
            return []
        var centerLon = _wrapLon(-root.globeYaw)
        var seamSplitDeg = 180.0
        var parts = []
        var cur = [[poly[0][0], poly[0][1]]]

        function pushPartIfValid(p) {
            if (p && p.length >= 3)
                parts.push(p)
        }

        for (var i = 1; i <= poly.length; i++) {
            var a = poly[(i - 1) % poly.length]
            var b = poly[i % poly.length]
            var aLon = a[0], aLat = a[1]
            var bLon = b[0], bLat = b[1]
            var aRel = _wrapLon(aLon - centerLon)
            var bRel = _wrapLon(bLon - centerLon)
            var d = bRel - aRel
            if (d > seamSplitDeg || d < -seamSplitDeg) {
                var seamRel = d > 0.0 ? -180.0 : 180.0
                var bAdj = bRel + (d > 0.0 ? -360.0 : 360.0)
                var denom = bAdj - aRel
                if (Math.abs(denom) < 0.000001)
                    denom = denom >= 0 ? 0.000001 : -0.000001
                var t = (seamRel - aRel) / denom
                t = Math.max(0.0, Math.min(1.0, t))
                var seamLat = aLat + (bLat - aLat) * t
                var seamLonA = _wrapLon(seamRel + centerLon)
                var seamLonB = _wrapLon((seamRel > 0.0 ? -180.0 : 180.0) + centerLon)
                cur.push([seamLonA, seamLat])
                pushPartIfValid(cur)
                cur = [[seamLonB, seamLat]]
                if (i < poly.length)
                    cur.push([bLon, bLat])
            } else if (i < poly.length) {
                cur.push([bLon, bLat])
            }
        }

        pushPartIfValid(cur)
        if (parts.length === 0)
            return [poly]
        return parts
    }

    function _drawClippedGlobePart(ctx, points, cx, cy, r) {
        if (!points || points.length < 3)
            return
        var insideCount = 0
        for (var i = 0; i < points.length; i++) {
            if (points[i].z >= 0.0)
                insideCount += 1
        }
        if (insideCount < 3)
            return
        if (insideCount === points.length) {
            root._globeBuildProjectedRingScreenPath(ctx, points, cx, cy, r)
            ctx.fill()
            return
        }
        var frag = []
        var prev = points[points.length - 1]
        var prevIn = prev.z >= 0.0
        for (var j = 0; j < points.length; j++) {
            var cur = points[j]
            var curIn = cur.z >= 0.0
            if (prevIn && curIn) {
                if (frag.length === 0)
                    frag.push(prev)
                frag.push(cur)
            } else if (prevIn && !curIn) {
                var tOut = prev.z / (prev.z - cur.z)
                if (frag.length === 0)
                    frag.push(prev)
                frag.push(root._globeSnapToLimb3(Qt.vector3d(
                    prev.x + (cur.x - prev.x) * tOut,
                    prev.y + (cur.y - prev.y) * tOut,
                    0.0
                )))
                if (frag.length >= 3) {
                    _fillGlobeFrag(ctx, frag, cx, cy, r)
                }
                frag = []
            } else if (!prevIn && curIn) {
                var tIn = prev.z / (prev.z - cur.z)
                frag = [root._globeSnapToLimb3(Qt.vector3d(
                    prev.x + (cur.x - prev.x) * tIn,
                    prev.y + (cur.y - prev.y) * tIn,
                    0.0
                )), cur]
            }
            prev = cur
            prevIn = curIn
        }
        if (frag.length >= 3) {
            _fillGlobeFrag(ctx, frag, cx, cy, r)
        }
    }

    function _drawGlobePolygon(ctx, poly, cx, cy, r) {
        if (!poly || poly.length < 3)
            return
        var seamParts = root.globeGeoViewSeamSplitEnabled ? _splitPolyByViewSeam(poly) : [poly]
        var tinyA = 0.03
        var tinyN = 8
        var sampleStep = 1
        if (root.morphAnimating)
            sampleStep = Math.max(1, root.morphSampleStep)
        else if (root.interacting || spinTimer.running)
            sampleStep = Math.max(1, root.spinSampleStep)
        for (var p = 0; p < seamParts.length; p++) {
            var ring = seamParts[p]
            if (!ring || ring.length < 3)
                continue
            if (ring.length <= tinyN && _globeGeoAbsPlanarAreaDeg2(ring) < tinyA)
                continue
            var part = []
            for (var i = 0; i < ring.length; i += sampleStep) {
                part.push(_applyRot(_unitFromLonLat(ring[i][0], ring[i][1])))
            }
            // Ensure closure in low-detail mode so clip/fill remains stable.
            if (sampleStep > 1 && (ring.length - 1) % sampleStep !== 0)
                part.push(_applyRot(_unitFromLonLat(ring[ring.length - 1][0], ring[ring.length - 1][1])))
            if (part.length < 3)
                continue
            _drawClippedGlobePart(ctx, part, cx, cy, r)
        }
    }

    function _pointInPoly(lon, lat, poly) {
        var inside = false
        for (var i = 0, j = poly.length - 1; i < poly.length; j = i++) {
            var xi = poly[i][0], yi = poly[i][1]
            var xj = poly[j][0], yj = poly[j][1]
            var intersect = ((yi > lat) !== (yj > lat)) &&
                    (lon < (xj - xi) * (lat - yi) / ((yj - yi) + 0.0000001) + xi)
            if (intersect) inside = !inside
        }
        return inside
    }

    function _isLand(lon, lat) {
        for (var i = 0; i < landPolyIndex.length; i++) {
            var e = landPolyIndex[i]
            if (lon < e.minLon || lon > e.maxLon || lat < e.minLat || lat > e.maxLat)
                continue
            if (_pointInPoly(lon, lat, e.p))
                return true
        }
        return false
    }

    function _drawGlobeLandMask(ctx, cx, cy, r, stepPx) {
        var x0 = Math.floor(cx - r)
        var x1 = Math.ceil(cx + r)
        var y0 = Math.floor(cy - r)
        var y1 = Math.ceil(cy + r)
        for (var py = y0; py <= y1; py += stepPx) {
            var ny = (cy - py) / r
            for (var px = x0; px <= x1; px += stepPx) {
                var nx = (px - cx) / r
                var rr = nx * nx + ny * ny
                if (rr > 1.0)
                    continue
                var nz = Math.sqrt(Math.max(0.0, 1.0 - rr))
                var local = _inverseRot(Qt.vector3d(nx, ny, nz))
                var lon = _wrapLon(_rad2deg(Math.atan2(local.x, local.z)))
                var lat = _rad2deg(Math.asin(Math.max(-1.0, Math.min(1.0, local.y))))
                if (_isLand(lon, lat))
                    ctx.fillRect(px, py, stepPx, stepPx)
            }
        }
    }

    function pickFromScreen(px, py) {
        if (root.projectionMode !== 0)
            return
        if (root.colorMenuOpen || spinTimer.running || root.morphAnimating || root.backToGlobePending
                || root._morphPaintQueued || root._deferredPaintPending)
            return
        if (unfoldProgress > 0.2)
            return
        var cx = width * globeCenterXFactor
        var cy = height * globeCenterYFactor
        var r = globeRadiusPx
        var nx = (px - cx) / r
        var ny = -(py - cy) / r
        var rr = nx * nx + ny * ny
        if (rr > 1.0)
            return
        // Near-rim picks are numerically touchy and can destabilize the transition path.
        if (rr > 0.94)
            return
        // Stability mode: avoid value-type (Qt.vector3d) inverse pick math on double-click path.
        // Use current globe center longitude as morph center.
        mapCenterLon = _wrapLon(-root.globeYaw)
        root._startMorph(1.0)
    }

    function backToGlobe() {
        if (root.backToGlobePending)
            return
        root.backToGlobePending = true
        // Reverse (flat->globe) morph is currently the crash-prone direction on Qt 5.15.
        // Keep forward morph effect, but return to globe in one stable step.
        morphStepTimer.stop()
        root.morphAnimating = false
        root.unfoldProgress = 0.0
        root.requestMorphPaint()
        backFinalizeTimer.start()
    }

    function _startMorph(toValue) {
        if (root.backToGlobePending || root._morphPaintQueued || root._deferredPaintPending)
            return
        var now = Date.now()
        if (root.morphLastEndMs > 0 && (now - root.morphLastEndMs) < root.morphCooldownMs)
            return
        var target = toValue >= 0.5 ? 1.0 : 0.0
        morphStepTimer.stop()
        spinTimer.stop()
        root.interacting = false
        root.morphStart = root.unfoldProgress
        root.morphTarget = target
        root.morphStepIndex = 0
        if (Math.abs(root.morphStart - root.morphTarget) < 0.001) {
            root.unfoldProgress = root.morphTarget
            root.morphAnimating = false
            root.requestMorphPaint()
            return
        }
        root.morphAnimating = true
        morphStepTimer.start()
        root.requestMorphPaint()
    }

    function cycleOceanColor() {
        oceanColorIndex = (oceanColorIndex + 1) % root.colorOptionCount
        root.requestMorphPaint()
    }

    function cycleLandColor() {
        landColorIndex = (landColorIndex + 1) % root.colorOptionCount
        root.requestMorphPaint()
    }

    function _requestPaintDeferred() {
        if (root._deferredPaintPending)
            return
        root._deferredPaintPending = true
        deferredPaintTimer.start()
    }

    function requestMorphPaint() {
        if (root._morphPaintQueued)
            return
        root._morphPaintQueued = true
        morphCanvas.requestPaint()
    }

    function setOceanColorIndex(i) {
        var next = ((i % root.colorOptionCount) + root.colorOptionCount) % root.colorOptionCount
        if (next === oceanColorIndex)
            return
        oceanColorIndex = next
        _requestPaintDeferred()
    }

    function setLandColorIndex(i) {
        var next = ((i % root.colorOptionCount) + root.colorOptionCount) % root.colorOptionCount
        if (next === landColorIndex)
            return
        landColorIndex = next
        _requestPaintDeferred()
    }

    Canvas {
        id: morphCanvas
        anchors.fill: parent
        antialiasing: true
        renderTarget: Canvas.Image
        renderStrategy: Canvas.Cooperative

        onPaint: {
            root._morphPaintQueued = false
            var ctx = getContext("2d")
            ctx.globalAlpha = 1.0
            ctx.setTransform(1, 0, 0, 1, 0, 0)
            ctx.clearRect(0, 0, width, height)

            var w = width, h = height
            var rows = root.worldPolyData
            var oceanCol = root._oceanColorAt(root.oceanColorIndex)
            var landCol = root._landColorAt(root.landColorIndex)
            var oceanShiftBase = root.oceanCenterShiftScale
            var oceanScaleBase = root.oceanRadiusScale
            var globeCx = w * root.globeCenterXFactor
            var globeCy = h * root.globeCenterYFactor
            var globeR = root.globeRadiusPx
            var mapCx = w * 0.5
            var mapCy = h * 0.5
            var mapR = Math.min(w, h) * 0.58
            var rawP = Math.max(0.0, Math.min(1.0, root.unfoldProgress))
            // Never leave idle rendering in a half-morph state.
            // If animation is not active, lock to a pure state.
            var isMorphing = root.morphAnimating && rawP > 0.0 && rawP < 1.0
            var p = 0.0
            if (!isMorphing) {
                p = rawP >= 0.5 ? 1.0 : 0.0
            } else {
                p = rawP
            }
            if (root.projectionMode !== 0)
                p = 0.0
            var cx = globeCx * (1.0 - p) + mapCx * p
            var cy = globeCy * (1.0 - p) + mapCy * p
            var r = globeR * (1.0 - p) + mapR * p

            // White background as requested.
            ctx.fillStyle = "#ffffff"
            ctx.fillRect(0, 0, w, h)
            // Ocean fill + land draw.
            if (p === 0.0) {
                var ocx = cx - (r * oceanShiftBase)
                var ocy = cy - (r * oceanShiftBase)
                var orr = r * oceanScaleBase
                ctx.fillStyle = oceanCol
                ctx.beginPath()
                ctx.ellipse(ocx, ocy, orr, orr, 0, 0, Math.PI * 2)
                ctx.fill()
                ctx.fillStyle = landCol
                for (var gi = 0; gi < rows.length; gi++) {
                    _drawGlobePolygon(ctx, rows[gi].p, cx, cy, r)
                }
            } else {
                // During unfold, blend between globe disc and Mercator rectangle.
                var mapTop = cy - (h * 0.47)
                var mapHeight = h * 0.94
                // Keep globe-corrected ocean mostly stable; transition late.
                var tMorph = Math.max(0.0, Math.min(1.0, (p - 0.70) / 0.30))
                var q = 1.0 - tMorph
                var qSmooth = q * q * (3.0 - 2.0 * q) // smoothstep easing
                var oceanShift = qSmooth * oceanShiftBase
                var oceanScale = 1.0 + (oceanScaleBase - 1.0) * qSmooth
                var ocx = cx - (r * oceanShift)
                var ocy = cy - (r * oceanShift)
                var orr = r * oceanScale
                ctx.fillStyle = oceanCol
                if (p <= 0.35) {
                    ctx.beginPath()
                    ctx.ellipse(ocx, ocy, orr, orr, 0, 0, Math.PI * 2)
                    ctx.fill()
                } else if (p >= 0.65) {
                    ctx.fillRect(cx - (w * 0.5), mapTop, w, mapHeight)
                } else {
                    var t = (p - 0.35) / 0.30
                    ctx.globalAlpha = 1.0 - t
                    ctx.beginPath()
                    ctx.ellipse(ocx, ocy, orr, orr, 0, 0, Math.PI * 2)
                    ctx.fill()
                    ctx.globalAlpha = t
                    ctx.fillRect(cx - (w * 0.5), mapTop, w, mapHeight)
                    ctx.globalAlpha = 1.0
                }
                // Land transition: crossfade globe land to flat land.
                // This avoids per-vertex morph path churn that is crash-prone on some Qt 5.15 stacks.
                ctx.save()
                // Keep land constrained to the currently visible ocean footprint.
                // Early morph: clip to globe/ocean ellipse; late morph: clip to map frame.
                ctx.beginPath()
                if (p < 0.65) {
                    ctx.ellipse(ocx, ocy, orr, orr, 0, 0, Math.PI * 2)
                } else {
                    ctx.rect(cx - (w * 0.5), mapTop, w, mapHeight)
                }
                ctx.clip()
                ctx.fillStyle = landCol
                // Stability mode: during morph, render only flat-land with alpha ramp.
                // This avoids per-frame hemisphere-clipped globe land path churn.
                if (p < 0.98) {
                    var landA = Math.max(0.0, Math.min(1.0, (p - 0.20) / 0.80))
                    ctx.globalAlpha = landA
                    for (var pmi = 0; pmi < rows.length; pmi++)
                        _drawFlatPolygon(ctx, rows[pmi].p, cx, cy, w, h)
                    ctx.globalAlpha = 1.0
                } else {
                    for (var pfi = 0; pfi < rows.length; pfi++)
                        _drawFlatPolygon(ctx, rows[pfi].p, cx, cy, w, h)
                }
                ctx.restore()
            }

            // No polar cap overlay; it created a false white strip near map bottom.
        }
        Component.onCompleted: root.requestMorphPaint()
    }


    MouseArea {
        anchors.fill: parent
        acceptedButtons: Qt.LeftButton
        property real lastX: 0
        property real lastY: 0
        property real lastDX: 0
        property real lastDY: 0
        onPressed: {
            root.oceanDropdownOpen = false
            root.landDropdownOpen = false
            spinTimer.stop()
            root.interacting = true
            root._dragMoveTick = 0
            lastX = mouse.x
            lastY = mouse.y
            lastDX = 0
            lastDY = 0
        }
        onPositionChanged: {
            if (root.colorMenuOpen)
                return
            if (!(mouse.buttons & Qt.LeftButton) || root.unfoldProgress > 0.2)
                return
            var dx = mouse.x - lastX
            var dy = mouse.y - lastY
            root.globeYaw += dx * 0.35
            root.globePitch += dy * 0.35
            root.globePitch = Math.max(-85, Math.min(85, root.globePitch))
            lastX = mouse.x
            lastY = mouse.y
            lastDX = dx
            lastDY = dy
            root._dragMoveTick += 1
            if (root._dragMoveTick % Math.max(1, root.dragRepaintStride) === 0)
                root.requestMorphPaint()
        }
        onReleased: {
            if (root.colorMenuOpen)
                return
            if (root.unfoldProgress > 0.2)
                return
            if (!root.globeInertialSpinEnabled) {
                root.spinVX = 0
                root.spinVY = 0
                root.interacting = false
                root.requestMorphPaint()
                return
            }
            var speed = Math.sqrt(lastDX * lastDX + lastDY * lastDY)
            if (speed < 5.0) {
                root.spinVX = 0
                root.spinVY = 0
                root.interacting = false
                return
            }
            var boost = Math.min(1.2, speed / 12.0)
            root.spinVX = lastDX * 0.20 * boost
            root.spinVY = lastDY * 0.20 * boost
            spinTimer.start()
        }
        onDoubleClicked: {
            if (root.colorMenuOpen)
                return
            spinTimer.stop()
            root.spinVX = 0
            root.spinVY = 0
            if (Math.abs(lastDX) < 4 && Math.abs(lastDY) < 4)
                root.pickFromScreen(mouse.x, mouse.y)
        }
    }

    Timer {
        id: spinTimer
        interval: 30
        repeat: true
        running: false
        onTriggered: {
            root.globeYaw += root.spinVX
            root.globePitch += root.spinVY
            root.globePitch = Math.max(-85, Math.min(85, root.globePitch))
            root.spinVX *= 0.85
            root.spinVY *= 0.85
            root.requestMorphPaint()
            if (Math.abs(root.spinVX) < 0.08 && Math.abs(root.spinVY) < 0.08)
            {
                root.interacting = false
                stop()
            }
        }
    }

    // Extra seam snapshot while idle debugging (yaw/pitch changes are throttled separately).
    Timer {
        id: globeGeoSpinProbeTimer
        interval: 45000
        repeat: true
        running: root.globeGeoDebug && root.globeGeoSpinProbeEnabled && root.unfoldProgress < 0.05
        onTriggered: root._runGlobeGeoSpinProbeLog()
    }

    Rectangle {
        anchors.left: parent.left
        anchors.verticalCenter: parent.verticalCenter
        anchors.leftMargin: 8
        color: "transparent"
        radius: 10
        border.width: 0
        width: 74
        height: oceanDropdownOpen ? 134 : 34
        visible: root.unfoldProgress < 0.55

        Column {
            anchors.centerIn: parent
            spacing: 4

            Rectangle {
                width: 62
                height: 24
                radius: 12
                color: "#2c4a63"
                border.color: "#9ac3df44"
                border.width: 1
                Text {
                    anchors.centerIn: parent
                    text: "Ocean"
                    color: "#e9f5ff"
                    font.pixelSize: 10
                    font.bold: true
                }
                MouseArea {
                    anchors.fill: parent
                    onClicked: {
                        root.oceanDropdownOpen = !root.oceanDropdownOpen
                        if (root.oceanDropdownOpen)
                            root.landDropdownOpen = false
                    }
                }
            }

            Column {
                visible: root.oceanDropdownOpen
                spacing: 4
                Repeater {
                    model: root.colorOptionCount
                    delegate: Rectangle {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: 44
                        height: 14
                        radius: 7
                        color: root._oceanColorAt(index)
                        border.width: (index === root.oceanColorIndex) ? 2 : 1
                        border.color: (index === root.oceanColorIndex) ? "#ffffff" : "#ffffff44"
                        MouseArea {
                            anchors.fill: parent
                            onClicked: {
                                root.setOceanColorIndex(index)
                                root.oceanDropdownOpen = false
                            }
                        }
                    }
                }
            }
        }
    }

    Rectangle {
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        anchors.rightMargin: 8
        color: "transparent"
        radius: 10
        border.width: 0
        width: 74
        height: landDropdownOpen ? 134 : 34
        visible: root.unfoldProgress < 0.55

        Column {
            anchors.centerIn: parent
            spacing: 4

            Rectangle {
                width: 62
                height: 24
                radius: 12
                color: "#6a443d"
                border.color: "#d3a49644"
                border.width: 1
                Text {
                    anchors.centerIn: parent
                    text: "Land"
                    color: "#fff0eb"
                    font.pixelSize: 10
                    font.bold: true
                }
                MouseArea {
                    anchors.fill: parent
                    onClicked: {
                        root.landDropdownOpen = !root.landDropdownOpen
                        if (root.landDropdownOpen)
                            root.oceanDropdownOpen = false
                    }
                }
            }

            Column {
                visible: root.landDropdownOpen
                spacing: 4
                Repeater {
                    model: root.colorOptionCount
                    delegate: Rectangle {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: 44
                        height: 14
                        radius: 7
                        color: root._landColorAt(index)
                        border.width: (index === root.landColorIndex) ? 2 : 1
                        border.color: (index === root.landColorIndex) ? "#ffffff" : "#ffffff44"
                        MouseArea {
                            anchors.fill: parent
                            onClicked: {
                                root.setLandColorIndex(index)
                                root.landDropdownOpen = false
                            }
                        }
                    }
                }
            }
        }
    }

    Rectangle {
        anchors.left: parent.left
        anchors.top: parent.top
        anchors.margins: 8
        color: "#161a22cc"
        radius: 10
        border.width: 0
        height: 34
        width: btnBack.width + 18
        // Show Back only once flat mode is actually reached.
        visible: root.unfoldProgress >= 0.95 && !root.backToGlobePending

        Rectangle {
            id: btnBack
            anchors.centerIn: parent
            width: 52
            height: 24
            radius: 12
            property bool hover: backMouse.containsMouse
            color: backMouse.pressed ? "#374258" : (hover ? "#44506b" : "#39445c")
            border.width: 0
            Text {
                anchors.centerIn: parent
                text: "Back"
                color: "#eaf0ff"
                font.pixelSize: 10
                font.bold: true
            }
            MouseArea {
                id: backMouse
                anchors.fill: parent
                hoverEnabled: true
                onClicked: root.backToGlobe()
            }
        }
    }

    Timer {
        id: morphStepTimer
        interval: root.morphIntervalMs
        repeat: true
        running: false
        onTriggered: {
            root.morphStepIndex += 1
            if (root.morphStepIndex >= root.morphSteps) {
                root.unfoldProgress = root.morphTarget
                root.morphAnimating = false
                root.morphLastEndMs = Date.now()
                stop()
                root.requestMorphPaint()
                return
            }
            // Multi-step keyframe ramp: smoother than a hard switch, still much lighter than
            // per-vertex morph geometry.
            var t = root.morphStepIndex / root.morphSteps
            root.unfoldProgress = root.morphStart + (root.morphTarget - root.morphStart) * t
            root.requestMorphPaint()
        }
    }

    Timer {
        id: backFinalizeTimer
        interval: 16
        repeat: false
        running: false
        onTriggered: {
            root.oceanDropdownOpen = false
            root.landDropdownOpen = false
            root.backToGlobePending = false
            root.requestMorphPaint()
        }
    }

    Timer {
        id: deferredPaintTimer
        interval: 0
        repeat: false
        running: false
        onTriggered: {
            root._deferredPaintPending = false
            root.requestMorphPaint()
        }
    }

    function _runGlobeGeoValidate() {
        if (!root.globeGeoDebug)
            return
        var rep = PolyTools.validateWorldPolyData(GlobeData.WorldPolyData, 500)
        _globeGeoLog("[map_weaver] globe_geo validate.stats=" + JSON.stringify(rep.stats))
        var hot = []
        for (var r = 0; r < rep.issues.length; r++)
            hot.push(rep.issues[r].i)
        if (hot.length === 0 && root.globeGeoDebugHeartbeat) {
            var all = GlobeData.WorldPolyData
            if (all && all.length > 0) {
                var cap = Math.min(96, all.length)
                for (var z = 0; z < cap; z += 4)
                    hot.push(z)
            }
        }
        root.globeGeoHotRawIndices = hot
        var st = rep.stats
        var statsSignal = st && (st.antimeridianSuspect > 0 || st.edgeJump > 0 || st.badLat > 0 || st.shortRing > 0)
        var sample = []
        for (var s = 0; s < rep.issues.length && sample.length < 12; s++) {
            if (_globeGeoIssueRowInteresting(rep.issues[s]))
                sample.push(rep.issues[s])
        }
        if (sample.length > 0)
            _globeGeoLog("[map_weaver] globe_geo validate.sample_issues=" + JSON.stringify(sample))
        else if (statsSignal)
            _globeGeoLog("[map_weaver] globe_geo validate.sample_issues=(empty in first scan batch; see stats)")
        else
            _globeGeoLog("[map_weaver] globe_geo validate.note=only_duplicate_consecutive_points_in_issue_list_omitted")
        if (root.globeGeoSpinProbeEnabled)
            root._runGlobeGeoSpinProbeLog()
    }

    onGlobeGeoDebugChanged: root._runGlobeGeoValidate()

    function _globeGeoMaybeSpinProbeThrottled() {
        if (!root.globeGeoDebug || !root.globeGeoSpinProbeEnabled)
            return
        if (root.unfoldProgress >= 0.05)
            return
        var now = Date.now()
        if (root.globeGeoSpinProbeThrottleMs > 0 && (now - root.globeGeoSpinProbeThrottleMs) < 1500)
            return
        root.globeGeoSpinProbeThrottleMs = now
        root._runGlobeGeoSpinProbeLog()
    }

    function _runGlobeGeoSpinProbeLog() {
        if (!root.globeGeoDebug || !root.globeGeoSpinProbeEnabled)
            return
        if (root.unfoldProgress >= 0.05)
            return
        // Same rings as paint: preprocessWorldPolyData (split at lon=0) — not raw GlobeData.WorldPolyData.
        // Always run _splitPolyByViewSeam here for diagnostics, even when drawing uses a single ring
        // (globeGeoViewSeamSplitEnabled false) so logs still show “would fragment” counts.
        var rows = root.worldPolyData
        if (!rows || rows.length === 0)
            return
        var yaw = root.globeYaw
        var pitch = root.globePitch
        var maxP = 0
        var maxIx = -1
        var maxC = ""
        var maxVerts = 0
        var maxPartVertCounts = []
        var dvs = root.globeGeoViewSeamSplitEnabled ? "1" : "0"
        for (var hi = 0; hi < rows.length; hi++) {
            var e = rows[hi]
            if (!e || !e.p)
                continue
            var prts = root._splitPolyByViewSeam(e.p)
            if (prts.length > maxP) {
                maxP = prts.length
                maxIx = hi
                maxC = e.c
                maxVerts = e.p.length
                maxPartVertCounts = []
                for (var pj = 0; pj < prts.length; pj++)
                    maxPartVertCounts.push(prts[pj].length)
            }
        }
        var ys = (Math.round(yaw * 100) / 100).toFixed(2)
        var ps = (Math.round(pitch * 100) / 100).toFixed(2)
        if (maxP <= 1) {
            _globeGeoLog("[map_weaver] globe_geo spin_probe yaw=" + ys + " pitch=" + ps
                + " maxViewSeamParts=1 drawViewSeamSplit=" + dvs + " drawPolys=" + rows.length
                + " (diagnostic split; no multi-part)")
            return
        }
        _globeGeoLog("[map_weaver] globe_geo spin_probe yaw=" + ys
            + " pitch=" + ps + " maxViewSeamParts=" + maxP + " drawViewSeamSplit=" + dvs
            + " worldPolyIndex=" + maxIx + " c=" + maxC + " verts=" + maxVerts)
        if (maxP >= 4) {
            _globeGeoLog("[map_weaver] globe_geo spin_probe.detail worldPolyIndex=" + maxIx
                + " verts=" + maxVerts + " maxViewSeamParts=" + maxP + " drawViewSeamSplit=" + dvs
                + " partVertCounts=" + JSON.stringify(maxPartVertCounts))
        }
    }

    Component.onCompleted: root._runGlobeGeoValidate()
}
