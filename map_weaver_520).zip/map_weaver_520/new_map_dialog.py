"""
New Map dialog — QuickMap-style shell.

Qt Designer (promote root dialog widget):
  Class name: NewMapDialog
  Header file: map_weaver.new_map_dialog

Promote map-type tiles:
  Class name: MapTypeCard
  Header file: map_weaver.map_type_card

Visual styling lives in new_map_dialog.qss (loaded via _apply_stylesheet).
Shell: rounded-rect path drives white fill + overlay stroke (no setMask — QRegion masks stair-step curves).
Border color/width/corner radius
can be set from QSS via qproperty-shellBorderColor, qproperty-shellBorderWidth, qproperty-shellCornerRadius.
Title/content radii are synced in _sync_child_shell_radii so panel fills match the shell curve.
"""

import os
import re
from datetime import datetime

from qgis.core import QgsProject
from qgis.PyQt import uic
from qgis.PyQt.QtCore import QEvent, QFileInfo, QRectF, QSize, Qt, pyqtProperty
from qgis.PyQt.QtGui import (
    QColor,
    QIcon,
    QPainter,
    QPainterPath,
    QPainterPathStroker,
    QPixmap,
)
from qgis.PyQt.QtWidgets import (
    QButtonGroup,
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from .map_type_card import MapTypeCard  # noqa: F401 — referenced by generated UI
from .plugin_settings_dialog import apply_global_palette_xml_to_project_if_present
from .route_arcs_project_blob import prepare_project_for_disk_write

FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "start_dialog.ui")
)


def _set_painter_antialiasing(painter):
    painter.setRenderHint(QPainter.Antialiasing, True)
    if hasattr(QPainter, "HighQualityAntialiasing"):
        painter.setRenderHint(QPainter.HighQualityAntialiasing, True)


class _ShellBorderOverlay(QWidget):
    """Thin ring on top of all dialog children so the shell stroke is never painted over."""

    def __init__(self, dialog):
        super().__init__(dialog)
        self._dlg = dialog
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFocusPolicy(Qt.NoFocus)

    def paintEvent(self, event):
        dlg = self._dlg
        w = max(1, int(dlg.shellBorderWidth))
        half = w / 2.0
        rad = float(dlg.shellCornerRadius)
        painter = QPainter(self)
        painter.setClipRect(self.rect())
        _set_painter_antialiasing(painter)
        inner = QRectF(self.rect()).adjusted(half, half, -half, -half)
        outline = NewMapDialog._rounded_shell_path(inner, max(0.0, rad - half))
        stroker = QPainterPathStroker()
        stroker.setWidth(float(w))
        stroker.setCapStyle(Qt.RoundCap)
        stroker.setJoinStyle(Qt.RoundJoin)
        stroke_path = stroker.createStroke(outline)
        painter.fillPath(stroke_path, dlg.shellBorderColor)


class NewMapDialog(QDialog, FORM_CLASS):
    """Frameless shell; rounded silhouette from painting + translucent corners (no integer window mask)."""

    _CARD_IMAGE_FILES = {
        "cardLocationPlot": "point_map.png",
        "cardThematic": "thematic_map.png",
        "cardIsochrone": "energy_transmission.png",
        "cardRouting": "airline_route_map.png",
        "cardCoverage": "heat_map.png",
        "cardTerritory": "pipeline_map.png",
    }

    _CARD_SPECS = (
        (
            "cardLocationPlot",
            "Location Plot",
            "Points, HQ markers, radius rings",
            "points",
            "points",
            "location",
            "location_plot",
        ),
        (
            "cardThematic",
            "Thematic Map",
            "Choropleth shading by data value",
            "join",
            "join",
            "thematic",
            "thematic_map",
        ),
        (
            "cardIsochrone",
            "Energy & Infrastructure",
            "Territories, pipelines, utilities",
            "mixed",
            "mixed",
            "isochrone",
            "energy_infrastructure",
        ),
        (
            "cardRouting",
            "Airline Route",
            "Origin-destination flight paths",
            "routes",
            "routes",
            "routing",
            "airline_route",
        ),
        (
            "cardCoverage",
            "Heat Map",
            "Point density visualization",
            "points",
            "points",
            "coverage",
            "heat_map",
        ),
        (
            "cardTerritory",
            "Raster Trace",
            "Trace features from scanned maps",
            "raster",
            "raster",
            "territory",
            "raster_trace",
        ),
    )

    def __init__(self, parent=None, plugin=None):
        super().__init__(parent)
        self._plugin = plugin
        self._window_drag_offset = None
        # Defaults; QSS qproperty-* overrides when setStyleSheet runs in _apply_stylesheet.
        self._shell_border_color = QColor("#991b1b")
        self._shell_border_width = 1
        self._shell_corner_radius = 28
        self.setupUi(self)
        self._setup_frameless_window()
        self._install_custom_titlebar()
        self._cards = []
        self._slug_by_attr = {}
        self._apply_stylesheet()
        self._sync_child_shell_radii()
        self._configure_cards()
        self._wire_ui()
        self._shell_border_overlay = _ShellBorderOverlay(self)
        self._sync_shell_border_overlay_geometry()

    def _sync_shell_border_overlay_geometry(self):
        if getattr(self, "_shell_border_overlay", None) is None:
            return
        self._shell_border_overlay.setGeometry(self.rect())
        self._shell_border_overlay.raise_()

    @staticmethod
    def _rounded_shell_path(rect: QRectF, radius_px: float) -> QPainterPath:
        path = QPainterPath()
        path.addRoundedRect(rect, radius_px, radius_px)
        return path

    # --- QSS: qproperty-shellBorderColor / shellBorderWidth / shellCornerRadius on QDialog#dlgNewMap ---
    def getShellBorderColor(self):
        return self._shell_border_color

    def setShellBorderColor(self, value):
        if isinstance(value, QColor) and value.isValid():
            c = value
        else:
            c = QColor(value) if value is not None else QColor()
        if not c.isValid():
            c = QColor("#991b1b")
        self._shell_border_color = c
        self._repaint_shell_chrome()

    def getShellBorderWidth(self):
        return self._shell_border_width

    def setShellBorderWidth(self, value):
        w = int(value) if value is not None else 1
        self._shell_border_width = max(1, min(12, w))
        self._repaint_shell_chrome()

    def getShellCornerRadius(self):
        return self._shell_corner_radius

    def setShellCornerRadius(self, value):
        r = int(value) if value is not None else 28
        self._shell_corner_radius = max(0, min(64, r))
        self._sync_child_shell_radii()
        self._update_rounded_window_mask()
        self._repaint_shell_chrome()

    def _sync_child_shell_radii(self):
        """Keep header/footer panel rounding identical to shellCornerRadius (avoids gaps vs shell fill/stroke)."""
        r = max(0, int(self.shellCornerRadius))
        if hasattr(self, "customTitleBar"):
            self.customTitleBar.setStyleSheet(
                f"QWidget#customTitleBar {{ background-color: #ffffff; border: none; "
                f"border-top-left-radius: {r}px; border-top-right-radius: {r}px; "
                f"min-height: 122px; }}"
            )
        if hasattr(self, "contentShell"):
            self.contentShell.setStyleSheet(
                f"QWidget#contentShell {{ background-color: #ffffff !important; border: none; "
                f"border-bottom-left-radius: {r}px; border-bottom-right-radius: {r}px; }}"
            )

    def _repaint_shell_chrome(self):
        o = getattr(self, "_shell_border_overlay", None)
        if o is not None:
            o.update()
        self.update()

    shellBorderColor = pyqtProperty(QColor, fget=getShellBorderColor, fset=setShellBorderColor)
    shellBorderWidth = pyqtProperty(int, fget=getShellBorderWidth, fset=setShellBorderWidth)
    shellCornerRadius = pyqtProperty(int, fget=getShellCornerRadius, fset=setShellCornerRadius)

    def _setup_frameless_window(self):
        """Frameless top-level window; translucent corners outside the painted shell stay transparent."""
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)

    def _update_rounded_window_mask(self):
        """Drop any window shape mask.

        setMask(QRegion) follows curves with integer pixel boundaries — visible stair-steps (often worst
        top-left). We rely on fillPath + overlay + WA_TranslucentBackground instead; corners outside the
        rounded rect stay visually smooth and show the canvas behind. Tradeoff: the full rectangular
        window may still receive clicks in those corner triangles until Qt supports per-pixel hit regions.
        """
        self.clearMask()

    def paintEvent(self, event):
        # White shell: same rounded path as the stroke overlay.
        painter = QPainter(self)
        painter.setClipRect(self.rect())
        _set_painter_antialiasing(painter)
        rad = float(self.shellCornerRadius)
        shell = self._rounded_shell_path(QRectF(self.rect()), rad)
        painter.fillPath(shell, QColor("#ffffff"))

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_rounded_window_mask()
        self._sync_shell_border_overlay_geometry()

    def showEvent(self, event):
        super().showEvent(event)
        self._update_rounded_window_mask()
        self._sync_shell_border_overlay_geometry()

    def _install_custom_titlebar(self):
        """Structure only; styles come from QSS (objectNames below)."""
        plugin_dir = os.path.dirname(__file__)
        self.customTitleBar = QWidget(self)
        self.customTitleBar.setObjectName("customTitleBar")

        title_root_layout = QVBoxLayout(self.customTitleBar)
        title_root_layout.setContentsMargins(0, 0, 0, 0)
        title_root_layout.setSpacing(0)

        self.innerTitleContainer = QWidget(self.customTitleBar)
        self.innerTitleContainer.setObjectName("innerTitleContainer")

        self.customTitleBar.setMinimumHeight(122)

        self.main_title_layout = QVBoxLayout(self.innerTitleContainer)
        self.main_title_layout.setContentsMargins(25, 10, 23, 6)
        self.main_title_layout.setSpacing(0)

        self.lbl_appname = QLabel()
        self.lbl_appname.setObjectName("WidgetTitle")
        logo_path = os.path.join(plugin_dir, "graphics", "maplogo.png")
        logo_pixmap = QPixmap(logo_path)
        if not logo_pixmap.isNull():
            self.lbl_appname.setPixmap(
                logo_pixmap.scaledToHeight(78, Qt.SmoothTransformation)
            )
            self.lbl_appname.setMinimumHeight(78)
        else:
            self.lbl_appname.setText("Mapestry")

        self.btn_title_close = QPushButton()
        self.btn_title_close.setObjectName("TitleCloseButton")
        icon_path = os.path.join(plugin_dir, "graphics", "swatchx.png")
        self.btn_title_close.setIcon(QIcon(icon_path))
        self.btn_title_close.setIconSize(QSize(32, 32))
        self.btn_title_close.setFixedSize(40, 40)
        self.btn_title_close.setAutoDefault(False)
        self.btn_title_close.setDefault(False)
        self.btn_title_close.setFocusPolicy(Qt.NoFocus)
        self.btn_title_close.setFlat(True)
        self.btn_title_close.clicked.connect(self.reject)

        self.button_row_layout = QHBoxLayout()
        self.button_row_layout.setContentsMargins(0, 0, 0, 0)
        self.button_row_layout.addWidget(self.lbl_appname, 0, Qt.AlignLeft | Qt.AlignTop)
        self.button_row_layout.addWidget(self.btn_title_close, 0, Qt.AlignRight | Qt.AlignTop)

        self.main_title_layout.addLayout(self.button_row_layout)

        title_root_layout.addWidget(self.innerTitleContainer)

        self.verticalLayout_main.insertWidget(0, self.customTitleBar)

        self.headerAccent = QFrame(self)
        self.headerAccent.setObjectName("headerAccent")
        self.headerAccent.setFrameShape(QFrame.NoFrame)
        self.headerAccent.setMinimumHeight(3)
        self.headerAccent.setMaximumHeight(3)
        self.verticalLayout_main.insertWidget(1, self.headerAccent)

        # Border ring is drawn above children (_ShellBorderOverlay); content can stay flush to the shell edge.
        self.verticalLayout_main.setContentsMargins(0, 0, 0, 0)

        self._enable_titlebar_drag()

    def _enable_titlebar_drag(self):
        """Allow moving the frameless dialog by dragging the custom header (not the close button)."""
        for w in (
            self.customTitleBar,
            self.innerTitleContainer,
            self.lbl_appname,
            self.headerAccent,
        ):
            w.installEventFilter(self)

    def eventFilter(self, watched, event):
        title_widgets = (
            self.customTitleBar,
            self.innerTitleContainer,
            self.lbl_appname,
            self.headerAccent,
        )
        if watched in title_widgets:
            et = event.type()
            if et == QEvent.MouseButtonPress:
                if event.button() == Qt.LeftButton:
                    self._window_drag_offset = event.globalPos() - self.frameGeometry().topLeft()
            elif et == QEvent.MouseMove:
                if (
                    event.buttons() & Qt.LeftButton
                    and self._window_drag_offset is not None
                ):
                    self.move(event.globalPos() - self._window_drag_offset)
            elif et == QEvent.MouseButtonRelease:
                if event.button() == Qt.LeftButton:
                    self._window_drag_offset = None
        return super().eventFilter(watched, event)

    def _apply_stylesheet(self):
        path = os.path.join(os.path.dirname(__file__), "new_map_dialog.qss")
        if os.path.isfile(path):
            with open(path, encoding="utf-8") as f:
                self.setStyleSheet(f.read())

    def _configure_cards(self):
        for row in self._CARD_SPECS:
            attr = row[0]
            title, desc, tag_text, tag_role, art = row[1], row[2], row[3], row[4], row[5]
            slug = row[6]
            card = getattr(self, attr, None)
            if card is None:
                continue
            img_name = self._CARD_IMAGE_FILES.get(attr)
            img_path = (
                os.path.join(os.path.dirname(__file__), "graphics", img_name)
                if img_name
                else None
            )
            card.configure(
                title,
                desc,
                tag_text,
                tag_role=tag_role,
                art_variant=art,
                illustration_path=img_path,
            )
            self._slug_by_attr[attr] = slug
            self._cards.append(card)

    def _wire_ui(self):
        if hasattr(self, "btnSegmentCreate") and hasattr(self, "btnSegmentEdit"):
            self._segment_group = QButtonGroup(self)
            self._segment_group.setExclusive(True)
            self._segment_group.addButton(self.btnSegmentCreate)
            self._segment_group.addButton(self.btnSegmentEdit)

        if hasattr(self, "lineProjectName"):
            self.lineProjectName.setPlaceholderText("e.g. Acme Corp Q2 Locations")
        if hasattr(self, "lineAuthor"):
            self.lineAuthor.setPlaceholderText("e.g. Jane Smith")

        for c in self._cards:
            c.clicked.connect(self._on_card_clicked)

        if self._cards:
            self._select_card(self._cards[0])

        if hasattr(self, "lineProjectName"):
            self.lineProjectName.textChanged.connect(self._update_filename_preview)

        if hasattr(self, "btnStartSession"):
            self.btnStartSession.setAutoDefault(False)
            self.btnStartSession.setDefault(False)
            self.btnStartSession.clicked.connect(self._on_start_session)
        elif hasattr(self, "buttonBox"):
            self.buttonBox.accepted.connect(self.accept)

        self._update_filename_preview()

    def _sync_create_project_button(self):
        if not hasattr(self, "btnStartSession"):
            return
        if not hasattr(self, "lineProjectName"):
            self.btnStartSession.setEnabled(True)
            return
        self.btnStartSession.setEnabled(bool(self.lineProjectName.text().strip()))

    def _save_project_via_dialog(self) -> bool:
        """Native save dialog; writes the current QGIS project. False if cancelled or save failed."""
        self._update_filename_preview()
        suggested = "project.qgz"
        if hasattr(self, "lblSuggestedFilename"):
            t = self.lblSuggestedFilename.text().strip()
            if t:
                suggested = t
        start_dir = ""
        try:
            start_dir = QgsProject.instance().homePath() or ""
        except Exception:
            start_dir = ""
        if not start_dir:
            start_dir = os.path.expanduser("~")
        start_path = os.path.join(start_dir, suggested)
        path, _ = QFileDialog.getSaveFileName(
            self,
            self.tr("Save Project"),
            start_path,
            self.tr("QGIS Projects (*.qgz *.qgs);;All files (*.*)"),
        )
        if not path:
            return False
        low = path.lower()
        if not low.endswith(".qgz") and not low.endswith(".qgs"):
            path += ".qgz"
        proj = QgsProject.instance()
        prepare_project_for_disk_write(proj)
        try:
            ok = proj.write(path)
        except TypeError:
            ok = proj.write(QFileInfo(path))
        if not ok:
            QMessageBox.warning(
                self,
                self.windowTitle(),
                self.tr("Could not save the project to the chosen path."),
            )
            return False
        return True

    def _persist_mapestry_identity_to_project(self) -> None:
        from qgis.core import QgsProject

        from . import map_weaver as _mw
        from .route_arcs_project_blob import MAP_WEAVER_PROJECT_SCOPE

        proj = QgsProject.instance()
        name = ""
        author = ""
        if hasattr(self, "lineProjectName"):
            name = self.lineProjectName.text().strip()
        if hasattr(self, "lineAuthor"):
            author = self.lineAuthor.text().strip()
        try:
            proj.writeEntry(MAP_WEAVER_PROJECT_SCOPE, _mw.MAPESTRY_PROJECT_FLAG_ENTRY, "1")
            proj.writeEntry(MAP_WEAVER_PROJECT_SCOPE, _mw.MAPESTRY_PROJECT_NAME_ENTRY, name)
            proj.writeEntry(MAP_WEAVER_PROJECT_SCOPE, _mw.MAPESTRY_PROJECT_AUTHOR_ENTRY, author)
        except Exception:
            pass

    def _clear_mapestry_project_stamp(self) -> None:
        from qgis.core import QgsProject

        from . import map_weaver as _mw
        from .route_arcs_project_blob import MAP_WEAVER_PROJECT_SCOPE

        proj = QgsProject.instance()
        for key in (
            _mw.MAPESTRY_PROJECT_FLAG_ENTRY,
            _mw.MAPESTRY_PROJECT_NAME_ENTRY,
            _mw.MAPESTRY_PROJECT_AUTHOR_ENTRY,
        ):
            try:
                proj.removeEntry(MAP_WEAVER_PROJECT_SCOPE, key)
            except Exception:
                pass
        for k in _mw._LEGACY_MAPESTRY_FLAG_KEYS:
            try:
                proj.removeCustomProperty(k)
            except Exception:
                pass

    def _on_start_session(self):
        """Create Project: save project as, then Airline Route → Route Connections; others → Add points."""
        self._persist_mapestry_identity_to_project()
        if not self._save_project_via_dialog():
            self._clear_mapestry_project_stamp()
            return
        apply_global_palette_xml_to_project_if_present()
        if self._plugin is not None:
            self._plugin.syncDockMapestryMeta()
            if self._active_slug() == "airline_route":
                self._plugin.openRouteConnectionsDialog()
            else:
                self._plugin.openPointMapDialog()
        self.accept()

    def _on_card_clicked(self, card):
        self._select_card(card)

    def _select_card(self, selected):
        for c in self._cards:
            c.set_selected(c is selected)
        self._update_filename_preview()

    def _active_slug(self):
        for attr, slug in self._slug_by_attr.items():
            w = getattr(self, attr, None)
            if w is not None and w.is_selected():
                return slug
        return "location_plot"

    def _update_filename_preview(self):
        if not hasattr(self, "lblSuggestedFilename"):
            return
        date_prefix = datetime.now().strftime("%Y%m%d")
        slug = self._active_slug()
        project = ""
        if hasattr(self, "lineProjectName"):
            project = self.lineProjectName.text().strip()
        safe = re.sub(r"[^a-zA-Z0-9_-]+", "_", project).strip("_").lower() if project else ""
        mid = f"{safe}_" if safe else ""
        self.lblSuggestedFilename.setText(f"{date_prefix}_{mid}{slug}_project.qgz")
        self._sync_create_project_button()
