# -*- coding: utf-8 -*-
"""Route Connections arc sync without closing the dialog (vendor ``sync_arcs`` calls ``dialog.close()``)."""

from qgis.PyQt.QtCore import Qt


def sync_route_arcs_without_close(host):
    """
    Same behavior as ``vendor.route_connections.route_connections.RouteConnections.sync_arcs``,
    but does **not** close the dialog so users can add more routes and Apply again.
    """
    self = host
    dlg = self.dialog
    if dlg is None:
        return
    source_layer = dlg.current_layer
    if not source_layer:
        return

    arc_layer = self.get_arc_layer(source_layer.crs())
    if not arc_layer.isEditable():
        arc_layer.startEditing()

    table_uuids = set()
    row_count = dlg.mConnectionsTable.rowCount()
    for row in range(row_count):
        start_item = dlg.mConnectionsTable.item(row, 0)
        if start_item is None:
            continue
        conn_id = start_item.data(Qt.UserRole + 1)
        if conn_id:
            table_uuids.add(conn_id)

    map_uuids = set()
    features_to_delete = []
    for feat in arc_layer.getFeatures():
        conn_id = feat.attribute("ConnID")
        if conn_id:
            map_uuids.add(conn_id)
            if conn_id not in table_uuids:
                features_to_delete.append(feat.id())

    if features_to_delete:
        arc_layer.deleteFeatures(features_to_delete)

    for row in range(row_count):
        start_item = dlg.mConnectionsTable.item(row, 0)
        end_item = dlg.mConnectionsTable.item(row, 1)
        if start_item is None or end_item is None:
            continue
        conn_id = start_item.data(Qt.UserRole + 1)
        if conn_id and conn_id not in map_uuids:
            start_fid = start_item.data(Qt.UserRole)
            end_fid = end_item.data(Qt.UserRole)
            start_text = start_item.text()
            end_text = end_item.text()
            self.draw_single_arc(
                start_fid, end_fid, start_text, end_text, conn_id, source_layer, arc_layer
            )

    arc_layer.triggerRepaint()
