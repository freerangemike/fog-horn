# -*- coding: utf-8 -*-
"""Pure QML Route Connections dialog host: models + bridge for route_connections_dialog_qml.qml."""

import os
import uuid
from functools import partial

from qgis.PyQt.QtCore import (
    QAbstractTableModel,
    QModelIndex,
    QObject,
    QTimer,
    Qt,
    pyqtProperty,
    pyqtSignal,
    pyqtSlot,
)
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import QDialog, QMessageBox, QVBoxLayout
from qgis.core import QgsProject, QgsVectorLayer, QgsWkbTypes
from qgis.gui import QgsMapToolIdentifyFeature

try:
    from PyQt5.QtQuickWidgets import QQuickWidget
except Exception:
    QQuickWidget = None

try:
    from PyQt5.QtCore import QUrl
except Exception:
    from qgis.PyQt.QtCore import QUrl

from .vendor.route_connections.edit_curve_tool import EditCurveMapTool
from .vendor.route_connections.route_connections import RouteConnections


class _RouteConnectionsQmlDialogShim:
    """Minimal stand-in for RouteConnectionsDialog.current_layer (EditCurveMapTool)."""

    def __init__(self, bridge):
        self._bridge = bridge

    @property
    def current_layer(self):
        return self._bridge.current_layer


class _MapIdentifyReceiver(QObject):
    """Receives QgsMapToolIdentifyFeature signals — NOT exposed to QML.

    Delivering identify callbacks directly to the QML context ``bridge`` QObject can crash
    inside QQmlData during canvasReleaseEvent (access violation on Windows). Copy primitives
    here and defer UI work to the next event-loop tick.
    """

    def __init__(self, bridge):
        super().__init__(bridge._dialog)
        self._bridge = bridge

    def on_feature_identified(self, feature):
        try:
            fid = feature.id()
            attrs = feature.attributes()
            display_text = str(attrs[0]) if attrs else "Feature {}".format(fid)
        except Exception:
            return
        QTimer.singleShot(
            0, partial(self._bridge._complete_map_identify, fid, display_text)
        )


class PreviewTableModel(QAbstractTableModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._headers = []
        self._rows = []

    def roleNames(self):
        return {Qt.DisplayRole: b"display"}

    def rowCount(self, parent=QModelIndex()):
        if parent.isValid():
            return 0
        return len(self._rows)

    def columnCount(self, parent=QModelIndex()):
        if parent.isValid():
            return 0
        return len(self._headers)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        if role != Qt.DisplayRole:
            return None
        row = self._rows[index.row()]
        col = index.column()
        if col >= len(row):
            return ""
        return row[col][0]

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            if 0 <= section < len(self._headers):
                return self._headers[section]
        return None

    def cell_fid(self, row, col):
        if row < 0 or row >= len(self._rows):
            return None
        r = self._rows[row]
        if col < 0 or col >= len(r):
            return None
        return r[col][1]

    def set_from_layer(self, layer):
        self.beginResetModel()
        self._headers = []
        self._rows = []
        if layer is None:
            self.endResetModel()
            return
        fields = layer.fields()
        self._headers = [fields.at(i).name() for i in range(fields.count())]
        features = list(layer.getFeatures())
        for feat in features:
            row = []
            for i in range(fields.count()):
                field = fields.at(i)
                val = feat.attribute(field.name())
                row.append((str(val), feat.id()))
            self._rows.append(row)
        self.endResetModel()


class ConnectionsTableModel(QAbstractTableModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._rows = []

    def roleNames(self):
        return {Qt.DisplayRole: b"display"}

    def rowCount(self, parent=QModelIndex()):
        if parent.isValid():
            return 0
        return len(self._rows)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else 2

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or role != Qt.DisplayRole:
            return None
        r = self._rows[index.row()]
        return r["start_text"] if index.column() == 0 else r["end_text"]

    def append_row(self, start_text, end_text, start_fid, end_fid, conn_id):
        self.beginInsertRows(QModelIndex(), len(self._rows), len(self._rows))
        self._rows.append(
            {
                "start_text": start_text,
                "end_text": end_text,
                "start_fid": start_fid,
                "end_fid": end_fid,
                "conn_id": conn_id,
            }
        )
        self.endInsertRows()

    def remove_rows(self, indices_desc):
        for row in indices_desc:
            if 0 <= row < len(self._rows):
                self.beginRemoveRows(QModelIndex(), row, row)
                del self._rows[row]
                self.endRemoveRows()

    def row_dict(self, row):
        if 0 <= row < len(self._rows):
            return self._rows[row]
        return None

    def all_rows(self):
        return list(self._rows)

    def clear(self):
        if not self._rows:
            return
        self.beginResetModel()
        self._rows = []
        self.endResetModel()


class RouteConnectionsQmlBridge(QObject):
    """Exposes state and actions to route_connections_dialog_qml.qml."""

    layerNamesChanged = pyqtSignal()
    layerIndexChanged = pyqtSignal()
    startTextChanged = pyqtSignal()
    endTextChanged = pyqtSignal()
    selectionPhaseChanged = pyqtSignal()
    previewHeadersChanged = pyqtSignal()
    previewColumnCountChanged = pyqtSignal()
    previewHighlightChanged = pyqtSignal()
    connectionsSelectedRowChanged = pyqtSignal()

    def __init__(self, iface, dialog, parent=None):
        super().__init__(parent)
        self._iface = iface
        self._dialog = dialog
        self._point_layers = []
        self._layer_index = -1
        self._start_text = ""
        self._end_text = ""
        self._next_pick = "start"
        self._start_fid = None
        self._end_fid = None
        self._preview_highlight_row = -1
        self._preview_highlight_col = -1
        self._connections_selected_row = -1
        self._map_tool = None
        self._identify_receiver = _MapIdentifyReceiver(self)

        self.preview_model = PreviewTableModel(self)
        self.connections_model = ConnectionsTableModel(self)

        self._route_svc = RouteConnections(iface)
        self._shim = _RouteConnectionsQmlDialogShim(self)
        self._curve_tool = EditCurveMapTool(iface.mapCanvas(), self._route_svc, self._shim)

    def _emit_preview_structure(self):
        self.previewHeadersChanged.emit()
        self.previewColumnCountChanged.emit()

    @pyqtProperty("QStringList", notify=previewHeadersChanged)
    def previewHeaders(self):
        return self.preview_model._headers

    @pyqtProperty(int, notify=previewColumnCountChanged)
    def previewColumnCount(self):
        return len(self.preview_model._headers)

    @pyqtProperty(QObject, constant=True)
    def previewModel(self):
        return self.preview_model

    @pyqtProperty(QObject, constant=True)
    def connectionsModel(self):
        return self.connections_model

    @pyqtProperty("QStringList", notify=layerNamesChanged)
    def layerNames(self):
        return [layer.name() for layer in self._point_layers]

    @pyqtProperty(int, notify=layerIndexChanged)
    def layerIndex(self):
        return self._layer_index

    @pyqtProperty(str, notify=startTextChanged)
    def startText(self):
        return self._start_text

    @pyqtProperty(str, notify=endTextChanged)
    def endText(self):
        return self._end_text

    @pyqtProperty(str, notify=selectionPhaseChanged)
    def selectionPhase(self):
        return self._next_pick

    @pyqtProperty(int, notify=previewHighlightChanged)
    def previewHighlightRow(self):
        return self._preview_highlight_row

    @pyqtProperty(int, notify=previewHighlightChanged)
    def previewHighlightColumn(self):
        return self._preview_highlight_col

    @pyqtProperty(int, notify=connectionsSelectedRowChanged)
    def connectionsSelectedRow(self):
        return self._connections_selected_row

    @property
    def current_layer(self):
        if self._layer_index < 0 or self._layer_index >= len(self._point_layers):
            return None
        return self._point_layers[self._layer_index]

    def _set_layer_index(self, idx):
        if idx == self._layer_index:
            return
        self._layer_index = idx
        self.layerIndexChanged.emit()
        self._reset_pick_state()
        layer = self.current_layer
        self.preview_model.set_from_layer(layer)
        self._emit_preview_structure()

    def _reset_pick_state(self):
        self._start_text = ""
        self._end_text = ""
        self._start_fid = None
        self._end_fid = None
        self._next_pick = "start"
        self.startTextChanged.emit()
        self.endTextChanged.emit()
        self.selectionPhaseChanged.emit()
        self._clear_preview_highlight()

    def _clear_preview_highlight(self):
        self._preview_highlight_row = -1
        self._preview_highlight_col = -1
        self.previewHighlightChanged.emit()

    @pyqtSlot(int)
    def selectLayer(self, index):
        if index < 0 or index >= len(self._point_layers):
            self._set_layer_index(-1)
            return
        self._set_layer_index(index)

    @pyqtSlot(str)
    def setStartText(self, text):
        text = str(text)
        if text == self._start_text:
            return
        self._start_text = text
        self._start_fid = None
        self.startTextChanged.emit()

    @pyqtSlot(str)
    def setEndText(self, text):
        text = str(text)
        if text == self._end_text:
            return
        self._end_text = text
        self._end_fid = None
        self.endTextChanged.emit()

    @pyqtSlot(int, int)
    def previewCellClicked(self, row, column):
        fid = self.preview_model.cell_fid(row, column)
        if fid is None:
            return
        item_text = self.preview_model.data(
            self.preview_model.index(row, column), Qt.DisplayRole
        )
        self._preview_highlight_row = row
        self._preview_highlight_col = column
        self.previewHighlightChanged.emit()

        if self._next_pick == "start":
            self._start_text = item_text or ""
            self._start_fid = fid
            self._next_pick = "end"
        else:
            self._end_text = item_text or ""
            self._end_fid = fid
            self._next_pick = "start"
        self.startTextChanged.emit()
        self.endTextChanged.emit()
        self.selectionPhaseChanged.emit()

    @pyqtSlot(int)
    def selectConnectionRow(self, row):
        self._connections_selected_row = row
        self.connectionsSelectedRowChanged.emit()

    @pyqtSlot()
    def removeConnection(self):
        row = self._connections_selected_row
        if row < 0:
            return
        self.connections_model.remove_rows([row])
        self._connections_selected_row = -1
        self.connectionsSelectedRowChanged.emit()

    def find_feature_by_text(self, text):
        layer = self.current_layer
        if not layer:
            return None
        for feat in layer.getFeatures():
            for attr in feat.attributes():
                if str(attr) == text:
                    return feat.id()
        return None

    @pyqtSlot()
    def addConnection(self):
        layer = self.current_layer
        if not layer:
            return
        start_text = self._start_text.strip()
        end_text = self._end_text.strip()
        if not start_text or not end_text:
            return

        start_fid = self._start_fid
        if start_fid is None:
            start_fid = self.find_feature_by_text(start_text)
            if start_fid is None:
                QMessageBox.warning(
                    self._dialog,
                    self.tr("Location Not Found"),
                    self.tr("Could not find start location: '{}' in the selected layer.").format(
                        start_text
                    ),
                )
                return

        end_fid = self._end_fid
        if end_fid is None:
            end_fid = self.find_feature_by_text(end_text)
            if end_fid is None:
                QMessageBox.warning(
                    self._dialog,
                    self.tr("Location Not Found"),
                    self.tr("Could not find end location: '{}' in the selected layer.").format(
                        end_text
                    ),
                )
                return

        conn_id = str(uuid.uuid4())
        self.connections_model.append_row(start_text, end_text, start_fid, end_fid, conn_id)
        self._reset_pick_state()

    @pyqtSlot()
    def selectFromMap(self):
        layer = self.current_layer
        if not layer:
            return
        self._dialog.hide()

        prev = self._map_tool
        if prev is not None:
            try:
                prev.featureIdentified.disconnect(self._identify_receiver.on_feature_identified)
            except Exception:
                pass

        self._map_tool = QgsMapToolIdentifyFeature(self._iface.mapCanvas(), layer)
        self._map_tool.featureIdentified.connect(self._identify_receiver.on_feature_identified)
        self._iface.mapCanvas().setMapTool(self._map_tool)

    def _complete_map_identify(self, fid, display_text):
        tool = self._map_tool
        self._map_tool = None
        if tool is not None:
            try:
                tool.featureIdentified.disconnect(self._identify_receiver.on_feature_identified)
            except Exception:
                pass
            try:
                self._iface.mapCanvas().unsetMapTool(tool)
            except Exception:
                pass

        self._dialog.show()
        self._dialog.raise_()
        self._dialog.activateWindow()

        if self._next_pick == "start":
            self._start_text = display_text
            self._start_fid = fid
            self._next_pick = "end"
        else:
            self._end_text = display_text
            self._end_fid = fid
            self._next_pick = "start"
        self.startTextChanged.emit()
        self.endTextChanged.emit()
        self.selectionPhaseChanged.emit()

    @pyqtSlot()
    def editCurve(self):
        self._iface.mapCanvas().setMapTool(self._curve_tool)
        self._dialog.hide()

    @pyqtSlot()
    def rejectDialog(self):
        self._dialog.reject()

    @pyqtSlot()
    def apply(self):
        layer = self.current_layer
        if not layer:
            QMessageBox.warning(
                self._dialog,
                "Route Connections",
                "Choose a point layer with CSV or point data.",
            )
            return

        rows = self.connections_model.all_rows()

        rc = self._route_svc
        arc_layer = rc.get_arc_layer(layer.crs())
        if not arc_layer.isEditable():
            arc_layer.startEditing()

        table_uuids = {r["conn_id"] for r in rows if r.get("conn_id")}
        map_uuids = set()
        features_to_delete = []
        for feat in arc_layer.getFeatures():
            conn_id = feat.attribute("ConnID")
            if conn_id:
                map_uuids.add(conn_id)
                if conn_id not in table_uuids:
                    features_to_delete.append(feat.id())

        if features_to_delete:
            arc_layer.deleteFeatures(features_to_delete)

        for r in rows:
            conn_id = r["conn_id"]
            if conn_id and conn_id not in map_uuids:
                rc.draw_single_arc(
                    r["start_fid"],
                    r["end_fid"],
                    r["start_text"],
                    r["end_text"],
                    conn_id,
                    layer,
                    arc_layer,
                )

        arc_layer.triggerRepaint()
        self._dialog.accept()

    def tr(self, text):
        return text

    def begin_reset(self):
        layers = QgsProject.instance().mapLayers().values()
        self._point_layers = []
        for layer in layers:
            if isinstance(layer, QgsVectorLayer) and layer.geometryType() == QgsWkbTypes.PointGeometry:
                self._point_layers.append(layer)

        self.layerNamesChanged.emit()

        if len(self._point_layers) == 1:
            self._set_layer_index(0)
        elif len(self._point_layers) > 1:
            self._set_layer_index(0)
        else:
            self._set_layer_index(-1)


def open_route_connections_qml_dialog(iface, parent=None):
    if QQuickWidget is None:
        QMessageBox.warning(
            parent,
            "Qt Quick",
            "QQuickWidget is not available in this QGIS build.",
        )
        return

    dlg = QDialog(parent)
    dlg.setWindowTitle("Route Connections")
    dlg.resize(900, 560)

    layout = QVBoxLayout(dlg)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(0)

    qml_path = os.path.join(os.path.dirname(__file__), "route_connections_dialog_qml.qml")
    if not os.path.isfile(qml_path):
        QMessageBox.warning(parent, "Route Connections", "Missing QML file:\n{}".format(qml_path))
        return

    bridge = RouteConnectionsQmlBridge(iface, dlg, dlg)
    quick = QQuickWidget(dlg)
    quick.setResizeMode(QQuickWidget.SizeRootObjectToView)
    quick.setClearColor(QColor("#0f172a"))
    eng = quick.engine()
    if eng is not None:
        eng.rootContext().setContextProperty("bridge", bridge)

    url = QUrl.fromLocalFile(os.path.abspath(qml_path))
    try:
        url.setQuery("v={}".format(os.path.getmtime(qml_path)))
    except Exception:
        pass
    quick.setSource(url)
    if quick.status() == QQuickWidget.Error:
        errs = quick.errors()
        msg = errs[0].toString() if errs else "Unknown QML error"
        QMessageBox.warning(parent, "Route Connections", msg)
        return

    layout.addWidget(quick)
    bridge.begin_reset()
    dlg.show()
    dlg.raise_()
    dlg.activateWindow()
