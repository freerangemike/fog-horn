import os
import uuid

from qgis.PyQt import uic
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QDialog, QTableWidgetItem, QMessageBox
from qgis.core import QgsProject, QgsVectorLayer, QgsWkbTypes
from qgis.gui import QgsMapToolIdentifyFeature, QgsMapToolPan

FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "route_connections_dialog_base.ui")
)


class RouteConnectionsDialog(QDialog, FORM_CLASS):
    def __init__(self, plugin, parent=None):
        mw = None
        if plugin is not None and getattr(plugin, "iface", None) is not None:
            mw = plugin.iface.mainWindow()
        super(RouteConnectionsDialog, self).__init__(mw if mw is not None else parent)
        self.plugin = plugin
        self.iface = plugin.iface
        self.setupUi(self)
        try:
            self.setWindowFlags(self.windowFlags() | Qt.Tool)
        except Exception:
            pass

        self.next_selection = "start"
        self.current_layer = None

        self.mLayerComboBox.currentIndexChanged.connect(self.on_layer_changed)
        self.mDataPreviewTable.cellClicked.connect(self.on_cell_clicked)
        self.mAddButton.clicked.connect(self.add_connection)
        self.mRemoveButton.clicked.connect(self.remove_connection)
        self.mSelectFromMapButton.clicked.connect(self.select_from_map)
        self.mEditCurveButton.clicked.connect(self._on_edit_curve_clicked)
        self.mCloseButton.clicked.connect(self.close)

        self.mStartLineEdit.textChanged.connect(self.on_start_text_changed)
        self.mEndLineEdit.textChanged.connect(self.on_end_text_changed)

        self.current_start_fid = None
        self.current_end_fid = None

        self._edit_curve_canvas_tool_signal = None
        self._cached_pan_tool = None
        self._setup_edit_curve_canvas_watch()

    def _raise_above_main_window(self, take_focus=False):
        """Raise stacking order; optional keyboard focus (avoid when map canvas must receive clicks)."""
        try:
            self.raise_()
            if take_focus:
                self.activateWindow()
        except Exception:
            pass

    def _route_connections_pan_tool(self):
        if self._cached_pan_tool is None:
            self._cached_pan_tool = QgsMapToolPan(self.iface.mapCanvas())
        return self._cached_pan_tool

    def _setup_edit_curve_canvas_watch(self):
        canvas = self.iface.mapCanvas()
        if canvas is None or self._edit_curve_canvas_tool_signal is not None:
            return
        handler = self._on_edit_curve_canvas_tool_changed
        if hasattr(canvas, "mapToolSet"):
            canvas.mapToolSet.connect(handler)
            self._edit_curve_canvas_tool_signal = "mapToolSet"
        elif hasattr(canvas, "mapToolChanged"):
            canvas.mapToolChanged.connect(handler)
            self._edit_curve_canvas_tool_signal = "mapToolChanged"
        else:
            return
        self._on_edit_curve_canvas_tool_changed()

    def _teardown_edit_curve_canvas_watch(self):
        canvas = self.iface.mapCanvas()
        sig = self._edit_curve_canvas_tool_signal
        if canvas is None or sig is None:
            self._edit_curve_canvas_tool_signal = None
            return
        handler = self._on_edit_curve_canvas_tool_changed
        try:
            getattr(canvas, sig).disconnect(handler)
        except (TypeError, RuntimeError):
            pass
        self._edit_curve_canvas_tool_signal = None

    def _sync_edit_curve_button_from_canvas(self):
        canvas = self.iface.mapCanvas()
        tool = getattr(self.plugin, "edit_curve_tool", None)
        if canvas is None or tool is None:
            return
        try:
            active = canvas.mapTool() is tool
        except Exception:
            active = False
        self.mEditCurveButton.blockSignals(True)
        self.mEditCurveButton.setChecked(active)
        self.mEditCurveButton.blockSignals(False)

    def _on_edit_curve_canvas_tool_changed(self, *args):
        new_tool = args[0] if args else None
        canvas = self.iface.mapCanvas()
        if new_tool is None and canvas is not None:
            try:
                new_tool = canvas.mapTool()
            except Exception:
                new_tool = None
        curve_tool = getattr(self.plugin, "edit_curve_tool", None)
        try:
            active = curve_tool is not None and new_tool is curve_tool
        except Exception:
            active = False
        self.mEditCurveButton.blockSignals(True)
        self.mEditCurveButton.setChecked(active)
        self.mEditCurveButton.blockSignals(False)
        if active:
            self._raise_above_main_window(take_focus=False)

    def _on_edit_curve_clicked(self, checked=False):
        tool = getattr(self.plugin, "edit_curve_tool", None)
        canvas = self.iface.mapCanvas()
        if tool is None or canvas is None:
            return
        if checked:
            canvas.setMapTool(tool)
            self._raise_above_main_window(take_focus=False)
        else:
            canvas.setMapTool(self._route_connections_pan_tool())

    def showEvent(self, event):
        super(RouteConnectionsDialog, self).showEvent(event)
        if self._edit_curve_canvas_tool_signal is None:
            self._setup_edit_curve_canvas_watch()
        else:
            self._sync_edit_curve_button_from_canvas()
        self._raise_above_main_window(take_focus=True)

    def closeEvent(self, event):
        self._teardown_edit_curve_canvas_watch()
        canvas = self.iface.mapCanvas()
        tool = getattr(self.plugin, "edit_curve_tool", None)
        if canvas is not None and tool is not None:
            try:
                if canvas.mapTool() is tool:
                    canvas.setMapTool(self._route_connections_pan_tool())
            except Exception:
                pass
        self.mEditCurveButton.blockSignals(True)
        self.mEditCurveButton.setChecked(False)
        self.mEditCurveButton.blockSignals(False)
        super(RouteConnectionsDialog, self).closeEvent(event)

    def on_start_text_changed(self, text):
        self.current_start_fid = None

    def on_end_text_changed(self, text):
        self.current_end_fid = None

    def find_feature_by_text(self, text):
        if not self.current_layer:
            return None
        for feat in self.current_layer.getFeatures():
            attrs = feat.attributes()
            for attr in attrs:
                if str(attr) == text:
                    return feat.id()
        return None

    def populate_layers(self):
        self.mLayerComboBox.clear()
        layers = QgsProject.instance().mapLayers().values()

        self.point_layers = []
        for layer in layers:
            if isinstance(layer, QgsVectorLayer) and layer.geometryType() == QgsWkbTypes.PointGeometry:
                self.point_layers.append(layer)
                self.mLayerComboBox.addItem(layer.name(), layer.id())

        if len(self.point_layers) == 1:
            self.mLayerComboBox.setCurrentIndex(0)
            self.on_layer_changed(0)
        elif len(self.point_layers) > 1:
            self.mLayerComboBox.setCurrentIndex(0)
            self.on_layer_changed(0)

    def on_layer_changed(self, index):
        if index < 0:
            self.current_layer = None
            self.mDataPreviewTable.setRowCount(0)
            self.mDataPreviewTable.setColumnCount(0)
            self.mConnectionsTable.setRowCount(0)
            return

        layer_id = self.mLayerComboBox.itemData(index)
        self.current_layer = QgsProject.instance().mapLayer(layer_id)

        if not self.current_layer:
            return

        self.populate_preview_table()

        self.next_selection = "start"
        self.mStartLineEdit.clear()
        self.mEndLineEdit.clear()
        self.current_start_fid = None
        self.current_end_fid = None

        self.restore_connections_from_route_arcs()

    def restore_connections_from_route_arcs(self):
        """Rebuild the connections table from the Route Arcs layer (same CRS as the point layer)."""
        from .route_arcs_layer import find_route_arcs_layer_for_crs

        self.mConnectionsTable.setRowCount(0)
        if self.current_layer is None:
            return
        try:
            arc = find_route_arcs_layer_for_crs(self.current_layer.crs())
        except Exception:
            arc = None
        if arc is None:
            return
        for feat in arc.getFeatures():
            try:
                start_txt = feat.attribute("Start")
                end_txt = feat.attribute("End")
                conn_id = feat.attribute("ConnID")
            except Exception:
                continue
            start_txt = "" if start_txt is None else str(start_txt)
            end_txt = "" if end_txt is None else str(end_txt)
            conn_id = "" if conn_id is None else str(conn_id)
            if not conn_id:
                continue
            start_fid = self.find_feature_by_text(start_txt)
            end_fid = self.find_feature_by_text(end_txt)
            if start_fid is None or end_fid is None:
                continue
            row = self.mConnectionsTable.rowCount()
            self.mConnectionsTable.insertRow(row)
            start_item = QTableWidgetItem(start_txt)
            start_item.setData(Qt.UserRole, start_fid)
            start_item.setData(Qt.UserRole + 1, conn_id)
            end_item = QTableWidgetItem(end_txt)
            end_item.setData(Qt.UserRole, end_fid)
            self.mConnectionsTable.setItem(row, 0, start_item)
            self.mConnectionsTable.setItem(row, 1, end_item)

    def populate_preview_table(self):
        self.mDataPreviewTable.clear()

        if not self.current_layer:
            return

        fields = self.current_layer.fields()

        self.mDataPreviewTable.setColumnCount(fields.count())
        self.mDataPreviewTable.setHorizontalHeaderLabels([f.name() for f in fields])

        features = list(self.current_layer.getFeatures())
        self.mDataPreviewTable.setRowCount(len(features))

        for row, feat in enumerate(features):
            for col, field in enumerate(fields):
                val = feat.attribute(field.name())
                item = QTableWidgetItem(str(val))
                item.setData(Qt.UserRole, feat.id())
                self.mDataPreviewTable.setItem(row, col, item)

        self.mDataPreviewTable.resizeColumnsToContents()

    def on_cell_clicked(self, row, column):
        item = self.mDataPreviewTable.item(row, column)
        if not item:
            return

        cell_text = item.text()
        fid = item.data(Qt.UserRole)

        if self.next_selection == "start":
            self.mStartLineEdit.setText(cell_text)
            self.current_start_fid = fid
            self.next_selection = "end"
        else:
            self.mEndLineEdit.setText(cell_text)
            self.current_end_fid = fid
            self.next_selection = "start"

    def select_from_map(self):
        if not self.current_layer:
            return

        self.hide()

        self.map_tool = QgsMapToolIdentifyFeature(self.iface.mapCanvas(), self.current_layer)
        self.map_tool.featureIdentified.connect(self.on_feature_identified)
        self.iface.mapCanvas().setMapTool(self.map_tool)

    def on_feature_identified(self, feature):
        self.iface.mapCanvas().unsetMapTool(self.map_tool)
        self.show()

        fid = feature.id()
        attrs = feature.attributes()
        display_text = str(attrs[0]) if attrs else f"Feature {fid}"

        if self.next_selection == "start":
            self.mStartLineEdit.setText(display_text)
            self.current_start_fid = fid
            self.next_selection = "end"
        else:
            self.mEndLineEdit.setText(display_text)
            self.current_end_fid = fid
            self.next_selection = "start"

    def add_connection(self):
        start_text = self.mStartLineEdit.text()
        end_text = self.mEndLineEdit.text()

        if not start_text or not end_text:
            return

        start_fid = self.current_start_fid
        if start_fid is None:
            start_fid = self.find_feature_by_text(start_text)
            if start_fid is None:
                QMessageBox.warning(
                    self,
                    "Location Not Found",
                    f"Could not find start location: '{start_text}' in the selected layer.",
                )
                return

        end_fid = self.current_end_fid
        if end_fid is None:
            end_fid = self.find_feature_by_text(end_text)
            if end_fid is None:
                QMessageBox.warning(
                    self,
                    "Location Not Found",
                    f"Could not find end location: '{end_text}' in the selected layer.",
                )
                return

        conn_id = str(uuid.uuid4())

        row_position = self.mConnectionsTable.rowCount()
        self.mConnectionsTable.insertRow(row_position)

        start_item = QTableWidgetItem(start_text)
        start_item.setData(Qt.UserRole, start_fid)
        start_item.setData(Qt.UserRole + 1, conn_id)

        end_item = QTableWidgetItem(end_text)
        end_item.setData(Qt.UserRole, end_fid)

        self.mConnectionsTable.setItem(row_position, 0, start_item)
        self.mConnectionsTable.setItem(row_position, 1, end_item)

        self.mStartLineEdit.clear()
        self.mEndLineEdit.clear()
        self.current_start_fid = None
        self.current_end_fid = None
        self.next_selection = "start"

    def remove_connection(self):
        selected_rows = self.mConnectionsTable.selectionModel().selectedRows()
        for index in sorted(selected_rows, reverse=True):
            self.mConnectionsTable.removeRow(index.row())
