import QtQuick 2.12

Rectangle {
    id: root
    width: 360
    height: 220
    color: "#ffffff"

    property real yaw: 0.5
    property real pitch: 0.15

    Canvas {
        id: globeCanvas
        anchors.fill: parent
        antialiasing: true

        onPaint: {
            var ctx = getContext("2d")
            var w = width
            var h = height
            ctx.globalAlpha = 1.0
            ctx.setTransform(1, 0, 0, 1, 0, 0)
            ctx.clearRect(0, 0, w, h)

            var cx = w / 2
            var cy = h / 2
            var r = Math.min(w, h) * 0.42

            // Sphere fill
            var grad = ctx.createRadialGradient(cx - r * 0.35, cy - r * 0.4, r * 0.15, cx, cy, r)
            grad.addColorStop(0.0, "#7fc7ff")
            grad.addColorStop(0.6, "#4ea0e0")
            grad.addColorStop(1.0, "#2f6ba1")
            ctx.fillStyle = grad
            ctx.beginPath()
            ctx.arc(cx, cy, r, 0, Math.PI * 2)
            ctx.fill()

            // Clip all graticule/land details to sphere
            ctx.save()
            ctx.beginPath()
            ctx.arc(cx, cy, r, 0, Math.PI * 2)
            ctx.clip()

            function rotate(lat, lon) {
                var clat = Math.cos(lat)
                var x = clat * Math.cos(lon)
                var y = Math.sin(lat)
                var z = clat * Math.sin(lon)

                var cyaw = Math.cos(root.yaw)
                var syaw = Math.sin(root.yaw)
                var x1 = x * cyaw + z * syaw
                var z1 = -x * syaw + z * cyaw

                var cp = Math.cos(root.pitch)
                var sp = Math.sin(root.pitch)
                var y2 = y * cp - z1 * sp
                var z2 = y * sp + z1 * cp

                return { x: x1, y: y2, z: z2 }
            }

            function drawBlob(lat0, lon0, sx, sy) {
                var c = rotate(lat0, lon0)
                if (c.z < 0)
                    return
                var lx = cx + c.x * r
                var ly = cy - c.y * r
                ctx.beginPath()
                ctx.ellipse(lx, ly, sx, sy, 0.5, 0, Math.PI * 2)
                ctx.fill()
            }

            // Graticule
            ctx.strokeStyle = "rgba(255, 255, 255, 0.5)"
            ctx.lineWidth = 1
            for (var gl = -60; gl <= 60; gl += 30) {
                var prev = null
                for (var i = 0; i <= 180; i++) {
                    var lon = -Math.PI + (i / 180.0) * (2 * Math.PI)
                    var p = rotate(gl * Math.PI / 180.0, lon)
                    if (p.z >= 0) {
                        var px = cx + p.x * r
                        var py = cy - p.y * r
                        if (prev !== null) {
                            ctx.beginPath()
                            ctx.moveTo(prev.x, prev.y)
                            ctx.lineTo(px, py)
                            ctx.stroke()
                        }
                        prev = { x: px, y: py }
                    } else {
                        prev = null
                    }
                }
            }

            // Old fake land blobs
            ctx.fillStyle = "rgba(70, 135, 78, 0.9)"
            drawBlob(0.35, -1.3, r * 0.2, r * 0.11)
            drawBlob(0.05, -0.6, r * 0.13, r * 0.08)
            drawBlob(-0.2, 0.25, r * 0.22, r * 0.14)
            drawBlob(0.45, 1.0, r * 0.16, r * 0.1)
            drawBlob(-0.35, 1.4, r * 0.12, r * 0.07)

            ctx.restore()

            // Rim stroke
            ctx.strokeStyle = "#c89a38"
            ctx.lineWidth = 2
            ctx.beginPath()
            ctx.arc(cx, cy, r, 0, Math.PI * 2)
            ctx.stroke()
        }
    }

    Rectangle {
        anchors.fill: parent
        color: "transparent"
        border.color: "#c89a38"
        border.width: 2
        radius: 13
    }

    MouseArea {
        anchors.fill: parent
        property real lastX: 0
        property real lastY: 0
        onPressed: {
            lastX = mouse.x
            lastY = mouse.y
        }
        onPositionChanged: {
            if (!pressed)
                return
            var dx = mouse.x - lastX
            var dy = mouse.y - lastY
            root.yaw += dx * 0.01
            root.pitch += dy * 0.01
            if (root.pitch > 1.2)
                root.pitch = 1.2
            if (root.pitch < -1.2)
                root.pitch = -1.2
            lastX = mouse.x
            lastY = mouse.y
            globeCanvas.requestPaint()
        }
    }

    Component.onCompleted: globeCanvas.requestPaint()
}
