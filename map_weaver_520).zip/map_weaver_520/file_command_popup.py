# -*- coding: utf-8 -*-
"""Modal-less File command list: rounded panel + painted shadow (no QGraphicsDropShadowEffect on rows)."""

from qgis.PyQt import QtCore, QtGui, QtWidgets

# Inline QSS so Fusion respects text/hover regardless of global sheet order.
# QObject child styles when parent uses QGraphicsEffect — breaks :hover reliably.
_POPUP_ROW_QSS = """
QWidget#fileCommandPopup {
    background-color: transparent;
}
QWidget#fileCommandPopup QPushButton#fileCommandRowBtn {
    color: rgb(255, 247, 242);
    background-color: rgba(255, 255, 255, 0);
    border: none;
    border-radius: 7px;
    text-align: left;
    padding: 7px 11px;
    font-size: 13px;
    min-height: 21px;
    outline: none;
}
QWidget#fileCommandPopup QPushButton#fileCommandRowBtn:hover {
    background-color: rgb(214, 150, 150);
    color: rgb(255, 255, 255);
    border: 1px solid rgb(232, 200, 200);
}
QWidget#fileCommandPopup QPushButton#fileCommandRowBtn:pressed {
    background-color: rgb(110, 40, 40);
    color: rgb(255, 255, 255);
    border: 1px solid rgb(200, 160, 160);
}
"""


class FileCommandPopup(QtWidgets.QWidget):
    """Popup with painted rounded shadow + gradient panel; row buttons styled locally."""

    _BORDER = QtGui.QColor(146, 70, 70)
    _TOP_LINE = QtGui.QColor(220, 180, 180)

    def __init__(self, parent, specs, radius_px=10):
        super().__init__(parent)
        self.setObjectName("fileCommandPopup")
        self._radius = int(radius_px)
        self.setStyleSheet(_POPUP_ROW_QSS)

        flags = QtCore.Qt.Popup | QtCore.Qt.FramelessWindowHint
        if hasattr(QtCore.Qt, "NoDropShadowWindowHint"):
            flags |= QtCore.Qt.NoDropShadowWindowHint
        self.setWindowFlags(flags)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground, True)
        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.setMouseTracking(True)
        self.setAttribute(QtCore.Qt.WA_Hover, True)

        # Outer gutter for down-right shadow (drawn behind panel in paintEvent).
        self._shadow_gutter = QtCore.QMargins(4, 4, 16, 20)
        row_pad = QtCore.QMargins(8, 6, 8, 6)

        lay = QtWidgets.QVBoxLayout(self)
        m = QtCore.QMargins(
            self._shadow_gutter.left() + row_pad.left(),
            self._shadow_gutter.top() + row_pad.top(),
            self._shadow_gutter.right() + row_pad.right(),
            self._shadow_gutter.bottom() + row_pad.bottom(),
        )
        lay.setContentsMargins(m.left(), m.top(), m.right(), m.bottom())
        lay.setSpacing(0)

        fm = QtGui.QFontMetrics(self.font())
        max_tw = max(fm.horizontalAdvance(t[0]) for t in specs)
        inner_margin_w = m.left() + m.right()
        min_inner_w = max(240 - inner_margin_w, max_tw + 36)

        for title, cb in specs:
            b = QtWidgets.QPushButton(title, self)
            b.setObjectName("fileCommandRowBtn")
            b.setFlat(True)
            b.setAutoDefault(False)
            b.setDefault(False)
            b.setFocusPolicy(QtCore.Qt.NoFocus)
            b.setCursor(QtCore.Qt.PointingHandCursor)
            b.setMouseTracking(True)
            b.setAttribute(QtCore.Qt.WA_Hover, True)
            b.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
            b.setMinimumWidth(min_inner_w)
            b.setMinimumHeight(35)
            b.setAutoFillBackground(False)
            if hasattr(QtCore.Qt, "WA_StyledBackground"):
                b.setAttribute(QtCore.Qt.WA_StyledBackground, True)

            pb = b.palette()
            pb.setColor(QtGui.QPalette.ButtonText, QtGui.QColor(255, 247, 242))
            pb.setColor(QtGui.QPalette.WindowText, QtGui.QColor(255, 247, 242))
            b.setPalette(pb)

            b.clicked.connect(lambda _=False, fn=cb: self._run_and_hide(fn))
            lay.addWidget(b)

        self.adjustSize()

    def _panel_rect(self):
        """Rounded panel area (excluding shadow gutter)."""
        g = self._shadow_gutter
        return QtCore.QRectF(self.rect()).adjusted(
            float(g.left()), float(g.top()), float(-g.right()), float(-g.bottom())
        ).adjusted(1.0, 1.0, -1.0, -1.0)

    def paintEvent(self, event):
        p = QtGui.QPainter(self)
        p.setCompositionMode(QtGui.QPainter.CompositionMode_Source)
        p.fillRect(self.rect(), QtGui.QColor(0, 0, 0, 0))
        p.setCompositionMode(QtGui.QPainter.CompositionMode_SourceOver)
        p.setRenderHint(QtGui.QPainter.Antialiasing, True)

        panel = self._panel_rect()
        rad = float(self._radius)

        # Rounded shadow: farthest/low-alpha layers first, then tighter/darker toward the panel.
        p.setPen(QtCore.Qt.NoPen)
        for i in range(9, -1, -1):
            t = i / 9.0
            dx = 2.2 + t * 4.0
            dy = 2.8 + t * 5.0
            alpha = int(8 + (1.0 - t) * 36)
            p.setBrush(QtGui.QBrush(QtGui.QColor(0, 0, 0, min(alpha, 58))))
            sr = QtCore.QRectF(panel)
            sr.translate(dx, dy)
            p.drawRoundedRect(sr, rad, rad)

        grad = QtGui.QLinearGradient(0.0, panel.top(), 0.0, panel.bottom())
        grad.setColorAt(0.0, QtGui.QColor(162, 74, 74))
        grad.setColorAt(1.0, QtGui.QColor(145, 58, 58))
        p.setPen(QtGui.QPen(self._BORDER))
        p.setBrush(QtGui.QBrush(grad))
        p.drawRoundedRect(panel, rad, rad)

        p.setPen(QtGui.QPen(self._TOP_LINE))
        x0 = panel.left() + rad * 0.55
        x1 = panel.right() - rad * 0.55
        p.drawLine(QtCore.QLineF(x0, panel.top() + 1.0, x1, panel.top() + 1.0))

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.hide()
            event.accept()
            return
        super().keyPressEvent(event)

    def _run_and_hide(self, fn):
        self.hide()
        if callable(fn):
            fn()
