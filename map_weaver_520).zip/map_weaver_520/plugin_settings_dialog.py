# -*- coding: utf-8 -*-
"""Mapestry plugin settings: theme palette and project color scheme integration."""

from __future__ import annotations

import os
import re
import xml.etree.ElementTree as ET

from qgis.core import QgsColorScheme, QgsProject, QgsProjectColorScheme, Qgis
from qgis.gui import QgsColorButton
from qgis.PyQt import uic
from qgis.PyQt.QtCore import QSettings
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QWidget,
)
from qgis.utils import iface

THEME_SLOT_COUNT = 20
SETTINGS_GROUP = "map_weaver"
SETTINGS_PALETTE_KEY = "theme_palette_v1"
XML_ROOT_TAG = "map_weaver_theme_palette"
XML_VERSION = "1"

# On-disk palette XML lives next to the plugin, under Settings/ (user-sharable).
PLUGIN_ROOT = os.path.dirname(os.path.abspath(__file__))
PALETTE_SETTINGS_SUBDIR = "Settings"
PALETTE_XML_BASENAME = "theme_palette.xml"
GLOBAL_PALETTE_XML_BASENAME = "color_palette.xml"


def _palette_settings_dir() -> str:
    return os.path.join(PLUGIN_ROOT, PALETTE_SETTINGS_SUBDIR)


def _ensure_palette_settings_dir() -> str:
    d = _palette_settings_dir()
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        pass
    return d


def _default_palette_xml_path() -> str:
    return os.path.join(_ensure_palette_settings_dir(), PALETTE_XML_BASENAME)


def _global_palette_xml_path() -> str:
    return os.path.join(_ensure_palette_settings_dir(), GLOBAL_PALETTE_XML_BASENAME)


def _settings() -> QSettings:
    s = QSettings()
    s.beginGroup(SETTINGS_GROUP)
    return s


def _palette_label(slot_index: int) -> str:
    """QGIS project color label (1-based, matches UI copy)."""
    return "Color {}".format(slot_index + 1)


def _canonical_theme_label(name) -> str | None:
    """
    If ``name`` refers to a theme slot (Color 1 … Color 20), return canonical ``Color N``.
    Accepts alternate spacing/casing from QgsProject / scheme APIs.
    """
    s = (str(name) if name is not None else "").strip()
    if not s:
        return None
    m = re.match(r"(?i)^color\s*(\d{1,2})\s*$", s)
    if not m:
        return None
    idx = int(m.group(1))
    if 1 <= idx <= THEME_SLOT_COUNT:
        return _palette_label(idx - 1)
    return None


def _default_color_for_slot(slot_index: int) -> QColor:
    return QColor.fromHsv(int((slot_index * 360.0 / THEME_SLOT_COUNT) % 360), 120, 230)


def _tuple_from_scheme_entry(entry):
    """Normalize QgsProjectColorScheme.fetchColors() entries to (QColor, str)."""
    try:
        from qgis.core import QgsNamedColor

        if isinstance(entry, QgsNamedColor):
            c = entry.color()
            n = entry.name() or ""
            if not n.strip() and hasattr(entry, "label"):
                try:
                    n = entry.label() or ""
                except Exception:
                    n = ""
            if c is None or not isinstance(c, QColor):
                c = QColor()
            return (QColor(c), str(n) if n is not None else "")
    except Exception:
        pass
    if isinstance(entry, (list, tuple)) and len(entry) >= 2:
        c, n = entry[0], entry[1]
        if not isinstance(c, QColor):
            try:
                c = QColor(c)
            except Exception:
                c = QColor()
        return (c, str(n) if n is not None else "")
    return None


def _existing_project_color_rows() -> list[tuple[QColor, str]]:
    rows = []
    try:
        try:
            scheme = QgsProjectColorScheme(QgsProject.instance())
        except TypeError:
            scheme = QgsProjectColorScheme()
        try:
            fetched = scheme.fetchColors(QgsColorScheme.AllContexts)
        except TypeError:
            fetched = scheme.fetchColors(
                QgsColorScheme.AllContexts,
                QColor(),
                QgsColorScheme.MatchAll,
            )
    except Exception:
        return rows
    if not fetched:
        return rows
    for entry in fetched:
        t = _tuple_from_scheme_entry(entry)
        if t is not None:
            rows.append(t)
    return rows


def _reserved_theme_labels() -> set[str]:
    return {_palette_label(i) for i in range(THEME_SLOT_COUNT)}


def _project_theme_slot_colors_from_project() -> dict[str, QColor]:
    """QgsProject colors whose names map to Color 1 … Color 20 (canonical label -> color)."""
    out: dict[str, QColor] = {}
    for c, n in _existing_project_color_rows():
        canon = _canonical_theme_label(n)
        if canon is None:
            continue
        if isinstance(c, QColor) and c.isValid():
            out[canon] = QColor(c)
    return out


def _read_global_theme_palette_by_slot() -> dict[int, QColor] | None:
    """Parse ``Settings/color_palette.xml`` into slot→color, or None if missing/invalid/empty."""
    path = _global_palette_xml_path()
    if not os.path.isfile(path):
        return None
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError):
        return None
    if root.tag != XML_ROOT_TAG:
        return None
    by_slot = _theme_palette_by_slot_from_valid_root(root)
    return by_slot if by_slot else None


def _merge_palette_into_project_colors(
    palette: list[tuple[QColor, str]],
) -> list[tuple[QColor, str]]:
    """Keep unrelated project colors; replace any row whose label matches Color 1 … Color 20."""
    kept = []
    for c, n in _existing_project_color_rows():
        if _canonical_theme_label(n) is not None:
            continue
        kept.append((c, n))
    return kept + list(palette)


def _theme_palette_by_slot_from_valid_root(root: ET.Element) -> dict[int, QColor]:
    """Parse ``color`` elements under a verified ``map_weaver_theme_palette`` root (may be empty)."""
    by_slot: dict[int, QColor] = {}
    for el in root.findall("color"):
        try:
            slot = int(el.get("slot", "0"))
        except ValueError:
            continue
        hx = el.get("hex") or ""
        qc = QColor(hx) if hx else QColor()
        if 1 <= slot <= THEME_SLOT_COUNT and qc.isValid():
            by_slot[slot] = qc
    return by_slot


def palette_tuples_from_theme_slots(by_slot: dict[int, QColor]) -> list[tuple[QColor, str]]:
    """Twenty (color, label) rows for project merge; missing slots use defaults."""
    out: list[tuple[QColor, str]] = []
    for i in range(THEME_SLOT_COUNT):
        c = by_slot.get(i + 1)
        if c is None or not isinstance(c, QColor) or not c.isValid():
            c = _default_color_for_slot(i)
        out.append((QColor(c), _palette_label(i)))
    return out


def apply_global_palette_xml_to_project_if_present(project: QgsProject | None = None) -> bool:
    """
    If ``Settings/color_palette.xml`` exists next to the plugin, merge its theme colors into
    the project color scheme (labels Color 1 … Color 20). Returns True if the file was read and applied.
    """
    path = _global_palette_xml_path()
    if not os.path.isfile(path):
        return False
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError):
        return False
    if root.tag != XML_ROOT_TAG:
        return False
    by_slot = _theme_palette_by_slot_from_valid_root(root)
    if not by_slot:
        return False
    rows = palette_tuples_from_theme_slots(by_slot)
    project = project or QgsProject.instance()
    try:
        project.setProjectColors(_merge_palette_into_project_colors(rows))
    except Exception:
        return False
    return True


class PluginSettingsDialog(QDialog):
    """Twenty-slot theme palette; project colors sync on load / global save; XML share; QSettings persistence."""

    def __init__(self, parent=None):
        super().__init__(parent)
        ui_path = os.path.join(os.path.dirname(__file__), "plugin_settings.ui")
        uic.loadUi(ui_path, self)
        self._color_buttons: list[QgsColorButton] = []
        lay = self.verticalLayout_palette
        for i in range(THEME_SLOT_COUNT):
            row = QWidget(self.scrollAreaWidgetContents)
            h = QHBoxLayout(row)
            h.setContentsMargins(0, 0, 0, 0)
            h.setSpacing(10)
            lab = QLabel(_palette_label(i), row)
            lab.setMinimumWidth(72)
            btn = QgsColorButton(row)
            btn.setMinimumHeight(28)
            btn.setShowMenu(True)
            btn.setColor(_default_color_for_slot(i))
            h.addWidget(lab)
            h.addWidget(btn, 1)
            lay.addWidget(row)
            self._color_buttons.append(btn)
        lay.addStretch(1)

        self.btnSavePaletteXml.clicked.connect(self._on_save_palette_xml)
        self.btnLoadPaletteXml.clicked.connect(self._on_load_palette_xml)
        self.btnSetGlobalColors.clicked.connect(self._on_set_global_colors)
        self.btnLoadGlobalColors.clicked.connect(self._on_load_global_colors)

        self._load_palette_from_settings()

    def accept(self):
        self._persist_palette_to_settings()
        super().accept()

    def _palette_from_buttons(self) -> list[tuple[QColor, str]]:
        out = []
        for i, btn in enumerate(self._color_buttons):
            c = btn.color()
            if not isinstance(c, QColor) or not c.isValid():
                c = _default_color_for_slot(i)
            out.append((QColor(c), _palette_label(i)))
        return out

    def _set_buttons_from_colors(self, colors: list[QColor]) -> None:
        for i, btn in enumerate(self._color_buttons):
            if i < len(colors) and isinstance(colors[i], QColor) and colors[i].isValid():
                btn.setColor(QColor(colors[i]))
            else:
                btn.setColor(_default_color_for_slot(i))

    def _persist_palette_to_settings(self) -> None:
        s = _settings()
        for i, btn in enumerate(self._color_buttons):
            c = btn.color()
            if isinstance(c, QColor) and c.isValid():
                s.setValue(
                    "{}/color_{:02d}".format(SETTINGS_PALETTE_KEY, i + 1),
                    c.name(QColor.HexArgb),
                )
            else:
                s.remove("{}/color_{:02d}".format(SETTINGS_PALETTE_KEY, i + 1))

    def _load_palette_from_settings(self) -> None:
        """Fill swatches: project theme colors, else global XML, else QSettings, else defaults."""
        s = _settings()
        proj_slots = _project_theme_slot_colors_from_project()
        xml_slots = _read_global_theme_palette_by_slot()
        colors = []
        for i in range(THEME_SLOT_COUNT):
            lab = _palette_label(i)
            if lab in proj_slots:
                colors.append(proj_slots[lab])
                continue
            if xml_slots is not None:
                c = xml_slots.get(i + 1)
                if c is not None and isinstance(c, QColor) and c.isValid():
                    colors.append(QColor(c))
                    continue
            key = "{}/color_{:02d}".format(SETTINGS_PALETTE_KEY, i + 1)
            hx = s.value(key, "", type=str)
            if isinstance(hx, str) and len(hx.strip()) >= 6:
                qc = QColor(hx.strip())
                if qc.isValid():
                    colors.append(qc)
                    continue
            colors.append(_default_color_for_slot(i))
        self._set_buttons_from_colors(colors)

    def _push_current_palette_to_project(self) -> bool:
        """Merge the current button palette into QgsProject project colors. False on failure."""
        palette = self._palette_from_buttons()
        try:
            QgsProject.instance().setProjectColors(_merge_palette_into_project_colors(palette))
        except Exception as e:
            QMessageBox.warning(
                self,
                self.tr("Mapestry"),
                self.tr("Could not update project colors: {}").format(e),
            )
            return False
        return True

    def _palette_xml_root_from_buttons(self) -> ET.Element:
        root = ET.Element(XML_ROOT_TAG, version=XML_VERSION)
        for i, btn in enumerate(self._color_buttons):
            c = btn.color()
            if not isinstance(c, QColor) or not c.isValid():
                c = _default_color_for_slot(i)
            ET.SubElement(
                root,
                "color",
                slot=str(i + 1),
                label=_palette_label(i),
                hex=c.name(QColor.HexArgb),
            )
        return root

    def _write_palette_xml_root_to_path(self, root: ET.Element, path: str) -> str | None:
        try:
            ET.ElementTree(root).write(path, encoding="utf-8", xml_declaration=True)
        except OSError as e:
            return str(e)
        return None

    def _apply_palette_from_xml_root(self, root: ET.Element) -> str | None:
        if root.tag != XML_ROOT_TAG:
            return self.tr("This file is not a Mapestry theme palette (root tag {}).").format(
                repr(root.tag)
            )
        by_slot = _theme_palette_by_slot_from_valid_root(root)
        if not by_slot:
            return self.tr("No valid color entries were found in this file.")
        for i, btn in enumerate(self._color_buttons):
            c = by_slot.get(i + 1)
            if c is not None:
                btn.setColor(c)
        return None

    def _on_save_palette_xml(self) -> None:
        _ensure_palette_settings_dir()
        default_path = _default_palette_xml_path()
        path, _ = QFileDialog.getSaveFileName(
            self,
            self.tr("Save theme palette"),
            default_path,
            self.tr("Mapestry palette XML (*.xml);;All files (*.*)"),
        )
        if not path:
            return
        if not path.lower().endswith(".xml"):
            path += ".xml"
        root = self._palette_xml_root_from_buttons()
        err = self._write_palette_xml_root_to_path(root, path)
        if err:
            QMessageBox.warning(
                self,
                self.tr("Mapestry"),
                self.tr("Could not write file: {}").format(err),
            )
            return
        if iface is not None:
            iface.messageBar().pushMessage(
                self.tr("Mapestry"),
                self.tr("Palette saved to {}").format(path),
                level=Qgis.Success,
                duration=4,
            )

    def _on_set_global_colors(self) -> None:
        """Write current palette to Settings/color_palette.xml (no file dialog)."""
        _ensure_palette_settings_dir()
        path = _global_palette_xml_path()
        root = self._palette_xml_root_from_buttons()
        err = self._write_palette_xml_root_to_path(root, path)
        if err:
            QMessageBox.warning(
                self,
                self.tr("Mapestry"),
                self.tr("Could not write global palette: {}").format(err),
            )
            return
        if not self._push_current_palette_to_project():
            return
        if iface is not None:
            iface.messageBar().pushMessage(
                self.tr("Mapestry"),
                self.tr("Global palette saved to {}. Project colors updated.").format(path),
                level=Qgis.Success,
                duration=4,
            )

    def _on_load_palette_xml(self) -> None:
        _ensure_palette_settings_dir()
        start_dir = _palette_settings_dir()
        path, _ = QFileDialog.getOpenFileName(
            self,
            self.tr("Load theme palette"),
            start_dir,
            self.tr("Mapestry palette XML (*.xml);;All files (*.*)"),
        )
        if not path:
            return
        try:
            root = ET.parse(path).getroot()
        except ET.ParseError as e:
            QMessageBox.warning(
                self,
                self.tr("Mapestry"),
                self.tr("Invalid XML: {}").format(e),
            )
            return
        except OSError as e:
            QMessageBox.warning(
                self,
                self.tr("Mapestry"),
                self.tr("Could not read file: {}").format(e),
            )
            return
        err = self._apply_palette_from_xml_root(root)
        if err:
            QMessageBox.warning(self, self.tr("Mapestry"), err)
            return
        if not self._push_current_palette_to_project():
            return
        if iface is not None:
            iface.messageBar().pushMessage(
                self.tr("Mapestry"),
                self.tr("Palette loaded from {}. Project colors updated.").format(path),
                level=Qgis.Success,
                duration=4,
            )

    def _on_load_global_colors(self) -> None:
        """Load palette from Settings/color_palette.xml (no file dialog)."""
        path = _global_palette_xml_path()
        if not os.path.isfile(path):
            QMessageBox.information(
                self,
                self.tr("Mapestry"),
                self.tr(
                    "No global palette file found yet.\n\n"
                    "Expected file:\n{}\n\n"
                    'Use "Set Global Colors" to create it.'
                ).format(path),
            )
            return
        try:
            root = ET.parse(path).getroot()
        except ET.ParseError as e:
            QMessageBox.warning(
                self,
                self.tr("Mapestry"),
                self.tr("Invalid XML: {}").format(e),
            )
            return
        except OSError as e:
            QMessageBox.warning(
                self,
                self.tr("Mapestry"),
                self.tr("Could not read file: {}").format(e),
            )
            return
        err = self._apply_palette_from_xml_root(root)
        if err:
            QMessageBox.warning(self, self.tr("Mapestry"), err)
            return
        if not self._push_current_palette_to_project():
            return
        if iface is not None:
            iface.messageBar().pushMessage(
                self.tr("Mapestry"),
                self.tr("Global palette loaded from {}. Project colors updated.").format(path),
                level=Qgis.Success,
                duration=4,
            )
