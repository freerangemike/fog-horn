# -*- coding: utf-8 -*-
"""Preferred attribute-field matching for Route Connections preview columns."""

from __future__ import annotations

# Priority groups: first group with a matching field name wins; only that field
# is selected by default. Matching is case-insensitive on the whole field name
# after stripping spaces/underscores/hyphens.
_ADDRESS_KEYS = (
    "address",
    "addresses",
    "adress",
    "adresses",
    "addres",
    "addreses",
    "adres",
    "adreses",
    "addrss",
    "addresse",
    "addr",
    "addrs",
)

_LOCATION_KEYS = (
    "location",
    "locations",
    "loc",
    "locs",
)

_PLACE_KEYS = (
    "place",
    "places",
    "placename",
    "placenames",
    "site",
    "sites",
    "name",
    "names",
)

_PRIORITY_GROUPS = (_ADDRESS_KEYS, _LOCATION_KEYS, _PLACE_KEYS)


def _normalize_field_key(name: str) -> str:
    raw = str(name or "").strip().lower()
    return "".join(ch for ch in raw if ch.isalnum())


def preferred_display_field_name(field_names) -> str | None:
    """
    Return the best default display field, or None if the layer has no fields.

    Order: address-like → location-like → place/site/name → first field.
    """
    names = [str(n) for n in (field_names or []) if str(n or "").strip()]
    if not names:
        return None
    by_key = {_normalize_field_key(n): n for n in names}
    for group in _PRIORITY_GROUPS:
        for key in group:
            if key in by_key:
                return by_key[key]
    return names[0]


def default_visible_field_names(field_names) -> list[str]:
    """Default checked columns for the preview table (one preferred field)."""
    preferred = preferred_display_field_name(field_names)
    if preferred is None:
        return []
    return [preferred]
