# -*- coding: utf-8 -*-
"""Copy library basemap datasets into the project folder before loading."""

from __future__ import annotations

import os
import shutil


def _allocate_unique_stem(dest_dir: str, stem: str, primary_ext: str) -> str:
    """Return stem, or stem_1 / stem_2 / … so ``stem + primary_ext`` is free."""
    candidate = stem
    n = 0
    while True:
        primary = os.path.join(dest_dir, candidate + primary_ext)
        if not os.path.exists(primary):
            return candidate
        n += 1
        candidate = "{}_{}".format(stem, n)


def _sidecar_names_for_shapefile(src_dir: str, stem: str) -> list[str]:
    """All files in ``src_dir`` that belong to shapefile ``stem`` (stem.ext…)."""
    names = []
    prefix = stem + "."
    try:
        listing = os.listdir(src_dir)
    except OSError:
        return names
    for name in listing:
        if name == stem or name.startswith(prefix):
            path = os.path.join(src_dir, name)
            if os.path.isfile(path):
                names.append(name)
    return names


def copy_library_dataset_to_project_folder(src_path: str, dest_dir: str) -> str:
    """
    Copy a library dataset into ``dest_dir`` with a unique basename (_1, _2, …).

    Returns the path to the primary file to open (``.shp``, ``.zip``, ``.gpkg``,
    or ``.geojson``). Raises ``OSError`` / ``ValueError`` on failure.
    """
    src_path = os.path.normpath(os.path.abspath(src_path))
    if not os.path.isfile(src_path):
        raise FileNotFoundError(src_path)
    dest_dir = os.path.normpath(os.path.abspath(dest_dir))
    if not os.path.isdir(dest_dir):
        raise NotADirectoryError(dest_dir)

    src_dir = os.path.dirname(src_path)
    base = os.path.basename(src_path)
    stem, ext = os.path.splitext(base)
    ext_lower = ext.lower()
    if not stem:
        raise ValueError("Invalid library file name: {}".format(src_path))

    unique_stem = _allocate_unique_stem(dest_dir, stem, ext_lower)

    if ext_lower == ".shp":
        sidecars = _sidecar_names_for_shapefile(src_dir, stem)
        if base not in sidecars:
            sidecars.append(base)
        if not sidecars:
            raise FileNotFoundError(src_path)
        for name in sidecars:
            src_file = os.path.join(src_dir, name)
            if not os.path.isfile(src_file):
                continue
            # Preserve suffix after stem (e.g. .shp.xml → unique_stem.shp.xml).
            if name == stem:
                dest_name = unique_stem
            elif name.startswith(stem + "."):
                dest_name = unique_stem + name[len(stem) :]
            else:
                continue
            shutil.copy2(src_file, os.path.join(dest_dir, dest_name))
        return os.path.join(dest_dir, unique_stem + ext_lower)

    if ext_lower in (".zip", ".gpkg", ".geojson", ".json"):
        dest_path = os.path.join(dest_dir, unique_stem + ext_lower)
        shutil.copy2(src_path, dest_path)
        return dest_path

    raise ValueError("Unsupported library file type: {}".format(ext_lower))
