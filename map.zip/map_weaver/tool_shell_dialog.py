# -*- coding: utf-8 -*-
"""Minimal workflow shells from Designer .ui (OK/Cancel + optional Apply)."""

import os

from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import QDialog, QDialogButtonBox


class ToolShellDialog(QDialog):
    """Loads a .ui dialog; registers the tool as Active on OK or Apply."""

    def __init__(self, plugin, ui_filename, slug, parent=None):
        super().__init__(parent)
        self._plugin = plugin
        self._slug = slug
        ui_path = os.path.join(os.path.dirname(__file__), ui_filename)
        if not os.path.isfile(ui_path):
            raise FileNotFoundError(ui_path)
        uic.loadUi(ui_path, self)
        bb = getattr(self, "dlgExport", None)
        if isinstance(bb, QDialogButtonBox):
            bb.clicked.connect(self._on_button_box_clicked)

    def _on_button_box_clicked(self, button):
        bb = getattr(self, "dlgExport", None)
        if bb is None or button is None:
            return
        try:
            role = bb.buttonRole(button)
        except Exception:
            return
        if role == QDialogButtonBox.ApplyRole:
            self._register_completed()

    def accept(self):
        self._register_completed()
        super().accept()

    def _register_completed(self):
        p = self._plugin
        if p is not None and hasattr(p, "register_completed_tool"):
            p.register_completed_tool(self._slug)
