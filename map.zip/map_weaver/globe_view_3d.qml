import QtQuick 2.15
import QtQuick3D 1.15

Rectangle {
    id: root
    width: 360
    height: 220
    color: "#ffffff"

    // Unbounded angles for full drag rotation.
    property real yaw: 0
    property real pitch: 0

    View3D {
        anchors.fill: parent
        renderMode: View3D.Offscreen
        camera: cam

        environment: SceneEnvironment {
            clearColor: "#ffffff"
            backgroundMode: SceneEnvironment.Color
            antialiasingMode: SceneEnvironment.MSAA
            antialiasingQuality: SceneEnvironment.High
        }

        PerspectiveCamera {
            id: cam
            z: 280
            clipNear: 1
            clipFar: 2000
        }

        DirectionalLight {
            eulerRotation.x: -20
            eulerRotation.y: -20
            brightness: 32
        }

        DirectionalLight {
            eulerRotation.x: 35
            eulerRotation.y: 150
            brightness: 16
        }

        Node {
            id: globePivot
            eulerRotation.x: root.pitch
            eulerRotation.y: root.yaw

            Model {
                source: "#Cube"
                scale: Qt.vector3d(120, 120, 120)
                eulerRotation: Qt.vector3d(20, 30, 0)
                pickable: true

                materials: DefaultMaterial {
                    diffuseColor: "#4f95d8"
                    lighting: DefaultMaterial.NoLighting
                }
            }
        }
    }

    Rectangle {
        anchors.fill: parent
        color: "transparent"
        border.color: "#c89a38"
        border.width: 2
        radius: 13
    }

    MouseArea {
        anchors.fill: parent
        property real lastX: 0
        property real lastY: 0

        onPressed: {
            lastX = mouse.x
            lastY = mouse.y
        }
        onPositionChanged: {
            if (!pressed)
                return
            var dx = mouse.x - lastX
            var dy = mouse.y - lastY
            root.yaw += dx * 0.45
            root.pitch += dy * 0.45
            lastX = mouse.x
            lastY = mouse.y
        }
    }
}
