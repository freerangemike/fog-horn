# -*- coding: utf-8 -*-
"""Border line-style QComboBox: Fusion chrome, detached popup tweaks, delegate frame."""

import os

from qgis.PyQt.QtCore import QEvent, QMetaObject, QRect, QSize, Qt, pyqtSlot
from qgis.PyQt.QtGui import QBrush, QCursor, QIcon, QPalette, QPainter, QPen, QColor, QPixmap
from qgis.PyQt.QtWidgets import (
    QComboBox,
    QFrame,
    QStyledItemDelegate,
    QStyle,
    QStyleFactory,
    QStyleOptionViewItem,
    QToolButton,
)


# --- Tuning ---------------------------------------------------------------

# Popup width tweak vs combo (px); list chrome: border_style_combo.qss (popup half) + woolywidget parity.
_POPUP_WIDTH_TRIM = 0

# Grows dropdown vs combo so the selection frame can extend ~2px right without clipping before the gutter.
_POPUP_EXTRA_WIDTH = 4

# List height = sum(row heights) + spacing + this. Lower = less gray under the last item (if too low,
# bottom border or scroll chevrons return).
_VIEW_HEIGHT_EXTRA = 6

# Reserve for QSS menu border height (top + bottom strokes shrink the viewport if not added here).
_VIEW_MENU_BORDER_DW = 2

# Added under the list inside the popup frame (plus layout contentsMargins).
_POPUP_HEIGHT_GAP = 0

_VIEWPORT_MARGIN_LEFT = 2
_VIEWPORT_MARGIN_RIGHT = 4

# 0 = use full row width −1px bottom for cosmetic pen; larger pulls frame in from cell right edge.
_FRAME_TRIM_RIGHT = 0

# Inset from viewport edges so 1px cosmetic strokes are not clipped.
_FRAME_VIEWPORT_INSET = 2

_FRAME_CENTER_NUDGE_X = 2

# Split marker in border_style_combo.qss: first block → combo.setStyleSheet; second → detached view.
_QSS_SPLIT_MARKER = "/* MW_BORDER_STYLE_SPLIT_POPUP */"
_qss_pair_cache = None


def _qss_closed_and_popup():
    """Load (closed_combo_qss, detached_view_qss) once from border_style_combo.qss."""
    global _qss_pair_cache
    if _qss_pair_cache is not None:
        return _qss_pair_cache
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "border_style_combo.qss")
    with open(path, encoding="utf-8") as f:
        text = f.read()
    if _QSS_SPLIT_MARKER not in text:
        raise ValueError(
            "border_style_combo.qss must contain the split marker %r (see file header comment)."
            % (_QSS_SPLIT_MARKER,)
        )
    closed, popup = text.split(_QSS_SPLIT_MARKER, 1)
    _qss_pair_cache = (closed.strip(), popup.strip())
    return _qss_pair_cache


# Match QGIS line-style order: Solid, No line, Dash, Dot, Dash dot, Dash dot dot.
_PEN_ORDER = (
    Qt.SolidLine,
    Qt.NoPen,
    Qt.DashLine,
    Qt.DotLine,
    Qt.DashDotLine,
    Qt.DashDotDotLine,
)
_TIPS = (
    "Solid",
    "No line",
    "Dashed",
    "Dotted",
    "Dash dot",
    "Dash dot dot",
)


# --- Delegate -------------------------------------------------------------


class _LineDelegate(QStyledItemDelegate):
    """White tile + line art for current row; Fusion blue selection is neutralized."""

    def __init__(
        self,
        list_view,
        allow_frame_outside_cell=True,
        hover_fill_color=None,
        hover_use_index_at_cursor=False,
    ):
        super(_LineDelegate, self).__init__(list_view)
        self._list = list_view
        # Border list: allow unclipped frame vs viewport (line preview). Icon grid: False or frame
        # bleeds into adjacent cells and Qt does not repaint them when selection moves.
        self._allow_frame_outside_cell = allow_frame_outside_cell
        # Fusion + QStyledItemDelegate often skip QSS ::item:hover — optional cell tint.
        self._hover_fill_color = hover_fill_color
        # QListView IconMode sometimes omits State_MouseOver on the option — use cursor cell.
        self._hover_use_index_at_cursor = hover_use_index_at_cursor

    def paint(self, painter, option, index):  # noqa: N802
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        cur = self._list is not None and index.isValid() and index == self._list.currentIndex()
        white = QColor(255, 255, 255)

        if cur:
            opt.state &= ~QStyle.State_Selected
            opt.state &= ~QStyle.State_HasFocus
            opt.backgroundBrush = QBrush(white)
            pal = QPalette(opt.palette)
            pal.setBrush(QPalette.Base, QBrush(white))
            pal.setBrush(QPalette.AlternateBase, QBrush(white))
            pal.setBrush(QPalette.Highlight, QBrush(white))
            pal.setColor(QPalette.HighlightedText, QColor(40, 40, 40))
            opt.palette = pal
        elif self._hover_fill_color is not None:
            hov = bool(opt.state & QStyle.State_MouseOver)
            if (
                not hov
                and self._hover_use_index_at_cursor
                and self._list is not None
            ):
                vp = self._list.viewport()
                if vp is not None:
                    mid = self._list.indexAt(vp.mapFromGlobal(QCursor.pos()))
                    hov = mid.isValid() and mid == index
            if hov:
                opt.backgroundBrush = QBrush(self._hover_fill_color)

        super(_LineDelegate, self).paint(painter, opt, index)

        if not cur:
            return

        painter.save()
        painter.setRenderHint(QPainter.Antialiasing, False)
        painter.setBrush(Qt.NoBrush)
        pen = QPen(QColor(40, 40, 40), 1, Qt.SolidLine)
        if hasattr(pen, "setCosmetic"):
            pen.setCosmetic(True)
        painter.setPen(pen)
        trim = max(0, _FRAME_TRIM_RIGHT)
        r = opt.rect.normalized().adjusted(0, 0, -trim, -1)
        if self._allow_frame_outside_cell:
            vp = self._list.viewport()
            if vp is not None:
                ins = max(1, _FRAME_VIEWPORT_INSET)
                safe = vp.rect().adjusted(ins, ins, -ins, -ins)
                r = r.intersected(safe)
                nug = int(_FRAME_CENTER_NUDGE_X)
                if nug:
                    r = r.adjusted(nug, 0, nug, 0)
                    r = r.intersected(safe)
        else:
            r = r.adjusted(1, 1, -1, -1)
        if r.width() < 2 or r.height() < 2:
            painter.restore()
            return
        if self._allow_frame_outside_cell:
            painter.setClipping(False)
            try:
                painter.setClipRect(QRect(-0x7FFF, -0x7FFF, 0xFFFE, 0xFFFE))
            except (TypeError, AttributeError):
                pass
        x1, y1, x2, y2 = r.left(), r.top(), r.right(), r.bottom()
        painter.drawLine(x1, y1, x2, y1)
        painter.drawLine(x1, y1, x1, y2)
        painter.drawLine(x1, y2, x2, y2)
        painter.drawLine(x2, y1, x2, y2)
        painter.restore()


def _attach_delegate(view):
    if view is None:
        return
    d = _LineDelegate(view)
    view._mw_cmb_border_delegate = d
    view.setItemDelegate(d)


def _line_icon(pen_style, w, h):
    pm = QPixmap(max(1, w), max(1, h))
    pm.fill(QColor(255, 255, 255))
    if pen_style == Qt.NoPen:
        return QIcon(pm)
    painter = QPainter(pm)
    painter.setRenderHint(QPainter.Antialiasing, True)
    pen = QPen(QColor(45, 45, 45), 2)
    pen.setStyle(pen_style)
    pen.setCapStyle(Qt.FlatCap)
    painter.setPen(pen)
    y = pm.height() // 2
    painter.drawLine(4, y, pm.width() - 4, y)
    painter.end()
    return QIcon(pm)


class BorderStyleCombo(QComboBox):
    """Line previews + Fusion + detached popup sizing for Dock border Style control."""

    def __init__(self, parent=None):
        super(BorderStyleCombo, self).__init__(parent)
        self.setObjectName("cmbBorderStyle")
        self.setAttribute(Qt.WA_StyledBackground, True)
        fusion = QStyleFactory.create("Fusion")
        if fusion is not None:
            self.setStyle(fusion)
        self._apply_closed_stylesheet()
        self._apply_view_skeleton()
        self.rebuild_line_items()

    def _apply_closed_stylesheet(self):
        """Closed combo chrome from border_style_combo.qss (includes :disabled)."""
        self.setStyleSheet(_qss_closed_and_popup()[0])

    def changeEvent(self, event):
        super(BorderStyleCombo, self).changeEvent(event)
        if event.type() == QEvent.EnabledChange:
            self._repolish_border_style_sheet()

    def polishEvent(self, event):
        super(BorderStyleCombo, self).polishEvent(event)
        self.update()

    def _repolish_border_style_sheet(self):
        self._apply_closed_stylesheet()
        st = self.style()
        if st is not None:
            try:
                st.unpolish(self)
                st.polish(self)
            except Exception:
                pass

    def _apply_view_skeleton(self):
        v = self.view()
        if v is None:
            return
        v.setFrameShape(QFrame.NoFrame)
        v.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        v.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        if hasattr(v, "setViewportMargins"):
            v.setViewportMargins(_VIEWPORT_MARGIN_LEFT, 0, _VIEWPORT_MARGIN_RIGHT, 0)
        if hasattr(v, "setUniformItemSizes"):
            v.setUniformItemSizes(True)
        if hasattr(v, "setSpacing"):
            v.setSpacing(0)
        if hasattr(v, "setIndentation"):
            v.setIndentation(0)
        if hasattr(v, "setShowDecorationSelected"):
            v.setShowDecorationSelected(False)

    def rebuild_line_items(self):
        """Repopulate from geometry (call after dock size/layout settles)."""
        uw = max(self.width(), self.geometry().width(), 52)
        uh = max(self.height(), self.geometry().height(), 18)
        iw = max(24, uw - 14)
        ih = max(12, uh - 6)

        prev = self.currentData() if self.count() else None

        self.blockSignals(True)
        self.clear()
        self.setIconSize(QSize(iw, ih))
        self.setMaxVisibleItems(max(32, len(_PEN_ORDER)))
        for i, ps in enumerate(_PEN_ORDER):
            self.addItem(_line_icon(ps, iw, ih), "", int(ps))
            self.setItemData(i, _TIPS[i], Qt.ToolTipRole)
        if hasattr(QComboBox, "Ignore"):
            self.setSizeAdjustPolicy(QComboBox.Ignore)
        self.setMinimumContentsLength(0)
        if prev is None:
            self.setCurrentIndex(0)
        else:
            for row in range(self.count()):
                try:
                    if int(self.itemData(row)) == int(prev):
                        self.setCurrentIndex(row)
                        break
                except (TypeError, ValueError):
                    continue
            else:
                self.setCurrentIndex(0)
        self.blockSignals(False)

        self._apply_view_skeleton()
        _attach_delegate(self.view())

    def showPopup(self):
        super(BorderStyleCombo, self).showPopup()

        cw_base = max(1, self.width() - _POPUP_WIDTH_TRIM)
        cw = cw_base + max(0, _POPUP_EXTRA_WIDTH)
        v = self.view()
        if v is None:
            return
        v.setFrameShape(QFrame.NoFrame)
        v.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        v.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        vsb = v.verticalScrollBar()
        if vsb is not None:
            vsb.hide()
            vsb.setFixedWidth(0)
        hsb = v.horizontalScrollBar()
        if hsb is not None:
            hsb.hide()
            hsb.setFixedHeight(0)
            hsb.setMaximumHeight(0)
        if hasattr(v, "setViewportMargins"):
            v.setViewportMargins(_VIEWPORT_MARGIN_LEFT, 0, _VIEWPORT_MARGIN_RIGHT, 0)
        if hasattr(v, "setIndentation"):
            v.setIndentation(0)
        if hasattr(v, "setShowDecorationSelected"):
            v.setShowDecorationSelected(False)
        v.setStyleSheet(_qss_closed_and_popup()[1])
        # Popup QSS changes size hints; polish here, then defer sizing so sizeHintForRow sees updated style (no processEvents).
        st = v.style()
        if st is not None:
            try:
                st.unpolish(v)
                st.polish(v)
                vp0 = v.viewport()
                if vp0 is not None:
                    st.unpolish(vp0)
                    st.polish(vp0)
            except Exception:
                pass

        self._mw_popup_sizing_cw = cw
        QMetaObject.invokeMethod(self, "_mw_finishBorderPopupSizing", Qt.QueuedConnection)

    @pyqtSlot()
    def _mw_finishBorderPopupSizing(self):
        cw = getattr(self, "_mw_popup_sizing_cw", None)
        if cw is None:
            return
        v = self.view()
        if v is None:
            return
        popup = v.window()

        if popup is not None and popup is not self:
            lay = popup.layout()
            if lay is not None:
                lay.setContentsMargins(0, 0, 0, 0)
                lay.setSpacing(0)
            if isinstance(popup, QFrame):
                popup.setFrameShape(QFrame.NoFrame)
                popup.setFrameShadow(QFrame.Plain)

            popup.setMinimumWidth(cw)
            popup.setMaximumWidth(cw)
            popup.setFixedWidth(cw)
            aw = popup.contentsRect().width()
            if aw <= 0:
                aw = cw
            v.setMinimumWidth(max(1, aw))
            v.setMaximumWidth(max(1, aw))
            v.setFixedWidth(max(1, aw))
        else:
            v.setMinimumWidth(cw)
            v.setMaximumWidth(cw)
            v.setFixedWidth(cw)

        n = self.count()
        if n > 0:
            row_h = 1
            for r in range(n):
                rh = v.sizeHintForRow(r)
                if rh > row_h:
                    row_h = rh
            if row_h < 8:
                row_h = max(self.iconSize().height(), self.fontMetrics().height()) + 12
            sp = v.spacing()
            view_h = row_h * n + sp * max(0, n - 1) + max(0, _VIEW_HEIGHT_EXTRA)
            view_h += max(0, _VIEW_MENU_BORDER_DW)
            v.setMinimumHeight(view_h)
            v.setMaximumHeight(view_h)
            v.setFixedHeight(view_h)
            v.updateGeometry()

        if popup is not None and popup is not self:
            popup.setMaximumHeight(16777215)
            extra_h = 0
            lay = popup.layout()
            if lay is not None:
                m = lay.contentsMargins()
                extra_h = m.top() + m.bottom()
            else:
                cm = popup.contentsMargins()
                extra_h = cm.top() + cm.bottom()
            desired = v.height() + extra_h + max(0, _POPUP_HEIGHT_GAP)
            popup.setMinimumHeight(desired)
            popup.setMaximumHeight(desired)
            popup.setFixedHeight(desired)
            for btn in popup.findChildren(QToolButton):
                btn.hide()

        _attach_delegate(v)
