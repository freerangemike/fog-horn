"""Split woolywidget.qss: panel chrome vs CustomArrowColorButton chrome (single file, two consumers)."""
import os

_ARROW_START = "/* MW_ARROW_CHROME_START */"
_ARROW_END = "/* MW_ARROW_CHROME_END */"


def _wooly_qss_path():
    return os.path.join(os.path.dirname(__file__), "woolywidget.qss")

def _wooly_glass_qss_path():
    return os.path.join(os.path.dirname(__file__), "woolywidget_glass.qss")


def load_wooly_qss_full():
    path = _wooly_qss_path()
    if not os.path.isfile(path):
        return ""
    with open(path, encoding="utf-8") as f:
        return f.read()

def load_wooly_glass_qss_full():
    path = _wooly_glass_qss_path()
    if not os.path.isfile(path):
        return ""
    with open(path, encoding="utf-8") as f:
        return f.read()


def arrow_chrome_stylesheet():
    """Rules applied only on CustomArrowColorButton via setStyleSheet(self) — makes qproperty-* + :disabled reliable."""
    text = load_wooly_qss_full()
    s = text.find(_ARROW_START)
    e = text.find(_ARROW_END)
    if s == -1 or e == -1 or e <= s:
        return ""
    return text[s + len(_ARROW_START) : e].strip()


def panel_stylesheet_without_arrow_chrome():
    """Full woolywidget.qss with the arrow block removed so cascade does not fight widget-local rules."""
    text = load_wooly_qss_full()
    s = text.find(_ARROW_START)
    e = text.find(_ARROW_END)
    if s == -1 or e == -1:
        return text
    end_pos = e + len(_ARROW_END)
    return (text[:s] + text[end_pos:]).strip()


def glass_panel_stylesheet():
    """Alternative sleek/glass theme stylesheet for dock contents."""
    return load_wooly_glass_qss_full().strip()
