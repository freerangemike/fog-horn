# -*- coding: utf-8 -*-
"""Plot Points tool — create a point layer from latitude/longitude columns in a tabular file."""

from __future__ import annotations

import os
import re

from qgis.core import (
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
)
from qgis.PyQt.QtCore import QVariant, Qt
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from .geocode_layer import geocode_storage_directory
from .route_connections_import import (
    _FILE_FILTER,
    _guess_column,
    _split_headers_and_data,
    read_tabular_file,
)

_LAT_KEYS = (
    "lat",
    "latitude",
    "y",
    "ylat",
    "laty",
    "point_y",
    "pointy",
    "northing",
)
_LON_KEYS = (
    "lon",
    "lng",
    "long",
    "longitude",
    "x",
    "xlon",
    "lonx",
    "point_x",
    "pointx",
    "easting",
)

_PLOT_POINTS_GPKG_LAYER = "plotted_points"


def _parse_coordinate(value):
    """Parse a lat/lon cell; accepts plain numbers and comma decimals."""
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    text = text.replace(",", ".")
    # Strip degree symbols / trailing letters sometimes found in exports.
    text = re.sub(r"[°º\s]+", "", text)
    text = re.sub(r"[NnEeSsWw]$", "", text)
    try:
        return float(text)
    except ValueError:
        return None


def _safe_field_name(name, used):
    base = re.sub(r"[^A-Za-z0-9_]+", "_", str(name or "").strip()) or "field"
    if base[0].isdigit():
        base = "f_" + base
    candidate = base
    n = 2
    while candidate.lower() in used:
        candidate = "{}_{}".format(base, n)
        n += 1
    used.add(candidate.lower())
    return candidate


def _safe_file_stem(name: str) -> str:
    stem = re.sub(r"[^A-Za-z0-9_-]+", "_", str(name or "").strip()).strip("_")
    return stem or "plotted_points"


def _unique_gpkg_path(folder: str, display_name: str) -> str:
    stem = _safe_file_stem(display_name)
    path = os.path.join(folder, "{}.gpkg".format(stem))
    if not os.path.exists(path):
        return os.path.normpath(path)
    n = 2
    while True:
        path = os.path.join(folder, "{}_{}.gpkg".format(stem, n))
        if not os.path.exists(path):
            return os.path.normpath(path)
        n += 1


def _write_memory_layer_to_gpkg(memory_lyr: QgsVectorLayer, gpkg_path: str) -> bool:
    parent = os.path.dirname(gpkg_path)
    if parent:
        try:
            os.makedirs(parent, exist_ok=True)
        except OSError:
            return False
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = _PLOT_POINTS_GPKG_LAYER
    options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
    project = QgsProject.instance()
    ctx = project.transformContext() if project else None
    try:
        err, _warnings, _path, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
            memory_lyr, gpkg_path, ctx, options
        )
        if err[0] == QgsVectorFileWriter.NoError and os.path.isfile(gpkg_path):
            return True
    except Exception:
        pass
    try:
        err = QgsVectorFileWriter.writeAsVectorFormat(
            memory_lyr,
            gpkg_path,
            "UTF-8",
            memory_lyr.crs(),
            "GPKG",
        )
        if isinstance(err, tuple):
            return err[0] == QgsVectorFileWriter.NoError and os.path.isfile(gpkg_path)
        return err == QgsVectorFileWriter.NoError and os.path.isfile(gpkg_path)
    except Exception:
        return False


def _load_plot_points_gpkg(gpkg_path: str, display_name: str) -> QgsVectorLayer | None:
    if not gpkg_path or not os.path.isfile(gpkg_path):
        return None
    uri = "{}|layername={}".format(gpkg_path, _PLOT_POINTS_GPKG_LAYER)
    lyr = QgsVectorLayer(uri, display_name, "ogr")
    if lyr.isValid():
        return lyr
    lyr = QgsVectorLayer(gpkg_path, display_name, "ogr")
    if lyr.isValid():
        return lyr
    return None


class PlotPointsDialog(QDialog):
    """Import lat/lon from Excel/CSV/text and add a point layer to the project."""

    def __init__(self, plugin, parent=None):
        mw = None
        if plugin is not None and getattr(plugin, "iface", None) is not None:
            mw = plugin.iface.mainWindow()
        super().__init__(mw if mw is not None else parent)
        self._plugin = plugin
        self.setWindowTitle(self.tr("Plot Points"))
        self.setMinimumWidth(720)
        self.setMinimumHeight(520)
        try:
            self.setWindowFlags(self.windowFlags() | Qt.Tool)
        except Exception:
            pass

        self._raw_rows = []
        self._headers = []
        self._data_rows = []
        self._file_path = ""

        layout = QVBoxLayout(self)

        layout.addWidget(
            QLabel(
                self.tr(
                    "Open a tabular file, choose latitude and longitude columns, "
                    "then add a point layer to the map."
                )
            )
        )

        file_row = QHBoxLayout()
        self.path_edit = QLineEdit()
        self.path_edit.setReadOnly(True)
        self.path_edit.setPlaceholderText(self.tr("No file selected"))
        browse_btn = QPushButton(self.tr("Browse…"))
        browse_btn.clicked.connect(self._on_browse)
        file_row.addWidget(self.path_edit, 1)
        file_row.addWidget(browse_btn)
        layout.addLayout(file_row)

        self.has_headers_check = QCheckBox(self.tr("First row has column headings"))
        self.has_headers_check.setChecked(True)
        self.has_headers_check.toggled.connect(self._rebuild_columns)
        layout.addWidget(self.has_headers_check)

        cols = QHBoxLayout()
        self.lat_combo = QComboBox()
        self.lon_combo = QComboBox()
        cols.addWidget(QLabel(self.tr("Latitude:")))
        cols.addWidget(self.lat_combo, 1)
        cols.addWidget(QLabel(self.tr("Longitude:")))
        cols.addWidget(self.lon_combo, 1)
        layout.addLayout(cols)

        name_row = QHBoxLayout()
        name_row.addWidget(QLabel(self.tr("Layer name:")))
        self.layer_name_edit = QLineEdit()
        self.layer_name_edit.setText(self.tr("Plotted Points"))
        self.layer_name_edit.setPlaceholderText(self.tr("Plotted Points"))
        name_row.addWidget(self.layer_name_edit, 1)
        layout.addLayout(name_row)

        layout.addWidget(
            QLabel(
                self.tr(
                    "Coordinates are treated as WGS 84 (EPSG:4326). "
                    "Points are saved as a GeoPackage beside the project "
                    "(or in staging until the project is saved)."
                )
            )
        )

        layout.addWidget(QLabel(self.tr("Preview (first rows):")))
        self.preview = QTableWidget(self)
        self.preview.setEditTriggers(QTableWidget.NoEditTriggers)
        self.preview.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.preview, 1)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        add_btn = QPushButton(self.tr("Add Point Layer"))
        add_btn.setDefault(True)
        add_btn.clicked.connect(self._on_add_layer)
        close_btn = QPushButton(self.tr("Close"))
        close_btn.clicked.connect(self.close)
        buttons.addWidget(add_btn)
        buttons.addWidget(close_btn)
        layout.addLayout(buttons)

        self._rebuild_columns()

    def _on_browse(self):
        path, _selected = QFileDialog.getOpenFileName(
            self,
            self.tr("Open Tabular File"),
            "",
            _FILE_FILTER,
        )
        if not path:
            return
        try:
            raw_rows = read_tabular_file(path)
        except ImportError as exc:
            QMessageBox.warning(self, self.tr("Plot Points"), str(exc))
            return
        except OSError as exc:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("Could not read file:\n{error}").format(error=exc),
            )
            return
        if not raw_rows:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("The selected file has no data rows."),
            )
            return

        self._file_path = path
        self._raw_rows = raw_rows
        self.path_edit.setText(path)
        base = os.path.splitext(os.path.basename(path))[0].strip()
        if base and not self.layer_name_edit.text().strip():
            self.layer_name_edit.setText(base)
        elif base and self.layer_name_edit.text().strip() in (
            "",
            self.tr("Plotted Points"),
            "Plotted Points",
        ):
            self.layer_name_edit.setText(base)
        self._rebuild_columns()

    def _rebuild_columns(self, *_args):
        has_headers = self.has_headers_check.isChecked()
        self._headers, self._data_rows = _split_headers_and_data(
            self._raw_rows, has_headers
        )
        prev_lat = self.lat_combo.currentText()
        prev_lon = self.lon_combo.currentText()

        self.lat_combo.blockSignals(True)
        self.lon_combo.blockSignals(True)
        try:
            self.lat_combo.clear()
            self.lon_combo.clear()
            for header in self._headers:
                self.lat_combo.addItem(header)
                self.lon_combo.addItem(header)
        finally:
            self.lat_combo.blockSignals(False)
            self.lon_combo.blockSignals(False)

        if self._headers:
            if has_headers:
                guessed_lat = _guess_column(self._headers, _LAT_KEYS)
                guessed_lon = _guess_column(self._headers, _LON_KEYS)
                if guessed_lat:
                    self.lat_combo.setCurrentText(guessed_lat)
                elif prev_lat and self.lat_combo.findText(prev_lat) >= 0:
                    self.lat_combo.setCurrentText(prev_lat)
                if guessed_lon:
                    self.lon_combo.setCurrentText(guessed_lon)
                elif prev_lon and self.lon_combo.findText(prev_lon) >= 0:
                    self.lon_combo.setCurrentText(prev_lon)
                else:
                    if self.lon_combo.count() >= 2 and not guessed_lon:
                        if guessed_lat and self.lat_combo.currentIndex() == 0:
                            self.lon_combo.setCurrentIndex(1)
            else:
                if self.lat_combo.count() >= 1:
                    self.lat_combo.setCurrentIndex(0)
                if self.lon_combo.count() >= 2:
                    self.lon_combo.setCurrentIndex(1)

        preview_rows = self._data_rows[:8]
        cols = len(self._headers)
        self.preview.clear()
        self.preview.setColumnCount(cols)
        self.preview.setHorizontalHeaderLabels(self._headers)
        self.preview.setRowCount(len(preview_rows))
        for row_idx, row in enumerate(preview_rows):
            for col_idx in range(cols):
                value = row[col_idx] if col_idx < len(row) else ""
                self.preview.setItem(row_idx, col_idx, QTableWidgetItem(value))

    def _on_add_layer(self):
        if not self._data_rows or not self._headers:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("Open a tabular file first."),
            )
            return

        lat_name = self.lat_combo.currentText()
        lon_name = self.lon_combo.currentText()
        if not lat_name or not lon_name:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("Choose latitude and longitude columns."),
            )
            return
        if lat_name == lon_name:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("Latitude and longitude must be different columns."),
            )
            return

        col_index = {name: idx for idx, name in enumerate(self._headers)}
        lat_idx = col_index.get(lat_name)
        lon_idx = col_index.get(lon_name)
        if lat_idx is None or lon_idx is None:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("Invalid column selection."),
            )
            return

        layer_name = (self.layer_name_edit.text() or "").strip() or self.tr(
            "Plotted Points"
        )

        used_names = set()
        field_specs = []
        for idx, header in enumerate(self._headers):
            fname = _safe_field_name(header, used_names)
            field_specs.append((idx, fname))

        uri = "Point?crs=EPSG:4326"
        memory_layer = QgsVectorLayer(uri, layer_name, "memory")
        if not memory_layer.isValid():
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("Could not create the point layer."),
            )
            return

        provider = memory_layer.dataProvider()
        provider.addAttributes(
            [QgsField(fname, QVariant.String) for _idx, fname in field_specs]
        )
        memory_layer.updateFields()

        features = []
        skipped = 0
        for row in self._data_rows:
            lat = _parse_coordinate(row[lat_idx] if lat_idx < len(row) else "")
            lon = _parse_coordinate(row[lon_idx] if lon_idx < len(row) else "")
            if lat is None or lon is None:
                skipped += 1
                continue
            if not (-90.0 <= lat <= 90.0) or not (-180.0 <= lon <= 180.0):
                skipped += 1
                continue
            feat = QgsFeature(memory_layer.fields())
            feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
            for src_idx, fname in field_specs:
                value = row[src_idx] if src_idx < len(row) else ""
                feat.setAttribute(fname, value)
            features.append(feat)

        if not features:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr(
                    "No valid latitude/longitude pairs were found in the selected columns."
                ),
            )
            return

        provider.addFeatures(features)
        memory_layer.updateExtents()

        folder = geocode_storage_directory(QgsProject.instance())
        if not folder:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr(
                    "Could not find a folder to save the GeoPackage. "
                    "Save the project first, or set a geocode staging folder in Settings."
                ),
            )
            return

        gpkg_path = _unique_gpkg_path(folder, layer_name)
        if not _write_memory_layer_to_gpkg(memory_layer, gpkg_path):
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr("Could not write GeoPackage:\n{path}").format(path=gpkg_path),
            )
            return

        layer = _load_plot_points_gpkg(gpkg_path, layer_name)
        if layer is None:
            QMessageBox.warning(
                self,
                self.tr("Plot Points"),
                self.tr(
                    "GeoPackage was written but could not be loaded:\n{path}"
                ).format(path=gpkg_path),
            )
            return

        QgsProject.instance().addMapLayer(layer)
        try:
            QgsProject.instance().setDirty(True)
        except Exception:
            pass

        msg = self.tr(
            "Added {count} point(s) to layer “{name}”.\nSaved to:\n{path}"
        ).format(count=len(features), name=layer_name, path=gpkg_path)
        if skipped:
            msg += "\n" + self.tr(
                "Skipped {count} row(s) with invalid coordinates."
            ).format(count=skipped)
        QMessageBox.information(self, self.tr("Plot Points"), msg)

        iface = getattr(self._plugin, "iface", None) if self._plugin else None
        if iface is not None:
            try:
                iface.mapCanvas().refresh()
            except Exception:
                pass
