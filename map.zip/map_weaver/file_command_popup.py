# -*- coding: utf-8 -*-
"""Modal-less File command list: rounded panel + painted shadow (no QGraphicsDropShadowEffect on rows)."""

from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.PyQt import sip

# Property-driven row highlight (not :hover) — Qt keeps :hover stuck after a submenu popup.
_POPUP_ROW_QSS = """
QWidget#fileCommandPopup {
    background-color: transparent;
}
QWidget#fileCommandPopup QPushButton#fileCommandRowBtn {
    color: rgb(255, 247, 242);
    background-color: rgba(255, 255, 255, 0);
    border: none;
    border-radius: 7px;
    text-align: left;
    padding: 7px 11px;
    font-size: 13px;
    min-height: 21px;
    outline: none;
}
QWidget#fileCommandPopup QPushButton#fileCommandRowBtn[rowHover="true"] {
    background-color: rgb(214, 150, 150);
    color: rgb(255, 255, 255);
    border: 1px solid rgb(232, 200, 200);
}
QWidget#fileCommandPopup QPushButton#fileCommandRowBtn:pressed {
    background-color: rgb(110, 40, 40);
    color: rgb(255, 255, 255);
    border: 1px solid rgb(200, 160, 160);
}
QWidget#fileCommandPopup QPushButton#fileCommandRowBtn:disabled {
    color: rgba(255, 247, 242, 0.42);
}
"""

# After a submenu opens, keep it until this elapses even if the pointer
# crosses other main-menu rows (native QMenu-style grace / hold).
_SUBMENU_HOLD_MS = 2000
# Main Project / Layer / Export menus: same grace after the pointer leaves.
_MENU_LEAVE_HOLD_MS = 2000
# After leaving the submenu, wait this long before closing (if hold expired).
_SUBMENU_LEAVE_MS = 280
# Tool submenus under a Qt.Popup often never get Enter/Leave; poll cursor instead.
_SUBMENU_HOVER_POLL_MS = 40


class _SubmenuHoverHelper(QtCore.QObject):
    """Open submenu on anchor hover; close after leave only when hold has expired."""

    def __init__(self, owner_popup, anchor_btn, submenu_specs, open_left=False):
        super().__init__(anchor_btn)
        self._owner = owner_popup
        self._anchor = anchor_btn
        self._specs = submenu_specs
        self._open_left = open_left
        self._timer = QtCore.QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(_SUBMENU_LEAVE_MS)
        self._timer.timeout.connect(self._on_close_timer)

    def _on_close_timer(self):
        owner = self._owner
        if owner._pointer_in_submenu_or_anchor():
            return
        remaining = owner._submenu_hold_remaining_ms()
        if remaining > 0:
            self._timer.start(remaining)
            return
        owner._close_submenu()
        owner._refresh_row_hover_from_cursor()

    def eventFilter(self, obj, event):
        et = event.type()
        sub = getattr(self._owner, "_submenu", None)
        if et == QtCore.QEvent.Enter:
            self._timer.stop()
            if obj is self._anchor:
                self._owner._open_submenu(
                    self._anchor, self._specs, open_left=self._open_left
                )
                sub = getattr(self._owner, "_submenu", None)
                if sub is not None and not sip.isdeleted(sub):
                    sub.installEventFilter(self)
            elif sub is not None and not sip.isdeleted(sub) and obj is sub:
                self._owner._submenu_pointer_seen = True
            return False
        if et == QtCore.QEvent.Leave:
            # Leaving the anchor while crossing to the submenu must not close.
            if obj is self._anchor:
                return False
            if (
                sub is not None
                and not sip.isdeleted(sub)
                and obj is sub
            ):
                self._owner._submenu_pointer_seen = True
                self._timer.start(
                    max(_SUBMENU_LEAVE_MS, self._owner._submenu_hold_remaining_ms())
                )
            return False
        return False


class _RowHoverHelper(QtCore.QObject):
    """Single active row highlight; clears stuck hover when moving between rows."""

    def __init__(self, popup):
        super().__init__(popup)
        self._popup = popup

    def eventFilter(self, obj, event):
        if not isinstance(obj, QtWidgets.QPushButton):
            return False
        if obj.objectName() != "fileCommandRowBtn":
            return False
        et = event.type()
        if et == QtCore.QEvent.Enter:
            if not obj.isEnabled():
                return False
            anchor = getattr(self._popup, "_submenu_anchor", None)
            if anchor is not None and obj is not anchor:
                self._popup._dismiss_submenu_for_row_hover()
            # While a submenu is open and still in its hold window, keep the
            # parent row highlighted so the flyout stays visually attached.
            if (
                anchor is not None
                and obj is not anchor
                and self._popup._submenu_in_hold()
            ):
                self._popup._set_row_hover(anchor, True)
            else:
                self._popup._set_row_hover(obj, True)
        elif et == QtCore.QEvent.Leave:
            self._popup._refresh_row_hover_from_cursor()
        return False


class FileCommandPopup(QtWidgets.QWidget):
    """Popup with painted rounded shadow + gradient panel; row buttons styled locally."""

    _BORDER = QtGui.QColor(146, 70, 70)
    _TOP_LINE = QtGui.QColor(220, 180, 180)

    def __init__(
        self,
        parent,
        specs,
        radius_px=10,
        submenu_on_hover=False,
        submenu_open_left=False,
        as_submenu=False,
        fixed_width=None,
    ):
        super().__init__(parent)
        self.setObjectName("fileCommandPopup")
        self._radius = int(radius_px)
        self._submenu_on_hover = bool(submenu_on_hover)
        self._submenu_open_left = bool(submenu_open_left)
        self._as_submenu = bool(as_submenu)
        self._fixed_width = int(fixed_width) if fixed_width else None
        self._hover_helpers = []
        self._row_buttons = []
        self._submenu = None
        self._submenu_anchor = None
        self._submenu_pointer_seen = False
        self._submenu_opened_ms = 0
        self._leave_started_ms = 0
        self.setStyleSheet(_POPUP_ROW_QSS)

        if self._as_submenu:
            # Tool, not Popup: Popup eats the first outside click (double-click to pick Raster).
            flags = QtCore.Qt.Tool | QtCore.Qt.FramelessWindowHint
        else:
            flags = QtCore.Qt.Popup | QtCore.Qt.FramelessWindowHint
        if hasattr(QtCore.Qt, "NoDropShadowWindowHint"):
            flags |= QtCore.Qt.NoDropShadowWindowHint
        self.setWindowFlags(flags)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground, True)
        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.setMouseTracking(True)
        self.setAttribute(QtCore.Qt.WA_Hover, True)

        self._leave_close_timer = QtCore.QTimer(self)
        self._leave_close_timer.setSingleShot(True)
        self._leave_close_timer.timeout.connect(self._hide_if_pointer_outside)

        self._submenu_hold_timer = QtCore.QTimer(self)
        self._submenu_hold_timer.setSingleShot(True)
        self._submenu_hold_timer.timeout.connect(self._on_submenu_hold_elapsed)

        # Cursor poll for submenu row hover (Enter events are unreliable on Tool
        # windows while a Qt.Popup sibling holds the mouse grab).
        self._hover_poll_timer = QtCore.QTimer(self)
        self._hover_poll_timer.setInterval(_SUBMENU_HOVER_POLL_MS)
        self._hover_poll_timer.timeout.connect(self._poll_cursor_row_hover)

        self._row_hover_helper = _RowHoverHelper(self)
        self.installEventFilter(self._row_hover_helper)

        self._shadow_gutter = QtCore.QMargins(4, 4, 16, 20)
        row_pad = QtCore.QMargins(8, 6, 8, 6)

        lay = QtWidgets.QVBoxLayout(self)
        m = QtCore.QMargins(
            self._shadow_gutter.left() + row_pad.left(),
            self._shadow_gutter.top() + row_pad.top(),
            self._shadow_gutter.right() + row_pad.right(),
            self._shadow_gutter.bottom() + row_pad.bottom(),
        )
        lay.setContentsMargins(m.left(), m.top(), m.right(), m.bottom())
        lay.setSpacing(0)

        fm = QtGui.QFontMetrics(self.font())
        titles = []
        for spec in specs:
            title, _, submenu, _tip = self._parse_spec(spec)
            titles.append(title)
            if submenu:
                titles.extend(st[0] for st in submenu)

        if self._fixed_width is not None:
            total_w = max(80, self._fixed_width)
            min_inner_w = max(40, total_w - m.left() - m.right())
            # Button text area ≈ inner width minus horizontal padding from QSS.
            elide_w = max(24, min_inner_w - 28)
        else:
            max_tw = max((fm.horizontalAdvance(t) for t in titles), default=120)
            inner_margin_w = m.left() + m.right()
            min_inner_w = max(240 - inner_margin_w, max_tw + 36)
            elide_w = None
            total_w = None

        for spec in specs:
            title, cb, submenu, tooltip = self._parse_spec(spec)
            if submenu is not None:
                title = "{}  \u25B8".format(title)
            display = title
            if elide_w is not None:
                display = fm.elidedText(title, QtCore.Qt.ElideRight, elide_w)
            b = QtWidgets.QPushButton(display, self)
            b.setObjectName("fileCommandRowBtn")
            b.setFlat(True)
            b.setAutoDefault(False)
            b.setDefault(False)
            b.setFocusPolicy(QtCore.Qt.NoFocus)
            b.setCursor(QtCore.Qt.PointingHandCursor)
            b.setMouseTracking(True)
            b.setAttribute(QtCore.Qt.WA_Hover, True)
            # String property so QSS [rowHover="true"] matches reliably.
            b.setProperty("rowHover", "false")
            b.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
            b.setMinimumWidth(min_inner_w)
            if self._fixed_width is not None:
                b.setMaximumWidth(min_inner_w)
            b.setMinimumHeight(35)
            b.setAutoFillBackground(False)
            if hasattr(QtCore.Qt, "WA_StyledBackground"):
                b.setAttribute(QtCore.Qt.WA_StyledBackground, True)
            if tooltip:
                b.setToolTip(str(tooltip))
            elif display != title:
                # Elided label without explicit tip — show full text on hover.
                b.setToolTip(title.replace("&&", "&"))

            pb = b.palette()
            pb.setColor(QtGui.QPalette.ButtonText, QtGui.QColor(255, 247, 242))
            pb.setColor(QtGui.QPalette.WindowText, QtGui.QColor(255, 247, 242))
            b.setPalette(pb)

            b.installEventFilter(self._row_hover_helper)
            self._row_buttons.append(b)

            if submenu is not None:
                if self._submenu_on_hover:
                    helper = _SubmenuHoverHelper(
                        self,
                        b,
                        submenu,
                        open_left=self._submenu_open_left,
                    )
                    b.installEventFilter(helper)
                    self._hover_helpers.append(helper)
                else:
                    b.clicked.connect(
                        lambda _=False, btn=b, sub=submenu: self._open_submenu(
                            btn, sub, open_left=self._submenu_open_left
                        )
                    )
            else:
                if callable(cb):
                    b._command_fn = cb
                    # Submenus are Qt.Tool under a Qt.Popup parent: the parent's
                    # outside-click close can destroy the flyout before clicked
                    # fires. pressed runs on mouse-down and is more reliable.
                    if self._as_submenu:
                        b.pressed.connect(
                            lambda _=False, fn=cb: self._run_and_hide(fn)
                        )
                    else:
                        b.clicked.connect(
                            lambda _=False, fn=cb: self._run_and_hide(fn)
                        )
                else:
                    b.setEnabled(False)
            lay.addWidget(b)

        if total_w is not None:
            self.setFixedWidth(total_w)
        self.adjustSize()
        if total_w is not None:
            self.setFixedWidth(total_w)

    @staticmethod
    def _parse_spec(spec):
        """(title, callback[, tooltip]) or (title, [(sub_title, callback), ...])."""
        title = spec[0]
        if len(spec) >= 2 and isinstance(spec[1], (list, tuple)) and not callable(spec[1]):
            return title, None, list(spec[1]), None
        tooltip = spec[2] if len(spec) >= 3 else None
        return title, spec[1], None, tooltip

    def _apply_row_hover(self, btn, hover):
        hover = bool(hover)
        if btn is None or sip.isdeleted(btn):
            return
        value = "true" if hover else "false"
        if str(btn.property("rowHover") or "") == value:
            return
        btn.setProperty("rowHover", value)
        btn.setDown(False)
        st = btn.style()
        if st is not None:
            st.unpolish(btn)
            st.polish(btn)
        btn.update()

    def _set_row_hover(self, btn, active=True):
        for row in self._row_buttons:
            self._apply_row_hover(row, active and row is btn)

    def _poll_cursor_row_hover(self):
        """Update row highlight from global cursor (submenu Tool windows)."""
        if not self.isVisible() or sip.isdeleted(self):
            return
        pos = QtGui.QCursor.pos()
        hit = self._row_at_global_pos(pos)
        prev = getattr(self, "_tooltip_row", None)
        if hit is not None and hit.isEnabled():
            self._set_row_hover(hit, True)
            tip = hit.toolTip()
            if tip and prev is not hit:
                self._tooltip_row = hit
                QtWidgets.QToolTip.showText(pos, tip, hit)
            elif not tip:
                self._tooltip_row = hit
        else:
            if prev is not None:
                QtWidgets.QToolTip.hideText()
                self._tooltip_row = None
            self._set_row_hover(None, False)

        # Keep the owning main menu alive while the pointer is on this flyout.
        owner = getattr(self, "_owner_popup", None)
        if owner is None or sip.isdeleted(owner):
            return
        self_rect = QtCore.QRect(self.mapToGlobal(QtCore.QPoint(0, 0)), self.size())
        if self_rect.contains(pos):
            owner._submenu_pointer_seen = True
            owner._leave_close_timer.stop()
            owner._leave_started_ms = 0

    def _row_at_global_pos(self, global_pos):
        for row in self._row_buttons:
            top_left = row.mapToGlobal(QtCore.QPoint(0, 0))
            rect = QtCore.QRect(top_left, row.size())
            if rect.contains(global_pos):
                return row
        return None

    def _submenu_global_rect(self):
        sub = getattr(self, "_submenu", None)
        if sub is None or sip.isdeleted(sub) or not sub.isVisible():
            return None
        return QtCore.QRect(sub.mapToGlobal(QtCore.QPoint(0, 0)), sub.size())

    def _pointer_in_submenu_or_anchor(self):
        pos = QtGui.QCursor.pos()
        anchor = getattr(self, "_submenu_anchor", None)
        if anchor is not None and self._row_at_global_pos(pos) is anchor:
            return True
        sub_rect = self._submenu_global_rect()
        if sub_rect is not None and sub_rect.contains(pos):
            return True
        return False

    def _submenu_hold_remaining_ms(self):
        if self._submenu_opened_ms <= 0:
            return 0
        elapsed = QtCore.QDateTime.currentMSecsSinceEpoch() - self._submenu_opened_ms
        return max(0, _SUBMENU_HOLD_MS - int(elapsed))

    def _submenu_in_hold(self):
        sub = getattr(self, "_submenu", None)
        if sub is None or sip.isdeleted(sub) or not sub.isVisible():
            return False
        return self._submenu_hold_remaining_ms() > 0

    def _stop_submenu_hover_timers(self):
        for helper in self._hover_helpers:
            helper._timer.stop()
        self._submenu_hold_timer.stop()

    def _dismiss_submenu_for_row_hover(self):
        """Close submenu when pointer moves to another main-menu row — after hold only."""
        if self._submenu_in_hold():
            # Keep flyout; schedule a check when the hold ends.
            remaining = self._submenu_hold_remaining_ms()
            if remaining > 0 and not self._submenu_hold_timer.isActive():
                self._submenu_hold_timer.start(remaining)
            return
        self._stop_submenu_hover_timers()
        self._close_submenu()

    def _on_submenu_hold_elapsed(self):
        if self._pointer_in_submenu_or_anchor():
            return
        # Still over a main-menu row that is not the anchor → dismiss.
        self._close_submenu()
        self._refresh_row_hover_from_cursor()

    def _refresh_row_hover_from_cursor(self):
        pos = QtGui.QCursor.pos()
        hit = self._row_at_global_pos(pos)
        sub = getattr(self, "_submenu", None)
        anchor = getattr(self, "_submenu_anchor", None)
        if (
            sub is not None
            and not sip.isdeleted(sub)
            and sub.isVisible()
            and anchor is not None
        ):
            sub_rect = self._submenu_global_rect()
            if sub_rect is not None and sub_rect.contains(pos):
                self._set_row_hover(anchor, True)
                return
            if self._submenu_in_hold() or not getattr(self, "_submenu_pointer_seen", False):
                self._set_row_hover(anchor, True)
                return
        if hit is not None:
            self._set_row_hover(hit, True)
            return
        self._set_row_hover(None, False)

    def _screen_available_rect_for(self, global_pos):
        screen = QtGui.QGuiApplication.screenAt(global_pos)
        if screen is None:
            screen = QtGui.QGuiApplication.primaryScreen()
        if screen is None:
            return None
        return screen.availableGeometry()

    def _submenu_global_pos(self, anchor_btn, prefer_right=True):
        """Place submenu to the right by default; flip left if it would clip the screen."""
        sub = self._submenu
        if sub is None or sip.isdeleted(sub) or anchor_btn is None:
            return QtCore.QPoint(0, 0)
        w = sub.width()
        h = sub.height()
        y = anchor_btn.mapToGlobal(QtCore.QPoint(0, 0)).y()
        # Align painted panel edges (exclude shadow gutters). The right gutter is
        # wider than the left, so left-open must not use full widget width or a
        # ~16px visual gap appears between the two panels.
        g = self._shadow_gutter
        panel_left_x = self.mapToGlobal(QtCore.QPoint(g.left(), 0)).x()
        panel_right_x = self.mapToGlobal(QtCore.QPoint(self.width() - g.right(), 0)).x()
        # Slight overlap so the pointer can cross without a dead gap.
        seam = 4
        # Right: widget.x such that painted-left (x + g.left) meets main panel-right.
        right_pos = QtCore.QPoint(panel_right_x - seam, y)
        # Left: widget.x such that painted-right (x + w - g.right) meets main panel-left.
        left_pos = QtCore.QPoint(panel_left_x + seam - (w - g.right()), y)
        avail = self._screen_available_rect_for(anchor_btn.mapToGlobal(QtCore.QPoint(0, 0)))
        if avail is None:
            return right_pos if prefer_right else left_pos

        def fits(pos):
            return pos.x() >= avail.left() and (pos.x() + w) <= avail.right() + 1

        if prefer_right:
            if fits(right_pos):
                pos = right_pos
            elif fits(left_pos):
                pos = left_pos
            else:
                room_right = avail.right() - panel_right_x
                room_left = panel_left_x - avail.left()
                pos = right_pos if room_right >= room_left else left_pos
        else:
            if fits(left_pos):
                pos = left_pos
            elif fits(right_pos):
                pos = right_pos
            else:
                pos = left_pos

        # Keep vertically on-screen when possible.
        if pos.y() + h > avail.bottom() + 1:
            pos.setY(max(avail.top(), avail.bottom() - h + 1))
        if pos.y() < avail.top():
            pos.setY(avail.top())
        return pos

    def _open_submenu(self, anchor_btn, submenu_specs, open_left=False):
        existing = getattr(self, "_submenu", None)
        if (
            existing is not None
            and not sip.isdeleted(existing)
            and existing.isVisible()
            and self._submenu_anchor is anchor_btn
        ):
            # Already open for this row — refresh hold clock only if needed.
            self._set_row_hover(anchor_btn, True)
            existing.raise_()
            return

        self._close_submenu()
        parent = self.parent() if self.parent() is not None else self
        self._submenu = FileCommandPopup(
            parent, submenu_specs, as_submenu=True, fixed_width=300
        )
        self._submenu._owner_popup = self
        self._submenu_anchor = anchor_btn
        self._submenu_pointer_seen = False
        self._submenu_opened_ms = QtCore.QDateTime.currentMSecsSinceEpoch()
        self._submenu.adjustSize()
        # Right is default; flip left only when the flyout would clip the screen.
        pos = self._submenu_global_pos(anchor_btn, prefer_right=not open_left)
        self._submenu.move(pos)
        self._submenu.show()
        # Submenu must stay above the parent — raising the parent after open
        # covers the overlap strip and kills hover / travel into the flyout.
        self._submenu.raise_()
        self._submenu._hover_poll_timer.start()
        self._set_row_hover(anchor_btn, True)
        if self._submenu_on_hover:
            for helper in self._hover_helpers:
                if helper._anchor is anchor_btn:
                    self._submenu.installEventFilter(helper)
                    break
        self._submenu_hold_timer.start(_SUBMENU_HOLD_MS)
        # Pointer moved to the flyout: cancel the main menu leave countdown.
        self._leave_close_timer.stop()
        self._leave_started_ms = 0

    def _close_submenu(self):
        self._submenu_hold_timer.stop()
        sub = getattr(self, "_submenu", None)
        if sub is not None and not sip.isdeleted(sub):
            try:
                sub._hover_poll_timer.stop()
            except Exception:
                pass
            sub.hide()
            sub.deleteLater()
        self._submenu = None
        self._submenu_anchor = None
        self._submenu_pointer_seen = False
        self._submenu_opened_ms = 0

    def _menu_leave_hold_remaining_ms(self):
        if self._leave_started_ms <= 0:
            return 0
        elapsed = QtCore.QDateTime.currentMSecsSinceEpoch() - self._leave_started_ms
        return max(0, _MENU_LEAVE_HOLD_MS - int(elapsed))

    def _panel_rect(self):
        g = self._shadow_gutter
        return QtCore.QRectF(self.rect()).adjusted(
            float(g.left()), float(g.top()), float(-g.right()), float(-g.bottom())
        ).adjusted(1.0, 1.0, -1.0, -1.0)

    def paintEvent(self, event):
        p = QtGui.QPainter(self)
        p.setCompositionMode(QtGui.QPainter.CompositionMode_Source)
        p.fillRect(self.rect(), QtGui.QColor(0, 0, 0, 0))
        p.setCompositionMode(QtGui.QPainter.CompositionMode_SourceOver)
        p.setRenderHint(QtGui.QPainter.Antialiasing, True)

        panel = self._panel_rect()
        rad = float(self._radius)

        p.setPen(QtCore.Qt.NoPen)
        for i in range(9, -1, -1):
            t = i / 9.0
            dx = 2.2 + t * 4.0
            dy = 2.8 + t * 5.0
            alpha = int(8 + (1.0 - t) * 36)
            p.setBrush(QtGui.QBrush(QtGui.QColor(0, 0, 0, min(alpha, 58))))
            sr = QtCore.QRectF(panel)
            sr.translate(dx, dy)
            p.drawRoundedRect(sr, rad, rad)

        grad = QtGui.QLinearGradient(0.0, panel.top(), 0.0, panel.bottom())
        grad.setColorAt(0.0, QtGui.QColor(162, 74, 74))
        grad.setColorAt(1.0, QtGui.QColor(145, 58, 58))
        p.setPen(QtGui.QPen(self._BORDER))
        p.setBrush(QtGui.QBrush(grad))
        p.drawRoundedRect(panel, rad, rad)

        p.setPen(QtGui.QPen(self._TOP_LINE))
        x0 = panel.left() + rad * 0.55
        x1 = panel.right() - rad * 0.55
        p.drawLine(QtCore.QLineF(x0, panel.top() + 1.0, x1, panel.top() + 1.0))

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.hide()
            event.accept()
            return
        super().keyPressEvent(event)

    def enterEvent(self, event):
        self._leave_close_timer.stop()
        self._leave_started_ms = 0
        super().enterEvent(event)

    def leaveEvent(self, event):
        # Native-style hold: stay open ~2s after the pointer leaves the panel.
        self._leave_started_ms = QtCore.QDateTime.currentMSecsSinceEpoch()
        delay = _MENU_LEAVE_HOLD_MS
        if not self._as_submenu and self._submenu_in_hold():
            delay = max(delay, self._submenu_hold_remaining_ms())
        self._leave_close_timer.start(delay)
        super().leaveEvent(event)

    def showEvent(self, event):
        super().showEvent(event)
        if self._as_submenu:
            self._hover_poll_timer.start()

    def _hide_if_pointer_outside(self):
        if not self.isVisible() or sip.isdeleted(self):
            return
        pos = QtGui.QCursor.pos()
        self_rect = QtCore.QRect(self.mapToGlobal(QtCore.QPoint(0, 0)), self.size())
        if self_rect.contains(pos):
            self._leave_started_ms = 0
            return
        # Main menu stays open while the pointer is over its submenu flyout.
        if not self._as_submenu:
            sub_rect = self._submenu_global_rect()
            if sub_rect is not None and sub_rect.contains(pos):
                self._leave_started_ms = 0
                return
            if self._submenu_in_hold():
                remaining = self._submenu_hold_remaining_ms()
                if remaining > 0:
                    self._leave_close_timer.start(remaining)
                    return
        else:
            # Flyout stays open while the pointer is back on its parent row.
            owner = getattr(self, "_owner_popup", None)
            if owner is not None and not sip.isdeleted(owner):
                anchor = getattr(owner, "_submenu_anchor", None)
                if anchor is not None and owner._row_at_global_pos(pos) is anchor:
                    self._leave_started_ms = 0
                    return
        remaining = self._menu_leave_hold_remaining_ms()
        if remaining > 0:
            self._leave_close_timer.start(remaining)
            return
        self.hide()

    def _run_and_hide(self, fn):
        if getattr(self, "_running_command", False):
            return
        self._running_command = True
        self._leave_close_timer.stop()
        self._leave_started_ms = 0
        self._hover_poll_timer.stop()
        self._close_submenu()
        self.hide()
        owner = getattr(self, "_owner_popup", None)
        if owner is not None and not sip.isdeleted(owner):
            owner._leave_close_timer.stop()
            owner._leave_started_ms = 0
            # Avoid re-entering hideEvent capture while we intentionally close.
            owner._suppress_submenu_click_capture = True
            try:
                owner._close_submenu()
                owner.hide()
            finally:
                owner._suppress_submenu_click_capture = False
        try:
            if callable(fn):
                fn()
        finally:
            self._running_command = False

    def _capture_submenu_command_under_cursor(self):
        """If the pointer is on a submenu action row, return its callback."""
        if getattr(self, "_suppress_submenu_click_capture", False):
            return None
        sub = getattr(self, "_submenu", None)
        if sub is None or sip.isdeleted(sub) or not sub.isVisible():
            return None
        pos = QtGui.QCursor.pos()
        sub_rect = QtCore.QRect(sub.mapToGlobal(QtCore.QPoint(0, 0)), sub.size())
        if not sub_rect.contains(pos):
            return None
        row = sub._row_at_global_pos(pos)
        if row is None or not row.isEnabled():
            return None
        fn = getattr(row, "_command_fn", None)
        return fn if callable(fn) else None

    def hideEvent(self, event):
        # Parent Qt.Popup closes on the same mouse-press that targets a Tool
        # submenu row, destroying the flyout before clicked/pressed can run.
        # Capture and defer that command so Open Recent (and similar) still fire.
        pending = None
        if not self._as_submenu:
            pending = self._capture_submenu_command_under_cursor()
        self._leave_close_timer.stop()
        self._submenu_hold_timer.stop()
        self._hover_poll_timer.stop()
        self._leave_started_ms = 0
        self._tooltip_row = None
        QtWidgets.QToolTip.hideText()
        self._close_submenu()
        for row in self._row_buttons:
            self._apply_row_hover(row, False)
        super().hideEvent(event)
        if pending is not None:
            QtCore.QTimer.singleShot(0, pending)
