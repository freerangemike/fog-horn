# -*- coding: utf-8 -*-
"""Identify Route Arcs layers without relying on display name; tag layers Mapestry creates."""

from __future__ import annotations

import os
import re

from qgis.core import (
    QgsField,
    QgsProject,
    QgsSimpleLineSymbolLayer,
    QgsSingleSymbolRenderer,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import Qt, QVariant
from qgis.PyQt import sip

# Set on layers created or adopted by Route Connections (survives rename).
ROUTE_ARCS_LAYER_CUSTOM_PROPERTY = "map_weaver/is_route_arcs_layer"
ROUTE_ARCS_LAYER_CUSTOM_VALUE = "1"
# Point layer id that owns this Route Arcs layer (one arcs layer per point layer).
ROUTE_ARCS_SOURCE_LAYER_PROPERTY = "map_weaver/route_arcs_source_layer_id"
ROUTE_ARCS_GPKG_LAYER_NAME = "route_arcs"
ROUTE_ARCS_GPKG_FILE_PROP = "map_weaver/route_arcs_gpkg_file"


def _route_arcs_crs_matches(crs_layer, crs_other):
    if crs_layer is None or crs_other is None:
        return False
    try:
        if crs_layer == crs_other:
            return True
    except Exception:
        pass
    try:
        if hasattr(crs_layer, "hasSameCrsAs") and crs_layer.hasSameCrsAs(crs_other):
            return True
    except Exception:
        pass
    try:
        a, b = crs_layer.authid(), crs_other.authid()
        if a and b and a == b:
            return True
    except Exception:
        pass
    return False


def route_arcs_field_schema_ok(lyr: QgsVectorLayer) -> bool:
    """Vendor Route Arcs memory layer: line geometry + Start, End, ConnID string fields."""
    if lyr is None:
        return False
    try:
        if sip.isdeleted(lyr):
            return False
    except Exception:
        return False
    try:
        if lyr.geometryType() != QgsWkbTypes.LineGeometry:
            return False
    except Exception:
        return False
    try:
        names = {f.name() for f in lyr.fields()}
    except Exception:
        return False
    return {"Start", "End", "ConnID"}.issubset(names)


def has_route_arcs_tag(lyr: QgsVectorLayer) -> bool:
    try:
        return str(lyr.customProperty(ROUTE_ARCS_LAYER_CUSTOM_PROPERTY, "") or "") == ROUTE_ARCS_LAYER_CUSTOM_VALUE
    except Exception:
        return False


def mark_route_arcs_layer(lyr: QgsVectorLayer) -> None:
    """Tag a layer as Mapestry Route Arcs (call after create or when adopting a unique candidate)."""
    if lyr is None:
        return
    try:
        lyr.setCustomProperty(ROUTE_ARCS_LAYER_CUSTOM_PROPERTY, ROUTE_ARCS_LAYER_CUSTOM_VALUE)
    except Exception:
        pass


def get_route_arcs_source_layer_id(lyr: QgsVectorLayer) -> str:
    if lyr is None:
        return ""
    try:
        return str(lyr.customProperty(ROUTE_ARCS_SOURCE_LAYER_PROPERTY, "") or "").strip()
    except Exception:
        return ""


def set_route_arcs_source_layer_id(lyr: QgsVectorLayer, point_layer_id: str) -> None:
    if lyr is None:
        return
    try:
        lyr.setCustomProperty(
            ROUTE_ARCS_SOURCE_LAYER_PROPERTY, str(point_layer_id or "").strip()
        )
    except Exception:
        pass


def ensure_route_arcs_line_round_caps(lyr: QgsVectorLayer) -> None:
    """Round line caps and joins on simple-line symbol layers (Route Arcs appearance)."""
    if lyr is None:
        return
    try:
        if sip.isdeleted(lyr):
            return
    except Exception:
        return
    try:
        r = lyr.renderer()
        if not isinstance(r, QgsSingleSymbolRenderer):
            return
        sym = r.symbol()
        if sym is None:
            return
        changed = False
        for i in range(sym.symbolLayerCount()):
            sl = sym.symbolLayer(i)
            if isinstance(sl, QgsSimpleLineSymbolLayer):
                sl.setPenCapStyle(Qt.RoundCap)
                sl.setPenJoinStyle(Qt.RoundJoin)
                changed = True
        if changed:
            lyr.triggerRepaint()
    except Exception:
        pass


def is_route_arcs_layer(lyr) -> bool:
    """True if this layer is treated as Route Arcs (tag, or legacy name + schema)."""
    if lyr is None or not isinstance(lyr, QgsVectorLayer):
        return False
    try:
        if sip.isdeleted(lyr):
            return False
    except Exception:
        return False
    if not route_arcs_field_schema_ok(lyr):
        return False
    if has_route_arcs_tag(lyr):
        return True
    try:
        if lyr.name() == "Route Arcs":
            mark_route_arcs_layer(lyr)
            return True
    except Exception:
        pass
    return False


def iter_route_arcs_layers(project=None):
    project = project or QgsProject.instance()
    for lyr in project.mapLayers().values():
        if is_route_arcs_layer(lyr):
            yield lyr


def project_has_route_arcs_with_features(project=None) -> bool:
    """True if the project has a Route Arcs–like layer worth surfacing (tagged, or schema + data)."""
    project = project or QgsProject.instance()
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer):
            continue
        try:
            if sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        if not route_arcs_field_schema_ok(lyr):
            continue
        if has_route_arcs_tag(lyr):
            return True
        try:
            if lyr.featureCount() > 0:
                return True
        except Exception:
            continue
    return False


def _schema_candidates_for_crs(crs, project=None):
    project = project or QgsProject.instance()
    out = []
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer):
            continue
        try:
            if sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        if not route_arcs_field_schema_ok(lyr):
            continue
        if not _route_arcs_crs_matches(lyr.crs(), crs):
            continue
        out.append(lyr)
    return out


def find_route_arcs_layer_for_crs(crs, project=None):
    """
    Legacy: return a Route Arcs layer for ``crs`` without creating one.

    Prefer layers that are not yet bound to a point layer. Prefer tagged matches.
    """
    project = project or QgsProject.instance()
    candidates = _schema_candidates_for_crs(crs, project)
    if not candidates:
        return None
    unbound = [lyr for lyr in candidates if not get_route_arcs_source_layer_id(lyr)]
    pool = unbound or candidates
    tagged = [lyr for lyr in pool if has_route_arcs_tag(lyr)]
    if len(tagged) == 1:
        return tagged[0]
    if len(tagged) > 1:
        tagged.sort(key=lambda L: (L.featureCount() if L else 0), reverse=True)
        return tagged[0]
    untagged = [lyr for lyr in pool if not has_route_arcs_tag(lyr)]
    if len(untagged) == 1:
        mark_route_arcs_layer(untagged[0])
        return untagged[0]
    legacy = [lyr for lyr in untagged if lyr.name() == "Route Arcs"]
    if len(legacy) == 1:
        mark_route_arcs_layer(legacy[0])
        return legacy[0]
    return None


def _point_layer_has_attribute_value(point_layer, text) -> bool:
    needle = "" if text is None else str(text).strip().casefold()
    if not needle or point_layer is None:
        return False
    try:
        fields = [f.name() for f in point_layer.fields()]
    except Exception:
        return False
    for feat in point_layer.getFeatures():
        for name in fields:
            try:
                val = feat.attribute(name)
            except Exception:
                continue
            if val is None:
                continue
            if str(val).strip().casefold() == needle:
                return True
    return False


def _score_arcs_layer_against_point_layer(arc_layer, point_layer) -> int:
    """How many Start/End pairs on ``arc_layer`` resolve on ``point_layer``."""
    if arc_layer is None or point_layer is None:
        return 0
    score = 0
    try:
        features = list(arc_layer.getFeatures())
    except Exception:
        return 0
    for feat in features:
        try:
            start_txt = feat.attribute("Start")
            end_txt = feat.attribute("End")
        except Exception:
            continue
        if _point_layer_has_attribute_value(point_layer, start_txt) and _point_layer_has_attribute_value(
            point_layer, end_txt
        ):
            score += 1
    return score


def find_route_arcs_layer_for_point_layer(
    point_layer, project=None, adopt_legacy=True, match_by_content=False
):
    """
    Return the Route Arcs layer owned by ``point_layer``, or None.

    Lookup order:
    1. Custom property source layer id
    2. Unique legend name ``Route Arcs — {point layer name}`` (repairs missing id)
    3. Optional content match (pairs resolve on this point layer)
    4. Optional legacy: single unbound same-CRS Route Arcs layer
    """
    if point_layer is None:
        return None
    try:
        if sip.isdeleted(point_layer):
            return None
    except Exception:
        return None
    project = project or QgsProject.instance()
    try:
        point_id = str(point_layer.id())
    except Exception:
        return None

    for lyr in iter_route_arcs_layers(project):
        if get_route_arcs_source_layer_id(lyr) == point_id:
            return lyr

    # Repair / find by display name used when the arcs layer was created.
    desired_name = route_arcs_display_name_for_point_layer(point_layer)
    name_matches = []
    for lyr in iter_route_arcs_layers(project):
        try:
            if lyr.name() == desired_name:
                name_matches.append(lyr)
        except Exception:
            continue
    if len(name_matches) == 1:
        adopted = name_matches[0]
        mark_route_arcs_layer(adopted)
        set_route_arcs_source_layer_id(adopted, point_id)
        return adopted

    if match_by_content:
        candidates = []
        for lyr in iter_route_arcs_layers(project):
            owner = get_route_arcs_source_layer_id(lyr)
            if owner and owner != point_id:
                continue
            score = _score_arcs_layer_against_point_layer(lyr, point_layer)
            if score > 0:
                candidates.append((score, lyr))
        if candidates:
            candidates.sort(key=lambda item: item[0], reverse=True)
            best_score, best = candidates[0]
            # Require a unique top score so two point layers with overlapping
            # place names do not steal each other's arcs layer.
            if sum(1 for score, _ in candidates if score == best_score) == 1:
                mark_route_arcs_layer(best)
                set_route_arcs_source_layer_id(best, point_id)
                try:
                    if best.name() in ("Route Arcs", "") or not str(best.name()).strip():
                        best.setName(desired_name)
                except Exception:
                    pass
                return best

    if not adopt_legacy:
        return None

    unbound = []
    for lyr in iter_route_arcs_layers(project):
        if get_route_arcs_source_layer_id(lyr):
            continue
        if not _route_arcs_crs_matches(lyr.crs(), point_layer.crs()):
            continue
        unbound.append(lyr)
    if len(unbound) != 1:
        return None

    adopted = unbound[0]
    mark_route_arcs_layer(adopted)
    set_route_arcs_source_layer_id(adopted, point_id)
    try:
        if adopted.name() in ("Route Arcs", "") or not str(adopted.name()).strip():
            adopted.setName(desired_name)
    except Exception:
        pass
    return adopted


def route_arcs_display_name_for_point_layer(point_layer) -> str:
    try:
        name = (point_layer.name() or "").strip()
    except Exception:
        name = ""
    if name:
        return "Route Arcs — {}".format(name)
    return "Route Arcs"


def _vector_writer_error_code(err):
    if isinstance(err, (tuple, list)):
        return err[0] if err else QgsVectorFileWriter.NoError
    return err


def _vector_writer_succeeded(err) -> bool:
    try:
        return _vector_writer_error_code(err) == QgsVectorFileWriter.NoError
    except Exception:
        return False


def _gpkg_layer_uri(gpkg_path: str) -> str:
    return "{}|layername={}".format(gpkg_path, ROUTE_ARCS_GPKG_LAYER_NAME)


def set_route_arcs_gpkg_file(lyr: QgsVectorLayer, gpkg_path: str) -> None:
    if lyr is None or not gpkg_path:
        return
    try:
        lyr.setCustomProperty(ROUTE_ARCS_GPKG_FILE_PROP, os.path.basename(gpkg_path))
    except Exception:
        pass


def resolve_route_arcs_gpkg_path(lyr: QgsVectorLayer, project=None) -> str | None:
    if lyr is None:
        return None
    project = project or QgsProject.instance()
    try:
        basename = str(lyr.customProperty(ROUTE_ARCS_GPKG_FILE_PROP, "") or "").strip()
    except Exception:
        basename = ""
    if basename:
        try:
            from .geocode_layer import geocode_storage_directory

            folder = geocode_storage_directory(project)
            if folder:
                candidate = os.path.normpath(os.path.join(folder, basename))
                if os.path.isfile(candidate):
                    return candidate
        except Exception:
            pass
    try:
        raw = str(lyr.source() or "").split("|")[0]
        if raw.lower().endswith(".gpkg") and os.path.isfile(raw):
            return os.path.normpath(raw)
    except Exception:
        pass
    return None


def _is_memory_route_arcs_layer(lyr: QgsVectorLayer) -> bool:
    if lyr is None:
        return False
    try:
        if lyr.providerType() == "memory":
            return True
    except Exception:
        pass
    try:
        src = (lyr.source() or "").strip().lower()
        if src.startswith("linestring?") or src.startswith("multilinestring?"):
            return True
    except Exception:
        pass
    return False


def _safe_route_arcs_gpkg_stem(display_name: str) -> str:
    base = re.sub(
        r"^Route Arcs\s*[—–-]?\s*",
        "",
        str(display_name or "").strip(),
        flags=re.IGNORECASE,
    ).strip()
    if not base:
        base = "layer"
    stem = re.sub(r"[^A-Za-z0-9_-]+", "_", base).strip("_")
    return "route_arcs_{}".format(stem or "layer")


def _unique_route_arcs_gpkg_path(folder: str, display_name: str) -> str:
    stem = _safe_route_arcs_gpkg_stem(display_name)
    path = os.path.join(folder, "{}.gpkg".format(stem))
    if not os.path.exists(path):
        return os.path.normpath(path)
    n = 2
    while True:
        path = os.path.join(folder, "{}_{}.gpkg".format(stem, n))
        if not os.path.exists(path):
            return os.path.normpath(path)
        n += 1


def _load_route_arcs_gpkg(gpkg_path: str, display_name: str) -> QgsVectorLayer | None:
    if not gpkg_path or not os.path.isfile(gpkg_path):
        return None
    lyr = QgsVectorLayer(_gpkg_layer_uri(gpkg_path), display_name, "ogr")
    if lyr.isValid():
        return lyr
    lyr = QgsVectorLayer(gpkg_path, display_name, "ogr")
    if lyr.isValid():
        return lyr
    return None


def _create_empty_route_arcs_gpkg(gpkg_path: str, crs) -> bool:
    parent = os.path.dirname(gpkg_path)
    if parent:
        try:
            os.makedirs(parent, exist_ok=True)
        except OSError:
            return False
    crs_auth = crs.authid() if crs is not None and crs.isValid() else "EPSG:4326"
    mem = QgsVectorLayer(
        "LineString?crs={}".format(crs_auth), ROUTE_ARCS_GPKG_LAYER_NAME, "memory"
    )
    pr = mem.dataProvider()
    pr.addAttributes(
        [
            QgsField("Start", QVariant.String),
            QgsField("End", QVariant.String),
            QgsField("ConnID", QVariant.String),
        ]
    )
    mem.updateFields()
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = ROUTE_ARCS_GPKG_LAYER_NAME
    options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
    project = QgsProject.instance()
    ctx = project.transformContext() if project else None
    try:
        err, _warnings, _path, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
            mem, gpkg_path, ctx, options
        )
        if _vector_writer_succeeded(err):
            return os.path.isfile(gpkg_path)
    except Exception:
        pass
    try:
        err = QgsVectorFileWriter.writeAsVectorFormat(
            mem,
            gpkg_path,
            "UTF-8",
            crs if crs is not None and crs.isValid() else mem.crs(),
            "GPKG",
        )
        if isinstance(err, tuple):
            return err[0] == QgsVectorFileWriter.NoError and os.path.isfile(gpkg_path)
        return err == QgsVectorFileWriter.NoError and os.path.isfile(gpkg_path)
    except Exception:
        return False


def _write_route_arcs_layer_to_gpkg(lyr: QgsVectorLayer, gpkg_path: str) -> bool:
    if lyr is None or not gpkg_path:
        return False
    parent = os.path.dirname(gpkg_path)
    if parent:
        try:
            os.makedirs(parent, exist_ok=True)
        except OSError:
            return False
    was_editable = False
    try:
        was_editable = lyr.isEditable()
        if was_editable:
            lyr.commitChanges()
    except Exception:
        pass
    ok = False
    try:
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = ROUTE_ARCS_GPKG_LAYER_NAME
        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
        project = QgsProject.instance()
        ctx = project.transformContext() if project else None
        try:
            err, _warnings, _path, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
                lyr, gpkg_path, ctx, options
            )
            ok = _vector_writer_succeeded(err) and os.path.isfile(gpkg_path)
        except Exception:
            ok = False
        if not ok:
            try:
                err = QgsVectorFileWriter.writeAsVectorFormat(
                    lyr,
                    gpkg_path,
                    "UTF-8",
                    lyr.crs(),
                    "GPKG",
                )
                if isinstance(err, tuple):
                    ok = err[0] == QgsVectorFileWriter.NoError
                else:
                    ok = err == QgsVectorFileWriter.NoError
                ok = ok and os.path.isfile(gpkg_path)
            except Exception:
                ok = False
    finally:
        if was_editable:
            try:
                lyr.startEditing()
            except Exception:
                pass
    return ok


def _finalize_route_arcs_map_layer(
    arc_layer: QgsVectorLayer,
    gpkg_path: str,
    project,
    source_layer_id: str = "",
) -> QgsVectorLayer:
    mark_route_arcs_layer(arc_layer)
    set_route_arcs_gpkg_file(arc_layer, gpkg_path)
    if source_layer_id:
        set_route_arcs_source_layer_id(arc_layer, source_layer_id)
    ensure_route_arcs_line_round_caps(arc_layer)
    try:
        if not arc_layer.isEditable():
            arc_layer.startEditing()
    except Exception:
        pass
    return arc_layer


def _create_gpkg_route_arcs_layer(crs, display_name, project, source_layer_id=""):
    """Create a Route Arcs layer backed by a GeoPackage sidecar file."""
    try:
        from .geocode_layer import geocode_storage_directory
    except Exception:
        geocode_storage_directory = None
    folder = geocode_storage_directory(project) if geocode_storage_directory else None
    if not folder:
        return None
    gpkg_path = _unique_route_arcs_gpkg_path(folder, display_name)
    if not _create_empty_route_arcs_gpkg(gpkg_path, crs):
        return None
    arc_layer = _load_route_arcs_gpkg(gpkg_path, display_name)
    if arc_layer is None:
        return None
    project.addMapLayer(arc_layer)
    return _finalize_route_arcs_map_layer(
        arc_layer, gpkg_path, project, source_layer_id=source_layer_id
    )


def migrate_memory_route_arcs_to_gpkg(lyr: QgsVectorLayer, project=None) -> QgsVectorLayer:
    """Replace a scratch Route Arcs memory layer with a GeoPackage-backed layer."""
    if lyr is None or not _is_memory_route_arcs_layer(lyr):
        return lyr
    project = project or QgsProject.instance()
    try:
        from .geocode_layer import geocode_storage_directory
    except Exception:
        return lyr
    folder = geocode_storage_directory(project)
    if not folder:
        return lyr

    display_name = lyr.name() or "Route Arcs"
    source_id = get_route_arcs_source_layer_id(lyr)
    gpkg_path = resolve_route_arcs_gpkg_path(lyr, project)
    if not gpkg_path or not os.path.isfile(gpkg_path):
        gpkg_path = _unique_route_arcs_gpkg_path(folder, display_name)
    if not _write_route_arcs_layer_to_gpkg(lyr, gpkg_path):
        return lyr

    new_lyr = _load_route_arcs_gpkg(gpkg_path, display_name)
    if new_lyr is None:
        return lyr

    try:
        renderer = lyr.renderer()
        if renderer is not None:
            new_lyr.setRenderer(renderer.clone())
    except Exception:
        pass

    project.addMapLayer(new_lyr)
    _finalize_route_arcs_map_layer(new_lyr, gpkg_path, project, source_layer_id=source_id)
    try:
        project.removeMapLayer(lyr.id())
    except Exception:
        pass
    return new_lyr


def ensure_route_arcs_layer_persisted(lyr: QgsVectorLayer, project=None) -> QgsVectorLayer:
    if lyr is None:
        return lyr
    if _is_memory_route_arcs_layer(lyr):
        return migrate_memory_route_arcs_to_gpkg(lyr, project=project)
    return lyr


def ensure_all_route_arcs_layers_persisted(project=None) -> None:
    project = project or QgsProject.instance()
    for lyr in list(iter_route_arcs_layers(project)):
        ensure_route_arcs_layer_persisted(lyr, project=project)


def migrate_route_arcs_gpkg_to_project_folder_if_needed(
    project=None, project_folder: str | None = None
) -> None:
    """Copy Route Arcs sidecar GPKGs beside the project when saving for the first time."""
    project = project or QgsProject.instance()
    if not project_folder:
        try:
            from .geocode_layer import project_data_directory

            project_folder = project_data_directory(project)
        except Exception:
            project_folder = None
    if not project_folder:
        return
    project_folder = os.path.normpath(project_folder)
    try:
        os.makedirs(project_folder, exist_ok=True)
    except OSError:
        return

    try:
        from .geocode_layer import _geocode_staging_directory_path
    except Exception:
        _geocode_staging_directory_path = None

    staging_norm = None
    if _geocode_staging_directory_path is not None:
        try:
            staging = _geocode_staging_directory_path(project, create=False)
            if staging and os.path.isdir(staging):
                staging_norm = os.path.normpath(staging)
        except Exception:
            staging_norm = None

    for lyr in list(iter_route_arcs_layers(project)):
        try:
            if lyr.isEditable():
                lyr.commitChanges()
        except Exception:
            pass
        src = resolve_route_arcs_gpkg_path(lyr, project)
        if not src or not os.path.isfile(src):
            continue
        src_norm = os.path.normpath(src)
        if os.path.dirname(src_norm) == project_folder:
            set_route_arcs_gpkg_file(lyr, src_norm)
            continue
        if staging_norm and not src_norm.startswith(staging_norm):
            continue
        dest = os.path.join(project_folder, os.path.basename(src_norm))
        if os.path.normpath(dest) != src_norm:
            if not _write_route_arcs_layer_to_gpkg(lyr, dest):
                continue
        if not os.path.isfile(dest):
            continue
        try:
            if hasattr(lyr, "setDataSource"):
                lyr.setDataSource(
                    _gpkg_layer_uri(dest),
                    lyr.name(),
                    "ogr",
                )
                set_route_arcs_gpkg_file(lyr, dest)
        except Exception:
            pass


def create_route_arcs_layer(crs, display_name="Route Arcs", project=None, source_layer_id=""):
    """Create a new GeoPackage-backed Route Arcs layer."""
    project = project or QgsProject.instance()
    return _create_gpkg_route_arcs_layer(
        crs, display_name, project, source_layer_id=source_layer_id
    )


def get_or_create_route_arcs_for_point_layer(point_layer, project=None):
    """Find or create the Route Arcs layer bound to this point layer."""
    if point_layer is None:
        return None
    project = project or QgsProject.instance()
    existing = find_route_arcs_layer_for_point_layer(
        point_layer, project=project, adopt_legacy=True
    )
    if existing is not None:
        return ensure_route_arcs_layer_persisted(existing, project=project)
    try:
        point_id = str(point_layer.id())
        crs = point_layer.crs()
    except Exception:
        return None
    return create_route_arcs_layer(
        crs,
        display_name=route_arcs_display_name_for_point_layer(point_layer),
        project=project,
        source_layer_id=point_id,
    )
