# -*- coding: utf-8 -*-
"""Radius Buffer tool — geometry-generator rings on point layers."""

import os
import re

from qgis.core import QgsProject, QgsVectorLayer, QgsWkbTypes
from qgis.PyQt import uic
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QGuiApplication
from qgis.PyQt.QtWidgets import QDialog, QFileDialog, QListWidgetItem, QMessageBox

from .library_basemap_list import (
    populate_library_basemap_qlist_widget,
    wire_library_basemap_qlist_widget,
)
from .point_buffer_layer import (
    DEFAULT_BUFFER_FILL_COLOR,
    DEFAULT_BUFFER_OUTLINE_COLOR,
    DEFAULT_BUFFER_TRANSPARENCY,
    DEFAULT_BUFFER_UNITS,
    apply_point_buffer,
    combo_index_for_unit_key,
    convert_map_units_to_display,
    crs_allows_metric_buffer,
    default_radius_for_units,
    is_point_buffer_layer,
    list_point_buffer_layers,
    list_project_point_layers,
    point_buffer_display_units,
    point_buffer_fill_color,
    point_buffer_outline_color,
    point_buffer_radius_map_units,
    point_buffer_transparency,
    remove_point_buffer,
    reproject_point_layer_to_gpkg,
    set_point_buffer_radius,
    suggest_projected_crs_for_layer,
    unit_key_from_combo_index,
    unit_labels_for_combo,
)


class RadiusBufferDialog(QDialog):
    """Manage radius buffers on point layers (symbology + custom properties)."""

    def __init__(self, plugin, parent=None):
        super().__init__(parent)
        self._plugin = plugin
        self._syncing_controls = False
        self._project_layers_wired = False
        ui_path = os.path.join(os.path.dirname(__file__), "radius_buffer.ui")
        self.dlgRadiusBuffer = self
        try:
            uic.loadUi(ui_path, self)
        finally:
            try:
                del self.dlgRadiusBuffer
            except AttributeError:
                pass

        cmb_units = getattr(self, "cmbRadiusUnits", None)
        if cmb_units is not None:
            cmb_units.clear()
            cmb_units.addItems(unit_labels_for_combo())
            cmb_units.setCurrentIndex(combo_index_for_unit_key(DEFAULT_BUFFER_UNITS))
            cmb_units.currentIndexChanged.connect(self._on_radius_units_changed)

        spn = getattr(self, "spnRadius", None)
        if spn is not None:
            spn.setValue(default_radius_for_units(DEFAULT_BUFFER_UNITS))
        sld_trans = getattr(self, "sldTransparency", None)
        spn_trans = getattr(self, "spnTransparency", None)
        if sld_trans is not None:
            sld_trans.valueChanged.connect(self._on_transparency_slider_changed)
        if spn_trans is not None:
            spn_trans.valueChanged.connect(self._on_transparency_spin_changed)
        self._set_transparency_value(DEFAULT_BUFFER_TRANSPARENCY)

        fill_btn = getattr(self, "plhBufferFillColor", None)
        if fill_btn is not None:
            fill_btn.setColor(DEFAULT_BUFFER_FILL_COLOR)
        outline_btn = getattr(self, "plhBufferOutlineColor", None)
        if outline_btn is not None:
            outline_btn.setColor(DEFAULT_BUFFER_OUTLINE_COLOR)

        self.pbnApplyBuffer.clicked.connect(self._on_apply_buffer)
        self.pbnRemoveBuffer.clicked.connect(self._on_remove_buffer)
        bb = getattr(self, "buttonBox", None)
        if bb is not None:
            bb.accepted.connect(self._on_dialog_finished)

        lst = getattr(self, "lstBufferLayers", None)
        if lst is not None:
            lst.currentItemChanged.connect(self._on_buffer_layer_selection_changed)

        cmb = getattr(self, "cmbPointLayers", None)
        if cmb is not None:
            cmb.currentIndexChanged.connect(self._on_point_layer_combo_changed)

        lst_lib = getattr(self, "lstLibraryBasemaps", None)
        if lst_lib is not None:
            wire_library_basemap_qlist_widget(lst_lib, self._on_library_basemap_chosen)

        pbn_browse = getattr(self, "pbnBrowseLayer", None)
        if pbn_browse is not None:
            pbn_browse.clicked.connect(self._on_browse_layer)

    def _library_folder(self):
        if self._plugin is None or not hasattr(self._plugin, "_library_folder"):
            return None
        try:
            return self._plugin._library_folder()
        except Exception:
            return None

    def _refresh_library_basemap_list(self):
        lst = getattr(self, "lstLibraryBasemaps", None)
        if lst is None:
            return
        populate_library_basemap_qlist_widget(lst, self._library_folder() or "")

    def _wire_project_layer_signals(self):
        if self._project_layers_wired:
            return
        proj = QgsProject.instance()
        try:
            proj.layersAdded.connect(self._on_project_layers_added)
            proj.layersRemoved.connect(self._on_project_layers_removed)
            self._project_layers_wired = True
        except Exception:
            pass

    def _unwire_project_layer_signals(self):
        if not self._project_layers_wired:
            return
        proj = QgsProject.instance()
        try:
            proj.layersAdded.disconnect(self._on_project_layers_added)
        except (TypeError, RuntimeError):
            pass
        try:
            proj.layersRemoved.disconnect(self._on_project_layers_removed)
        except (TypeError, RuntimeError):
            pass
        self._project_layers_wired = False

    @staticmethod
    def _is_point_layer(lyr) -> bool:
        if lyr is None or not isinstance(lyr, QgsVectorLayer):
            return False
        try:
            from qgis.PyQt import sip

            if sip.isdeleted(lyr):
                return False
        except Exception:
            return False
        try:
            return lyr.geometryType() == QgsWkbTypes.PointGeometry
        except Exception:
            return False

    def _on_project_layers_added(self, layers):
        select_id = self._selected_point_layer_id()
        for lyr in layers or []:
            if self._is_point_layer(lyr):
                try:
                    select_id = lyr.id()
                except Exception:
                    pass
        self._refresh_library_basemap_list()
        self._refresh_lists(select_layer_id=select_id)

    def _on_project_layers_removed(self, _layer_ids):
        self._refresh_lists(select_layer_id=self._selected_point_layer_id())

    def _on_library_basemap_chosen(self, path):
        if self._plugin is not None and hasattr(self._plugin, "loadBasemapFromFile"):
            self._plugin.loadBasemapFromFile(path, stack_by_geometry=True)

    def _on_browse_layer(self):
        path, _selected = QFileDialog.getOpenFileName(
            self,
            self.tr("Add layer"),
            "",
            self.tr(
                "Vector files (*.shp *.zip *.gpkg *.geojson *.json);;"
                "All files (*.*)"
            ),
        )
        path = (path or "").strip()
        if not path:
            return
        if self._plugin is not None and hasattr(self._plugin, "loadBasemapFromFile"):
            self._plugin.loadBasemapFromFile(path, stack_by_geometry=True)

    def _current_unit_key(self) -> str:
        cmb_units = getattr(self, "cmbRadiusUnits", None)
        if cmb_units is None:
            return DEFAULT_BUFFER_UNITS
        return unit_key_from_combo_index(cmb_units.currentIndex())

    def _on_transparency_slider_changed(self, value):
        spn = getattr(self, "spnTransparency", None)
        if spn is None or spn.value() == value:
            return
        spn.blockSignals(True)
        try:
            spn.setValue(value)
        finally:
            spn.blockSignals(False)

    def _on_transparency_spin_changed(self, value):
        sld = getattr(self, "sldTransparency", None)
        if sld is None or sld.value() == value:
            return
        sld.blockSignals(True)
        try:
            sld.setValue(value)
        finally:
            sld.blockSignals(False)

    def _set_transparency_value(self, value):
        pct = max(0, min(100, int(round(float(value)))))
        sld = getattr(self, "sldTransparency", None)
        spn = getattr(self, "spnTransparency", None)
        if sld is not None:
            sld.blockSignals(True)
            try:
                sld.setValue(pct)
            finally:
                sld.blockSignals(False)
        if spn is not None:
            spn.blockSignals(True)
            try:
                spn.setValue(pct)
            finally:
                spn.blockSignals(False)

    def _current_transparency(self) -> float:
        spn_trans = getattr(self, "spnTransparency", None)
        if spn_trans is not None:
            return float(spn_trans.value())
        sld_trans = getattr(self, "sldTransparency", None)
        if sld_trans is None:
            return DEFAULT_BUFFER_TRANSPARENCY
        return float(sld_trans.value())

    def _current_fill_color(self):
        btn = getattr(self, "plhBufferFillColor", None)
        if btn is None:
            return DEFAULT_BUFFER_FILL_COLOR
        try:
            return btn.color()
        except Exception:
            return DEFAULT_BUFFER_FILL_COLOR

    def _current_outline_color(self):
        btn = getattr(self, "plhBufferOutlineColor", None)
        if btn is None:
            return DEFAULT_BUFFER_OUTLINE_COLOR
        try:
            return btn.color()
        except Exception:
            return DEFAULT_BUFFER_OUTLINE_COLOR

    def _set_color_buttons(self, fill_color, outline_color):
        fill_btn = getattr(self, "plhBufferFillColor", None)
        if fill_btn is not None:
            fill_btn.setColor(fill_color)
        outline_btn = getattr(self, "plhBufferOutlineColor", None)
        if outline_btn is not None:
            outline_btn.setColor(outline_color)

    def _apply_default_controls(self):
        cmb_units = getattr(self, "cmbRadiusUnits", None)
        spn = getattr(self, "spnRadius", None)
        unit_key = DEFAULT_BUFFER_UNITS
        if cmb_units is not None:
            cmb_units.blockSignals(True)
            try:
                cmb_units.setCurrentIndex(combo_index_for_unit_key(unit_key))
            finally:
                cmb_units.blockSignals(False)
        if spn is not None:
            spn.setValue(default_radius_for_units(unit_key))
        self._set_transparency_value(DEFAULT_BUFFER_TRANSPARENCY)
        self._set_color_buttons(DEFAULT_BUFFER_FILL_COLOR, DEFAULT_BUFFER_OUTLINE_COLOR)

    def _on_radius_units_changed(self, index):
        if self._syncing_controls:
            return
        lyr = self._layer_by_id(self._selected_buffer_layer_id())
        if lyr is not None and is_point_buffer_layer(lyr):
            return
        spn = getattr(self, "spnRadius", None)
        if spn is None:
            return
        unit_key = unit_key_from_combo_index(index)
        spn.setValue(default_radius_for_units(unit_key))

    def _on_dialog_finished(self):
        if self._plugin is not None and hasattr(self._plugin, "register_completed_tool"):
            self._plugin.register_completed_tool("radius_buffer")

    def showEvent(self, event):
        super().showEvent(event)
        self._wire_project_layer_signals()
        self._refresh_library_basemap_list()
        self._refresh_lists()
        self._center_on_screen()

    def hideEvent(self, event):
        self._unwire_project_layer_signals()
        super().hideEvent(event)

    def closeEvent(self, event):
        self._unwire_project_layer_signals()
        super().closeEvent(event)

    def _center_on_screen(self):
        ref = self.parentWidget()
        center_pt = ref.frameGeometry().center() if ref is not None else None
        if center_pt is None:
            center_pt = self.frameGeometry().center()
        screen = QGuiApplication.screenAt(center_pt)
        if screen is None:
            screen = QGuiApplication.primaryScreen()
        if screen is None:
            return
        ag = screen.availableGeometry()
        geo = self.frameGeometry()
        geo.moveCenter(ag.center())
        self.move(geo.topLeft())

    def _refresh_lists(self, select_layer_id: str | None = None):
        self._refresh_buffer_layer_list(select_layer_id=select_layer_id)
        self._refresh_point_layer_combo(select_layer_id=select_layer_id)
        self._sync_radius_controls()

    def _refresh_buffer_layer_list(self, select_layer_id: str | None = None):
        lst = getattr(self, "lstBufferLayers", None)
        if lst is None:
            return
        prev_id = select_layer_id
        if prev_id is None:
            item = lst.currentItem()
            if item is not None:
                prev_id = item.data(Qt.UserRole)
        lst.blockSignals(True)
        try:
            lst.clear()
            select_row = -1
            buffer_layers = list_point_buffer_layers()
            labels = self._disambiguated_layer_labels(buffer_layers)
            for row, lyr in enumerate(buffer_layers):
                map_r = point_buffer_radius_map_units(lyr)
                units = point_buffer_display_units(lyr)
                detail = ""
                if map_r is not None:
                    display_r = convert_map_units_to_display(map_r, units, lyr)
                    detail = self.tr("{0} {1}").format(
                        self._format_radius(display_r),
                        units,
                    )
                label = labels.get(lyr.id(), lyr.name())
                if detail:
                    label = self.tr("{0} — {1}").format(label, detail)
                item = QListWidgetItem(label)
                item.setData(Qt.UserRole, lyr.id())
                lst.addItem(item)
                if prev_id and lyr.id() == prev_id:
                    select_row = row
            if select_row >= 0:
                lst.setCurrentRow(select_row)
        finally:
            lst.blockSignals(False)

    def _refresh_point_layer_combo(self, select_layer_id: str | None = None):
        cmb = getattr(self, "cmbPointLayers", None)
        if cmb is None:
            return
        prev_id = select_layer_id or self._selected_point_layer_id()
        layers = list_project_point_layers()
        cmb.blockSignals(True)
        try:
            cmb.clear()
            if not layers:
                cmb.addItem(
                    self.tr("(No point layers — add from library or Browse)"),
                    "",
                )
                cmb.setEnabled(False)
                return
            cmb.setEnabled(True)
            select_idx = -1
            labels = self._disambiguated_layer_labels(layers)
            for idx, lyr in enumerate(layers):
                cmb.addItem(labels.get(lyr.id(), lyr.name()), lyr.id())
                if prev_id and lyr.id() == prev_id:
                    select_idx = idx
            if select_idx >= 0:
                cmb.setCurrentIndex(select_idx)
            elif cmb.count() > 0:
                cmb.setCurrentIndex(0)
        finally:
            cmb.blockSignals(False)

    @staticmethod
    def _format_radius(value: float) -> str:
        try:
            v = float(value)
        except (TypeError, ValueError):
            return "0"
        if abs(v - round(v)) < 0.0005:
            return str(int(round(v)))
        return "{:.2f}".format(v)

    def _selected_buffer_layer_id(self) -> str | None:
        lst = getattr(self, "lstBufferLayers", None)
        if lst is None:
            return None
        item = lst.currentItem()
        if item is None:
            return None
        role = item.data(Qt.UserRole)
        return str(role) if role else None

    def _selected_point_layer_id(self) -> str | None:
        cmb = getattr(self, "cmbPointLayers", None)
        if cmb is None or cmb.currentIndex() < 0:
            return None
        role = cmb.currentData()
        return str(role) if role else None

    def _layer_by_id(self, layer_id: str | None) -> QgsVectorLayer | None:
        if not layer_id:
            return None
        lyr = QgsProject.instance().mapLayer(layer_id)
        if lyr is None or not isinstance(lyr, QgsVectorLayer):
            return None
        try:
            from qgis.PyQt import sip

            if sip.isdeleted(lyr):
                return None
        except Exception:
            return None
        return lyr

    @staticmethod
    def _disambiguated_layer_labels(layers) -> dict[str, str]:
        """Suffix duplicate layer names so identical names are distinguishable in lists."""
        name_totals: dict[str, int] = {}
        for lyr in layers:
            key = lyr.name().lower()
            name_totals[key] = name_totals.get(key, 0) + 1
        name_seen: dict[str, int] = {}
        labels: dict[str, str] = {}
        for lyr in layers:
            name = lyr.name()
            key = name.lower()
            if name_totals.get(key, 0) > 1:
                name_seen[key] = name_seen.get(key, 0) + 1
                labels[lyr.id()] = "{} ({})".format(name, name_seen[key])
            else:
                labels[lyr.id()] = name
        return labels

    def _selected_editing_layer(self) -> QgsVectorLayer | None:
        """Layer the user is editing: point combo wins over buffer list selection."""
        lyr = self._layer_by_id(self._selected_point_layer_id())
        if lyr is not None:
            return lyr
        return self._layer_by_id(self._selected_buffer_layer_id())

    def _target_layer_for_apply(self) -> QgsVectorLayer | None:
        return self._selected_editing_layer()

    def _sync_radius_controls(self):
        if self._syncing_controls:
            return
        self._syncing_controls = True
        try:
            lyr = self._selected_editing_layer()
            spn = getattr(self, "spnRadius", None)
            cmb_units = getattr(self, "cmbRadiusUnits", None)
            lbl = getattr(self, "lblCrsNote", None)
            if lyr is None:
                self._apply_default_controls()
                if lbl is not None:
                    lbl.setText(
                        self.tr(
                            "Select a point layer to create a buffer, or choose an existing buffer layer to edit."
                        )
                    )
                if self.pbnRemoveBuffer is not None:
                    self.pbnRemoveBuffer.setEnabled(False)
                if self.pbnApplyBuffer is not None:
                    self.pbnApplyBuffer.setEnabled(
                        self._layer_by_id(self._selected_point_layer_id()) is not None
                    )
                return
            if is_point_buffer_layer(lyr):
                units = point_buffer_display_units(lyr)
                if cmb_units is not None:
                    cmb_units.setCurrentIndex(combo_index_for_unit_key(units))
                map_r = point_buffer_radius_map_units(lyr)
                if map_r is not None and spn is not None:
                    spn.setValue(convert_map_units_to_display(map_r, units, lyr))
                self._set_transparency_value(point_buffer_transparency(lyr))
                self._set_color_buttons(
                    point_buffer_fill_color(lyr),
                    point_buffer_outline_color(lyr),
                )
            else:
                self._apply_default_controls()
            ok, msg = crs_allows_metric_buffer(lyr)
            if lbl is not None:
                if ok:
                    lbl.setText(
                        self.tr(
                            "Layer CRS: {0}. Buffers are drawn with geometry-generator symbology."
                        ).format(lyr.crs().authid())
                    )
                else:
                    lbl.setText(
                        msg
                        + " "
                        + self.tr(
                            "Apply Buffer will ask you to choose a projected CRS first."
                        )
                    )
            if self.pbnRemoveBuffer is not None:
                self.pbnRemoveBuffer.setEnabled(is_point_buffer_layer(lyr))
            if self.pbnApplyBuffer is not None:
                self.pbnApplyBuffer.setEnabled(True)
        finally:
            self._syncing_controls = False

    def _on_buffer_layer_selection_changed(self, current, previous):
        if current is None:
            self._sync_radius_controls()
            return
        layer_id = current.data(Qt.UserRole)
        cmb = getattr(self, "cmbPointLayers", None)
        if cmb is not None and layer_id:
            idx = cmb.findData(layer_id)
            if idx >= 0:
                cmb.blockSignals(True)
                try:
                    cmb.setCurrentIndex(idx)
                finally:
                    cmb.blockSignals(False)
        self._sync_radius_controls()

    def _on_point_layer_combo_changed(self, index):
        if self._syncing_controls:
            return
        layer_id = self._selected_point_layer_id()
        lst = getattr(self, "lstBufferLayers", None)
        if lst is not None:
            matched = False
            if layer_id:
                for row in range(lst.count()):
                    item = lst.item(row)
                    if item is not None and item.data(Qt.UserRole) == layer_id:
                        lst.blockSignals(True)
                        try:
                            lst.setCurrentRow(row)
                        finally:
                            lst.blockSignals(False)
                        matched = True
                        break
            if not matched:
                lst.blockSignals(True)
                try:
                    lst.clearSelection()
                finally:
                    lst.blockSignals(False)
        self._sync_radius_controls()

    def _ensure_projected_layer_for_buffer(
        self, lyr: QgsVectorLayer
    ) -> tuple[QgsVectorLayer | None, str | None]:
        """
        Return a layer suitable for buffering.

        If ``lyr`` is already projected, returns (lyr, None).
        If geographic, prompts for CRS and saves a projected GeoPackage copy.
        Returns (None, None) when the user cancels CRS selection.
        """
        ok, _msg = crs_allows_metric_buffer(lyr)
        if ok:
            return lyr, None

        suggested = suggest_projected_crs_for_layer(lyr)
        dest_crs = suggested
        try:
            from qgis.gui import QgsProjectionSelectionDialog

            dlg = QgsProjectionSelectionDialog(self)
            dlg.setCrs(suggested)
            dlg.setWindowTitle(self.tr("Choose projected CRS for buffering"))
            if dlg.exec_() != QDialog.Accepted:
                return None, None
            dest_crs = dlg.crs()
        except Exception:
            # Fallback: use suggested UTM without a picker.
            pass

        if dest_crs is None or not dest_crs.isValid():
            return None, self.tr("Choose a valid projected CRS.")
        try:
            if dest_crs.isGeographic():
                return None, self.tr(
                    "Pick a projected CRS (meters/feet), not a geographic one (degrees)."
                )
        except Exception:
            pass

        from .geocode_layer import geocode_storage_directory

        folder = geocode_storage_directory(QgsProject.instance())
        if not folder:
            return None, self.tr(
                "Could not find a folder to save the GeoPackage. "
                "Save the project first, or set a geocode staging folder in Settings."
            )

        base_name = (lyr.name() or "points").strip() or "points"
        safe = re.sub(r"[^A-Za-z0-9_-]+", "_", base_name).strip("_") or "points"
        display_name = "{} (projected)".format(base_name)
        gpkg_path = os.path.join(folder, "{}_projected.gpkg".format(safe))
        n = 2
        while os.path.exists(gpkg_path):
            gpkg_path = os.path.join(folder, "{}_projected_{}.gpkg".format(safe, n))
            n += 1

        out_lyr, err = reproject_point_layer_to_gpkg(
            lyr, dest_crs, gpkg_path, display_name=display_name
        )
        if out_lyr is None:
            return None, err or self.tr("Reproject failed.")

        QgsProject.instance().addMapLayer(out_lyr)
        try:
            QgsProject.instance().setDirty(True)
        except Exception:
            pass

        self._refresh_lists(select_layer_id=out_lyr.id())
        return out_lyr, None

    def _on_apply_buffer(self):
        lyr = self._target_layer_for_apply()
        if lyr is None:
            QMessageBox.warning(
                self,
                self.windowTitle(),
                self.tr("Select a point layer."),
            )
            return
        ok_crs, _msg = crs_allows_metric_buffer(lyr)
        if not ok_crs:
            lyr, reproj_err = self._ensure_projected_layer_for_buffer(lyr)
            if lyr is None:
                if reproj_err:
                    QMessageBox.warning(
                        self,
                        self.windowTitle(),
                        reproj_err,
                    )
                return
        spn = getattr(self, "spnRadius", None)
        cmb_units = getattr(self, "cmbRadiusUnits", None)
        if spn is None or cmb_units is None:
            return
        radius = float(spn.value())
        unit_key = self._current_unit_key()
        transparency = self._current_transparency()
        fill_color = self._current_fill_color()
        outline_color = self._current_outline_color()
        if is_point_buffer_layer(lyr):
            ok, err = set_point_buffer_radius(
                lyr,
                radius,
                unit_key,
                transparency_pct=transparency,
                fill_color=fill_color,
                outline_color=outline_color,
            )
        else:
            ok, err = apply_point_buffer(
                lyr,
                radius,
                unit_key,
                transparency_pct=transparency,
                fill_color=fill_color,
                outline_color=outline_color,
            )
        if not ok:
            QMessageBox.warning(
                self,
                self.windowTitle(),
                err or self.tr("Could not apply the buffer."),
            )
            return
        try:
            layer_id = lyr.id()
        except Exception:
            layer_id = None
        self._refresh_lists(select_layer_id=layer_id)
        if self._plugin is not None and hasattr(self._plugin, "register_completed_tool"):
            self._plugin.register_completed_tool("radius_buffer")

    def _on_remove_buffer(self):
        lyr = self._selected_editing_layer()
        if lyr is None or not is_point_buffer_layer(lyr):
            QMessageBox.information(
                self,
                self.windowTitle(),
                self.tr("Select a buffer layer to remove."),
            )
            return
        if (
            QMessageBox.question(
                self,
                self.windowTitle(),
                self.tr(
                    'Remove the radius buffer from "{0}"? Point markers are kept.'
                ).format(lyr.name()),
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            != QMessageBox.Yes
        ):
            return
        remove_point_buffer(lyr)
        self._refresh_lists()
        if not list_point_buffer_layers():
            dw = getattr(self._plugin, "dockwidget", None)
            if dw is not None and hasattr(dw, "unregister_completed_tool"):
                dw.unregister_completed_tool("radius_buffer")
