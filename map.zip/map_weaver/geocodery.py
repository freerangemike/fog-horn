from qgis.PyQt.QtCore import QObject, QUrl, pyqtSignal
from qgis.PyQt.QtNetwork import QNetworkAccessManager, QNetworkRequest
import json
import urllib.parse


class MapTilerGeocoder(QObject):
    resultReady = pyqtSignal(str, float, float)   # address, lon, lat
    errorOccurred = pyqtSignal(str, str)          # address, error message

    def __init__(self, api_key, parent=None):
        super().__init__(parent)
        self.api_key = api_key
        self.manager = QNetworkAccessManager(self)

    def geocode(self, address):
        encoded = urllib.parse.quote(address)
        url = (
            f"https://api.maptiler.com/geocoding/{encoded}.json"
            f"?key={self.api_key}"
        )

        request = QNetworkRequest(QUrl(url))
        reply = self.manager.get(request)
        # Bind reply/address per invocation so the slot always sees the matching QNetworkReply
        # (and avoid callbacks after the loop variable would otherwise drift).
        reply.finished.connect(lambda r=reply, a=address: self._handleReply(a, r))

    def _handleReply(self, address, reply):
        if reply.error():
            self.errorOccurred.emit(address, reply.errorString())
            reply.deleteLater()
            return

        data = reply.readAll().data()
        reply.deleteLater()

        try:
            js = json.loads(data)
            features = js.get("features", [])
            if not features:
                self.errorOccurred.emit(address, "No results found")
                return

            # MapTiler returns [lon, lat]
            lon, lat = features[0]["center"]
            self.resultReady.emit(address, lon, lat)

        except Exception as e:
            self.errorOccurred.emit(address, str(e))
