.pragma library

function wrapLon(lon) {
    var t = lon
    while (t > 180.0)
        t -= 360.0
    while (t < -180.0)
        t += 360.0
    return t
}

/**
 * Split a closed lon/lat ring when consecutive vertices jump more than ±180°
 * relative to centerLon (use 0 for antimeridian in dataset space).
 * Mirrors the logic in globe_view_scene3d.qml _splitPolyByViewSeam.
 */
function splitPolyAtLonSeam(poly, centerLon) {
    if (!poly || poly.length < 3)
        return []

    var seamSplitDeg = 180.0
    var parts = []
    var cur = [[poly[0][0], poly[0][1]]]

    function pushPartIfValid(p) {
        if (p && p.length >= 3)
            parts.push(p)
    }

    for (var i = 1; i <= poly.length; i++) {
        var a = poly[(i - 1) % poly.length]
        var b = poly[i % poly.length]

        var aLon = a[0]
        var aLat = a[1]
        var bLon = b[0]
        var bLat = b[1]

        var aRel = wrapLon(aLon - centerLon)
        var bRel = wrapLon(bLon - centerLon)
        var d = bRel - aRel
        if (d > seamSplitDeg || d < -seamSplitDeg) {
            var seamRel = d > 0.0 ? -180.0 : 180.0
            var bAdj = bRel + (d > 0.0 ? -360.0 : 360.0)
            var denom = bAdj - aRel
            if (Math.abs(denom) < 0.000001)
                denom = denom >= 0 ? 0.000001 : -0.000001
            var t = (seamRel - aRel) / denom
            t = Math.max(0.0, Math.min(1.0, t))
            var seamLat = aLat + (bLat - aLat) * t
            var seamLonA = wrapLon(seamRel + centerLon)
            var seamLonB = wrapLon((seamRel > 0.0 ? -180.0 : 180.0) + centerLon)
            cur.push([seamLonA, seamLat])
            pushPartIfValid(cur)
            cur = [[seamLonB, seamLat]]
            if (i < poly.length)
                cur.push([bLon, bLat])
        } else if (i < poly.length) {
            cur.push([bLon, bLat])
        }
    }

    pushPartIfValid(cur)
    if (parts.length === 0)
        return [poly]
    return parts
}

function validateRing(poly) {
    var msgs = []
    if (!poly || poly.length < 3) {
        msgs.push("fewer_than_3_points")
        return msgs
    }
    var dupAdjacent = false
    var bigJump = 0
    var minLon = Infinity
    var maxLon = -Infinity
    var minLat = Infinity
    var maxLat = -Infinity
    for (var i = 0; i < poly.length; i++) {
        var lon = poly[i][0]
        var lat = poly[i][1]
        if (typeof lon !== "number" || typeof lat !== "number" ||
                !isFinite(lon) || !isFinite(lat)) {
            msgs.push("non_numeric_or_non_finite")
            return msgs
        }
        if (lat < -90.0 || lat > 90.0)
            msgs.push("lat_out_of_range")
        var j = i + 1
        if (j === poly.length)
            j = 0
        var lonN = poly[j][0]
        var latN = poly[j][1]
        var dLon = wrapLon(lonN - lon)
        if (Math.abs(dLon) > 179.98)
            bigJump++

        minLon = Math.min(minLon, lon)
        maxLon = Math.max(maxLon, lon)
        minLat = Math.min(minLat, lat)
        maxLat = Math.max(maxLat, lat)

        if (lonN === lon && latN === lat)
            dupAdjacent = true
    }

    var lonSpanNaive = maxLon - minLon
    // Indexing polygons by minLon/maxLon is wrong when a ring crosses the ±180 seam.
    if (lonSpanNaive >= 359.995)
        msgs.push("degenerate_lon_span_full")
    else if (lonSpanNaive > 180.001)
        msgs.push("naive_lon_span_antimeridian_suspect")
    else if (bigJump > 0)
        msgs.push("edge_lon_jump_near_360")

    if (dupAdjacent)
        msgs.push("duplicate_consecutive_points")

    return msgs
}

/**
 * Expand polygon entries split at Greenwich-relative seam (centerLon=0).
 */
function preprocessWorldPolyData(entries) {
    var out = []
    if (!entries)
        return out
    for (var ei = 0; ei < entries.length; ei++) {
        var e = entries[ei]
        if (!e || !e.p)
            continue
        var parts = splitPolyAtLonSeam(e.p, 0.0)
        for (var pi = 0; pi < parts.length; pi++) {
            out.push({
                "c": e.c,
                "p": parts[pi]
            })
        }
    }
    return out
}

/**
 * Full scan for console inspection; inexpensive vs paint (runs once).
 */
function validateWorldPolyData(entries, maxIssues) {
    var cap = maxIssues || 80
    var issues = []
    var stats = {
        count: 0,
        antimeridianSuspect: 0,
        edgeJump: 0,
        badLat: 0,
        shortRing: 0
    }
    if (!entries)
        return { "issues": issues, "stats": stats }

    for (var i = 0; i < entries.length; i++) {
        var e = entries[i]
        stats.count++
        if (!e || !e.p) {
            stats.shortRing++
            if (issues.length < cap)
                issues.push({ "i": i, "c": e ? e.c : null, "msgs": ["missing_p"] })
            continue
        }
        var msgs = validateRing(e.p)
        if (msgs.length === 0)
            continue
        if (msgs.indexOf("naive_lon_span_antimeridian_suspect") >= 0)
            stats.antimeridianSuspect++
        if (msgs.indexOf("edge_lon_jump_near_360") >= 0)
            stats.edgeJump++
        if (msgs.indexOf("lat_out_of_range") >= 0)
            stats.badLat++
        if (msgs.indexOf("fewer_than_3_points") >= 0)
            stats.shortRing++

        if (issues.length < cap) {
            var minLon = 9999
            var maxLon = -9999
            for (var j = 0; j < e.p.length; j++) {
                var lon = e.p[j][0]
                if (lon < minLon)
                    minLon = lon
                if (lon > maxLon)
                    maxLon = lon
            }
            issues.push({
                "i": i,
                "c": e.c,
                "n": e.p.length,
                "minLon": minLon,
                "maxLon": maxLon,
                "lonSpanNaive": maxLon - minLon,
                "msgs": msgs
            })
        }
    }
    return { "issues": issues, "stats": stats }
}
