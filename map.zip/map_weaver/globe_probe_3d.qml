import QtQuick 2.15
import QtQuick3D 1.15

Rectangle {
    width: 64
    height: 64
    color: "transparent"

    View3D {
        anchors.fill: parent
        camera: cam
        environment: SceneEnvironment {
            clearColor: "#ffffff"
            backgroundMode: SceneEnvironment.Color
        }
        PerspectiveCamera { id: cam; z: 200 }
        DirectionalLight { brightness: 20 }
        Model {
            source: "#Cube"
            scale: Qt.vector3d(22, 22, 22)
            eulerRotation: Qt.vector3d(20, 35, 0)
            materials: DefaultMaterial {
                diffuseColor: "#4f95d8"
                lighting: DefaultMaterial.NoLighting
            }
        }
    }

    Text {
        text: "3D probe"
        color: "#a24146"
        anchors.left: parent.left
        anchors.top: parent.top
        anchors.leftMargin: 4
        anchors.topMargin: 2
        font.pixelSize: 10
        z: 20
    }
}
