"""Route Connections logic (embedded from route_connections plugin)."""

import math

from qgis.PyQt.QtCore import QVariant
from qgis.core import QgsFeature, QgsField, QgsGeometry, QgsPointXY, QgsProject, QgsVectorLayer, QgsWkbTypes

from .edit_curve_tool import EditCurveMapTool
from .route_connections_dialog import RouteConnectionsDialog
from .route_connections_sync import sync_route_arcs_without_close


class RouteConnectionsController:
    """Coordinates dialog, arc layer, and curve editing (no menu/toolbar)."""

    def __init__(self, iface):
        self.iface = iface
        self.dialog = None
        self.edit_curve_tool = None

    def run(self):
        if self.dialog is None:
            self.dialog = RouteConnectionsDialog(self)
            self.dialog.mApplyButton.setText("Apply")
            self.dialog.mApplyButton.clicked.connect(self.sync_arcs)
            self.edit_curve_tool = EditCurveMapTool(
                self.iface.mapCanvas(), self, self.dialog
            )

        self.dialog.populate_layers()
        self.dialog.show()

    def get_arc_layer(self, source):
        from qgis.core import QgsVectorLayer

        from .route_arcs_layer import (
            create_route_arcs_layer,
            find_route_arcs_layer_for_crs,
            get_or_create_route_arcs_for_point_layer,
        )

        if isinstance(source, QgsVectorLayer):
            return get_or_create_route_arcs_for_point_layer(source)
        dlg = getattr(self, "dialog", None)
        current = getattr(dlg, "current_layer", None) if dlg is not None else None
        if current is not None:
            return get_or_create_route_arcs_for_point_layer(current)
        lyr = find_route_arcs_layer_for_crs(source)
        if lyr is not None:
            return lyr
        return create_route_arcs_layer(source, project=QgsProject.instance())

    def sync_arcs(self):
        sync_route_arcs_without_close(self)

    def draw_single_arc(self, start_fid, end_fid, start_text, end_text, conn_id, source_layer, arc_layer):
        start_feat = source_layer.getFeature(start_fid)
        end_feat = source_layer.getFeature(end_fid)

        if not start_feat.isValid() or not end_feat.isValid():
            return

        p1 = start_feat.geometry().asPoint()
        p2 = end_feat.geometry().asPoint()

        obstacle_points = []
        for feat in source_layer.getFeatures():
            if feat.id() not in (start_fid, end_fid):
                geom = feat.geometry()
                if geom and geom.type() == QgsWkbTypes.PointGeometry:
                    obstacle_points.append(geom.asPoint())

        arc_points = self.get_best_bezier_curve(p1, p2, obstacle_points, tolerance=0.5)

        line_geom = QgsGeometry.fromPolylineXY(arc_points)
        new_feat = QgsFeature()
        new_feat.setGeometry(line_geom)

        new_feat.setFields(arc_layer.fields())
        new_feat.setAttribute("Start", start_text)
        new_feat.setAttribute("End", end_text)
        new_feat.setAttribute("ConnID", conn_id)

        arc_layer.addFeature(new_feat)

    def get_best_bezier_curve(self, p1, p2, obstacle_points, tolerance=0.5):
        curvatures = [0.3, -0.3, 0.5, -0.5, 0.7, -0.7, 0.9, -0.9, 0.1, -0.1]

        best_points = None
        best_collisions = float("inf")

        for curvature in curvatures:
            points = self.get_bezier_curve(p1, p2, curvature=curvature)
            line_geom = QgsGeometry.fromPolylineXY(points)

            collisions = 0
            for pt in obstacle_points:
                pt_geom = QgsGeometry.fromPointXY(pt)
                if line_geom.distance(pt_geom) < tolerance:
                    collisions += 1

            if collisions == 0:
                return points

            if collisions < best_collisions:
                best_collisions = collisions
                best_points = points

        return best_points

    def get_bezier_curve(self, p1, p2, segments=50, curvature=0.3):
        x1, y1 = p1.x(), p1.y()
        x2, y2 = p2.x(), p2.y()

        mx, my = (x1 + x2) / 2.0, (y1 + y2) / 2.0

        dx, dy = x2 - x1, y2 - y1

        dist = math.hypot(dx, dy)

        nx, ny = -dy, dx

        if dist > 0:
            nx, ny = nx / dist, ny / dist

        cx = mx + nx * dist * curvature
        cy = my + ny * dist * curvature

        points = []
        for i in range(segments + 1):
            t = i / float(segments)
            x = ((1 - t) ** 2) * x1 + 2 * (1 - t) * t * cx + (t ** 2) * x2
            y = ((1 - t) ** 2) * y1 + 2 * (1 - t) * t * cy + (t ** 2) * y2
            points.append(QgsPointXY(x, y))

        return points
