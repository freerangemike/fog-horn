# -*- coding: utf-8 -*-
"""Point-layer radius buffers via geometry-generator symbology (Method 2)."""

from __future__ import annotations

import os

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsGeometryGeneratorSymbolLayer,
    QgsProject,
    QgsSingleSymbolRenderer,
    QgsSymbol,
    QgsUnitTypes,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.PyQt import sip

from qgis.PyQt.QtGui import QColor

POINT_BUFFER_LAYER_PROP = "map_weaver/is_point_buffer_layer"
POINT_BUFFER_RADIUS_PROP = "map_weaver/point_buffer_radius"
POINT_BUFFER_UNITS_PROP = "map_weaver/point_buffer_units"
POINT_BUFFER_SEGMENTS_PROP = "map_weaver/point_buffer_segments"
POINT_BUFFER_TRANSPARENCY_PROP = "map_weaver/point_buffer_transparency"
POINT_BUFFER_FILL_COLOR_PROP = "map_weaver/point_buffer_fill_color"
POINT_BUFFER_OUTLINE_COLOR_PROP = "map_weaver/point_buffer_outline_color"

DEFAULT_BUFFER_SEGMENTS = 24
DEFAULT_BUFFER_UNITS = "miles"
DEFAULT_BUFFER_RADIUS_MILES = 100.0
DEFAULT_BUFFER_TRANSPARENCY = 60
DEFAULT_BUFFER_FILL_COLOR = QColor(255, 190, 190)
DEFAULT_BUFFER_OUTLINE_COLOR = QColor(170, 70, 70)

METERS_PER_FOOT = 0.3048
METERS_PER_MILE = 1609.344
METERS_PER_KILOMETER = 1000.0

UNIT_CHOICES = (
    ("feet", QgsUnitTypes.DistanceFeet),
    ("meters", QgsUnitTypes.DistanceMeters),
    ("kilometers", QgsUnitTypes.DistanceKilometers),
    ("miles", QgsUnitTypes.DistanceMiles),
)


def _unit_key_to_qgis(unit_key: str):
    key = str(unit_key or DEFAULT_BUFFER_UNITS).strip().lower()
    for name, qgis_unit in UNIT_CHOICES:
        if name == key:
            return qgis_unit
    return QgsUnitTypes.DistanceMeters


def unit_labels_for_combo():
    return [label for label, _ in UNIT_CHOICES]


def unit_key_from_combo_index(index: int) -> str:
    idx = max(0, int(index))
    if idx < len(UNIT_CHOICES):
        return UNIT_CHOICES[idx][0]
    return DEFAULT_BUFFER_UNITS


def combo_index_for_unit_key(unit_key: str) -> int:
    key = str(unit_key or DEFAULT_BUFFER_UNITS).strip().lower()
    for i, (name, _) in enumerate(UNIT_CHOICES):
        if name == key:
            return i
    return combo_index_for_unit_key(DEFAULT_BUFFER_UNITS)


def default_radius_for_units(unit_key: str) -> float:
    """Default radius value shown in the dialog for the given unit (100 miles base)."""
    key = str(unit_key or DEFAULT_BUFFER_UNITS).strip().lower()
    miles = DEFAULT_BUFFER_RADIUS_MILES
    if key == "miles":
        return miles
    if key == "feet":
        return miles * 5280.0
    if key == "meters":
        return miles * METERS_PER_MILE
    if key == "kilometers":
        return miles * (METERS_PER_MILE / METERS_PER_KILOMETER)
    return miles


def _radius_input_to_meters(value: float, unit_key: str) -> float:
    key = str(unit_key or DEFAULT_BUFFER_UNITS).strip().lower()
    if key == "meters":
        return float(value)
    if key == "feet":
        return float(value) * METERS_PER_FOOT
    if key == "miles":
        return float(value) * METERS_PER_MILE
    if key == "kilometers":
        return float(value) * METERS_PER_KILOMETER
    return float(value)


def _meters_to_radius_display(value_m: float, unit_key: str) -> float:
    key = str(unit_key or DEFAULT_BUFFER_UNITS).strip().lower()
    if key == "meters":
        return float(value_m)
    if key == "feet":
        return float(value_m) / METERS_PER_FOOT
    if key == "miles":
        return float(value_m) / METERS_PER_MILE
    if key == "kilometers":
        return float(value_m) / METERS_PER_KILOMETER
    return float(value_m)


def _meters_to_crs_map_units(value_m: float, crs) -> tuple[float | None, str | None]:
    if crs is None or not crs.isValid():
        return None, "Layer CRS is not valid."
    unit = crs.mapUnits()
    if unit == QgsUnitTypes.DistanceMeters:
        return float(value_m), None
    if unit == QgsUnitTypes.DistanceFeet:
        return float(value_m) / METERS_PER_FOOT, None
    if unit == QgsUnitTypes.DistanceKilometers:
        return float(value_m) / METERS_PER_KILOMETER, None
    if unit == QgsUnitTypes.DistanceMiles:
        return float(value_m) / METERS_PER_MILE, None
    if unit == QgsUnitTypes.DistanceDegrees:
        return None, "Layer uses a geographic CRS (degrees)."
    try:
        return (
            float(
                QgsUnitTypes.convertDistance(
                    float(value_m),
                    QgsUnitTypes.DistanceMeters,
                    unit,
                )
            ),
            None,
        )
    except Exception:
        return None, "Could not convert radius to the layer CRS units."


def _crs_map_units_to_meters(value_map: float, crs) -> float:
    if crs is None or not crs.isValid():
        return float(value_map)
    unit = crs.mapUnits()
    if unit == QgsUnitTypes.DistanceMeters:
        return float(value_map)
    if unit == QgsUnitTypes.DistanceFeet:
        return float(value_map) * METERS_PER_FOOT
    if unit == QgsUnitTypes.DistanceKilometers:
        return float(value_map) * METERS_PER_KILOMETER
    if unit == QgsUnitTypes.DistanceMiles:
        return float(value_map) * METERS_PER_MILE
    try:
        return float(
            QgsUnitTypes.convertDistance(
                float(value_map),
                unit,
                QgsUnitTypes.DistanceMeters,
            )
        )
    except Exception:
        return float(value_map)


def has_point_buffer_tag(lyr: QgsVectorLayer) -> bool:
    if lyr is None:
        return False
    try:
        if sip.isdeleted(lyr):
            return False
    except Exception:
        return False
    try:
        return (
            str(lyr.customProperty(POINT_BUFFER_LAYER_PROP, "") or "").strip() == "1"
        )
    except Exception:
        return False


def is_point_buffer_layer(lyr: QgsVectorLayer) -> bool:
    if not has_point_buffer_tag(lyr):
        return False
    try:
        if lyr.geometryType() != QgsWkbTypes.PointGeometry:
            return False
    except Exception:
        return False
    return True


def mark_point_buffer_layer(
    lyr: QgsVectorLayer,
    radius_map_units: float,
    display_units: str = DEFAULT_BUFFER_UNITS,
    segments: int = DEFAULT_BUFFER_SEGMENTS,
    transparency_pct: float = DEFAULT_BUFFER_TRANSPARENCY,
    fill_color: QColor | None = None,
    outline_color: QColor | None = None,
) -> None:
    if lyr is None:
        return
    fc = fill_color if fill_color is not None else DEFAULT_BUFFER_FILL_COLOR
    oc = outline_color if outline_color is not None else DEFAULT_BUFFER_OUTLINE_COLOR
    try:
        lyr.setCustomProperty(POINT_BUFFER_LAYER_PROP, "1")
        lyr.setCustomProperty(POINT_BUFFER_RADIUS_PROP, str(float(radius_map_units)))
        lyr.setCustomProperty(POINT_BUFFER_UNITS_PROP, str(display_units or DEFAULT_BUFFER_UNITS))
        lyr.setCustomProperty(POINT_BUFFER_SEGMENTS_PROP, str(int(segments)))
        lyr.setCustomProperty(POINT_BUFFER_TRANSPARENCY_PROP, str(float(transparency_pct)))
        lyr.setCustomProperty(POINT_BUFFER_FILL_COLOR_PROP, _serialize_color_rgb(fc))
        lyr.setCustomProperty(POINT_BUFFER_OUTLINE_COLOR_PROP, _serialize_color_rgb(oc))
    except Exception:
        pass


def clear_point_buffer_tags(lyr: QgsVectorLayer) -> None:
    if lyr is None:
        return
    for key in (
        POINT_BUFFER_LAYER_PROP,
        POINT_BUFFER_RADIUS_PROP,
        POINT_BUFFER_UNITS_PROP,
        POINT_BUFFER_SEGMENTS_PROP,
        POINT_BUFFER_TRANSPARENCY_PROP,
        POINT_BUFFER_FILL_COLOR_PROP,
        POINT_BUFFER_OUTLINE_COLOR_PROP,
    ):
        try:
            lyr.removeCustomProperty(key)
        except Exception:
            pass


def point_buffer_radius_map_units(lyr: QgsVectorLayer) -> float | None:
    if not is_point_buffer_layer(lyr):
        return None
    try:
        return float(str(lyr.customProperty(POINT_BUFFER_RADIUS_PROP, "") or "").strip())
    except (TypeError, ValueError):
        return None


def point_buffer_display_units(lyr: QgsVectorLayer) -> str:
    if lyr is None:
        return DEFAULT_BUFFER_UNITS
    try:
        raw = str(lyr.customProperty(POINT_BUFFER_UNITS_PROP, "") or "").strip().lower()
    except Exception:
        raw = ""
    return raw or DEFAULT_BUFFER_UNITS


def point_buffer_segments(lyr: QgsVectorLayer) -> int:
    if lyr is None:
        return DEFAULT_BUFFER_SEGMENTS
    try:
        return int(str(lyr.customProperty(POINT_BUFFER_SEGMENTS_PROP, "") or "").strip())
    except (TypeError, ValueError):
        return DEFAULT_BUFFER_SEGMENTS


def point_buffer_transparency(lyr: QgsVectorLayer) -> float:
    if lyr is None:
        return DEFAULT_BUFFER_TRANSPARENCY
    try:
        return float(
            str(lyr.customProperty(POINT_BUFFER_TRANSPARENCY_PROP, "") or "").strip()
        )
    except (TypeError, ValueError):
        return DEFAULT_BUFFER_TRANSPARENCY


def _serialize_color_rgb(color: QColor) -> str:
    return "{},{},{}".format(color.red(), color.green(), color.blue())


def _deserialize_color_rgb(raw, default: QColor) -> QColor:
    try:
        parts = [int(p.strip()) for p in str(raw or "").split(",")]
    except (TypeError, ValueError):
        return QColor(default)
    if len(parts) != 3:
        return QColor(default)
    return QColor(
        max(0, min(255, parts[0])),
        max(0, min(255, parts[1])),
        max(0, min(255, parts[2])),
    )


def point_buffer_fill_color(lyr: QgsVectorLayer) -> QColor:
    if lyr is None:
        return QColor(DEFAULT_BUFFER_FILL_COLOR)
    try:
        raw = lyr.customProperty(POINT_BUFFER_FILL_COLOR_PROP, "")
    except Exception:
        raw = ""
    return _deserialize_color_rgb(raw, DEFAULT_BUFFER_FILL_COLOR)


def point_buffer_outline_color(lyr: QgsVectorLayer) -> QColor:
    if lyr is None:
        return QColor(DEFAULT_BUFFER_OUTLINE_COLOR)
    try:
        raw = lyr.customProperty(POINT_BUFFER_OUTLINE_COLOR_PROP, "")
    except Exception:
        raw = ""
    return _deserialize_color_rgb(raw, DEFAULT_BUFFER_OUTLINE_COLOR)


def _mark_project_dirty() -> None:
    try:
        QgsProject.instance().setDirty(True)
    except Exception:
        pass


def _alpha_from_transparency(transparency_pct: float) -> int:
    """PowerPoint-style: 0% = opaque, 100% = fully transparent."""
    try:
        pct = float(transparency_pct)
    except (TypeError, ValueError):
        pct = DEFAULT_BUFFER_TRANSPARENCY
    pct = max(0.0, min(100.0, pct))
    return int(round(255.0 * (1.0 - (pct / 100.0))))


def _style_buffer_colors(
    fill_sym,
    fill_color: QColor,
    outline_color: QColor,
    transparency_pct: float,
) -> None:
    if fill_sym is None:
        return
    alpha = _alpha_from_transparency(transparency_pct)
    fc = QColor(fill_color)
    fc.setAlpha(alpha)
    oc = QColor(outline_color)
    oc.setAlpha(alpha)
    try:
        for i in range(fill_sym.symbolLayerCount()):
            sl = fill_sym.symbolLayer(i)
            if sl is None:
                continue
            try:
                sl.setColor(fc)
            except Exception:
                pass
            if hasattr(sl, "strokeColor"):
                try:
                    sl.setStrokeColor(oc)
                except Exception:
                    pass
    except Exception:
        pass


def _style_buffer_fill(fill_sym, transparency_pct: float) -> None:
    _style_buffer_colors(
        fill_sym,
        DEFAULT_BUFFER_FILL_COLOR,
        DEFAULT_BUFFER_OUTLINE_COLOR,
        transparency_pct,
    )


def crs_allows_metric_buffer(lyr: QgsVectorLayer) -> tuple[bool, str]:
    if lyr is None:
        return False, "No layer."
    crs = lyr.crs()
    if crs is None or not crs.isValid():
        return False, "Layer CRS is not valid."
    try:
        if crs.isGeographic():
            return (
                False,
                "Layer uses a geographic CRS (degrees). Reproject the layer or project to meters/feet before buffering.",
            )
    except Exception:
        pass
    return True, ""


def convert_radius_to_map_units(
    radius: float, unit_key: str, lyr: QgsVectorLayer
) -> tuple[float | None, str | None]:
    ok, msg = crs_allows_metric_buffer(lyr)
    if not ok:
        return None, msg
    try:
        value = float(radius)
    except (TypeError, ValueError):
        return None, "Enter a valid radius."
    if value <= 0:
        return None, "Radius must be greater than zero."
    meters = _radius_input_to_meters(value, unit_key)
    return _meters_to_crs_map_units(meters, lyr.crs())


def convert_map_units_to_display(
    radius_map_units: float, unit_key: str, lyr: QgsVectorLayer
) -> float:
    meters = _crs_map_units_to_meters(float(radius_map_units), lyr.crs() if lyr else None)
    return _meters_to_radius_display(meters, unit_key)


def list_point_buffer_layers(project=None) -> list[QgsVectorLayer]:
    project = project or QgsProject.instance()
    out = []
    try:
        layers = list(project.mapLayers().values())
    except Exception:
        return out
    for lyr in layers:
        if is_point_buffer_layer(lyr):
            out.append(lyr)
    out.sort(key=lambda layer: layer.name().lower())
    return out


def project_has_point_buffer_layer(project=None) -> bool:
    return bool(list_point_buffer_layers(project))


def list_project_point_layers(project=None) -> list[QgsVectorLayer]:
    project = project or QgsProject.instance()
    out = []
    try:
        layers = list(project.mapLayers().values())
    except Exception:
        return out
    for lyr in layers:
        if lyr is None:
            continue
        try:
            if sip.isdeleted(lyr):
                continue
        except Exception:
            continue
        if not isinstance(lyr, QgsVectorLayer):
            continue
        try:
            if lyr.geometryType() != QgsWkbTypes.PointGeometry:
                continue
        except Exception:
            continue
        out.append(lyr)
    out.sort(key=lambda layer: layer.name().lower())
    return out


def _buffer_expression(radius_map_units: float, segments: int) -> str:
    return "buffer($geometry, {}, {})".format(
        repr(float(radius_map_units)),
        int(segments),
    )


def _make_buffer_generator_layer(
    radius_map_units: float,
    segments: int,
    transparency_pct: float,
    fill_color: QColor | None = None,
    outline_color: QColor | None = None,
):
    expr = _buffer_expression(radius_map_units, segments)
    gen = None
    try:
        gen = QgsGeometryGeneratorSymbolLayer.create({"geometryModifier": expr})
    except Exception:
        gen = QgsGeometryGeneratorSymbolLayer()
    if gen is None:
        gen = QgsGeometryGeneratorSymbolLayer()
    try:
        gen.setGeometryExpression(expr)
    except Exception:
        pass
    try:
        gen.setSymbolType(QgsSymbol.Fill)
    except Exception:
        try:
            from qgis.core import Qgis

            gen.setSymbolType(Qgis.SymbolType.Fill)
        except Exception:
            pass
    try:
        from qgis.core import QgsFillSymbol

        fc = fill_color if fill_color is not None else DEFAULT_BUFFER_FILL_COLOR
        oc = outline_color if outline_color is not None else DEFAULT_BUFFER_OUTLINE_COLOR
        alpha = _alpha_from_transparency(transparency_pct)
        fill = QgsFillSymbol.createSimple(
            {
                "color": "{},{},{}".format(fc.red(), fc.green(), fc.blue()),
                "outline_color": "{},{},{}".format(oc.red(), oc.green(), oc.blue()),
                "outline_width": "0.26",
            }
        )
        _style_buffer_colors(fill, fc, oc, transparency_pct)
        gen.setSubSymbol(fill)
    except Exception:
        pass
    return gen


def _find_buffer_generator(symbol):
    if symbol is None:
        return None, None
    for i in range(symbol.symbolLayerCount()):
        sl = symbol.symbolLayer(i)
        if not isinstance(sl, QgsGeometryGeneratorSymbolLayer):
            continue
        try:
            expr = (sl.geometryExpression() or "").replace(" ", "")
        except Exception:
            expr = ""
        if "buffer($geometry" in expr:
            return i, sl
    return None, None


def _editable_symbol(lyr: QgsVectorLayer):
    try:
        renderer = lyr.renderer()
    except Exception:
        renderer = None
    if isinstance(renderer, QgsSingleSymbolRenderer):
        sym = renderer.symbol()
        return sym.clone() if sym is not None else QgsSymbol.defaultSymbol(lyr.geometryType())
    return QgsSymbol.defaultSymbol(lyr.geometryType())


def apply_point_buffer(
    lyr: QgsVectorLayer,
    radius: float,
    unit_key: str = DEFAULT_BUFFER_UNITS,
    segments: int = DEFAULT_BUFFER_SEGMENTS,
    transparency_pct: float = DEFAULT_BUFFER_TRANSPARENCY,
    fill_color: QColor | None = None,
    outline_color: QColor | None = None,
) -> tuple[bool, str | None]:
    if lyr is None:
        return False, "No layer selected."
    radius_map, err = convert_radius_to_map_units(radius, unit_key, lyr)
    if err or radius_map is None:
        return False, err or "Could not convert radius."
    fc = fill_color if fill_color is not None else DEFAULT_BUFFER_FILL_COLOR
    oc = outline_color if outline_color is not None else DEFAULT_BUFFER_OUTLINE_COLOR
    sym = _editable_symbol(lyr)
    if sym is None:
        return False, "Could not read layer symbology."
    _idx, existing = _find_buffer_generator(sym)
    if existing is None:
        sym.insertSymbolLayer(
            0,
            _make_buffer_generator_layer(
                radius_map, segments, transparency_pct, fill_color=fc, outline_color=oc
            ),
        )
    else:
        try:
            existing.setGeometryExpression(_buffer_expression(radius_map, segments))
            sub = existing.subSymbol()
            if sub is not None:
                _style_buffer_colors(sub, fc, oc, transparency_pct)
        except Exception:
            return False, "Could not update buffer symbology."
    try:
        lyr.setRenderer(QgsSingleSymbolRenderer(sym))
    except Exception:
        return False, "Could not apply symbology to the layer."
    mark_point_buffer_layer(
        lyr,
        radius_map,
        unit_key,
        segments,
        transparency_pct=transparency_pct,
        fill_color=fc,
        outline_color=oc,
    )
    _mark_project_dirty()
    try:
        lyr.triggerRepaint()
    except Exception:
        pass
    return True, None


def set_point_buffer_radius(
    lyr: QgsVectorLayer,
    radius: float,
    unit_key: str | None = None,
    segments: int | None = None,
    transparency_pct: float | None = None,
    fill_color: QColor | None = None,
    outline_color: QColor | None = None,
) -> tuple[bool, str | None]:
    if not is_point_buffer_layer(lyr):
        return False, "Layer is not a Radius Buffer layer."
    units = unit_key or point_buffer_display_units(lyr)
    segs = segments if segments is not None else point_buffer_segments(lyr)
    alpha = (
        transparency_pct
        if transparency_pct is not None
        else point_buffer_transparency(lyr)
    )
    fc = fill_color if fill_color is not None else point_buffer_fill_color(lyr)
    oc = outline_color if outline_color is not None else point_buffer_outline_color(lyr)
    return apply_point_buffer(
        lyr,
        radius,
        units,
        segs,
        transparency_pct=alpha,
        fill_color=fc,
        outline_color=oc,
    )


def remove_point_buffer(lyr: QgsVectorLayer) -> bool:
    if lyr is None or not has_point_buffer_tag(lyr):
        return False
    try:
        renderer = lyr.renderer()
    except Exception:
        renderer = None
    if not isinstance(renderer, QgsSingleSymbolRenderer):
        clear_point_buffer_tags(lyr)
        _mark_project_dirty()
        return True
    sym = renderer.symbol()
    if sym is None:
        clear_point_buffer_tags(lyr)
        _mark_project_dirty()
        return True
    sym = sym.clone()
    remove_indices = []
    for i in range(sym.symbolLayerCount()):
        sl = sym.symbolLayer(i)
        if not isinstance(sl, QgsGeometryGeneratorSymbolLayer):
            continue
        try:
            expr = (sl.geometryExpression() or "").replace(" ", "")
        except Exception:
            expr = ""
        if "buffer($geometry" in expr:
            remove_indices.append(i)
    for i in reversed(remove_indices):
        sym.deleteSymbolLayer(i)
    try:
        lyr.setRenderer(QgsSingleSymbolRenderer(sym))
    except Exception:
        pass
    clear_point_buffer_tags(lyr)
    _mark_project_dirty()
    try:
        lyr.triggerRepaint()
    except Exception:
        pass
    return True


def suggest_projected_crs_for_layer(lyr: QgsVectorLayer) -> QgsCoordinateReferenceSystem:
    """Suggest a metric CRS (UTM from layer extent centroid) for buffering."""
    fallback = QgsCoordinateReferenceSystem("EPSG:3857")
    if lyr is None:
        return fallback
    try:
        extent = lyr.extent()
    except Exception:
        return fallback
    if extent is None or extent.isEmpty():
        return fallback
    center = extent.center()
    try:
        src = lyr.crs()
    except Exception:
        src = None
    wgs = QgsCoordinateReferenceSystem("EPSG:4326")
    if src is not None and src.isValid() and src != wgs:
        try:
            if (src.authid() or "").strip().upper() != "EPSG:4326":
                xform = QgsCoordinateTransform(src, wgs, QgsProject.instance())
                center = xform.transform(center)
        except Exception:
            pass
    try:
        lon = float(center.x())
        lat = float(center.y())
    except Exception:
        return fallback
    if not (-180.0 <= lon <= 180.0) or not (-90.0 <= lat <= 90.0):
        return fallback
    zone = int((lon + 180.0) // 6.0) + 1
    zone = max(1, min(60, zone))
    epsg = (32600 if lat >= 0 else 32700) + zone
    crs = QgsCoordinateReferenceSystem("EPSG:{}".format(epsg))
    return crs if crs.isValid() else fallback


def _vector_writer_error_code(err):
    """Normalize writeAsVectorFormat(V3) error return across QGIS versions."""
    if isinstance(err, (tuple, list)):
        return err[0] if err else QgsVectorFileWriter.NoError
    return err


def _vector_writer_succeeded(err) -> bool:
    try:
        return _vector_writer_error_code(err) == QgsVectorFileWriter.NoError
    except Exception:
        return False


def reproject_point_layer_to_gpkg(
    lyr: QgsVectorLayer,
    dest_crs: QgsCoordinateReferenceSystem,
    gpkg_path: str,
    display_name: str | None = None,
) -> tuple[QgsVectorLayer | None, str | None]:
    """
    Write ``lyr`` to a new GeoPackage in ``dest_crs`` and return a loaded OGR layer.

    Does not add the layer to the project. Returns (layer, None) on success or
    (None, error_message) on failure.
    """
    if lyr is None:
        return None, "No layer selected."
    try:
        if sip.isdeleted(lyr):
            return None, "Layer is no longer available."
    except Exception:
        pass
    if dest_crs is None or not dest_crs.isValid():
        return None, "Choose a valid projected CRS."
    try:
        if dest_crs.isGeographic():
            return None, "Destination CRS must be projected (meters/feet), not geographic."
    except Exception:
        pass
    if not gpkg_path:
        return None, "Missing output path."
    parent = os.path.dirname(gpkg_path)
    if parent:
        try:
            os.makedirs(parent, exist_ok=True)
        except OSError as exc:
            return None, "Could not create folder: {}".format(exc)

    layer_title = (display_name or "").strip() or (lyr.name() or "points")
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = "points"
    options.ct = QgsCoordinateTransform(
        lyr.crs(), dest_crs, QgsProject.instance().transformContext()
    )
    options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
    try:
        err, _warnings, _path, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
            lyr, gpkg_path, QgsProject.instance().transformContext(), options
        )
        if not _vector_writer_succeeded(err):
            return None, "Could not write GeoPackage (error {}).".format(
                _vector_writer_error_code(err)
            )
    except Exception as exc:
        return None, "Could not write GeoPackage: {}".format(exc)

    if not os.path.isfile(gpkg_path):
        return None, "GeoPackage was not created."

    uri = "{}|layername=points".format(gpkg_path)
    out = QgsVectorLayer(uri, layer_title, "ogr")
    if not out.isValid():
        out = QgsVectorLayer(gpkg_path, layer_title, "ogr")
    if not out.isValid():
        return None, "GeoPackage written but could not be loaded."
    return out, None
