# -*- coding: utf-8 -*-
"""Browse temp geocode GeoPackages and optionally add one to the map."""

from __future__ import annotations

import os

from qgis.PyQt import uic
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QDialog, QListWidgetItem, QMessageBox

from .geocode_layer import (
    add_temp_geocode_gpkg_to_map,
    list_all_temp_geocode_gpkgs,
    map_layer_for_gpkg_path,
    read_geocode_gpkg_address_lines,
)

FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "temp_geocode_layers.ui")
)

GPKG_PATH_ROLE = Qt.UserRole


class TempGeocodeLayersDialog(QDialog):
    """List all temp GPKG sidecars; preview addresses; add selected layer to the map."""

    def __init__(self, parent=None, on_layer_added=None):
        super().__init__(parent)
        self._on_layer_added = on_layer_added
        uic.loadUi(
            os.path.join(os.path.dirname(__file__), "temp_geocode_layers.ui"), self
        )
        self.lstTempGeocodeGpkgs.currentItemChanged.connect(
            self._on_selection_changed
        )
        self.pbnAddTempLayerToMap.clicked.connect(self._on_add_layer_to_map)
        self.pbnCloseTempDialog.clicked.connect(self.accept)
        self._refresh_list()

    def _refresh_list(self):
        lst = self.lstTempGeocodeGpkgs
        lst.blockSignals(True)
        lst.clear()
        for entry in list_all_temp_geocode_gpkgs():
            label = self._format_entry_label(entry)
            item = QListWidgetItem(label)
            item.setData(GPKG_PATH_ROLE, entry["path"])
            item.setToolTip(entry["path"])
            lst.addItem(item)
        lst.blockSignals(False)
        if lst.count():
            lst.setCurrentRow(0)
        else:
            self.tedTempAddresses.clear()

    def _format_entry_label(self, entry: dict) -> str:
        basename = entry.get("basename") or os.path.basename(entry.get("path") or "")
        count = entry.get("feature_count")
        count_text = str(count) if count is not None else "?"
        session = entry.get("session_id") or ""
        if session:
            session_short = session[:8]
            return self.tr("{0} ({1} pts) · …{2}").format(basename, count_text, session_short)
        return self.tr("{0} ({1} pts)").format(basename, count_text)

    def _selected_gpkg_path(self) -> str | None:
        item = self.lstTempGeocodeGpkgs.currentItem()
        if item is None:
            return None
        path = item.data(GPKG_PATH_ROLE)
        return str(path) if path else None

    def _on_selection_changed(self, current, _previous):
        ted = self.tedTempAddresses
        if current is None:
            ted.clear()
            return
        path = current.data(GPKG_PATH_ROLE)
        if not path:
            ted.clear()
            return
        lines = read_geocode_gpkg_address_lines(str(path))
        ted.setPlainText("\n".join(lines))

    def _on_add_layer_to_map(self):
        path = self._selected_gpkg_path()
        if not path:
            QMessageBox.information(
                self,
                self.windowTitle(),
                self.tr("Select a temp GeoPackage first."),
            )
            return
        existing = map_layer_for_gpkg_path(path)
        if existing is not None:
            QMessageBox.information(
                self,
                self.windowTitle(),
                self.tr("That GeoPackage is already on the map as “{0}”.").format(
                    existing.name()
                ),
            )
            return
        layer, err = add_temp_geocode_gpkg_to_map(path)
        if layer is None:
            messages = {
                "copy_failed": self.tr("Could not copy the GeoPackage into project storage."),
                "load_failed": self.tr("Could not load the GeoPackage."),
                "no_storage": self.tr("Could not resolve geocode storage for this project."),
            }
            QMessageBox.warning(
                self,
                self.windowTitle(),
                messages.get(err or "", self.tr("Could not add the layer to the map.")),
            )
            return
        if self._on_layer_added is not None:
            try:
                self._on_layer_added(layer)
            except Exception:
                pass
        QMessageBox.information(
            self,
            self.windowTitle(),
            self.tr("Added “{0}” to the map.").format(layer.name()),
        )
