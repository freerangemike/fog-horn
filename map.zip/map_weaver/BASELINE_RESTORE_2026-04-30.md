# Baseline Restore - 2026-04-30

**See also:** `BASELINE_RESTORE_2026-05-01.md` (New Map dialog / QSS baseline).

This file marks the current plugin state as the baseline requested by the user.

## Baseline definition

- Restored by user from an earlier version.
- Opens quickly.
- Globe artifact behavior remains unchanged from that earlier version.

## Intent for future work

- Use this restored state as the starting point for new experiments.
- Keep performance at baseline or better.
- Avoid accumulating iterative seam-point patch attempts.

## Files to treat as baseline-critical

- `map_weaver_dockwidget.py`
- `globe_view_scene3d.qml`
- `globe_view.qml`
- `globe_view_3d.qml`
- `globe_view_fake3d.qml`
- `globe_continents.js`
