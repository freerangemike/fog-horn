# -*- coding: utf-8 -*-
"""Read QGIS recent-project list (same QSettings store as the built-in Project menu)."""

from __future__ import annotations

import os

from qgis.core import QgsSettings
from qgis.PyQt.QtCore import QDir


def _recent_project_exists(path: str) -> bool:
    if not path:
        return False
    if "://" in path:
        return True
    return os.path.isfile(path)


def read_qgis_recent_projects() -> list[dict]:
    """Return recent projects in QGIS order (pinned first), mirroring readRecentProjects()."""
    settings = QgsSettings()
    out: list[dict] = []

    settings.beginGroup("UI")
    if "recentProjects" not in settings.childGroups():
        legacy = settings.value("recentProjectsList")
        if legacy:
            for project in legacy:
                path = str(project or "").strip()
                if not path:
                    continue
                out.append(
                    {
                        "title": path,
                        "path": path,
                        "pinned": False,
                        "exists": _recent_project_exists(path),
                    }
                )
        settings.endGroup()
        return out
    settings.endGroup()

    settings.beginGroup("UI/recentProjects")
    key_nums = []
    for key in settings.childGroups():
        try:
            key_nums.append(int(key))
        except (TypeError, ValueError):
            pass
    key_nums.sort()

    try:
        max_projects = int(
            QgsSettings().value("maxRecentProjects", 20, QgsSettings.App) or 20
        )
    except (TypeError, ValueError):
        max_projects = 20

    pin_pos = 0
    for key in key_nums:
        if len(out) >= max_projects:
            break
        settings.beginGroup(str(key))
        path = str(settings.value("path", "") or "").strip()
        title = str(settings.value("title", "") or "").strip()
        pinned = bool(settings.value("pin", False))
        settings.endGroup()
        if not path:
            continue
        entry = {
            "title": title,
            "path": path,
            "pinned": pinned,
            "exists": _recent_project_exists(path),
        }
        if pinned:
            out.insert(pin_pos, entry)
            pin_pos += 1
        else:
            out.append(entry)
    settings.endGroup()
    return out


def format_recent_project_menu_label(entry: dict) -> str:
    """Short display label (elided later to fit the fixed-width submenu)."""
    path = str(entry.get("path") or "").strip()
    title = str(entry.get("title") or "").strip()
    if title and title != path:
        name = title
    else:
        name = os.path.splitext(os.path.basename(path))[0] or path
    label = name.replace("&", "&&")
    if entry.get("pinned"):
        label = "\u25C6 {}".format(label)
    return label


def format_recent_project_tooltip(entry: dict) -> str:
    """Full path for tooltip — never truncated."""
    path = str(entry.get("path") or "").strip()
    return QDir.toNativeSeparators(path) if path else ""


def build_open_recent_submenu_specs(open_callback) -> list[tuple]:
    """
    Build FileCommandPopup submenu rows:
    (label, callback, tooltip) or (label, None, tooltip) when disabled.
    """
    entries = read_qgis_recent_projects()
    if not entries:
        return [("(No recent projects)", None, "")]
    specs = []
    for entry in entries:
        label = format_recent_project_menu_label(entry)
        tip = format_recent_project_tooltip(entry)
        path = entry["path"]
        if entry.get("exists"):
            specs.append((label, lambda p=path: open_callback(p), tip))
        else:
            specs.append((label, None, tip))
    return specs
