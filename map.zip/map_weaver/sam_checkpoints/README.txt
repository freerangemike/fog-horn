SAM weights for map_weaver “Raster trace (Segment Anything)”
============================================================

Place Meta’s ViT-B checkpoint here so users skip downloading:

  File: sam_vit_b_01ec64.pth
  Source: https://dl.fbaipublicfiles.com/segment_anything/sam_vit_b_01ec64.pth
  Size: ~375 MB

Do not put weights under vendor/ — that tree is reserved for vendored source drops.

PyTorch / torchvision / segment_anything (first-time only):

  • In the dialog: click “Install SAM stack (automatic)…”.

  • Or run scripts/install_sam_stack_for_qgis.bat (edit PYTHON= if detection fails).

Restart QGIS after installing packages if SAM still won’t run.
