import QtQuick 2.12

Rectangle {
    id: root
    width: 360
    height: 220
    color: "#ffffff"
    property real yaw: 0.0

    // Equirectangular Earth texture (public domain, NASA "Blue Marble" style).
    Image {
        id: earthMap
        visible: false
        asynchronous: true
        source: "graphics/earth_texture_2048.png"
        onStatusChanged: {
            globeCanvas.requestPaint()
        }
    }

    Canvas {
        id: globeCanvas
        anchors.fill: parent
        antialiasing: true
        renderTarget: Canvas.Image

        onPaint: {
            var ctx = getContext("2d")
            var w = width
            var h = height
            var cx = w / 2
            var cy = h / 2
            var r = Math.min(w, h) * 0.42

            // Qt 5 Canvas compatibility: avoid ctx.reset() (not always available).
            ctx.globalAlpha = 1.0
            ctx.setTransform(1, 0, 0, 1, 0, 0)
            ctx.clearRect(0, 0, w, h)

            // Globe mask
            ctx.save()
            ctx.beginPath()
            ctx.arc(cx, cy, r, 0, Math.PI * 2)
            ctx.clip()

            if (earthMap.status === Image.Ready && earthMap.width > 0 && earthMap.height > 0) {
                // Orthographic-ish strip mapping from equirectangular map onto a sphere disc.
                // This keeps continents recognizable and allows smooth spin by yaw.
                for (var sx = -Math.floor(r); sx <= Math.floor(r); sx++) {
                    var xn = sx / r
                    var inside = 1.0 - xn * xn
                    if (inside <= 0)
                        continue
                    var z = Math.sqrt(inside)
                    var lon = Math.atan2(xn, z) + root.yaw
                    var u = lon / (2 * Math.PI) + 0.5
                    u = u - Math.floor(u)

                    var srcX = Math.floor(u * (earthMap.width - 1))
                    var dstX = Math.floor(cx + sx)
                    var dstY = Math.floor(cy - r)
                    var dstH = Math.floor(2 * r)
                    ctx.drawImage(earthMap, srcX, 0, 1, earthMap.height, dstX, dstY, 1, dstH)
                }
            } else {
                // Fallback if texture cannot load.
                var grad = ctx.createRadialGradient(cx - r * 0.35, cy - r * 0.4, r * 0.15, cx, cy, r)
                grad.addColorStop(0.0, "#7fc7ff")
                grad.addColorStop(0.6, "#4ea0e0")
                grad.addColorStop(1.0, "#2f6ba1")
                ctx.fillStyle = grad
                ctx.fillRect(cx - r, cy - r, 2 * r, 2 * r)
            }

            // Soft shading for depth
            var shade = ctx.createRadialGradient(cx - r * 0.35, cy - r * 0.35, r * 0.1, cx, cy, r)
            shade.addColorStop(0.0, "rgba(255,255,255,0.22)")
            shade.addColorStop(0.55, "rgba(255,255,255,0.03)")
            shade.addColorStop(1.0, "rgba(0,0,0,0.26)")
            ctx.fillStyle = shade
            ctx.beginPath()
            ctx.arc(cx, cy, r, 0, Math.PI * 2)
            ctx.fill()
            ctx.restore()

            // Rim
            ctx.strokeStyle = "#c89a38"
            ctx.lineWidth = 2
            ctx.beginPath()
            ctx.arc(cx, cy, r, 0, Math.PI * 2)
            ctx.stroke()
        }
    }

    Rectangle {
        anchors.fill: parent
        color: "transparent"
        border.color: "#c89a38"
        border.width: 2
        radius: 13
    }

    MouseArea {
        anchors.fill: parent
        property real lastX: 0
        onPressed: {
            lastX = mouse.x
        }
        onPositionChanged: {
            if (!pressed)
                return
            var dx = mouse.x - lastX
            root.yaw += dx * 0.012
            lastX = mouse.x
            globeCanvas.requestPaint()
        }
    }

    // Initial paint only; no periodic timer hack.
    Component.onCompleted: globeCanvas.requestPaint()
}
