# -*- coding: utf-8 -*-
"""Route Connections arc sync without closing the dialog (vendor ``sync_arcs`` calls ``dialog.close()``)."""

from qgis.PyQt.QtCore import Qt
from qgis.core import QgsFeature, QgsGeometry, QgsPointXY, QgsWkbTypes


def _coerce_feature_id(value):
    if value is None:
        return None
    try:
        from qgis.PyQt.QtCore import QVariant

        if isinstance(value, QVariant):
            if not value.isValid() or value.isNull():
                return None
            value = value.value()
    except Exception:
        pass
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return value


def _coerce_conn_id(value):
    if value is None:
        return None
    try:
        from qgis.PyQt.QtCore import QVariant

        if isinstance(value, QVariant):
            if not value.isValid() or value.isNull():
                return None
            value = value.value()
    except Exception:
        pass
    text = "" if value is None else str(value).strip()
    return text or None


def _feature_by_id(layer, fid):
    fid = _coerce_feature_id(fid)
    if layer is None or fid is None:
        return None
    try:
        feat = layer.getFeature(fid)
        if feat is not None and feat.isValid():
            return feat
    except Exception:
        pass
    try:
        for feat in layer.getFeatures():
            try:
                if _coerce_feature_id(feat.id()) == fid:
                    return feat
            except Exception:
                continue
    except Exception:
        pass
    return None


def _point_xy_from_feature(feat):
    if feat is None or not feat.isValid():
        return None
    geom = feat.geometry()
    if geom is None or geom.isEmpty():
        return None
    try:
        if geom.isMultipart():
            multi = geom.asMultiPoint()
            if multi:
                return multi[0]
        return geom.asPoint()
    except Exception:
        pass
    try:
        c = geom.centroid()
        if c and not c.isEmpty():
            return c.asPoint()
    except Exception:
        pass
    return None


def draw_route_arc(host, start_fid, end_fid, start_text, end_text, conn_id, source_layer, arc_layer):
    """Draw one connection arc; tolerant of Qt UserRole / geometry quirks."""
    start_fid = _coerce_feature_id(start_fid)
    end_fid = _coerce_feature_id(end_fid)
    conn_id = _coerce_conn_id(conn_id)
    if start_fid is None or end_fid is None or not conn_id:
        return False

    start_feat = _feature_by_id(source_layer, start_fid)
    end_feat = _feature_by_id(source_layer, end_fid)
    if start_feat is None or end_feat is None:
        return False

    p1 = _point_xy_from_feature(start_feat)
    p2 = _point_xy_from_feature(end_feat)
    if p1 is None or p2 is None:
        return False

    obstacle_points = []
    for feat in source_layer.getFeatures():
        fid = _coerce_feature_id(feat.id())
        if fid in (start_fid, end_fid):
            continue
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            continue
        if geom.type() != QgsWkbTypes.PointGeometry:
            continue
        pt = _point_xy_from_feature(feat)
        if pt is not None:
            obstacle_points.append(pt)

    arc_points = host.get_best_bezier_curve(p1, p2, obstacle_points, tolerance=0.5)
    if not arc_points:
        # Degenerate fallback: straight segment so Apply never silently drops rows.
        arc_points = [QgsPointXY(p1), QgsPointXY(p2)]

    line_geom = QgsGeometry.fromPolylineXY(arc_points)
    new_feat = QgsFeature(arc_layer.fields())
    new_feat.setGeometry(line_geom)
    new_feat.setAttribute("Start", start_text)
    new_feat.setAttribute("End", end_text)
    new_feat.setAttribute("ConnID", conn_id)

    ok = arc_layer.addFeature(new_feat)
    return bool(ok)


def sync_route_arcs_without_close(host):
    """
    Same behavior as ``vendor.route_connections.route_connections.RouteConnections.sync_arcs``,
    but does **not** close the dialog so users can add more routes and Apply again.
    """
    self = host
    dlg = self.dialog
    if dlg is None:
        return
    source_layer = dlg.current_layer
    if not source_layer:
        return

    arc_layer = self.get_arc_layer(source_layer)
    if arc_layer is None:
        return
    try:
        from .route_arcs_layer import (
            mark_route_arcs_layer,
            set_route_arcs_source_layer_id,
        )

        mark_route_arcs_layer(arc_layer)
        set_route_arcs_source_layer_id(arc_layer, str(source_layer.id()))
    except Exception:
        pass
    if not arc_layer.isEditable():
        if not arc_layer.startEditing():
            return

    table_uuids = set()
    row_count = dlg.mConnectionsTable.rowCount()
    for row in range(row_count):
        start_item = dlg.mConnectionsTable.item(row, 0)
        if start_item is None:
            continue
        conn_id = _coerce_conn_id(start_item.data(Qt.UserRole + 1))
        if conn_id:
            table_uuids.add(conn_id)

    map_uuids = set()
    features_to_delete = []
    for feat in arc_layer.getFeatures():
        conn_id = _coerce_conn_id(feat.attribute("ConnID"))
        if conn_id:
            map_uuids.add(conn_id)
            if conn_id not in table_uuids:
                features_to_delete.append(feat.id())

    if features_to_delete:
        arc_layer.deleteFeatures(features_to_delete)

    drawn = 0
    for row in range(row_count):
        start_item = dlg.mConnectionsTable.item(row, 0)
        end_item = dlg.mConnectionsTable.item(row, 1)
        if start_item is None or end_item is None:
            continue
        conn_id = _coerce_conn_id(start_item.data(Qt.UserRole + 1))
        if not conn_id or conn_id in map_uuids:
            continue
        start_fid = start_item.data(Qt.UserRole)
        end_fid = end_item.data(Qt.UserRole)
        start_text = start_item.text()
        end_text = end_item.text()
        if draw_route_arc(
            self,
            start_fid,
            end_fid,
            start_text,
            end_text,
            conn_id,
            source_layer,
            arc_layer,
        ):
            drawn += 1
            map_uuids.add(conn_id)

    try:
        arc_layer.updateExtents()
    except Exception:
        pass
    try:
        if arc_layer.isEditable() and arc_layer.commitChanges():
            arc_layer.startEditing()
    except Exception:
        try:
            if not arc_layer.isEditable():
                arc_layer.startEditing()
        except Exception:
            pass

    try:
        from .route_arcs_layer import ensure_route_arcs_layer_persisted

        arc_layer = ensure_route_arcs_layer_persisted(arc_layer)
    except Exception:
        pass

    arc_layer.triggerRepaint()
    try:
        canvas = getattr(getattr(self, "iface", None), "mapCanvas", lambda: None)()
        if canvas is not None:
            canvas.refresh()
    except Exception:
        pass

    return drawn
