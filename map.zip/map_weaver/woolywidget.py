from qgis.PyQt.QtWidgets import QWidget

from .map_weaver_stylesheet import panel_stylesheet_without_arrow_chrome
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QPainter, QColor


class WoolyWidget(QWidget):
    def __init__(self, parent=None):
        super(WoolyWidget, self).__init__(parent)
        self.setObjectName("MainPanel")
        self._apply_stylesheet()

    def showEvent(self, event):
        super(WoolyWidget, self).showEvent(event)
        # setStyleSheet runs in __init__ before Designer children exist — qproperty-* is never applied
        # to descendants until we polish them once the tree is built.
        if getattr(self, "_mw_polished_style_descendants", False):
            return
        self._mw_polished_style_descendants = True
        st = self.style()
        if st is None:
            return
        for w in self.findChildren(QWidget):
            try:
                st.unpolish(w)
                st.polish(w)
            except Exception:
                pass

    def _apply_stylesheet(self):
        qss = panel_stylesheet_without_arrow_chrome()
        if qss:
            self.setStyleSheet(qss)
