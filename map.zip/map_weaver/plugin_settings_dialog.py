# -*- coding: utf-8 -*-
"""Mapestry plugin settings: theme palette and project color scheme integration."""

from __future__ import annotations

import os
import re
import xml.etree.ElementTree as ET

from qgis.core import QgsColorScheme, QgsProject, QgsProjectColorScheme, Qgis
from qgis.gui import QgsColorButton
from qgis.PyQt import uic
from qgis.PyQt.QtCore import QSettings, QSize, Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QListWidgetItem,
    QMessageBox,
    QWidget,
)
from qgis.utils import iface

THEME_SLOT_COUNT = 20
SETTINGS_GROUP = "map_weaver"
SETTINGS_PALETTE_KEY = "theme_palette_v1"
XML_ROOT_TAG = "map_weaver_theme_palette"
XML_VERSION = "1"

# On-disk palette XML lives next to the plugin, under Settings/ (user-sharable).
PLUGIN_ROOT = os.path.dirname(os.path.abspath(__file__))
PALETTE_SETTINGS_SUBDIR = "Settings"
PALETTE_XML_BASENAME = "theme_palette.xml"
GLOBAL_PALETTE_XML_BASENAME = "color_palette.xml"


def _palette_settings_dir() -> str:
    return os.path.join(PLUGIN_ROOT, PALETTE_SETTINGS_SUBDIR)


def _ensure_palette_settings_dir() -> str:
    d = _palette_settings_dir()
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        pass
    return d


def _default_palette_xml_path() -> str:
    return os.path.join(_ensure_palette_settings_dir(), PALETTE_XML_BASENAME)


def _global_palette_xml_path() -> str:
    return os.path.join(_ensure_palette_settings_dir(), GLOBAL_PALETTE_XML_BASENAME)


def _settings() -> QSettings:
    s = QSettings()
    s.beginGroup(SETTINGS_GROUP)
    return s


def _palette_label(slot_index: int) -> str:
    """QGIS project color label (1-based, matches UI copy)."""
    return "Color {}".format(slot_index + 1)


def _canonical_theme_label(name) -> str | None:
    """
    If ``name`` refers to a theme slot (Color 1 … Color 20), return canonical ``Color N``.
    Accepts alternate spacing/casing from QgsProject / scheme APIs.
    """
    s = (str(name) if name is not None else "").strip()
    if not s:
        return None
    m = re.match(r"(?i)^color\s*(\d{1,2})\s*$", s)
    if not m:
        return None
    idx = int(m.group(1))
    if 1 <= idx <= THEME_SLOT_COUNT:
        return _palette_label(idx - 1)
    return None


def _default_color_for_slot(slot_index: int) -> QColor:
    return QColor.fromHsv(int((slot_index * 360.0 / THEME_SLOT_COUNT) % 360), 120, 230)


def _tuple_from_scheme_entry(entry):
    """Normalize QgsProjectColorScheme.fetchColors() entries to (QColor, str)."""
    try:
        from qgis.core import QgsNamedColor

        if isinstance(entry, QgsNamedColor):
            c = entry.color()
            n = entry.name() or ""
            if not n.strip() and hasattr(entry, "label"):
                try:
                    n = entry.label() or ""
                except Exception:
                    n = ""
            if c is None or not isinstance(c, QColor):
                c = QColor()
            return (QColor(c), str(n) if n is not None else "")
    except Exception:
        pass
    if isinstance(entry, (list, tuple)) and len(entry) >= 2:
        c, n = entry[0], entry[1]
        if not isinstance(c, QColor):
            try:
                c = QColor(c)
            except Exception:
                c = QColor()
        return (c, str(n) if n is not None else "")
    return None


def _existing_project_color_rows() -> list[tuple[QColor, str]]:
    rows = []
    try:
        try:
            scheme = QgsProjectColorScheme(QgsProject.instance())
        except TypeError:
            scheme = QgsProjectColorScheme()
        try:
            fetched = scheme.fetchColors(QgsColorScheme.AllContexts)
        except TypeError:
            fetched = scheme.fetchColors(
                QgsColorScheme.AllContexts,
                QColor(),
                QgsColorScheme.MatchAll,
            )
    except Exception:
        return rows
    if not fetched:
        return rows
    for entry in fetched:
        t = _tuple_from_scheme_entry(entry)
        if t is not None:
            rows.append(t)
    return rows


def _reserved_theme_labels() -> set[str]:
    return {_palette_label(i) for i in range(THEME_SLOT_COUNT)}


def _project_theme_slot_colors_from_project() -> dict[str, QColor]:
    """QgsProject colors whose names map to Color 1 … Color 20 (canonical label -> color)."""
    out: dict[str, QColor] = {}
    for c, n in _existing_project_color_rows():
        canon = _canonical_theme_label(n)
        if canon is None:
            continue
        if isinstance(c, QColor) and c.isValid():
            out[canon] = QColor(c)
    return out


def _read_global_theme_palette_by_slot() -> dict[int, QColor] | None:
    """Parse ``Settings/color_palette.xml`` into slot→color, or None if missing/invalid/empty."""
    path = _global_palette_xml_path()
    if not os.path.isfile(path):
        return None
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError):
        return None
    if root.tag != XML_ROOT_TAG:
        return None
    by_slot = _theme_palette_by_slot_from_valid_root(root)
    return by_slot if by_slot else None


def _merge_palette_into_project_colors(
    palette: list[tuple[QColor, str]],
) -> list[tuple[QColor, str]]:
    """Keep unrelated project colors; replace any row whose label matches Color 1 … Color 20."""
    kept = []
    for c, n in _existing_project_color_rows():
        if _canonical_theme_label(n) is not None:
            continue
        kept.append((c, n))
    return kept + list(palette)


def _theme_palette_by_slot_from_valid_root(root: ET.Element) -> dict[int, QColor]:
    """Parse ``color`` elements under a verified ``map_weaver_theme_palette`` root (may be empty)."""
    by_slot: dict[int, QColor] = {}
    for el in root.findall("color"):
        try:
            slot = int(el.get("slot", "0"))
        except ValueError:
            continue
        hx = el.get("hex") or ""
        qc = QColor(hx) if hx else QColor()
        if 1 <= slot <= THEME_SLOT_COUNT and qc.isValid():
            by_slot[slot] = qc
    return by_slot


def palette_tuples_from_theme_slots(by_slot: dict[int, QColor]) -> list[tuple[QColor, str]]:
    """Twenty (color, label) rows for project merge; missing slots use defaults."""
    out: list[tuple[QColor, str]] = []
    for i in range(THEME_SLOT_COUNT):
        c = by_slot.get(i + 1)
        if c is None or not isinstance(c, QColor) or not c.isValid():
            c = _default_color_for_slot(i)
        out.append((QColor(c), _palette_label(i)))
    return out


def apply_global_palette_xml_to_project_if_present(project: QgsProject | None = None) -> bool:
    """
    If ``Settings/color_palette.xml`` exists next to the plugin, merge its theme colors into
    the project color scheme (labels Color 1 … Color 20). Returns True if the file was read and applied.
    """
    path = _global_palette_xml_path()
    if not os.path.isfile(path):
        return False
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError):
        return False
    if root.tag != XML_ROOT_TAG:
        return False
    by_slot = _theme_palette_by_slot_from_valid_root(root)
    if not by_slot:
        return False
    rows = palette_tuples_from_theme_slots(by_slot)
    project = project or QgsProject.instance()
    try:
        project.setProjectColors(_merge_palette_into_project_colors(rows))
    except Exception:
        return False
    return True


SETTING_COLOR = "color_settings"
SETTING_FILE_PATHS = "file_paths"
SETTING_EXPORT_OPTIONS = "export_options"
SETTING_EXPERIMENTAL_FEATURES = "experimental_features"
SETTING_SAVE_CONFIGURATION = "save_configuration"

# Export Map as Image defaults (used by dock Export button).
EXPORT_RESOLUTION_KEY = "export_resolution"
EXPORT_BITMAP_FORMAT_KEY = "export_bitmap_format"
DEFAULT_EXPORT_RESOLUTION = 600
DEFAULT_EXPORT_BITMAP_FORMAT = "png"
# Sentinel for QGIS “Format by Extension” (empty lastSaveAsImageFilter).
EXPORT_BITMAP_BY_EXTENSION = ""

# Show Experimental Features (default off).
SHOW_EXPERIMENTAL_FEATURES_KEY = "show_experimental_features"
DEFAULT_SHOW_EXPERIMENTAL_FEATURES = False
EXPERIMENTAL_TOOL_SLUGS = frozenset(
    {
        "thematic_map",
        "radius_buffer",
        "raster_trace",
        "energy_infrastructure",
    }
)

# Copy library layers into project folder before loading (default on).
COPY_LIBRARY_LAYERS_KEY = "copy_library_layers_to_project_folder"
DEFAULT_COPY_LIBRARY_LAYERS = True


def read_show_experimental_features() -> bool:
    s = _settings()
    try:
        v = s.value(SHOW_EXPERIMENTAL_FEATURES_KEY, DEFAULT_SHOW_EXPERIMENTAL_FEATURES)
    finally:
        s.endGroup()
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    text = str(v).strip().lower() if v is not None else ""
    if text in ("1", "true", "yes", "on"):
        return True
    if text in ("0", "false", "no", "off", ""):
        return False
    return DEFAULT_SHOW_EXPERIMENTAL_FEATURES


def write_show_experimental_features(enabled: bool) -> None:
    s = _settings()
    try:
        s.setValue(SHOW_EXPERIMENTAL_FEATURES_KEY, bool(enabled))
    finally:
        s.endGroup()


def read_copy_library_layers_to_project_folder() -> bool:
    s = _settings()
    try:
        v = s.value(COPY_LIBRARY_LAYERS_KEY, DEFAULT_COPY_LIBRARY_LAYERS)
    finally:
        s.endGroup()
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    text = str(v).strip().lower() if v is not None else ""
    if text in ("1", "true", "yes", "on"):
        return True
    if text in ("0", "false", "no", "off"):
        return False
    return DEFAULT_COPY_LIBRARY_LAYERS


def write_copy_library_layers_to_project_folder(enabled: bool) -> None:
    s = _settings()
    try:
        s.setValue(COPY_LIBRARY_LAYERS_KEY, bool(enabled))
    finally:
        s.endGroup()


def is_experimental_tool_slug(slug: str | None) -> bool:
    return str(slug or "").strip() in EXPERIMENTAL_TOOL_SLUGS


def _notify_dock_experimental_features_changed(widget) -> None:
    """Refresh Tools tab visibility when the setting changes (walk parents for the dock)."""
    w = widget
    while w is not None:
        refresh = getattr(w, "refresh_tools_for_experimental_features", None)
        if callable(refresh):
            try:
                refresh()
            except Exception:
                pass
            return
        try:
            w = w.parent()
        except Exception:
            return


def _qgis_image_file_filter(format_key: str) -> str:
    """Match QgsGuiUtils::createFileFilter_(format) — e.g. 'PNG format (*.png *.PNG)'."""
    fmt = (format_key or "").strip().lower()
    if not fmt:
        return ""
    return "{} format (*.{} *.{})".format(fmt.upper(), fmt, fmt.upper())


def _supported_export_bitmap_formats() -> list[tuple[str, str]]:
    """
    (format_key, display_label) pairs like QGIS Save Map as Image.

    format_key '' = Format by Extension; otherwise QImageWriter format (png, jpg, …).
    """
    from qgis.PyQt.QtGui import QImageWriter

    rows: list[tuple[str, str]] = [
        (EXPORT_BITMAP_BY_EXTENSION, "Format by Extension"),
    ]
    seen: set[str] = set()
    for raw in QImageWriter.supportedImageFormats():
        try:
            fmt = bytes(raw).decode("ascii").lower()
        except Exception:
            continue
        if not fmt or fmt == "svg" or fmt in seen:
            continue
        seen.add(fmt)
        rows.append((fmt, _qgis_image_file_filter(fmt)))
    # Keep Format by Extension first; sort the rest like QGIS’s QMap of filters.
    head, rest = rows[:1], rows[1:]
    rest.sort(key=lambda t: t[1].lower())
    return head + rest


def read_export_resolution() -> int:
    s = _settings()
    try:
        v = int(s.value(EXPORT_RESOLUTION_KEY, DEFAULT_EXPORT_RESOLUTION))
    except (TypeError, ValueError):
        v = DEFAULT_EXPORT_RESOLUTION
    finally:
        s.endGroup()
    return max(1, min(3000, v))


def write_export_resolution(dpi: int) -> None:
    s = _settings()
    try:
        s.setValue(EXPORT_RESOLUTION_KEY, int(max(1, min(3000, dpi))))
    finally:
        s.endGroup()


def read_export_bitmap_format() -> str:
    s = _settings()
    try:
        v = s.value(EXPORT_BITMAP_FORMAT_KEY, DEFAULT_EXPORT_BITMAP_FORMAT)
    finally:
        s.endGroup()
    if v is None:
        return DEFAULT_EXPORT_BITMAP_FORMAT
    return str(v).strip().lower()


def write_export_bitmap_format(format_key: str | None) -> None:
    key = "" if format_key is None else str(format_key).strip().lower()
    s = _settings()
    try:
        s.setValue(EXPORT_BITMAP_FORMAT_KEY, key)
    finally:
        s.endGroup()


def apply_export_bitmap_format_to_qgis(format_key: str | None = None) -> None:
    """Set QGIS UI/lastSaveAsImageFilter so Save Map as Image uses our default type."""
    if format_key is None:
        format_key = read_export_bitmap_format()
    filt = _qgis_image_file_filter(format_key or "")
    qs = QSettings()
    # Empty filter = Format by Extension (same as QGIS when none stored).
    qs.setValue("UI/lastSaveAsImageFilter", filt)


def apply_export_suggested_path_to_qgis(file_extension: str | None = None) -> None:
    """
    Prefill Save Map as Image/PDF file dialog with the project basename.

    QGIS calls getSaveAsImageName without a default filename, so it uses
    UI/lastSaveAsImageDir as the dialog initial path. When that value includes a
    filename, Qt preselects it (including native Windows dialogs).
    """
    proj = QgsProject.instance()
    try:
        path = (proj.fileName() or "").strip()
    except Exception:
        path = ""
    if not path:
        return
    folder = os.path.dirname(os.path.abspath(path))
    stem = os.path.splitext(os.path.basename(path))[0].strip()
    if not folder or not stem:
        return
    if file_extension is not None:
        ext = str(file_extension).strip().lower()
    else:
        ext = (read_export_bitmap_format() or "").strip().lower()
    if not ext:
        ext = DEFAULT_EXPORT_BITMAP_FORMAT
    suggested = os.path.join(folder, "{}.{}".format(stem, ext))
    QSettings().setValue("UI/lastSaveAsImageDir", suggested)


class ExportOptionsDialog(QDialog):
    """Export Resolution + Default Bitmap Type for the dock Export button."""

    def __init__(self, parent=None):
        super().__init__(parent)
        ui_path = os.path.join(os.path.dirname(__file__), "export_options.ui")
        uic.loadUi(ui_path, self)
        self._populate_bitmap_types()
        try:
            self.buttonBox.accepted.disconnect()
        except (TypeError, RuntimeError):
            pass
        self.buttonBox.accepted.connect(self._on_save_clicked)
        self._load_values()

    def _populate_bitmap_types(self) -> None:
        cmb = self.cmbDefaultBitmapType
        cmb.clear()
        for key, label in _supported_export_bitmap_formats():
            cmb.addItem(label, key)

    def _load_values(self) -> None:
        self.spnExportResolution.setValue(read_export_resolution())
        want = read_export_bitmap_format()
        cmb = self.cmbDefaultBitmapType
        idx = cmb.findData(want)
        if idx < 0 and want:
            # Prefer png if stored format is unavailable on this Qt build.
            idx = cmb.findData(DEFAULT_EXPORT_BITMAP_FORMAT)
        if idx < 0:
            idx = 0
        cmb.setCurrentIndex(idx)

    def _on_save_clicked(self) -> None:
        write_export_resolution(self.spnExportResolution.value())
        key = self.cmbDefaultBitmapType.currentData()
        if key is None:
            key = DEFAULT_EXPORT_BITMAP_FORMAT
        write_export_bitmap_format(str(key))
        apply_export_bitmap_format_to_qgis(str(key))
        self.accept()


class ExperimentalFeaturesDialog(QDialog):
    """On/Off gate for experimental map tools (default Off)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        ui_path = os.path.join(os.path.dirname(__file__), "experimental_features.ui")
        uic.loadUi(ui_path, self)
        from qgis.PyQt.QtWidgets import QButtonGroup

        self._mode_group = QButtonGroup(self)
        self._mode_group.setExclusive(True)
        self._mode_group.addButton(self.rbExperimentalOn)
        self._mode_group.addButton(self.rbExperimentalOff)
        try:
            self.buttonBox.accepted.disconnect()
        except (TypeError, RuntimeError):
            pass
        self.buttonBox.accepted.connect(self._on_save_clicked)
        self._load_values()

    def _load_values(self) -> None:
        on = read_show_experimental_features()
        self.rbExperimentalOn.setChecked(on)
        self.rbExperimentalOff.setChecked(not on)

    def _on_save_clicked(self) -> None:
        write_show_experimental_features(self.rbExperimentalOn.isChecked())
        _notify_dock_experimental_features_changed(self)
        self.accept()


class SaveConfigurationDialog(QDialog):
    """Yes/No: copy library layers into the project folder before loading (default Yes)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        ui_path = os.path.join(os.path.dirname(__file__), "save_configuration.ui")
        uic.loadUi(ui_path, self)
        from qgis.PyQt.QtWidgets import QButtonGroup

        self._mode_group = QButtonGroup(self)
        self._mode_group.setExclusive(True)
        self._mode_group.addButton(self.rbCopyLibraryYes)
        self._mode_group.addButton(self.rbCopyLibraryNo)
        try:
            self.buttonBox.accepted.disconnect()
        except (TypeError, RuntimeError):
            pass
        self.buttonBox.accepted.connect(self._on_save_clicked)
        self._load_values()

    def _load_values(self) -> None:
        on = read_copy_library_layers_to_project_folder()
        self.rbCopyLibraryYes.setChecked(on)
        self.rbCopyLibraryNo.setChecked(not on)

    def _on_save_clicked(self) -> None:
        write_copy_library_layers_to_project_folder(self.rbCopyLibraryYes.isChecked())
        self.accept()


class ColorSettingsDialog(QDialog):
    """Twenty-slot theme palette; project colors sync on load / global save; XML share; QSettings persistence."""

    def __init__(self, parent=None):
        super().__init__(parent)
        ui_path = os.path.join(os.path.dirname(__file__), "color_setting.ui")
        uic.loadUi(ui_path, self)
        self._color_buttons: list[QgsColorButton] = []
        lay = self.verticalLayout_palette
        for i in range(THEME_SLOT_COUNT):
            row = QWidget(self.scrollAreaWidgetContents)
            h = QHBoxLayout(row)
            h.setContentsMargins(0, 0, 0, 0)
            h.setSpacing(10)
            lab = QLabel(_palette_label(i), row)
            lab.setMinimumWidth(72)
            btn = QgsColorButton(row)
            btn.setMinimumHeight(28)
            btn.setShowMenu(True)
            btn.setColor(_default_color_for_slot(i))
            h.addWidget(lab)
            h.addWidget(btn, 1)
            lay.addWidget(row)
            self._color_buttons.append(btn)
        lay.addStretch(1)

        self.btnSavePaletteXml.clicked.connect(self._on_save_palette_xml)
        self.btnLoadPaletteXml.clicked.connect(self._on_load_palette_xml)
        self.btnSetGlobalColors.clicked.connect(self._on_set_global_colors)
        self.btnLoadGlobalColors.clicked.connect(self._on_load_global_colors)

        self._load_palette_from_settings()

    def accept(self):
        self._persist_palette_to_settings()
        super().accept()

    def _palette_from_buttons(self) -> list[tuple[QColor, str]]:
        out = []
        for i, btn in enumerate(self._color_buttons):
            c = btn.color()
            if not isinstance(c, QColor) or not c.isValid():
                c = _default_color_for_slot(i)
            out.append((QColor(c), _palette_label(i)))
        return out

    def _set_buttons_from_colors(self, colors: list[QColor]) -> None:
        for i, btn in enumerate(self._color_buttons):
            if i < len(colors) and isinstance(colors[i], QColor) and colors[i].isValid():
                btn.setColor(QColor(colors[i]))
            else:
                btn.setColor(_default_color_for_slot(i))

    def _persist_palette_to_settings(self) -> None:
        s = _settings()
        for i, btn in enumerate(self._color_buttons):
            c = btn.color()
            if isinstance(c, QColor) and c.isValid():
                s.setValue(
                    "{}/color_{:02d}".format(SETTINGS_PALETTE_KEY, i + 1),
                    c.name(QColor.HexArgb),
                )
            else:
                s.remove("{}/color_{:02d}".format(SETTINGS_PALETTE_KEY, i + 1))

    def _load_palette_from_settings(self) -> None:
        """Fill swatches: project theme colors, else global XML, else QSettings, else defaults."""
        s = _settings()
        proj_slots = _project_theme_slot_colors_from_project()
        xml_slots = _read_global_theme_palette_by_slot()
        colors = []
        for i in range(THEME_SLOT_COUNT):
            lab = _palette_label(i)
            if lab in proj_slots:
                colors.append(proj_slots[lab])
                continue
            if xml_slots is not None:
                c = xml_slots.get(i + 1)
                if c is not None and isinstance(c, QColor) and c.isValid():
                    colors.append(QColor(c))
                    continue
            key = "{}/color_{:02d}".format(SETTINGS_PALETTE_KEY, i + 1)
            hx = s.value(key, "", type=str)
            if isinstance(hx, str) and len(hx.strip()) >= 6:
                qc = QColor(hx.strip())
                if qc.isValid():
                    colors.append(qc)
                    continue
            colors.append(_default_color_for_slot(i))
        self._set_buttons_from_colors(colors)

    def _push_current_palette_to_project(self) -> bool:
        """Merge the current button palette into QgsProject project colors. False on failure."""
        palette = self._palette_from_buttons()
        try:
            QgsProject.instance().setProjectColors(_merge_palette_into_project_colors(palette))
        except Exception as e:
            QMessageBox.warning(
                self,
                self.tr("Mapestry"),
                self.tr("Could not update project colors: {}").format(e),
            )
            return False
        return True

    def _palette_xml_root_from_buttons(self) -> ET.Element:
        root = ET.Element(XML_ROOT_TAG, version=XML_VERSION)
        for i, btn in enumerate(self._color_buttons):
            c = btn.color()
            if not isinstance(c, QColor) or not c.isValid():
                c = _default_color_for_slot(i)
            ET.SubElement(
                root,
                "color",
                slot=str(i + 1),
                label=_palette_label(i),
                hex=c.name(QColor.HexArgb),
            )
        return root

    def _write_palette_xml_root_to_path(self, root: ET.Element, path: str) -> str | None:
        try:
            ET.ElementTree(root).write(path, encoding="utf-8", xml_declaration=True)
        except OSError as e:
            return str(e)
        return None

    def _apply_palette_from_xml_root(self, root: ET.Element) -> str | None:
        if root.tag != XML_ROOT_TAG:
            return self.tr("This file is not a Mapestry theme palette (root tag {}).").format(
                repr(root.tag)
            )
        by_slot = _theme_palette_by_slot_from_valid_root(root)
        if not by_slot:
            return self.tr("No valid color entries were found in this file.")
        for i, btn in enumerate(self._color_buttons):
            c = by_slot.get(i + 1)
            if c is not None:
                btn.setColor(c)
        return None

    def _on_save_palette_xml(self) -> None:
        _ensure_palette_settings_dir()
        default_path = _default_palette_xml_path()
        path, _ = QFileDialog.getSaveFileName(
            self,
            self.tr("Save theme palette"),
            default_path,
            self.tr("Mapestry palette XML (*.xml);;All files (*.*)"),
        )
        if not path:
            return
        if not path.lower().endswith(".xml"):
            path += ".xml"
        root = self._palette_xml_root_from_buttons()
        err = self._write_palette_xml_root_to_path(root, path)
        if err:
            QMessageBox.warning(
                self,
                self.tr("Mapestry"),
                self.tr("Could not write file: {}").format(err),
            )
            return
        if iface is not None:
            iface.messageBar().pushMessage(
                self.tr("Mapestry"),
                self.tr("Palette saved to {}").format(path),
                level=Qgis.Success,
                duration=4,
            )

    def _on_set_global_colors(self) -> None:
        """Write current palette to Settings/color_palette.xml (no file dialog)."""
        _ensure_palette_settings_dir()
        path = _global_palette_xml_path()
        root = self._palette_xml_root_from_buttons()
        err = self._write_palette_xml_root_to_path(root, path)
        if err:
            QMessageBox.warning(
                self,
                self.tr("Mapestry"),
                self.tr("Could not write global palette: {}").format(err),
            )
            return
        if not self._push_current_palette_to_project():
            return
        if iface is not None:
            iface.messageBar().pushMessage(
                self.tr("Mapestry"),
                self.tr("Global palette saved to {}. Project colors updated.").format(path),
                level=Qgis.Success,
                duration=4,
            )

    def _on_load_palette_xml(self) -> None:
        _ensure_palette_settings_dir()
        start_dir = _palette_settings_dir()
        path, _ = QFileDialog.getOpenFileName(
            self,
            self.tr("Load theme palette"),
            start_dir,
            self.tr("Mapestry palette XML (*.xml);;All files (*.*)"),
        )
        if not path:
            return
        try:
            root = ET.parse(path).getroot()
        except ET.ParseError as e:
            QMessageBox.warning(
                self,
                self.tr("Mapestry"),
                self.tr("Invalid XML: {}").format(e),
            )
            return
        except OSError as e:
            QMessageBox.warning(
                self,
                self.tr("Mapestry"),
                self.tr("Could not read file: {}").format(e),
            )
            return
        err = self._apply_palette_from_xml_root(root)
        if err:
            QMessageBox.warning(self, self.tr("Mapestry"), err)
            return
        if not self._push_current_palette_to_project():
            return
        if iface is not None:
            iface.messageBar().pushMessage(
                self.tr("Mapestry"),
                self.tr("Palette loaded from {}. Project colors updated.").format(path),
                level=Qgis.Success,
                duration=4,
            )

    def _on_load_global_colors(self) -> None:
        """Load palette from Settings/color_palette.xml (no file dialog)."""
        path = _global_palette_xml_path()
        if not os.path.isfile(path):
            QMessageBox.information(
                self,
                self.tr("Mapestry"),
                self.tr(
                    "No global palette file found yet.\n\n"
                    "Expected file:\n{}\n\n"
                    'Use "Set Global Colors" to create it.'
                ).format(path),
            )
            return
        try:
            root = ET.parse(path).getroot()
        except ET.ParseError as e:
            QMessageBox.warning(
                self,
                self.tr("Mapestry"),
                self.tr("Invalid XML: {}").format(e),
            )
            return
        except OSError as e:
            QMessageBox.warning(
                self,
                self.tr("Mapestry"),
                self.tr("Could not read file: {}").format(e),
            )
            return
        err = self._apply_palette_from_xml_root(root)
        if err:
            QMessageBox.warning(self, self.tr("Mapestry"), err)
            return
        if not self._push_current_palette_to_project():
            return
        if iface is not None:
            iface.messageBar().pushMessage(
                self.tr("Mapestry"),
                self.tr("Global palette loaded from {}. Project colors updated.").format(path),
                level=Qgis.Success,
                duration=4,
            )


class FilePathsDialog(QDialog):
    """Geocode staging folder and other path settings."""

    def __init__(self, parent=None):
        super().__init__(parent)
        from .geocode_layer import (
            default_geocode_staging_root,
            read_geocode_staging_root_override,
            validate_geocode_staging_root,
            write_geocode_staging_root_setting,
        )

        self._default_geocode_staging_root = default_geocode_staging_root
        self._read_geocode_staging_root_override = read_geocode_staging_root_override
        self._validate_geocode_staging_root = validate_geocode_staging_root
        self._write_geocode_staging_root_setting = write_geocode_staging_root_setting

        ui_path = os.path.join(os.path.dirname(__file__), "file_paths.ui")
        uic.loadUi(ui_path, self)
        self.labelGeocodeStagingDefault.setText(
            self.tr("Default: {}").format(self._default_geocode_staging_root())
        )
        self.btnBrowseGeocodeStagingRoot.clicked.connect(self._on_browse_geocode_staging)
        self.btnResetGeocodeStagingDefault.clicked.connect(
            self._on_reset_geocode_staging_default
        )
        try:
            self.buttonBox.accepted.disconnect()
        except (TypeError, RuntimeError):
            pass
        self.buttonBox.accepted.connect(self._on_save_clicked)
        self._load_paths()

    def _load_paths(self) -> None:
        override = self._read_geocode_staging_root_override()
        self.lineGeocodeStagingRoot.setText(override or "")

    def _on_browse_geocode_staging(self) -> None:
        start = self.lineGeocodeStagingRoot.text().strip()
        if not start:
            start = self._default_geocode_staging_root()
        path = QFileDialog.getExistingDirectory(
            self,
            self.tr("Choose geocode staging folder"),
            start,
        )
        if path:
            self.lineGeocodeStagingRoot.setText(path)

    def _on_reset_geocode_staging_default(self) -> None:
        self.lineGeocodeStagingRoot.clear()

    def _on_save_clicked(self) -> None:
        raw = self.lineGeocodeStagingRoot.text().strip()
        err = self._validate_geocode_staging_root(raw)
        if err:
            QMessageBox.warning(self, self.windowTitle(), err)
            return
        self._write_geocode_staging_root_setting(raw or None)
        self.accept()


class PluginSettingsDialog(QDialog):
    """Master plugin settings launcher."""

    def __init__(self, parent=None):
        super().__init__(parent)
        ui_path = os.path.join(os.path.dirname(__file__), "plugin_settings.ui")
        uic.loadUi(ui_path, self)
        self._populate_settings_list()
        lst = self.lstPluginSettings
        lst.itemClicked.connect(self._on_settings_item_clicked)
        lst.setStyleSheet("QListWidget::item { padding: 12px 14px; }")
        bb = self.buttonBox
        try:
            bb.accepted.connect(self.accept)
        except Exception:
            pass
        try:
            bb.rejected.connect(self.reject)
        except Exception:
            pass

    def _populate_settings_list(self) -> None:
        lst = self.lstPluginSettings
        lst.clear()
        entries = [
            (self.tr("Color Settings"), SETTING_COLOR),
            (self.tr("File Paths"), SETTING_FILE_PATHS),
            (self.tr("Export Options"), SETTING_EXPORT_OPTIONS),
            (self.tr("Save Configuration"), SETTING_SAVE_CONFIGURATION),
            (self.tr("Show Experimental Features"), SETTING_EXPERIMENTAL_FEATURES),
        ]
        for label, key in entries:
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, key)
            item.setSizeHint(QSize(0, 48))
            lst.addItem(item)

    def _on_settings_item_clicked(self, item: QListWidgetItem) -> None:
        key = item.data(Qt.UserRole)
        if key == SETTING_COLOR:
            dlg = ColorSettingsDialog(self)
            dlg.exec_()
        elif key == SETTING_FILE_PATHS:
            dlg = FilePathsDialog(self)
            dlg.exec_()
        elif key == SETTING_EXPORT_OPTIONS:
            dlg = ExportOptionsDialog(self)
            dlg.exec_()
        elif key == SETTING_SAVE_CONFIGURATION:
            dlg = SaveConfigurationDialog(self)
            dlg.exec_()
        elif key == SETTING_EXPERIMENTAL_FEATURES:
            dlg = ExperimentalFeaturesDialog(self)
            dlg.exec_()
        self.lstPluginSettings.clearSelection()
