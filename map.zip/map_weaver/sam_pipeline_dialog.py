# -*- coding: utf-8 -*-
"""Raster pipeline trace with Segment Anything (SAM) — preview, color mask hints, vector lines."""

from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import urllib.request
import numpy as np

from qgis.core import (
    Qgis,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsRasterLayer,
    QgsSingleSymbolRenderer,
    QgsSymbol,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.gui import QgsMapLayerComboBox

try:
    from qgis.gui import QgsMapLayerProxyModel
except ImportError:
    from qgis.core import QgsMapLayerProxyModel
from qgis.PyQt.QtCore import (
    Q_ARG,
    QByteArray,
    QMetaObject,
    QMetaType,
    Qt,
    QThread,
    QTimer,
    QVariant,
    pyqtSignal,
    pyqtSlot,
)
from qgis.PyQt.QtGui import QColor, QGuiApplication, QImage, QPainter, QPen, QPixmap, QShowEvent
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QAction,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QDoubleSpinBox,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSlider,
    QSpinBox,
    QStyle,
    QStyleOptionFrame,
    QVBoxLayout,
    QWidget,
)
try:
    from osgeo import gdal

    gdal.UseExceptions()
except Exception:
    gdal = None


def _configure_torch_embedded_env():
    """Torch Dynamo runs heavy introspection at torchvision import time; that can AV-crash embedded QGIS Python on Windows."""
    os.environ.setdefault("TORCHDYNAMO_DISABLE", "1")
    os.environ.setdefault("TORCH_COMPILE_DISABLE", "1")


_configure_torch_embedded_env()

SAM_VIT_B_URL = "https://dl.fbaipublicfiles.com/segment_anything/sam_vit_b_01ec64.pth"
SAM_VIT_B_FILE = "sam_vit_b_01ec64.pth"

# QgsProject.writeEntry(scope, key, str) — keys must be XML-safe (see QGIS QgsProject docs).
SAM_TRACE_PROJECT_SCOPE = "map_weaver"
SAM_TRACE_PROJECT_ENTRY_KEY = "sam_raster_trace_state_v1"
# Older experiment used a single custom-property key (never shipped in stable QGIS bindings here).
SAM_TRACE_LEGACY_CUSTOM_PROP_KEY = "map_weaver/sam_raster_trace_state_v1"



def _basename_lower(path):
    return os.path.basename(path or "").lower()


def _path_looks_like_python_interpreter(path):
    """True if path is likely python.exe / python3 (not qgis-bin.exe)."""
    if not path or not os.path.isfile(path):
        return False
    base = _basename_lower(path)
    if sys.platform == "win32":
        # python.exe, pythonw.exe, python3.exe — not qgis-bin.exe / qgis.exe
        return base.endswith(".exe") and "python" in base
    return base == "python" or base.startswith("python3")


def python_executable_for_pip():
    """
    Interpreter to run ``python -m pip``.

    On Windows, ``sys.executable`` inside QGIS is often ``qgis-bin.exe`` (or similar).
    Using it with ``-m pip`` starts another QGIS and treats arguments as layer paths.
    The real interpreter usually lives under ``sys.prefix``.
    """
    prefix = getattr(sys, "prefix", None) or ""
    if prefix:
        if sys.platform == "win32":
            for name in ("python.exe", "pythonw.exe", "python3.exe"):
                p = os.path.join(prefix, name)
                if os.path.isfile(p) and _path_looks_like_python_interpreter(p):
                    return p
        else:
            for rel in (("bin", "python3"), ("bin", "python")):
                p = os.path.join(prefix, *rel)
                if os.path.isfile(p):
                    return p

    # Standalone / OSGeo: …/apps/Python312/python.exe next to apps/qgis*
    try:
        from qgis.core import QgsApplication

        inst = QgsApplication.instance()
        if inst is not None:
            qgis_app_dir = os.path.normpath(inst.prefixPath())
            apps_dir = os.path.dirname(qgis_app_dir)
            if os.path.basename(apps_dir).lower() == "apps" and os.path.isdir(apps_dir):
                pydirs = []
                for entry in os.listdir(apps_dir):
                    el = entry.lower()
                    if el.startswith("python"):
                        if sys.platform == "win32":
                            cand = os.path.join(apps_dir, entry, "python.exe")
                        else:
                            cand = os.path.join(apps_dir, entry, "bin", "python3")
                            if not os.path.isfile(cand):
                                cand = os.path.join(apps_dir, entry, "bin", "python")
                        if os.path.isfile(cand):
                            pydirs.append(cand)
                if pydirs:
                    pydirs.sort()
                    return pydirs[-1]
    except Exception:
        pass

    root = os.environ.get("OSGEO4W_ROOT")
    if root and sys.platform == "win32":
        apps = os.path.join(root, "apps")
        if os.path.isdir(apps):
            for entry in sorted(os.listdir(apps), reverse=True):
                if entry.lower().startswith("python"):
                    cand = os.path.join(apps, entry, "python.exe")
                    if os.path.isfile(cand):
                        return cand

    exe = sys.executable or ""
    if _path_looks_like_python_interpreter(exe):
        return exe
    return exe


def sam_dependencies_available():
    """SAM requires PyTorch + Meta segment_anything in QGIS’s Python environment."""
    _configure_torch_embedded_env()
    user_site = ""
    try:
        import site

        user_site = site.getusersitepackages()
    except Exception:
        pass
    try:
        import torch

        # Force native DLL load (Windows often raises OSError here, not ImportError).
        _ = torch.tensor([1.0], device="cpu")
        import torchvision  # noqa: F401 — segment_anything imports this; fail early with a clear error
        from segment_anything import SamPredictor  # noqa: F401

        return True, ""
    except Exception as e:
        return False, format_sam_dependency_help(str(e))


def format_sam_dependency_help(import_err_detail: str) -> str:
    """Manual install instructions using the same interpreter QGIS is running."""
    py = python_executable_for_pip() or "python"
    lines = [
        "Easiest: use the button “Install SAM stack (automatic)…” in this dialog.",
        "",
        "If torch install fails with pip AttributeError (… isdisjoint …), upgrade pip in user site first:",
        f'  "{py}" -m pip install --user -U pip setuptools wheel packaging',
        "",
        "Then install SAM wheels:",
        f'  "{py}" -m pip install --user torch torchvision --index-url https://download.pytorch.org/whl/cpu',
        f'  "{py}" -m pip install --user segment-anything scikit-image opencv-python-headless',
        "",
        "There is also scripts/install_sam_stack_for_qgis.bat in the plugin folder (edit PYTHON= if needed).",
        "",
        "After pip succeeds, restart QGIS completely, then open this dialog again.",
        "",
        "If QGIS shows “Couldn’t load SIP module” / Python disabled / SyntaxError inside qgis\\core:",
        "  • Quit QGIS. Rename your per-user folder",
        r"      %APPDATA%\Python\Python312\site-packages",
        "    (e.g. to site-packages_BACKUP_sam) so bad wheels stop shadowing QGIS.",
        "  • Run QGIS installer → Repair (or reinstall the same QGIS version).",
        "  • Avoid files named typing.py / enum.py under that user site-packages — they break stdlib.",
        "",
        "If you see DLL / WinError / “DLL load failed”, install the latest Microsoft Visual C++ Redistributable (x64)",
        "from Microsoft, then restart Windows once and try again.",
        "",
        f"Error detail: {import_err_detail}",
    ]
    return "\n".join(lines)


def _numpy_constraint_file_for_pip():
    """
    Pip installing torch often upgrades numpy into the user site-packages folder.
    That copy shadows QGIS’s numpy and can destabilize PyQGIS / SIP. Pin numpy to the
    version QGIS already loaded while the dialog is running.
    """
    try:
        import numpy as np

        ver = np.__version__
    except Exception:
        return None
    try:
        fd, path = tempfile.mkstemp(suffix="_map_weaver_sam_constraints.txt", text=True)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(f"numpy=={ver}\n")
        return path
    except Exception:
        return None


class SamDepsPipWorker(QThread):
    """Install PyTorch (CPU) + segment_anything + helpers using QGIS’s Python."""

    progress = pyqtSignal(str)
    finished_ok = pyqtSignal()
    failed = pyqtSignal(str)

    def __init__(self, pip_constraint_file=None):
        super().__init__()
        self._pip_constraint_file = pip_constraint_file

    def run(self):
        py = python_executable_for_pip()
        if not py:
            self.failed.emit(
                "Could not find QGIS’s Python interpreter (only qgis-bin.exe?). "
                "Use “Manual install help…” or scripts/install_sam_stack_for_qgis.bat."
            )
            return
        if not _path_looks_like_python_interpreter(py):
            self.failed.emit(
                "Resolved interpreter does not look like python.exe:\n"
                + str(py)
                + "\n\nOn Windows, QGIS’s Python is usually under:\n"
                + r'  …\apps\Python312\python.exe'
                + "\n\nEdit scripts/install_sam_stack_for_qgis.bat and run it manually."
            )
            return


        env = os.environ.copy()
        env.setdefault("PIP_DISABLE_PIP_VERSION_CHECK", "1")
        # Avoid a stray PYTHONPATH pulling unrelated trees into pip / verify subprocesses.
        env.pop("PYTHONPATH", None)

        def pip_install_prefix():
            cmd = [py, "-m", "pip", "install", "--user"]
            if self._pip_constraint_file:
                cmd.extend(["-c", self._pip_constraint_file])
            return cmd

        def run_cmd(args):
            kwargs = {
                "capture_output": True,
                "text": True,
                "encoding": "utf-8",
                "errors": "replace",
                "env": env,
                "timeout": 900,
            }
            if sys.platform == "win32":
                cr = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                if cr:
                    kwargs["creationflags"] = cr
            self.progress.emit(" ".join(args))
            return subprocess.run(args, **kwargs)

        try:
            r = run_cmd([py, "-m", "pip", "--version"])
            if r.returncode != 0:
                self.failed.emit(
                    "pip is not available for QGIS’s Python.\n\n"
                    + (r.stderr or r.stdout or "")
                )
                return

            # Bundled pip in some QGIS builds mishandles PyTorch index wheels (internal error:
            # AttributeError: 'str' object has no attribute 'isdisjoint' in pip.models.wheel).
            self.progress.emit(
                "Upgrading pip/setuptools/wheel/packaging in user site (fixes many torch index installs)…"
            )
            r = run_cmd(
                [
                    py,
                    "-m",
                    "pip",
                    "install",
                    "--user",
                    "-U",
                    "pip",
                    "setuptools",
                    "wheel",
                    "packaging",
                ]
            )
            if r.returncode != 0:
                self.progress.emit(
                    "Note: pip self-upgrade reported an error; continuing with existing pip. Details:\n"
                    + ((r.stderr or r.stdout or "")[:800])
                )

            # CPU wheels are smaller than full CUDA builds; good default for SAM ViT-B on CPU/GPU-less setups.
            r = run_cmd(
                pip_install_prefix()
                + [
                    "torch",
                    "--index-url",
                    "https://download.pytorch.org/whl/cpu",
                ]
            )
            if r.returncode != 0:
                self.progress.emit(
                    "CPU wheel install failed; retrying torch from default PyPI (may be larger download)…"
                )
                r = run_cmd(pip_install_prefix() + ["torch"])
                if r.returncode != 0:
                    self.failed.emit(
                        "Installing torch failed.\n\n"
                        + (r.stdout or "")
                        + "\n"
                        + (r.stderr or "")
                    )
                    return

            # segment_anything imports torchvision.transforms (Meta SAM dependency).
            r = run_cmd(
                pip_install_prefix()
                + [
                    "torchvision",
                    "--index-url",
                    "https://download.pytorch.org/whl/cpu",
                ]
            )
            if r.returncode != 0:
                self.progress.emit(
                    "torchvision CPU wheel failed; retrying torchvision from default PyPI…"
                )
                r = run_cmd(pip_install_prefix() + ["torchvision"])
                if r.returncode != 0:
                    self.failed.emit(
                        "Installing torchvision failed (required by segment_anything).\n\n"
                        + (r.stdout or "")
                        + "\n"
                        + (r.stderr or "")
                    )
                    return

            r = run_cmd(
                pip_install_prefix()
                + [
                    "segment-anything",
                    "scikit-image",
                    "opencv-python-headless",
                ]
            )
            if r.returncode != 0:
                self.failed.emit(
                    "Installing segment_anything / scikit-image / opencv failed.\n\n"
                    + (r.stdout or "")
                    + "\n"
                    + (r.stderr or "")
                )
                return

            r = run_cmd(
                [
                    py,
                    "-c",
                    "import torch; import torchvision; from segment_anything import SamPredictor",
                ]
            )
            if r.returncode != 0:
                self.failed.emit(
                    "pip finished, but this interpreter still cannot import SAM dependencies:\n\n"
                    + (r.stdout or "")
                    + "\n"
                    + (r.stderr or "")
                    + "\n\nFully quit QGIS and open it again, then use “Manual install help…” if needed."
                )
                return
        except subprocess.TimeoutExpired:
            self.failed.emit(
                "pip timed out (download or install took too long). "
                "Check your network and try again, or install manually."
            )
            return
        except Exception as e:
            self.failed.emit(str(e))
            return
        finally:
            cf = self._pip_constraint_file
            if cf:
                try:
                    os.remove(cf)
                except OSError:
                    pass

        self.finished_ok.emit()


def _numpy_dtype_for_qgis_raster_type(dt):
    """Map Qgis.DataType to numpy dtype for QgsRasterBlock buffers."""
    mapping = {
        getattr(Qgis, "Byte", None): np.uint8,
        getattr(Qgis, "UInt16", None): np.uint16,
        getattr(Qgis, "Int16", None): np.int16,
        getattr(Qgis, "UInt32", None): np.uint32,
        getattr(Qgis, "Int32", None): np.int32,
        getattr(Qgis, "Float32", None): np.float32,
        getattr(Qgis, "Float64", None): np.float64,
    }
    return mapping.get(dt, np.float32)


def read_raster_rgb_numpy(layer: QgsRasterLayer, max_side: int):
    """
    Read raster as RGB uint8 array (H, W, 3) and processing geo mapping.
    Downscales so longest side <= max_side for SAM performance.
    Returns (rgb, geo) or (None, None) on failure.
    geo = dict with keys xmin, xmax, ymin, ymax, w, h (processing dimensions).
    """
    if layer is None or not layer.isValid():
        return None, None
    prov = layer.dataProvider()
    extent = prov.extent()
    bw = layer.width()
    bh = layer.height()
    if bw <= 0 or bh <= 0:
        return None, None

    scale = min(1.0, float(max_side) / float(max(bw, bh)))
    nw = max(1, int(round(bw * scale)))
    nh = max(1, int(round(bh * scale)))

    bands = []
    if layer.bandCount() >= 3:
        band_ids = (1, 2, 3)
    else:
        band_ids = (1,)

    # Prefer GDAL ReadAsArray (fast, reliable in QGIS).
    gdal_sources = [layer.source()]
    try:
        uri = prov.dataSourceUri()
        if uri:
            base = uri.split("|")[0].strip().strip('"')
            if base and base not in gdal_sources:
                gdal_sources.append(base)
    except Exception:
        pass
    ds = None
    if gdal is not None:
        for src in gdal_sources:
            if not src:
                continue
            try:
                ds = gdal.Open(src)
            except Exception:
                ds = None
            if ds is not None:
                break
    if ds is not None:
        try:
            for bid in band_ids:
                b = ds.GetRasterBand(int(bid))
                arr = b.ReadAsArray(buf_xsize=nw, buf_ysize=nh)
                if arr is None:
                    return None, None
                bands.append(arr.astype(np.float64))
        finally:
            del ds
    else:
        # QgsRasterBlock fallback
        for bid in band_ids:
            block = prov.block(int(bid), extent, nw, nh)
            if block.isEmpty():
                return None, None
            dt = _numpy_dtype_for_qgis_raster_type(block.dataType())
            buf = block.data()
            if buf is None:
                return None, None
            raw = np.frombuffer(bytes(buf), dtype=dt)
            expected = nw * nh
            if raw.size < expected:
                return None, None
            arr = raw.reshape((nh, nw))[:nh, :nw].astype(np.float64)
            bands.append(arr)

    if len(bands) == 1:
        g = bands[0]
        rgb64 = np.stack([g, g, g], axis=-1)
    else:
        rgb64 = np.stack(bands[:3], axis=-1)

    # Scale to 0–255 (handles Byte, UInt16, Float).
    lo = np.nanmin(rgb64)
    hi = np.nanmax(rgb64)
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        rgb_u8 = np.zeros((nh, nw, 3), dtype=np.uint8)
    else:
        norm = (rgb64 - lo) / (hi - lo)
        norm = np.clip(norm, 0.0, 1.0)
        rgb_u8 = (norm * 255.0).astype(np.uint8)

    xmin = extent.xMinimum()
    xmax = extent.xMaximum()
    ymin = extent.yMinimum()
    ymax = extent.yMaximum()
    geo = {"xmin": xmin, "xmax": xmax, "ymin": ymin, "ymax": ymax, "w": nw, "h": nh}
    return rgb_u8, geo


def hsv_mask_rgb(rgb: np.ndarray, h0, h1, s0, s1, v0, v1, invert: bool) -> np.ndarray:
    """Boolean mask (H,W) from RGB using OpenCV-style HSV (H 0–179)."""
    try:
        import cv2
    except ImportError:
        # Fallback: crude luminance band only if OpenCV missing
        gray = (
            0.299 * rgb[..., 0].astype(np.float64)
            + 0.587 * rgb[..., 1].astype(np.float64)
            + 0.114 * rgb[..., 2].astype(np.float64)
        )
        m = (gray >= v0) & (gray <= v1)
        return ~m if invert else m

    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    lower = np.array([h0, s0, v0], dtype=np.uint8)
    upper = np.array([h1, s1, v1], dtype=np.uint8)
    if h0 <= h1:
        m = cv2.inRange(hsv, lower, upper).astype(bool)
    else:
        # Wrap hue (e.g. reds crossing 179/0)
        m1 = cv2.inRange(hsv, np.array([h0, s0, v0]), np.array([179, s1, v1])).astype(bool)
        m2 = cv2.inRange(hsv, np.array([0, s0, v0]), np.array([h1, s1, v1])).astype(bool)
        m = m1 | m2
    if invert:
        m = ~m
    return m


def hue_interval_covering_samples(h_samples, margin: int, full_if_arc_ge: int = 95):
    """
    Smallest hue interval on OpenCV's 0–179 axis treated as a ring of period 180, covering
    all sampled hues ± margin. Returns (h_lo, h_hi); if h_lo > h_hi the band wraps reds across 0.
    When the shortest covering arc is ``full_if_arc_ge`` or larger, returns (0, 179).
    """
    hs = sorted(set(int(np.clip(int(h), 0, 179)) for h in h_samples))
    if not hs:
        return 0, 179
    if len(hs) == 1:
        c = hs[0]
        return max(0, c - margin), min(179, c + margin)
    n = len(hs)
    gaps = []
    for i in range(n):
        j = (i + 1) % n
        if j != 0:
            g = hs[j] - hs[i]
        else:
            g = (hs[0] + 180) - hs[-1]
        gaps.append(g)
    mx_i = int(np.argmax(gaps))
    arc_len = 180 - gaps[mx_i]
    if arc_len >= full_if_arc_ge:
        return 0, 179
    start = hs[(mx_i + 1) % n]
    end = hs[mx_i]
    if start <= end:
        return max(0, start - margin), min(179, end + margin)
    h_lo = max(0, start - margin)
    h_hi = min(179, end + margin)
    if h_lo <= h_hi:
        return 0, 179
    return h_lo, h_hi


def mask_close_short_gaps(mask_bool: np.ndarray, gap_px: int) -> np.ndarray:
    """Morphological close (ellipse) to bridge sub-pixel raster breaks before skeletonize.

    Kernel size ``min(63, 2*gap_px+1)`` preview pixels — larger spans break common anti-aliased gaps.
    """
    if gap_px <= 0:
        return mask_bool
    try:
        import cv2

        ksz = min(63, 2 * int(gap_px) + 1)
        if ksz < 3:
            return mask_bool
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ksz, ksz))
        u8 = (mask_bool.astype(np.uint8)) * 255
        u8 = cv2.morphologyEx(u8, cv2.MORPH_CLOSE, k)
        return u8 > 0
    except Exception:
        return mask_bool


def dilate_mask_cross(mask: np.ndarray, iterations: int) -> np.ndarray:
    """Expand True regions by ~1 px per iteration (3×3 cross); helps 1-pixel raster strokes before skeletonize."""
    if iterations <= 0:
        return mask
    try:
        import cv2

        u8 = (mask.astype(np.uint8)) * 255
        k = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
        u8 = cv2.dilate(u8, k, iterations=int(iterations))
        return u8 > 0
    except Exception:
        return mask


def morph_cleanup(mask: np.ndarray, iterations: int) -> np.ndarray:
    if iterations <= 0:
        return mask
    try:
        import cv2

        k = np.ones((3, 3), np.uint8)
        u8 = (mask.astype(np.uint8)) * 255
        u8 = cv2.morphologyEx(u8, cv2.MORPH_OPEN, k, iterations=iterations)
        u8 = cv2.morphologyEx(u8, cv2.MORPH_CLOSE, k, iterations=iterations)
        return u8 > 0
    except Exception:
        try:
            from scipy import ndimage

            m = ndimage.binary_opening(mask, iterations=iterations)
            return ndimage.binary_closing(m, iterations=iterations)
        except Exception:
            return mask


def _skeletonize_cv2_morph(mask_bool: np.ndarray):
    """Morphological skeleton — OpenCV only (no SciPy/skimage import chain)."""
    try:
        import cv2
    except ImportError:
        return None
    m = mask_bool.astype(bool)
    if not np.any(m):
        return m
    img = (m.astype(np.uint8) * 255)
    skel = np.zeros_like(img)
    kernel = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    while True:
        opened = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)
        temp = cv2.subtract(img, opened)
        eroded = cv2.erode(img, kernel)
        skel = cv2.bitwise_or(skel, temp)
        img = eroded.copy()
        if cv2.countNonZero(img) == 0:
            break
    out = skel.astype(bool)
    return out if np.any(out) else None


def _skeletonize_cv2_ximgproc(mask_bool: np.ndarray):
    """Zhang–Suen thinning via OpenCV contrib ximgproc when available."""
    try:
        import cv2
    except ImportError:
        return None
    xc = getattr(cv2, "ximgproc", None)
    if xc is None or not hasattr(xc, "thinning"):
        return None
    m = mask_bool.astype(bool)
    if not np.any(m):
        return m
    img = (m.astype(np.uint8) * 255)
    ttype = getattr(xc, "THINNING_ZHANGSUEN", 0)
    try:
        thin = xc.thinning(img, thinningType=ttype)
    except Exception:
        return None
    out = thin.astype(bool)
    return out if np.any(out) else None


def _zhang_suen_numpy_thin(bin_bool: np.ndarray) -> np.ndarray:
    """Classic Zhang–Suen thinning (pure NumPy). Neighbors P2..P9 clockwise from north."""
    X = bin_bool.astype(np.uint8).copy()
    X[~bin_bool] = 0
    X[bin_bool] = 1
    h, w = X.shape

    def neighbors_p2_p9(im, i, j):
        # P2=north … P9=northwest (clockwise)
        return [
            im[i - 1, j],
            im[i - 1, j + 1],
            im[i, j + 1],
            im[i + 1, j + 1],
            im[i + 1, j],
            im[i + 1, j - 1],
            im[i, j - 1],
            im[i - 1, j - 1],
        ]

    def transitions_a(p):
        seq = p + [p[0]]
        return sum(1 for k in range(8) if seq[k] == 0 and seq[k + 1] == 1)

    markers = np.zeros_like(X)
    while True:
        changed = False
        markers.fill(0)
        for i in range(1, h - 1):
            for j in range(1, w - 1):
                if X[i, j] != 1:
                    continue
                p = neighbors_p2_p9(X, i, j)
                b = int(sum(p))
                if b < 2 or b > 6:
                    continue
                if transitions_a(p) != 1:
                    continue
                if p[0] * p[2] * p[4] != 0:
                    continue
                if p[2] * p[4] * p[6] != 0:
                    continue
                markers[i, j] = 1
        if np.any(markers):
            X[markers.astype(bool)] = 0
            changed = True

        markers.fill(0)
        for i in range(1, h - 1):
            for j in range(1, w - 1):
                if X[i, j] != 1:
                    continue
                p = neighbors_p2_p9(X, i, j)
                b = int(sum(p))
                if b < 2 or b > 6:
                    continue
                if transitions_a(p) != 1:
                    continue
                if p[0] * p[2] * p[6] != 0:
                    continue
                if p[2] * p[4] * p[6] != 0:
                    continue
                markers[i, j] = 1
        if np.any(markers):
            X[markers.astype(bool)] = 0
            changed = True

        if not changed:
            break

    return X.astype(bool)


def skeletonize_mask(mask: np.ndarray) -> np.ndarray:
    """Skeletonize binary mask without importing skimage (avoids SciPy import crashes on some Windows QGIS builds)."""
    m = np.squeeze(np.asarray(mask, dtype=bool))
    if m.ndim != 2:
        raise ValueError(
            "skeletonize_mask expects a 2D boolean mask, got shape {}".format(m.shape)
        )
    if not np.any(m):
        return m


    # OpenCV contrib ximgproc.thinning has been observed to access-violation on Windows QGIS; prefer morph + NumPy there.
    if sys.platform == "win32":
        out = _skeletonize_cv2_morph(m)
        if out is not None:
            return out
        return _zhang_suen_numpy_thin(m)

    out = _skeletonize_cv2_ximgproc(m)
    if out is not None:
        return out

    out = _skeletonize_cv2_morph(m)
    if out is not None:
        return out

    return _zhang_suen_numpy_thin(m)


def _same_source_path(path_a: str, path_b: str) -> bool:
    if not path_a or not path_b:
        return False
    try:
        return os.path.normcase(os.path.abspath(path_a)) == os.path.normcase(
            os.path.abspath(path_b)
        )
    except OSError:
        return False


def _qgis_georef_raster_layer_type():
    """Qgis.LayerType value for rasters (name varies slightly by QGIS version)."""
    lt = getattr(Qgis, "LayerType", None)
    if lt is None:
        return None
    for name in ("RasterLayer", "Raster"):
        v = getattr(lt, name, None)
        if v is not None:
            return v
    return None


def pixel_path_to_xy(path, geo):
    """path: list of (col, row) in processing pixel space, origin top-left."""
    xmin, xmax = geo["xmin"], geo["xmax"]
    ymin, ymax = geo["ymin"], geo["ymax"]
    w, h = geo["w"], geo["h"]
    gw = xmax - xmin
    gh = ymax - ymin
    out = []
    for pt in path:
        if not isinstance(pt, (list, tuple)) or len(pt) < 2:
            raise ValueError("invalid pixel path vertex {!r}".format(pt))
        col, row = int(pt[0]), int(pt[1])
        x = xmin + (float(col) + 0.5) * gw / float(w)
        y = ymax - (float(row) + 0.5) * gh / float(h)
        out.append(QgsPointXY(x, y))
    return out


def _qimage_from_rgb888_numpy(rgb_u8: np.ndarray) -> QImage:
    """RGB888 ``QImage`` with row stride aligned to 4 bytes (Qt requirement for Format_RGB888).

    Without padding, ``3 * width`` often is not a multiple of 4 → ``QImage`` is null and the preview stays blank.
    """
    rgb_u8 = np.ascontiguousarray(rgb_u8, dtype=np.uint8)
    if rgb_u8.ndim != 3 or rgb_u8.shape[2] != 3:
        raise ValueError("expected HxWx3 uint8 RGB, got {!r}".format(getattr(rgb_u8, "shape", None)))
    h, w, _ = rgb_u8.shape
    bpl_src = w * 3
    bpl = (bpl_src + 3) & ~3
    if bpl == bpl_src:
        return QImage(bytes(rgb_u8.tobytes()), w, h, bpl, QImage.Format_RGB888).copy()
    buf = np.zeros((h, bpl), dtype=np.uint8)
    buf[:, :bpl_src] = rgb_u8.reshape(h, bpl_src)
    return QImage(bytes(buf.tobytes()), w, h, bpl, QImage.Format_RGB888).copy()


def polylines_from_skeleton(skel: np.ndarray):
    """Extract paths as lists of (x,y) pixel coords from boolean skeleton."""
    skel = np.squeeze(np.asarray(skel))
    if skel.ndim != 2:
        raise ValueError(
            "Skeleton must be a 2D mask, got shape {}".format(getattr(skel, "shape", None))
        )
    skel = skel.astype(bool)
    ys, xs = np.nonzero(skel)
    if len(xs) == 0:
        return []

    pos_set = set((int(xs[i]), int(ys[i])) for i in range(int(xs.shape[0])))
    nbrs = [
        (-1, -1),
        (-1, 0),
        (-1, 1),
        (0, -1),
        (0, 1),
        (1, -1),
        (1, 0),
        (1, 1),
    ]

    def degree(px, py):
        d = 0
        for dx, dy in nbrs:
            if (int(px + dx), int(py + dy)) in pos_set:
                d += 1
        return d

    junctions = set()
    endpoints = set()
    for x, y in pos_set:
        dd = degree(x, y)
        if dd == 1:
            endpoints.add((x, y))
        elif dd > 2:
            junctions.add((x, y))

    starts = endpoints | junctions
    if not starts:
        starts = {(int(xs[0]), int(ys[0]))}

    visited_edge = set()
    polylines_pix = []

    def edge_key(a, b):
        return tuple(sorted([a, b]))

    for start in starts:
        for dx, dy in nbrs:
            nb = (int(start[0] + dx), int(start[1] + dy))
            if nb not in pos_set:
                continue
            ek = edge_key(start, nb)
            if ek in visited_edge:
                continue
            path = [start]
            prev = start
            cur = nb
            visited_edge.add(ek)
            while True:
                path.append(cur)
                if cur in junctions or cur in endpoints:
                    break
                nxt_opts = []
                for ox, oy in nbrs:
                    cand = (int(cur[0] + ox), int(cur[1] + oy))
                    if cand in pos_set and cand != prev:
                        nxt_opts.append(cand)
                if len(nxt_opts) != 1:
                    break
                visited_edge.add(edge_key(prev, cur))
                nxt = nxt_opts[0]
                if not isinstance(nxt, tuple) or len(nxt) != 2:
                    raise ValueError("invalid skeleton neighbor {!r}".format(nxt))
                prev, cur = cur, (int(nxt[0]), int(nxt[1]))
            if len(path) >= 2:
                polylines_pix.append(path)

    return polylines_pix


def _normalize_pix_polyline(path):
    """Coerce skeleton vertices to plain Python (int, int) pairs (avoids numpy scalar edge cases)."""
    out = []
    if not path:
        return out
    for pt in path:
        try:
            out.append((int(pt[0]), int(pt[1])))
        except (TypeError, ValueError, IndexError):
            continue
    return out


def _approx_dp_simplify_polyline_xy(points, epsilon):
    """Douglas–Peucker in map units (OpenCV). Used when Qgs simplify is skipped (fragment cap)."""
    if epsilon is None or epsilon <= 0 or len(points) < 3:
        return points
    try:
        import cv2

        arr = np.array(
            [[float(p.x()), float(p.y())] for p in points], dtype=np.float64
        ).reshape(-1, 1, 2)
        approx = cv2.approxPolyDP(arr, float(epsilon), False)
        if approx is None or len(approx) < 2:
            return points
        return [QgsPointXY(float(r[0][0]), float(r[0][1])) for r in approx]
    except Exception:
        return points


def _sample_fg_points_from_bool_mask(mask: np.ndarray, max_pts: int):
    """Pick spread-out foreground coordinates inside a boolean mask (preview pixels).

    Grid-stratified centroids so SAM gets coverage without hundreds of manual clicks.
    """
    m = np.squeeze(np.asarray(mask, dtype=bool))
    if m.ndim != 2 or not np.any(m):
        return []
    H, W = int(m.shape[0]), int(m.shape[1])
    target = max(8, min(int(max_pts), 400))
    cell = max(6, int(np.sqrt((H * W) / float(target))))
    out = []
    for y0 in range(0, H, cell):
        y1 = min(H, y0 + cell)
        for x0 in range(0, W, cell):
            x1 = min(W, x0 + cell)
            sub = m[y0:y1, x0:x1]
            if not np.any(sub):
                continue
            ys, xs = np.nonzero(sub)
            cy = int(round(float(np.mean(ys)))) + y0
            cx = int(round(float(np.mean(xs)))) + x0
            cy = int(np.clip(cy, 0, H - 1))
            cx = int(np.clip(cx, 0, W - 1))
            out.append((cx, cy))
            if len(out) >= target:
                return out
    return out


def _dedupe_points_min_dist(points, min_dist_px: float):
    """Drop points closer than ``min_dist_px`` (keep earlier)."""
    if len(points) < 2:
        return points
    md = float(max(1.0, min_dist_px))
    md2 = md * md
    kept = []
    for p in points:
        x, y = float(p[0]), float(p[1])
        if all((x - float(q[0])) ** 2 + (y - float(q[1])) ** 2 >= md2 for q in kept):
            kept.append((x, y))
    return kept


def _approx_dp_simplify_pixel_path(path, eps_px):
    """Douglas–Peucker in preview-pixel space — removes 8-connected skeleton zigzag / “triangle” stairsteps."""
    if eps_px <= 0 or len(path) < 4:
        return path
    try:
        import cv2

        arr = np.array(
            [[float(pt[0]), float(pt[1])] for pt in path], dtype=np.float64
        ).reshape(-1, 1, 2)
        approx = cv2.approxPolyDP(arr, float(eps_px), False)
        if approx is None or len(approx) < 2:
            return path
        return [(int(round(r[0][0])), int(round(r[0][1]))) for r in approx]
    except Exception:
        return path


# Color-mask vectorize loads full preview resolution; huge masks exhaust RAM / crash embedded QGIS.
_MAX_VECTORIZE_MASK_PIXELS = 2_500_000
# Hard cap: downstream pixel→map + QgsGeometry simplify runs per fragment; large counts AV-crash QGIS on Windows.
_MAX_SKELETON_POLYLINE_FRAGMENTS = 4_000
# Above this, skip Douglas–Peucker in QgsGeometry (native); keep raw stair-step chains.
_MAX_QGS_SIMPLIFY_FRAGMENTS = 800


def merge_skeleton_polylines(paths, tol_px: int):
    """Coerce skeleton polylines to plain ``(int, int)`` vertices.

    Endpoint stitching after skeletonize was removed (Windows AV in the old iterative merge).
    Use **Join fragment gaps** instead: it runs morphological **close** on the mask before
    skeletonize (see ``mask_close_short_gaps``). ``tol_px`` is kept for logging only.
    """
    if not paths:
        return paths
    out = [_normalize_pix_polyline(p) for p in paths]
    out = [p for p in out if len(p) >= 2]
    return out


class SamPredictWorker(QThread):
    finished_ok = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, rgb: np.ndarray, points_xy: list, labels: list, checkpoint_path: str):
        super().__init__()
        self.rgb = rgb
        self.points_xy = points_xy
        self.labels = labels
        self.checkpoint_path = checkpoint_path

    def run(self):
        try:
            _configure_torch_embedded_env()
            import torch
            from segment_anything import SamPredictor, sam_model_registry
        except Exception as e:
            self.failed.emit(format_sam_dependency_help(str(e)))
            return

        ckpt = self.checkpoint_path
        if not ckpt or not os.path.isfile(ckpt):
            self.failed.emit(f"SAM checkpoint not found:\n{ckpt}")
            return

        try:
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            sam = sam_model_registry["vit_b"](checkpoint=ckpt)
            sam.to(device=device)
            sam.eval()
            predictor = SamPredictor(sam)
            img = self.rgb.astype(np.uint8)
            predictor.set_image(img)
            pts = np.array(self.points_xy, dtype=np.float32)
            lbs = np.array(self.labels, dtype=np.int32)
            masks, scores, _ = predictor.predict(
                point_coords=pts,
                point_labels=lbs,
                multimask_output=True,
            )
            best = int(np.argmax(scores))
            mask = masks[best].astype(bool)
            self.finished_ok.emit(mask)
        except Exception as e:
            self.failed.emit(str(e))


class PreviewLabel(QLabel):
    """Shows pixmap; maps clicks to image pixel coordinates."""

    clicked_pix = pyqtSignal(int, int, object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumSize(420, 280)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMouseTracking(True)
        self._img_w = 0
        self._img_h = 0
        self._zoom_callback = None

    def set_image_shape(self, iw, ih):
        self._img_w = iw
        self._img_h = ih

    @staticmethod
    def _pixmap_layout_px(pm):
        """Logical pixel size of pixmap as painted inside QLabel (HiDPI-safe)."""
        if pm is None or pm.isNull():
            return 0.0, 0.0
        dpr = float(pm.devicePixelRatio())
        if dpr <= 0:
            dpr = 1.0
        # Qt reports layout size in device-independent pixels when devicePixelRatio > 1.
        return pm.width() / dpr, pm.height() / dpr

    def mousePressEvent(self, event):
        if self._img_w <= 0 or self._img_h <= 0:
            return
        pm = self.pixmap()
        if pm is None or pm.isNull():
            return
        disp_w, disp_h = self._pixmap_layout_px(pm)
        if disp_w <= 0 or disp_h <= 0:
            return
        cr = self.contentsRect()
        # Center pixmap in label; offset may be negative when pixmap is larger than widget (clipped).
        # Logs proved max(0,…) forced y0=0 for a 542px pixmap in a 318px label → vertical mis-hit (H1/H4).
        x0 = float(cr.left()) + (float(cr.width()) - disp_w) / 2.0
        y0 = float(cr.top()) + (float(cr.height()) - disp_h) / 2.0
        pos = event.pos()
        lx = float(pos.x()) - x0
        ly = float(pos.y()) - y0
        if lx < 0 or ly < 0 or lx >= disp_w or ly >= disp_h:
            return
        ix = int(lx / disp_w * float(self._img_w))
        iy = int(ly / disp_h * float(self._img_h))
        ix = max(0, min(self._img_w - 1, ix))
        iy = max(0, min(self._img_h - 1, iy))
        self.clicked_pix.emit(ix, iy, event.button())

    def wheelEvent(self, event):
        cb = getattr(self, "_zoom_callback", None)
        if cb is not None and self._img_w > 0:
            cb(event.angleDelta().y())
            event.accept()
            return
        super(PreviewLabel, self).wheelEvent(event)


class SamPipelineDialog(QDialog):
    """SAM-assisted raster → line extraction for pipeline maps."""

    def __init__(self, plugin, parent=None):
        super().__init__(parent)
        self._plugin = plugin
        self._iface = plugin.iface if plugin is not None else None
        self._rgb = None
        self._geo = None
        self._temp_file_layer = None
        self._file_path = None
        self._sam_mask = None
        self._points = []
        self._labels = []
        self._prompt_colors = []
        # Bulk FG prompts for SAM only (not listed); merged at Run SAM.
        self._auto_sam_fg_xy = []
        self._worker = None
        self._pip_worker = None
        self._pip_busy = False
        self._last_polylines = []
        self._last_vector_layers = None  # list[tuple[str, list, QColor]] or None for single-layer export
        self._last_single_trace_line_color = None  # QColor for single-layer Add to map symbology
        self._last_trace_was_color_mask_only = False
        self._trace_state_blob_applied = ""
        # When False, flush_trace_state_to_project will not overwrite a non-empty saved blob with empty prompts.
        self._trace_allow_empty_flush = False

        self.setWindowTitle(self.tr("Raster trace (Segment Anything)"))
        self.resize(880, 680)

        root = QVBoxLayout(self)

        lay_file = QHBoxLayout()
        self.btn_open_raster = QPushButton(self.tr("Open raster image…"))
        self.btn_open_raster.clicked.connect(self._open_raster_file)
        lay_file.addWidget(self.btn_open_raster)
        self.lbl_raster_path = QLabel(self.tr("No image loaded"))
        self.lbl_raster_path.setWordWrap(True)
        self.lbl_raster_path.setMinimumHeight(22)
        lay_file.addWidget(self.lbl_raster_path, 1)
        root.addLayout(lay_file)

        lay_georef = QHBoxLayout()
        self.btn_georef = QPushButton(
            self.tr("Add raster to project & open Georeferencer…")
        )
        self.btn_georef.setToolTip(
            self.tr(
                "Adds the current image to the map (if it is not already there) and opens "
                "the Georeferencer so you can assign real-world coordinates before tracing."
            )
        )
        self.btn_georef.clicked.connect(self._on_open_georeferencer)
        lay_georef.addWidget(self.btn_georef)
        lay_georef.addStretch(1)
        root.addLayout(lay_georef)

        lay_layer = QHBoxLayout()
        lay_layer.addWidget(QLabel(self.tr("Or project layer:")))
        self.cmb_layer = QgsMapLayerComboBox()
        self.cmb_layer.setFilters(QgsMapLayerProxyModel.RasterLayer)
        self.cmb_layer.layerChanged.connect(self._on_layer_changed)
        lay_layer.addWidget(self.cmb_layer, 1)
        self.btn_reload = QPushButton(self.tr("Reload preview"))
        self.btn_reload.clicked.connect(self._reload_preview)
        lay_layer.addWidget(self.btn_reload)
        root.addLayout(lay_layer)

        ck_layout = QHBoxLayout()
        ck_layout.addWidget(QLabel(self.tr("SAM checkpoint:")))
        self.ed_ckpt = QLabel("")
        self.ed_ckpt.setWordWrap(True)
        ck_layout.addWidget(self.ed_ckpt, 1)
        self.btn_ckpt = QPushButton(self.tr("Browse…"))
        self.btn_ckpt.clicked.connect(self._browse_checkpoint)
        ck_layout.addWidget(self.btn_ckpt)
        self.btn_dl = QPushButton(self.tr("Download ViT-B"))
        self.btn_dl.clicked.connect(self._download_checkpoint)
        ck_layout.addWidget(self.btn_dl)
        root.addLayout(ck_layout)

        grp_mask = QGroupBox(self.tr("Color mask (optional, helps isolate pipe ink)"))
        fm = QGridLayout()
        self.chk_show_mask = QCheckBox(self.tr("Show mask overlay"))
        self.chk_show_mask.setChecked(True)
        self.chk_show_mask.setToolTip(
            self.tr(
                "Tint green where pixels fall inside the Hue/Sat/Val range (and after Invert if checked). "
                "That is the same True/False mask used when intersecting with SAM."
            )
        )
        self.chk_show_mask.stateChanged.connect(lambda *_: self._compose_preview())
        self.chk_apply_mask = QCheckBox(self.tr("Intersect SAM result with color mask"))
        self.chk_apply_mask.setChecked(True)
        self.chk_invert = QCheckBox(self.tr("Invert mask"))
        self.chk_invert.stateChanged.connect(lambda *_: self._compose_preview())

        # Defaults: full hue + moderate saturation floor — works better for multi-color pipeline maps
        # than a narrow green band (old defaults required invert + fiddling).
        self.sl_h0 = self._mk_slider(0, 179, 0)
        self.sl_h1 = self._mk_slider(0, 179, 179)
        self.sl_s0 = self._mk_slider(0, 255, 35)
        self.sl_s1 = self._mk_slider(0, 255, 255)
        self.sl_v0 = self._mk_slider(0, 255, 20)
        self.sl_v1 = self._mk_slider(0, 255, 255)
        self.sp_morph = QSpinBox()
        self.sp_morph.setRange(0, 8)
        self.sp_morph.setValue(1)
        self.sp_morph.setToolTip(
            self.tr(
                "Whole-number only: each unit runs one 3×3 morphological open then close on the mask. "
                "OpenCV does not support fractional iterations — there is nothing a decimal could mean here. "
                "0 = no cleanup (keeps every noisy pixel and fragile 1 px lines in the mask); "
                "1+ removes specks but can erase very thin strokes. Use “Trace dilate” below if lines vanish."
            )
        )
        self.sp_trace_dilate = QSpinBox()
        self.sp_trace_dilate.setRange(0, 3)
        self.sp_trace_dilate.setValue(0)
        self.sp_trace_dilate.setToolTip(
            self.tr(
                "Applied only when vectorizing: expands the traced mask by about 1 pixel per step (cross kernel) "
                "before skeletonizing. Use 1–2 when source lines are a single pixel wide or broken into dots; "
                "leave 0 if lines are already thick in the preview."
            )
        )
        self.sp_line_smooth = QDoubleSpinBox()
        self.sp_line_smooth.setRange(0.0, 4.0)
        self.sp_line_smooth.setDecimals(2)
        self.sp_line_smooth.setSingleStep(0.1)
        self.sp_line_smooth.setValue(1.05)
        self.sp_line_smooth.setToolTip(
            self.tr(
                "Smoothing in two stages: first trims skeleton zigzag in preview pixels (≈0.5× this value), "
                "then Douglas–Peucker in map units (this × pixel width). Higher = smoother but less detail. "
                "0 = skip both (raw stair-steps)."
            )
        )
        self.sp_join_gap = QSpinBox()
        self.sp_join_gap.setRange(0, 24)
        self.sp_join_gap.setValue(4)
        self.sp_join_gap.setToolTip(
            self.tr(
                "Before skeletonize: morphological close on the mask to bridge gaps in raster strokes. "
                "If Trace dilate is 0, a small cross-dilate is applied first from this value so thin lines reconnect. "
                "Try 8–14 for messy scans; reduce if unrelated colors merge."
            )
        )
        self.sp_fg_bleed = QSpinBox()
        self.sp_fg_bleed.setRange(0, 90)
        self.sp_fg_bleed.setValue(0)
        self.sp_fg_bleed.setToolTip(
            self.tr(
                "Multi-color vectorize only: widens each Foreground click’s HSV box so similar inks "
                "(lighter/darker or slightly off-hue) still match that color layer. "
                "The Hue/Sat/Val sliders above still gate the overall mask (green overlay); this only relaxes "
                "per-click matching when splitting orange vs purple vs green. Raise if lines are missing; lower if colors bleed together."
            )
        )
        for w in (
            self.sl_h0,
            self.sl_h1,
            self.sl_s0,
            self.sl_s1,
            self.sl_v0,
            self.sl_v1,
            self.sp_morph,
            self.chk_invert,
        ):
            if hasattr(w, "valueChanged"):
                w.valueChanged.connect(lambda *_: self._compose_preview())

        r = 0
        fm.addWidget(self.chk_show_mask, r, 0, 1, 4)
        r += 1
        fm.addWidget(self.chk_apply_mask, r, 0, 1, 4)
        r += 1
        self.chk_trace_color_only = QCheckBox(
            self.tr("Trace from color mask only (skip SAM)")
        )
        self.chk_trace_color_only.setToolTip(
            self.tr(
                "Vectorize lines directly from the Hue/Sat/Val mask (green overlay). "
                "No SAM clicks or PyTorch run — widen the mask until green covers the ink you want, then Vectorize."
            )
        )
        self.chk_trace_color_only.stateChanged.connect(self._on_trace_color_only_changed)
        fm.addWidget(self.chk_trace_color_only, r, 0, 1, 4)
        r += 1
        fm.addWidget(self.chk_invert, r, 0, 1, 4)
        r += 1
        self.lbl_mask_overlay_hint = QLabel(
            self.tr(
                "Green overlay: pixels inside your Hue/Sat/Val range — those pixels are “selected” for the mask. "
                "Where there is no green, that pixel fails the mask (excluded). "
                "With “Intersect SAM result with color mask” on, only overlap between SAM’s region and green stays."
            )
        )
        self.lbl_mask_overlay_hint.setWordWrap(True)
        self.lbl_mask_overlay_hint.setStyleSheet("font-size: 11px; color: palette(mid);")
        fm.addWidget(self.lbl_mask_overlay_hint, r, 0, 1, 4)
        r += 1
        hint = QLabel(
            self.tr(
                "Multi-color lines: keep hue 0–179 or use Auto-tune. "
                "If one ink (e.g. purple) never turns green, add a Foreground click on that line "
                "and use “Tune mask from foreground prompts”."
            )
        )
        hint.setWordWrap(True)
        fm.addWidget(hint, r, 0, 1, 4)
        r += 1
        tune_btns = QWidget()
        tune_btns_lay = QHBoxLayout(tune_btns)
        tune_btns_lay.setContentsMargins(0, 0, 0, 0)
        self.btn_auto_mask = QPushButton(self.tr("Auto-tune mask from image colors"))
        self.btn_auto_mask.setToolTip(
            self.tr(
                "Sets saturation/value thresholds from this image so colored ink is kept "
                "and pale map background is dropped (still adjustable)."
            )
        )
        self.btn_auto_mask.clicked.connect(self._auto_tune_color_mask)
        tune_btns_lay.addWidget(self.btn_auto_mask)
        self.btn_tune_mask_from_prompts = QPushButton(
            self.tr("Tune mask from foreground prompts")
        )
        self.btn_tune_mask_from_prompts.setToolTip(
            self.tr(
                "Uses the colors under your foreground (pipeline) clicks on the preview — "
                "sets Hue/Sat/Val to include those inks with margins. "
                "Background-only clicks are ignored here; switch “Next click” to Foreground first. "
                "Use this when one color (e.g. purple) never turns green with global Auto-tune."
            )
        )
        self.btn_tune_mask_from_prompts.clicked.connect(self._auto_tune_mask_from_prompt_colors)
        tune_btns_lay.addWidget(self.btn_tune_mask_from_prompts)
        fm.addWidget(tune_btns, r, 0, 1, 4)
        r += 1
        fm.addWidget(QLabel(self.tr("Hue min / max (0–179)")), r, 0)
        fm.addWidget(self.sl_h0, r, 1)
        fm.addWidget(self.sl_h1, r, 2)
        r += 1
        fm.addWidget(QLabel(self.tr("Sat min / max")), r, 0)
        fm.addWidget(self.sl_s0, r, 1)
        fm.addWidget(self.sl_s1, r, 2)
        r += 1
        fm.addWidget(
            QLabel(self.tr("Val min / max (brightness / lightness in HSV, 0–255)")),
            r,
            0,
        )
        fm.addWidget(self.sl_v0, r, 1)
        fm.addWidget(self.sl_v1, r, 2)
        r += 1
        fm.addWidget(QLabel(self.tr("Morph clean (open/close iters)")), r, 0)
        fm.addWidget(self.sp_morph, r, 1)
        r += 1
        fm.addWidget(QLabel(self.tr("Trace dilate (px before skeletonize, 0=off)")), r, 0)
        fm.addWidget(self.sp_trace_dilate, r, 1)
        r += 1
        fm.addWidget(QLabel(self.tr("Line smooth (× px width, 0=raw jagged)")), r, 0)
        fm.addWidget(self.sp_line_smooth, r, 1)
        r += 1
        fm.addWidget(QLabel(self.tr("Join fragment gaps (px, 0=off)")), r, 0)
        fm.addWidget(self.sp_join_gap, r, 1)
        r += 1
        fm.addWidget(
            QLabel(self.tr("Extra FG color tolerance (±HSV, multi-color trace)")),
            r,
            0,
        )
        fm.addWidget(self.sp_fg_bleed, r, 1)
        grp_mask.setLayout(fm)

        self._preview_zoom = 1.0

        mask_prompt_row = QWidget()
        mpr_lay = QHBoxLayout(mask_prompt_row)
        mpr_lay.setContentsMargins(0, 0, 0, 0)

        prompt_sidebar = QWidget()
        prompt_sidebar.setMinimumWidth(200)
        prompt_sidebar.setMaximumWidth(320)
        v_pts = QVBoxLayout(prompt_sidebar)
        v_pts.setContentsMargins(8, 0, 0, 0)
        v_pts.addWidget(QLabel(self.tr("SAM click prompts")))
        v_pts.addWidget(
            QLabel(
                self.tr(
                    "SAM finds one region guided by clicks — not every matching color. "
                    "Click on real pipeline strokes on the map in the preview. "
                    "Right-click a row to remove."
                )
            )
        )
        hl = QHBoxLayout()
        self.cmb_click_mode = QComboBox()
        self.cmb_click_mode.addItem(self.tr("Foreground (pipeline)"), 1)
        self.cmb_click_mode.addItem(self.tr("Background"), 0)
        hl.addWidget(QLabel(self.tr("Next click:")))
        hl.addWidget(self.cmb_click_mode, 1)
        v_pts.addLayout(hl)
        _lbl_bg_hint = QLabel(
            self.tr(
                "Background clicks remove those ink colors from the color mask — use them only on map paper/water, "
                "never on pipeline colors you want to trace."
            )
        )
        _lbl_bg_hint.setWordWrap(True)
        v_pts.addWidget(_lbl_bg_hint)
        self.lst_prompts = QListWidget()
        self.lst_prompts.setMinimumHeight(220)
        self.lst_prompts.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.lst_prompts.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.lst_prompts.setSelectionMode(QAbstractItemView.SingleSelection)
        self.lst_prompts.setContextMenuPolicy(Qt.CustomContextMenu)
        self.lst_prompts.customContextMenuRequested.connect(self._on_prompt_list_context_menu)
        v_pts.addWidget(self.lst_prompts, 1)
        rm_row = QHBoxLayout()
        self.btn_clear_pts = QPushButton(self.tr("Clear all"))
        self.btn_clear_pts.clicked.connect(self._clear_points)
        self.btn_remove_prompt = QPushButton(self.tr("Remove selected"))
        self.btn_remove_prompt.clicked.connect(self._remove_selected_prompt)
        rm_row.addWidget(self.btn_clear_pts)
        rm_row.addWidget(self.btn_remove_prompt)
        v_pts.addLayout(rm_row)

        auto_row = QHBoxLayout()
        self.sp_auto_fg_prompts = QSpinBox()
        self.sp_auto_fg_prompts.setRange(16, 256)
        self.sp_auto_fg_prompts.setValue(80)
        self.sp_auto_fg_prompts.setToolTip(
            self.tr(
                "Upper bound on SAM-only FG points from “Auto FG from mask” (not listed). "
                "More points can help SAM cover large maps; fewer runs faster."
            )
        )
        self.btn_auto_fg_from_mask = QPushButton(self.tr("Auto FG prompts from color mask"))
        self.btn_auto_fg_from_mask.setToolTip(
            self.tr(
                "Requires at least one manual foreground click per pipeline ink color first (those define "
                "which hues count as pipelines). Stores extra FG points for SAM only — they do not appear "
                "in the list. Matching uses the same HSV margins as multi-color trace plus “Extra FG color tolerance”. "
                "Each Run SAM still produces one segment mask — widely separated networks may need color-only trace or crops."
            )
        )
        self.btn_auto_fg_from_mask.clicked.connect(self._auto_fg_prompts_from_color_mask)
        self.btn_clear_auto_fg = QPushButton(self.tr("Clear auto FG"))
        self.btn_clear_auto_fg.setToolTip(
            self.tr(
                "Removes auto-generated SAM foreground points only. Manual prompts in the list are unchanged."
            )
        )
        self.btn_clear_auto_fg.clicked.connect(self._clear_auto_sam_fg)
        auto_row.addWidget(QLabel(self.tr("Auto FG max")))
        auto_row.addWidget(self.sp_auto_fg_prompts)
        auto_row.addWidget(self.btn_auto_fg_from_mask)
        auto_row.addWidget(self.btn_clear_auto_fg)
        v_pts.addLayout(auto_row)

        mpr_lay.addWidget(grp_mask, 3)
        mpr_lay.addWidget(prompt_sidebar, 0)
        root.addWidget(mask_prompt_row)

        grp_preview_row = QGroupBox(self.tr("Preview"))
        v_prev = QVBoxLayout(grp_preview_row)
        zoom_row = QHBoxLayout()
        zoom_row.addWidget(QLabel(self.tr("Zoom")))
        self.btn_zoom_out = QPushButton(self.tr("−"))
        self.btn_zoom_out.setFixedWidth(28)
        self.btn_zoom_out.setToolTip(self.tr("Zoom preview out"))
        self.slider_preview_zoom = QSlider(Qt.Horizontal)
        self.slider_preview_zoom.setRange(50, 400)
        self.slider_preview_zoom.setValue(100)
        self.slider_preview_zoom.setToolTip(
            self.tr("Preview zoom — does not change raster resolution (see Max raster side).")
        )
        self.btn_zoom_in = QPushButton(self.tr("+"))
        self.btn_zoom_in.setFixedWidth(28)
        self.btn_zoom_in.setToolTip(self.tr("Zoom preview in"))
        self.btn_zoom_reset = QPushButton(self.tr("100%"))
        self.btn_zoom_reset.setToolTip(self.tr("Reset preview zoom"))
        zoom_row.addWidget(self.btn_zoom_out)
        zoom_row.addWidget(self.slider_preview_zoom, 1)
        zoom_row.addWidget(self.btn_zoom_in)
        zoom_row.addWidget(self.btn_zoom_reset)
        v_prev.addLayout(zoom_row)
        self.lbl_sam_hint = QLabel(
            self.tr(
                "Weak mask: widen Hue/Sat/Val or Auto-tune. "
                "If land lines disappear after Run SAM, turn off “Intersect SAM result with color mask”. "
                "Scroll the mouse wheel over the preview image to zoom."
            )
        )
        self.lbl_sam_hint.setWordWrap(True)
        self.lbl_sam_hint.setStyleSheet("color: palette(mid); font-size: 11px;")
        v_prev.addWidget(self.lbl_sam_hint)

        self.preview = PreviewLabel()
        self.preview.clicked_pix.connect(self._on_preview_click)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setAlignment(Qt.AlignCenter)
        scroll.setWidget(self.preview)
        scroll.setMinimumHeight(260)
        scroll.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        scroll.setToolTip(
            self.tr(
                "Scroll the mouse wheel over the preview image to zoom in or out. "
                "When zoomed in, drag the scrollbars to pan."
            )
        )
        v_prev.addWidget(scroll, 1)

        self.btn_zoom_out.clicked.connect(self._on_preview_zoom_out)
        self.btn_zoom_in.clicked.connect(self._on_preview_zoom_in)
        self.btn_zoom_reset.clicked.connect(self._on_preview_zoom_reset)
        self.slider_preview_zoom.valueChanged.connect(self._on_preview_zoom_slider)

        root.addWidget(grp_preview_row, 1)

        self.preview._zoom_callback = self._on_preview_wheel_zoom

        self.lbl_status = QLabel("")
        self.lbl_status.setWordWrap(True)
        root.addWidget(self.lbl_status)

        mx = QHBoxLayout()
        self.sp_max_side = QSpinBox()
        self.sp_max_side.setRange(256, 8192)
        self.sp_max_side.setSingleStep(128)
        self.sp_max_side.setValue(1024)
        mx.addWidget(QLabel(self.tr("Max raster side (px)")))
        mx.addWidget(self.sp_max_side)
        mx.addStretch(1)
        root.addLayout(mx)

        btn_row = QHBoxLayout()
        self.btn_install_sam_stack = QPushButton(self.tr("Install SAM stack (automatic)…"))
        self.btn_install_sam_stack.clicked.connect(self._on_install_sam_stack_clicked)
        btn_row.addWidget(self.btn_install_sam_stack)
        self.btn_sam_deps_help = QPushButton(self.tr("Manual install help…"))
        self.btn_sam_deps_help.clicked.connect(self._show_sam_dependency_help)
        btn_row.addWidget(self.btn_sam_deps_help)
        self.btn_run_sam = QPushButton(self.tr("Run SAM"))
        self.btn_run_sam.clicked.connect(self._run_sam)
        btn_row.addWidget(self.btn_run_sam)
        self.btn_vectorize = QPushButton(self.tr("Vectorize lines"))
        self.btn_vectorize.clicked.connect(self._vectorize)
        btn_row.addWidget(self.btn_vectorize)
        self.btn_save_prompts_to_project = QPushButton(self.tr("Save prompts to project"))
        self.btn_save_prompts_to_project.setToolTip(
            self.tr(
                "Stores prompts, colors, mask sliders, and raster source in the current QGIS project. "
                "Use File → Save project so the .qgs/.qgz file on disk is updated."
            )
        )
        self.btn_save_prompts_to_project.clicked.connect(self._on_save_prompts_to_project_clicked)
        btn_row.addWidget(self.btn_save_prompts_to_project)
        self.btn_add_map = QPushButton(self.tr("Add lines to map"))
        self.btn_add_map.clicked.connect(self._add_to_map)
        btn_row.addWidget(self.btn_add_map)
        root.addLayout(btn_row)

        bb = QDialogButtonBox(QDialogButtonBox.Close)
        bb.rejected.connect(self.reject)
        bb.accepted.connect(self.accept)
        ok = bb.button(QDialogButtonBox.Ok)
        if ok is not None:
            ok.hide()
        root.addWidget(bb)

        self._checkpoint_path = self._default_checkpoint_path()
        self._sync_ckpt_label()
        self._apply_sam_dependency_state()
        self._on_trace_color_only_changed()

    def _color_only_mode(self):
        return (
            getattr(self, "chk_trace_color_only", None) is not None
            and self.chk_trace_color_only.isChecked()
        )

    def _on_trace_color_only_changed(self, *_args):
        only = self._color_only_mode()
        if getattr(self, "chk_apply_mask", None) is not None:
            self.chk_apply_mask.setEnabled(not only)
            self.chk_apply_mask.setToolTip(
                ""
                if not only
                else self.tr("Only used when Segment Anything runs — disabled in color-mask-only mode.")
            )
        if only:
            self._sam_mask = None
            self._compose_preview()
        deps_ok = getattr(self, "_sam_deps_ok", False)
        if getattr(self, "btn_run_sam", None) is not None:
            self.btn_run_sam.setEnabled(deps_ok and not only)
        if getattr(self, "btn_vectorize", None) is not None:
            self.btn_vectorize.setToolTip(
                self.tr(
                    "Skeletonize the green mask region and build line paths — no SAM required."
                )
                if only
                else self.tr("Skeletonize the orange SAM region into line paths.")
            )

    def _apply_sam_dependency_state(self):
        ok, detail = sam_dependencies_available()
        self._sam_deps_ok = ok
        only = self._color_only_mode()
        self.btn_run_sam.setEnabled(ok and not only)
        self.btn_install_sam_stack.setEnabled(not self._pip_busy)
        if ok:
            self.lbl_status.setToolTip("")
            return
        self.lbl_status.setToolTip(detail)
        # Don’t wipe “Loaded …×…” when a raster is already open (showEvent runs after reload).
        if self._rgb is not None:
            return
        head = (detail or "").strip().split("\n")[0].strip()
        if not head:
            head = self.tr("(see tooltip)")
        elif len(head) > 160:
            head = head[:157] + "…"
        short = self.tr(
            "SAM not ready — {0} Hover for full detail, or use “Manual install help…”."
        ).format(head)
        self.lbl_status.setText(short)

    def _on_install_sam_stack_clicked(self):
        if self._sam_deps_ok:
            QMessageBox.information(
                self,
                self.tr("SAM stack"),
                self.tr(
                    "PyTorch and segment_anything are already available. "
                    "You can use Run SAM (after loading an image and the checkpoint)."
                ),
            )
            return
        ret = QMessageBox.question(
            self,
            self.tr("Install SAM stack"),
            self.tr(
                "This downloads PyTorch + torchvision (CPU builds), Meta’s segment_anything, "
                "scikit-image, and OpenCV into your user profile for QGIS’s Python only.\n\n"
                "PyTorch can pull in many wheels; the installer pins NumPy to the version QGIS is "
                "already using to reduce the chance that Python inside QGIS breaks after a restart.\n\n"
                "You need an internet connection. It can take several minutes and use several hundred MB.\n\n"
                "Do not close this dialog until installation finishes.\n\n"
                "Continue?"
            ),
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes,
        )
        if ret != QMessageBox.Yes:
            return
        self._pip_busy = True
        self.btn_install_sam_stack.setEnabled(False)
        self.btn_sam_deps_help.setEnabled(False)
        self.btn_run_sam.setEnabled(False)
        self.lbl_status.setText(self.tr("Installing packages — please wait (can take many minutes)…"))

        self._pip_worker = SamDepsPipWorker(pip_constraint_file=_numpy_constraint_file_for_pip())
        self._pip_worker.progress.connect(self._on_pip_worker_progress)
        self._pip_worker.finished_ok.connect(self._on_pip_worker_finished_ok)
        self._pip_worker.failed.connect(self._on_pip_worker_failed)
        self._pip_worker.finished.connect(self._on_pip_worker_finished)
        self._pip_worker.start()

    def _on_pip_worker_progress(self, text):
        self.lbl_status.setText(self.tr("Installing: {}").format(text[:500]))

    def _on_pip_worker_finished_ok(self):
        self._apply_sam_dependency_state()
        QMessageBox.information(
            self,
            self.tr("Installation finished"),
            self.tr(
                "pip reported success. If “Run SAM” is still disabled or SAM errors when run, "
                "fully quit QGIS and start it again so new libraries load."
            ),
        )

    def _on_pip_worker_failed(self, msg):
        QMessageBox.warning(
            self,
            self.tr("Installation failed"),
            msg + "\n\n" + self.tr('Try “Manual install help…” or scripts/install_sam_stack_for_qgis.bat.'),
        )

    def _on_pip_worker_finished(self):
        self._pip_busy = False
        self.btn_install_sam_stack.setEnabled(True)
        self.btn_sam_deps_help.setEnabled(True)
        self._apply_sam_dependency_state()

    def _show_sam_dependency_help(self):
        _, msg = sam_dependencies_available()
        if self._sam_deps_ok:
            QMessageBox.information(
                self,
                self.tr("SAM dependencies"),
                self.tr(
                    "PyTorch and segment_anything are loaded. "
                    "You can run SAM if the checkpoint path is valid."
                ),
            )
            return
        QMessageBox.warning(self, self.tr("SAM dependencies"), msg)

    def _mk_slider(self, lo, hi, val):
        s = QSlider(Qt.Horizontal)
        s.setRange(lo, hi)
        s.setValue(val)
        return s

    def _default_checkpoint_path(self):
        # Ship sam_vit_b_01ec64.pth beside this module (see sam_checkpoints/README.txt).
        # Not under vendor/ — vendor is read-only third-party source drops only.
        base = os.path.join(os.path.dirname(__file__), "sam_checkpoints")
        os.makedirs(base, exist_ok=True)
        return os.path.join(base, SAM_VIT_B_FILE)

    def _sync_ckpt_label(self):
        p = self._checkpoint_path
        if os.path.isfile(p):
            self.ed_ckpt.setText(p)
        else:
            self.ed_ckpt.setText(self.tr("{} (missing)").format(p))

    def _browse_checkpoint(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            self.tr("SAM checkpoint"),
            os.path.dirname(self._checkpoint_path),
            self.tr("PyTorch checkpoint (*.pth);;All files (*)"),
        )
        if path:
            self._checkpoint_path = path
            self._sync_ckpt_label()

    def _download_checkpoint(self):
        dest = self._default_checkpoint_path()
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        self.lbl_status.setText(self.tr("Downloading ViT-B checkpoint…"))
        try:
            urllib.request.urlretrieve(SAM_VIT_B_URL, dest)
        except Exception as e:
            QMessageBox.warning(self, self.tr("Download failed"), str(e))
            self.lbl_status.setText("")
            return
        self._checkpoint_path = dest
        self._sync_ckpt_label()
        self.lbl_status.setText(self.tr("Checkpoint saved."))

    def showEvent(self, event):
        super().showEvent(event)
        plg = self._plugin
        if plg is not None and getattr(plg, "_sam_trace_project_reload_pending", False):
            plg._sam_trace_project_reload_pending = False
            self.invalidate_trace_project_blob_cache()
        self._center_on_screen()
        self._apply_sam_dependency_state()
        if isinstance(event, QShowEvent):
            self._maybe_restore_trace_state_from_project()
            QMetaObject.invokeMethod(
                self,
                "_post_show_refresh",
                Qt.QueuedConnection,
            )

    @pyqtSlot()
    def _post_show_refresh(self):
        """Run after the dialog/event loop tick so layer combo + project layers are settled."""
        lyr = self.cmb_layer.currentLayer()
        if isinstance(lyr, QgsRasterLayer) and lyr.isValid() and self._rgb is None:
            self._reload_preview(clear_prompts=False)
            self._clamp_prompt_points_to_preview()
            self._clamp_auto_sam_fg_to_preview()
            self._rebuild_prompt_colors_from_rgb()
            self._sync_prompt_list()
            self._compose_preview()
        lst = getattr(self, "lst_prompts", None)
        if lst is not None:
            lst.viewport().repaint()

    def _center_on_screen(self):
        ref = self.parentWidget()
        center_pt = ref.frameGeometry().center() if ref is not None else None
        if center_pt is None:
            center_pt = self.frameGeometry().center()
        screen = QGuiApplication.screenAt(center_pt)
        if screen is None:
            screen = QGuiApplication.primaryScreen()
        if screen is None:
            return
        ag = screen.availableGeometry()
        geo = self.frameGeometry()
        geo.moveCenter(ag.center())
        self.move(geo.topLeft())

    def _current_raster_layer(self):
        """File-backed layer takes precedence over the project layer combo."""
        if self._temp_file_layer is not None and self._temp_file_layer.isValid():
            return self._temp_file_layer
        lyr = self.cmb_layer.currentLayer()
        if isinstance(lyr, QgsRasterLayer) and lyr.isValid():
            return lyr
        return None

    def _resolve_raster_layer_for_processing(self):
        """
        Use CRS/georeferencing from a project raster when it references the same file
        as the dialog “open image” path. A fresh QgsRasterLayer from disk often has
        no proper geotransform → vectors land in the wrong place on the map.
        """
        temp = self._temp_file_layer
        fp = self._file_path
        if temp is not None and temp.isValid() and fp:
            for lyr in QgsProject.instance().mapLayers().values():
                if not isinstance(lyr, QgsRasterLayer) or not lyr.isValid():
                    continue
                src = lyr.source().split("|")[0].strip().strip('"')
                if _same_source_path(src, fp):
                    return lyr
            return temp
        lyr = self.cmb_layer.currentLayer()
        if isinstance(lyr, QgsRasterLayer) and lyr.isValid():
            return lyr
        return None

    def _zoom_canvas_to_raster_extent(self, rlayer: QgsRasterLayer):
        """Fit map canvas to raster bounds in the canvas CRS (so vectors line up visually)."""
        iface = self._iface
        if iface is None or rlayer is None or not rlayer.isValid():
            return
        canvas = iface.mapCanvas()
        try:
            ms = canvas.mapSettings()
            dst = ms.destinationCrs()
            src = rlayer.crs()
            ext = rlayer.extent()
            if src.isValid() and dst.isValid():
                xform = QgsCoordinateTransform(src, dst, QgsProject.instance())
                try:
                    xform.setBallparkTransformsEnabled(True)
                except Exception:
                    pass
                try:
                    ext = xform.transformBoundingBox(ext)
                except Exception:
                    pass
            canvas.setExtent(ext)
            canvas.refresh()
        except Exception:
            pass

    def _trigger_georeferencer_action(self) -> bool:
        """Trigger Layer → Georeferencer (object name may differ by locale; we match objectName)."""
        iface = self._iface
        if iface is None:
            return False
        mw = iface.mainWindow()
        if mw is None:
            return False
        for a in mw.findChildren(QAction):
            if a.objectName() == "mActionShowGeoreferencer" and a.isEnabled():
                a.trigger()
                return True
        mb = mw.menuBar()
        if mb is not None:
            for top in mb.actions():
                m = top.menu()
                if m is None or m.objectName() != "mLayerMenu":
                    continue
                for a in m.actions():
                    if a.objectName() == "mActionShowGeoreferencer" and a.isEnabled():
                        a.trigger()
                        return True
                break
        return False

    def _find_georeferencer_main_window(self):
        for w in QApplication.topLevelWidgets():
            try:
                if w.metaObject().className() == "QgsGeoreferencerMainWindow":
                    return w
            except Exception:
                continue
        return None

    def _georef_try_open_layer_path(self, path: str) -> bool:
        """
        Ask the Georeferencer window to open this raster file.
        Uses a short processEvents loop (no timers) until the window exists.
        """
        lt = _qgis_georef_raster_layer_type()
        if lt is None:
            return False
        win = None
        for _ in range(120):
            QApplication.processEvents()
            win = self._find_georeferencer_main_window()
            if win is not None:
                break
        if win is None:
            return False
        ol = getattr(win, "openLayer", None)
        if callable(ol):
            try:
                ol(lt, path)
                return True
            except TypeError:
                try:
                    ol(int(lt), path)
                    return True
                except Exception:
                    pass
            except Exception:
                pass
        try:
            if QMetaObject.invokeMethod(
                win,
                "openLayer",
                Qt.ConnectionType.QueuedConnection,
                Q_ARG(int, int(lt)),
                Q_ARG(str, path),
            ):
                return True
        except Exception:
            pass
        try:
            if QMetaObject.invokeMethod(
                win,
                "openLayer",
                Qt.ConnectionType.DirectConnection,
                Q_ARG(int, int(lt)),
                Q_ARG(str, path),
            ):
                return True
        except Exception:
            pass
        return False

    def _on_open_georeferencer(self):
        """Add current raster to the project (if needed) and open Georeferencer with the file."""
        iface = self._iface
        if iface is None:
            QMessageBox.warning(
                self,
                self.tr("Georeferencer"),
                self.tr("Map canvas is not available."),
            )
            return
        layer = self._resolve_raster_layer_for_processing()
        if layer is None or not layer.isValid():
            QMessageBox.warning(
                self,
                self.tr("Georeferencer"),
                self.tr("Load a raster first (open a file or choose a project layer)."),
            )
            return
        raw = layer.source().split("|")[0].strip().strip('"')
        if not raw:
            QMessageBox.warning(
                self,
                self.tr("Georeferencer"),
                self.tr("Could not read a file path from this raster layer."),
            )
            return
        if not os.path.isfile(raw):
            QMessageBox.warning(
                self,
                self.tr("Georeferencer"),
                self.tr(
                    "Georeferencer needs a normal file on disk (not a remote or virtual path). "
                    "Source was:\n{}"
                ).format(raw[:500]),
            )
            return
        path = os.path.abspath(raw)
        in_project = False
        for lyr in QgsProject.instance().mapLayers().values():
            if isinstance(lyr, QgsRasterLayer) and lyr.isValid():
                sp = lyr.source().split("|")[0].strip().strip('"')
                if _same_source_path(sp, path):
                    in_project = True
                    break
        if not in_project:
            base_name = os.path.splitext(os.path.basename(path))[0]
            rl = QgsRasterLayer(path, base_name, "gdal")
            if not rl.isValid():
                QMessageBox.warning(
                    self,
                    self.tr("Georeferencer"),
                    self.tr("Could not open raster:\n{}").format(path),
                )
                return
            QgsProject.instance().addMapLayer(rl)
        iface.mapCanvas().refresh()
        if not self._trigger_georeferencer_action():
            QMessageBox.warning(
                self,
                self.tr("Georeferencer"),
                self.tr(
                    "Could not find the Georeferencer action. "
                    "Open it from the menu: Layer → Georeferencer."
                ),
            )
            return
        if self._georef_try_open_layer_path(path):
            return
        QGuiApplication.clipboard().setText(path)
        QMessageBox.information(
            self,
            self.tr("Georeferencer"),
            self.tr(
                "Georeferencer is open. If the image did not load automatically, use "
                "File → Open Raster in that window.\n\n"
                "The full file path has been copied to the clipboard for the file dialog."
            ),
        )

    def _release_file_layer(self):
        self._temp_file_layer = None
        self._file_path = None
        self.lbl_raster_path.setText(self.tr("No image loaded"))
        self.lbl_raster_path.setToolTip("")

    def _open_raster_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            self.tr("Open raster image"),
            os.path.dirname(self._file_path) if self._file_path else "",
            self.tr(
                "Raster images (*.tif *.tiff *.gtiff *.png *.jpg *.jpeg *.bmp *.jp2 *.j2k);;"
                "GeoTIFF (*.tif *.tiff);;"
                "All files (*)"
            ),
        )
        if not path:
            return
        lyr = QgsRasterLayer(path, os.path.splitext(os.path.basename(path))[0], "gdal")
        if not lyr.isValid():
            QMessageBox.warning(
                self,
                self.tr("Raster"),
                self.tr("Could not open raster:\n{}").format(path),
            )
            return
        self._temp_file_layer = lyr
        self._file_path = path
        self.lbl_raster_path.setText(os.path.basename(path))
        self.lbl_raster_path.setToolTip(path)
        self.cmb_layer.blockSignals(True)
        self.cmb_layer.setLayer(None)
        self.cmb_layer.blockSignals(False)
        self._reload_preview()

    def _on_layer_changed(self, layer):
        if isinstance(layer, QgsRasterLayer) and layer is not None and layer.isValid():
            self._release_file_layer()
        # Default _reload_preview(clear_prompts=True) wiped prompts restored from the project whenever
        # the combo emitted layerChanged (common right after opening the dialog).
        self._reload_preview(clear_prompts=False)
        self._clamp_prompt_points_to_preview()
        self._clamp_auto_sam_fg_to_preview()
        self._rebuild_prompt_colors_from_rgb()
        self._sync_prompt_list()
        self._compose_preview()

    def _auto_tune_color_mask(self):
        """Pick saturation/value cutoffs from image pixels (colored ink vs gray paper)."""
        if self._rgb is None:
            QMessageBox.information(
                self,
                self.tr("Color mask"),
                self.tr("Load a raster preview first."),
            )
            return
        rgb = self._rgb
        try:
            import cv2

            hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
            _, s_ch, v_ch = cv2.split(hsv)
        except Exception:
            r = rgb[..., 0].astype(np.float64)
            g = rgb[..., 1].astype(np.float64)
            b = rgb[..., 2].astype(np.float64)
            mx = np.maximum(np.maximum(r, g), b)
            mn = np.minimum(np.minimum(r, g), b)
            s_ch = np.where(mx > 1e-6, (mx - mn) / mx * 255.0, 0.0).astype(np.uint8)
            v_ch = np.clip(mx, 0, 255).astype(np.uint8)
        s_flat = s_ch.reshape(-1)
        v_flat = v_ch.reshape(-1)
        s_thr = int(np.clip(np.percentile(s_flat, 55), 28, 110))
        v_thr_lo = int(np.clip(np.percentile(v_flat, 10), 12, 70))
        self.sl_h0.setValue(0)
        self.sl_h1.setValue(179)
        self.sl_s0.setValue(s_thr)
        self.sl_s1.setValue(255)
        self.sl_v0.setValue(v_thr_lo)
        self.sl_v1.setValue(255)
        self.chk_invert.setChecked(False)
        self._compose_preview()

    def _auto_tune_mask_from_prompt_colors(self):
        """Set HSV sliders from RGB under foreground clicks (median of small patch per click)."""
        if self._rgb is None:
            QMessageBox.information(
                self,
                self.tr("Color mask"),
                self.tr("Load a raster preview first."),
            )
            return
        fg_idx = [i for i, lb in enumerate(self._labels) if lb == 1]
        if not fg_idx:
            n_fg = sum(1 for lb in self._labels if lb == 1)
            n_bg = sum(1 for lb in self._labels if lb == 0)
            QMessageBox.information(
                self,
                self.tr("Color mask"),
                self.tr(
                    "This button samples colors under Foreground (pipeline) clicks only.\n\n"
                    "Right now you have {0} foreground and {1} background click(s). "
                    "Your list shows background points — they exclude colors from the mask but "
                    "do not define which pipeline inks to include.\n\n"
                    "Set “Next click” to Foreground, click on the pipeline colors you want traced, "
                    "then press “Tune mask from foreground prompts” again."
                ).format(n_fg, n_bg),
            )
            return
        try:
            import cv2
        except ImportError:
            QMessageBox.warning(
                self,
                self.tr("Color mask"),
                self.tr(
                    "OpenCV is required. Install the SAM stack from this dialog or: pip install opencv-python"
                ),
            )
            return

        H, W, _ = self._rgb.shape
        rad = 2
        h_samples = []
        s_samples = []
        v_samples = []
        for i in fg_idx:
            x, y = self._points[i]
            xi = int(np.clip(int(round(x)), 0, W - 1))
            yi = int(np.clip(int(round(y)), 0, H - 1))
            r0 = max(0, yi - rad)
            r1 = min(H, yi + rad + 1)
            c0 = max(0, xi - rad)
            c1 = min(W, xi + rad + 1)
            patch = self._rgb[r0:r1, c0:c1]
            if patch.size == 0:
                continue
            med = np.median(patch.reshape(-1, 3), axis=0).astype(np.uint8)
            pixel_rgb = np.uint8([[[med[0], med[1], med[2]]]])
            hsv = cv2.cvtColor(pixel_rgb, cv2.COLOR_RGB2HSV)[0, 0]
            h_samples.append(int(hsv[0]))
            s_samples.append(int(hsv[1]))
            v_samples.append(int(hsv[2]))

        if not h_samples:
            QMessageBox.warning(self, self.tr("Color mask"), self.tr("Could not sample colors."))
            return

        h_margin = 22
        s_margin = 50
        v_margin = 50
        h_lo, h_hi = hue_interval_covering_samples(h_samples, h_margin)

        s_lo = max(0, min(s_samples) - s_margin)
        s_hi = min(255, max(s_samples) + s_margin)
        v_lo = max(0, min(v_samples) - v_margin)
        v_hi = min(255, max(v_samples) + v_margin)

        self.sl_h0.setValue(h_lo)
        self.sl_h1.setValue(h_hi)
        self.sl_s0.setValue(s_lo)
        self.sl_s1.setValue(s_hi)
        self.sl_v0.setValue(v_lo)
        self.sl_v1.setValue(v_hi)
        self.chk_invert.setChecked(False)
        self._compose_preview()
        status = self.tr(
            "Mask range set from {} foreground prompt(s). "
            "Check the green overlay — widen sliders if needed."
        ).format(len(h_samples))
        if h_lo == 0 and h_hi == 179:
            status += " " + self.tr(
                "Hue spans the full range so every clicked ink color is included; "
                "narrow Sat/Val or add background clicks if the mask picks up extra colors."
            )
        self.lbl_status.setText(status)

    def flush_trace_state_to_project(self):
        """Persist prompts + mask UI into the .qgs via QgsProject custom properties."""
        import json

        try:
            state = self._trace_state_to_dict()
            blob = json.dumps(state, separators=(",", ":"))
        except (TypeError, ValueError):
            return
        empty_now = (
            len(self._points) == 0
            and len(self._labels) == 0
            and not (getattr(self, "_auto_sam_fg_xy", None) or [])
        )
        if empty_now and not getattr(self, "_trace_allow_empty_flush", False):
            ev, _ok = QgsProject.instance().readEntry(
                SAM_TRACE_PROJECT_SCOPE, SAM_TRACE_PROJECT_ENTRY_KEY, ""
            )
            prev_raw = (ev or "").strip()
            if prev_raw:
                try:
                    prev = json.loads(prev_raw)
                    if len(prev.get("points") or []) > 0:
                        return
                except (TypeError, ValueError):
                    pass
        QgsProject.instance().writeEntry(
            SAM_TRACE_PROJECT_SCOPE, SAM_TRACE_PROJECT_ENTRY_KEY, blob
        )
        self._trace_state_blob_applied = blob

    def _on_save_prompts_to_project_clicked(self):
        """Write trace JSON into QgsProject; user still needs File → Save for the project file on disk."""
        self.flush_trace_state_to_project()
        iface = self._iface
        if iface is not None:
            iface.messageBar().pushMessage(
                self.tr("Raster trace"),
                self.tr(
                    "Prompts and mask settings stored in this project. "
                    "Use File → Save project to write your .qgs/.qgz file."
                ),
                level=Qgis.Info,
                duration=10,
            )
        self.lbl_status.setText(
            self.tr(
                "Prompts saved into the project (in memory). Use File → Save project to write them to disk."
            )
        )

    def invalidate_trace_project_blob_cache(self):
        """After loading a different project file, allow saved trace state to apply on next show."""
        self._trace_state_blob_applied = ""

    def _trace_state_to_dict(self):
        src = {}
        lyr = self.cmb_layer.currentLayer()
        if isinstance(lyr, QgsRasterLayer) and lyr is not None and lyr.isValid():
            src = {"type": "layer_id", "id": lyr.id()}
            try:
                fp = lyr.source().split("|")[0].strip().strip('"')
                fp = os.path.normpath(fp)
                if fp and os.path.isfile(fp):
                    src["path_fallback"] = fp
            except OSError:
                pass
        elif self._file_path:
            src = {"type": "file", "path": os.path.normpath(self._file_path)}
        colors = []
        for c in self._prompt_colors:
            colors.append([c.red(), c.green(), c.blue(), c.alpha()])
        out = {
            "v": 2,
            "source": src,
            "points": [[float(x), float(y)] for x, y in self._points],
            "labels": [int(x) for x in self._labels],
            "colors": colors,
            "mask": {
                "h0": self.sl_h0.value(),
                "h1": self.sl_h1.value(),
                "s0": self.sl_s0.value(),
                "s1": self.sl_s1.value(),
                "v0": self.sl_v0.value(),
                "v1": self.sl_v1.value(),
            },
            "chk_show_mask": self.chk_show_mask.isChecked(),
            "chk_apply_mask": self.chk_apply_mask.isChecked(),
            "chk_trace_color_only": self.chk_trace_color_only.isChecked(),
            "chk_invert": self.chk_invert.isChecked(),
            "sp_morph": self.sp_morph.value(),
            "sp_trace_dilate": self.sp_trace_dilate.value(),
            "sp_join_gap": self.sp_join_gap.value(),
            "sp_fg_bleed": int(self.sp_fg_bleed.value()),
            "sp_auto_fg_prompts": int(self.sp_auto_fg_prompts.value()),
            "sp_max_side": self.sp_max_side.value(),
            "sp_line_smooth": float(self.sp_line_smooth.value()),
        }
        try:
            cm = self.cmb_click_mode.currentData()
            if cm is not None:
                out["click_mode"] = int(cm)
        except (TypeError, ValueError):
            pass
        sl = getattr(self, "slider_preview_zoom", None)
        if sl is not None:
            out["preview_zoom_pct"] = int(sl.value())
        cp = getattr(self, "_checkpoint_path", "") or ""
        if cp:
            try:
                ncp = os.path.normpath(cp)
                if os.path.isfile(ncp):
                    out["checkpoint_path"] = ncp
            except OSError:
                pass
        auto_xy = getattr(self, "_auto_sam_fg_xy", None) or []
        if auto_xy:
            out["auto_fg_xy"] = [[float(x), float(y)] for x, y in auto_xy]
        return out

    def _maybe_restore_trace_state_from_project(self):
        import json

        val, _ok = QgsProject.instance().readEntry(
            SAM_TRACE_PROJECT_SCOPE, SAM_TRACE_PROJECT_ENTRY_KEY, ""
        )
        raw = (val or "").strip()
        if not raw and hasattr(QgsProject.instance(), "readCustomProperty"):
            try:
                legacy = (
                    QgsProject.instance().readCustomProperty(
                        SAM_TRACE_LEGACY_CUSTOM_PROP_KEY, ""
                    )
                    or ""
                )
                if isinstance(legacy, QByteArray):
                    raw = bytes(legacy).decode("utf-8", errors="replace").strip()
                else:
                    raw = str(legacy).strip()
            except Exception:
                raw = ""
        if not raw:
            return
        if raw == self._trace_state_blob_applied:
            return
        try:
            data = json.loads(raw)
        except (TypeError, ValueError):
            return
        self._apply_trace_state_from_dict(data)
        self._trace_state_blob_applied = raw

    def _apply_trace_state_from_dict(self, data):
        if not isinstance(data, dict):
            return
        ver = int(data.get("v", 0))
        if ver not in (1, 2):
            return
        self._apply_mask_settings_from_trace_state_dict(data)
        self._apply_misc_trace_ui_from_trace_state_dict(data)
        src_ok = self._restore_raster_source_from_saved_state(data.get("source") or {})
        pts = data.get("points") or []
        lbs = data.get("labels") or []
        cols = data.get("colors") or []
        n = min(len(pts), len(lbs))
        had_saved_colors = (
            n > 0
            and len(cols) >= n
            and all(
                isinstance(cols[i], (list, tuple)) and len(cols[i]) >= 3 for i in range(n)
            )
        )
        self._points.clear()
        self._labels.clear()
        self._prompt_colors.clear()
        for i in range(n):
            try:
                x = float(pts[i][0])
                y = float(pts[i][1])
                lb = int(lbs[i])
            except (IndexError, TypeError, ValueError):
                continue
            self._points.append((x, y))
            self._labels.append(lb)
            if i < len(cols) and isinstance(cols[i], (list, tuple)) and len(cols[i]) >= 3:
                c = cols[i]
                try:
                    self._prompt_colors.append(
                        QColor(
                            int(c[0]),
                            int(c[1]),
                            int(c[2]),
                            int(c[3]) if len(c) > 3 else 255,
                        )
                    )
                except (TypeError, ValueError):
                    self._prompt_colors.append(QColor(128, 128, 128))
            else:
                self._prompt_colors.append(QColor(128, 128, 128))
        self._auto_sam_fg_xy = []
        raw_auto = data.get("auto_fg_xy")
        if isinstance(raw_auto, list):
            for pair in raw_auto:
                if isinstance(pair, (list, tuple)) and len(pair) >= 2:
                    try:
                        self._auto_sam_fg_xy.append((float(pair[0]), float(pair[1])))
                    except (TypeError, ValueError):
                        pass
        if src_ok:
            self._reload_preview(clear_prompts=False)
        else:
            self._sam_mask = None
            self._last_polylines = []
            self._last_vector_layers = None
            self._last_single_trace_line_color = None
            self._rgb = None
            self._geo = None
            self.preview.setPixmap(QPixmap())
            self.preview.set_image_shape(0, 0)
            self.lbl_status.setText(
                self.tr(
                    "Restored SAM/color prompts from the project. Select the raster layer or reopen "
                    "the image file to reload the preview."
                )
            )
            self._sync_prompt_list()
            self._compose_preview()
        self._clamp_prompt_points_to_preview()
        self._clamp_auto_sam_fg_to_preview()
        if not had_saved_colors:
            self._rebuild_prompt_colors_from_rgb()
        self._sync_prompt_list()
        self._compose_preview()
        self._trace_allow_empty_flush = len(self._points) == 0

    def _apply_mask_settings_from_trace_state_dict(self, data):
        m = data.get("mask") or {}

        def _set_slider(sp, key):
            if key not in m:
                return
            sp.blockSignals(True)
            try:
                sp.setValue(int(m[key]))
            finally:
                sp.blockSignals(False)

        for sp, key in (
            (self.sl_h0, "h0"),
            (self.sl_h1, "h1"),
            (self.sl_s0, "s0"),
            (self.sl_s1, "s1"),
            (self.sl_v0, "v0"),
            (self.sl_v1, "v1"),
        ):
            _set_slider(sp, key)

        def _set_chk(w, key):
            if key not in data:
                return
            w.blockSignals(True)
            try:
                w.setChecked(bool(data[key]))
            finally:
                w.blockSignals(False)

        _set_chk(self.chk_show_mask, "chk_show_mask")
        _set_chk(self.chk_apply_mask, "chk_apply_mask")
        _set_chk(self.chk_trace_color_only, "chk_trace_color_only")
        _set_chk(self.chk_invert, "chk_invert")

        for sp, key in (
            (self.sp_morph, "sp_morph"),
            (self.sp_trace_dilate, "sp_trace_dilate"),
            (self.sp_join_gap, "sp_join_gap"),
            (self.sp_fg_bleed, "sp_fg_bleed"),
            (self.sp_auto_fg_prompts, "sp_auto_fg_prompts"),
            (self.sp_max_side, "sp_max_side"),
        ):
            if key in data:
                sp.blockSignals(True)
                try:
                    sp.setValue(int(data[key]))
                finally:
                    sp.blockSignals(False)

        if "sp_line_smooth" in data:
            self.sp_line_smooth.blockSignals(True)
            try:
                self.sp_line_smooth.setValue(float(data["sp_line_smooth"]))
            finally:
                self.sp_line_smooth.blockSignals(False)

        self._apply_sam_dependency_state()

    def _apply_misc_trace_ui_from_trace_state_dict(self, data):
        if "click_mode" in data:
            try:
                v = int(data["click_mode"])
                self.cmb_click_mode.blockSignals(True)
                try:
                    for i in range(self.cmb_click_mode.count()):
                        item_data = self.cmb_click_mode.itemData(i)
                        if item_data is not None and int(item_data) == v:
                            self.cmb_click_mode.setCurrentIndex(i)
                            break
                finally:
                    self.cmb_click_mode.blockSignals(False)
            except (TypeError, ValueError):
                pass
        sl = getattr(self, "slider_preview_zoom", None)
        if sl is not None and "preview_zoom_pct" in data:
            try:
                z = int(data["preview_zoom_pct"])
                z = max(sl.minimum(), min(sl.maximum(), z))
                sl.blockSignals(True)
                try:
                    sl.setValue(z)
                finally:
                    sl.blockSignals(False)
                self._preview_zoom = max(0.5, min(4.0, z / 100.0))
            except (TypeError, ValueError):
                pass
        p = data.get("checkpoint_path")
        if isinstance(p, str):
            try:
                npth = os.path.normpath(p.strip())
                if npth and os.path.isfile(npth):
                    self._checkpoint_path = npth
                    self._sync_ckpt_label()
            except OSError:
                pass

    def _restore_raster_from_file_path(self, path: str) -> bool:
        path = os.path.normpath(path)
        if not path or not os.path.isfile(path):
            return False
        lyr = QgsRasterLayer(path, os.path.splitext(os.path.basename(path))[0], "gdal")
        if not lyr.isValid():
            return False
        self._temp_file_layer = lyr
        self._file_path = path
        self.lbl_raster_path.setText(os.path.basename(path))
        self.lbl_raster_path.setToolTip(path)
        self.cmb_layer.blockSignals(True)
        self.cmb_layer.setLayer(None)
        self.cmb_layer.blockSignals(False)
        return True

    def _restore_raster_source_from_saved_state(self, src):
        if not isinstance(src, dict):
            return False
        t = src.get("type")
        if t == "layer_id":
            lid = src.get("id")
            lyr = QgsProject.instance().mapLayer(lid)
            if isinstance(lyr, QgsRasterLayer) and lyr.isValid():
                self._release_file_layer()
                self.cmb_layer.blockSignals(True)
                self.cmb_layer.setLayer(lyr)
                self.cmb_layer.blockSignals(False)
                return True
            fb = src.get("path_fallback")
            if isinstance(fb, str):
                fb = os.path.normpath(fb)
                if os.path.isfile(fb):
                    self._release_file_layer()
                    return self._restore_raster_from_file_path(fb)
            return False
        if t == "file":
            path = src.get("path")
            if not path or not isinstance(path, str):
                return False
            self._release_file_layer()
            return self._restore_raster_from_file_path(os.path.normpath(path))
        return False

    def _clamp_prompt_points_to_preview(self):
        if self._rgb is None:
            return
        H, W = int(self._rgb.shape[0]), int(self._rgb.shape[1])
        for i in range(len(self._points)):
            x, y = self._points[i]
            xi = int(np.clip(int(round(x)), 0, max(0, W - 1)))
            yi = int(np.clip(int(round(y)), 0, max(0, H - 1)))
            self._points[i] = (float(xi), float(yi))

    def _clamp_auto_sam_fg_to_preview(self):
        if self._rgb is None:
            self._auto_sam_fg_xy = []
            return
        H, W = int(self._rgb.shape[0]), int(self._rgb.shape[1])
        out = []
        for x, y in getattr(self, "_auto_sam_fg_xy", []) or []:
            xi = int(np.clip(int(round(float(x))), 0, max(0, W - 1)))
            yi = int(np.clip(int(round(float(y))), 0, max(0, H - 1)))
            out.append((float(xi), float(yi)))
        self._auto_sam_fg_xy = out

    def _rebuild_prompt_colors_from_rgb(self):
        if self._rgb is None:
            return
        H, W = int(self._rgb.shape[0]), int(self._rgb.shape[1])
        for i in range(len(self._points)):
            x, y = int(round(self._points[i][0])), int(round(self._points[i][1]))
            if 0 <= x < W and 0 <= y < H:
                px = self._rgb[y, x]
                self._prompt_colors[i] = QColor(int(px[0]), int(px[1]), int(px[2]))

    def _reload_preview(self, clear_prompts=True):
        self._sam_mask = None
        self._last_polylines = []
        self._last_vector_layers = None
        self._last_single_trace_line_color = None
        if clear_prompts:
            self._trace_allow_empty_flush = True
            self._points.clear()
            self._labels.clear()
            self._prompt_colors.clear()
            self._auto_sam_fg_xy = []
            self._sync_prompt_list()
        layer = self._resolve_raster_layer_for_processing()
        if layer is None or not layer.isValid():
            self._rgb = None
            self._geo = None
            self.preview.setPixmap(QPixmap())
            self.preview.set_image_shape(0, 0)
            self.lbl_status.setText(
                self.tr("Open an image file, or choose a raster layer from the project.")
            )
            return
        max_side = int(self.sp_max_side.value())
        rgb, geo = read_raster_rgb_numpy(layer, max_side)
        self._rgb = rgb
        self._geo = geo
        if rgb is None:
            self.preview.setPixmap(QPixmap())
            self.lbl_status.setText(self.tr("Could not read raster."))
            return
        self.preview.set_image_shape(rgb.shape[1], rgb.shape[0])
        if self._file_path:
            tip = self._file_path
            if self._temp_file_layer is not None and layer != self._temp_file_layer:
                tip += "\n\n" + self.tr(
                    "Georeferencing uses the project raster layer with this same file path."
                )
            self.lbl_raster_path.setToolTip(tip)
        base = self.tr(
            "Loaded {}×{} (downscaled for SAM). "
            "Add foreground clicks on pipelines, optional background clicks, then Run SAM."
        ).format(geo["w"], geo["h"])
        ok_deps, dep_detail = sam_dependencies_available()
        self._sam_deps_ok = ok_deps
        self.btn_install_sam_stack.setEnabled(not self._pip_busy)
        if not ok_deps:
            head = (dep_detail or "").strip().split("\n")[0].strip()
            if len(head) > 140:
                head = head[:137] + "…"
            base += "\n\n" + self.tr(
                "SAM not ready: {0} — hover this status line for full detail, or “Manual install help…”."
            ).format(head or self.tr("(see tooltip)"))
            self.lbl_status.setToolTip(dep_detail)
        else:
            self.lbl_status.setToolTip("")
        self.lbl_status.setText(base)
        self._clamp_prompt_points_to_preview()
        self._clamp_auto_sam_fg_to_preview()
        self._compose_preview()
        self._apply_sam_dependency_state()

    def _color_mask(self):
        if self._rgb is None:
            return None
        return hsv_mask_rgb(
            self._rgb,
            self.sl_h0.value(),
            self.sl_h1.value(),
            self.sl_s0.value(),
            self.sl_s1.value(),
            self.sl_v0.value(),
            self.sl_v1.value(),
            self.chk_invert.isChecked(),
        )

    def _background_prompt_exclude_mask(self):
        """HSV regions to remove from the color mask (union over background label prompts)."""
        if self._rgb is None:
            return None
        bg_idx = [i for i, lb in enumerate(self._labels) if lb == 0]
        if not bg_idx:
            return None
        try:
            import cv2
        except ImportError:
            return None
        H, W, _ = self._rgb.shape
        excl = np.zeros((H, W), dtype=bool)
        rad = 2
        # Near-neutral map/ocean pixels have low S; OpenCV hue is meaningless there.
        # Wide S margins around gray (e.g. S≈20 ±60 → [0,80]) wrongly exclude purple/red ink
        # with moderate saturation. Use tight S/V bands and full hue for achromatic BG only.
        achromatic_s_max = 42
        dbg_bg = []
        for i in bg_idx:
            x, y = self._points[i]
            xi = int(np.clip(int(round(x)), 0, W - 1))
            yi = int(np.clip(int(round(y)), 0, H - 1))
            r0 = max(0, yi - rad)
            r1 = min(H, yi + rad + 1)
            c0 = max(0, xi - rad)
            c1 = min(W, xi + rad + 1)
            patch = self._rgb[r0:r1, c0:c1]
            if patch.size == 0:
                continue
            med = np.median(patch.reshape(-1, 3), axis=0).astype(np.uint8)
            pixel_rgb = np.uint8([[[med[0], med[1], med[2]]]])
            hsv = cv2.cvtColor(pixel_rgb, cv2.COLOR_RGB2HSV)[0, 0]
            hc = int(hsv[0])
            sc = int(hsv[1])
            vc = int(hsv[2])
            if sc <= achromatic_s_max:
                s_margin, v_margin = 22, 40
                h_lo, h_hi = 0, 179
                s_lo = max(0, sc - s_margin)
                s_hi = min(255, sc + s_margin)
                v_lo = max(0, vc - v_margin)
                v_hi = min(255, vc + v_margin)
                dbg_bg.append({"idx": i, "mode": "achromatic_sv", "sc": sc, "vc": vc})
            else:
                h_margin, s_margin, v_margin = 28, 60, 60
                h_lo = max(0, hc - h_margin)
                h_hi = min(179, hc + h_margin)
                s_lo = max(0, sc - s_margin)
                s_hi = min(255, sc + s_margin)
                v_lo = max(0, vc - v_margin)
                v_hi = min(255, vc + v_margin)
                dbg_bg.append({"idx": i, "mode": "chromatic_hsv", "hc": hc, "sc": sc})
            excl |= hsv_mask_rgb(
                self._rgb, h_lo, h_hi, s_lo, s_hi, v_lo, v_hi, False
            )
        if not np.any(excl):
            return None
        return excl

    def _effective_color_mask(self):
        """Color mask with pixels matching background prompts removed."""
        base = self._color_mask()
        if base is None:
            return None
        n_bg = sum(1 for lb in self._labels if lb == 0)
        excl = self._background_prompt_exclude_mask()
        if excl is None:
            return base
        out = base & ~excl
        return out

    @staticmethod
    def _hue_circ_dist(h1, h2):
        d = abs(int(h1) - int(h2))
        return min(d, 180 - d)

    def _fg_prompt_hsv_boxes(self):
        """One OpenCV HSV box per foreground prompt (median RGB patch under the click)."""
        if self._rgb is None:
            return []
        try:
            import cv2
        except ImportError:
            return []
        fg_idx = [i for i, lb in enumerate(self._labels) if lb == 1]
        if not fg_idx:
            return []
        H, W, _ = self._rgb.shape
        rad = 2
        extra = 0
        if getattr(self, "sp_fg_bleed", None) is not None:
            extra = int(np.clip(int(self.sp_fg_bleed.value()), 0, 90))
        h_margin = 22 + min(40, (extra * 3) // 4)
        s_margin = 50 + extra
        v_margin = 50 + extra
        boxes = []
        for i in fg_idx:
            x, y = self._points[i]
            xi = int(np.clip(int(round(x)), 0, W - 1))
            yi = int(np.clip(int(round(y)), 0, H - 1))
            r0 = max(0, yi - rad)
            r1 = min(H, yi + rad + 1)
            c0 = max(0, xi - rad)
            c1 = min(W, xi + rad + 1)
            patch = self._rgb[r0:r1, c0:c1]
            if patch.size == 0:
                continue
            med = np.median(patch.reshape(-1, 3), axis=0).astype(np.uint8)
            pixel_rgb = np.uint8([[[med[0], med[1], med[2]]]])
            hsv = cv2.cvtColor(pixel_rgb, cv2.COLOR_RGB2HSV)[0, 0]
            hc = int(hsv[0])
            sc = int(hsv[1])
            vc = int(hsv[2])
            h_lo = max(0, hc - h_margin)
            h_hi = min(179, hc + h_margin)
            s_lo = max(0, sc - s_margin)
            s_hi = min(255, sc + s_margin)
            v_lo = max(0, vc - v_margin)
            v_hi = min(255, vc + v_margin)
            boxes.append(
                {
                    "prompt_idx": i,
                    "hc": hc,
                    "h0": h_lo,
                    "h1": h_hi,
                    "s0": s_lo,
                    "s1": s_hi,
                    "v0": v_lo,
                    "v1": v_hi,
                }
            )
        return boxes

    def _merge_fg_hsv_clusters(self, boxes):
        """Cluster foreground prompts by similar hue; return merged HSV boxes."""
        if not boxes:
            return []
        if len(boxes) == 1:
            b = boxes[0]
            return [
                {
                    "h0": b["h0"],
                    "h1": b["h1"],
                    "s0": b["s0"],
                    "s1": b["s1"],
                    "v0": b["v0"],
                    "v1": b["v1"],
                    "line_color": self._line_color_for_fg_cluster_boxes([b]),
                }
            ]
        n = len(boxes)
        parent = list(range(n))

        def find(a):
            while parent[a] != a:
                parent[a] = parent[parent[a]]
                a = parent[a]
            return a

        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[rb] = ra

        hue_merge_max = 22
        for i in range(n):
            for j in range(i + 1, n):
                if self._hue_circ_dist(boxes[i]["hc"], boxes[j]["hc"]) <= hue_merge_max:
                    union(i, j)
        clusters = {}
        for i in range(n):
            r = find(i)
            clusters.setdefault(r, []).append(boxes[i])
        merged = []
        for grp in clusters.values():
            merged.append(
                {
                    "h0": min(b["h0"] for b in grp),
                    "h1": max(b["h1"] for b in grp),
                    "s0": min(b["s0"] for b in grp),
                    "s1": max(b["s1"] for b in grp),
                    "v0": min(b["v0"] for b in grp),
                    "v1": max(b["v1"] for b in grp),
                    "line_color": self._line_color_for_fg_cluster_boxes(grp),
                }
            )
        return merged

    def _expand_cluster_hsv_for_vectorize(self, c):
        """Widen FG cluster HSV slightly so ``eff & band`` does not drop anti-aliased / varied ink."""
        extra = 0
        if getattr(self, "sp_fg_bleed", None) is not None:
            extra = int(np.clip(int(self.sp_fg_bleed.value()), 0, 90))
        pad_h = 14 + min(28, extra // 2)
        pad_sv = 42 + min(55, extra)
        h0, h1 = int(c["h0"]), int(c["h1"])
        s0, s1 = int(c["s0"]), int(c["s1"])
        v0, v1 = int(c["v0"]), int(c["v1"])
        if h0 <= h1:
            h0 = max(0, h0 - pad_h)
            h1 = min(179, h1 + pad_h)
        s0 = max(0, s0 - pad_sv)
        s1 = min(255, s1 + pad_sv)
        v0 = max(0, v0 - pad_sv)
        v1 = min(255, v1 + pad_sv)
        return h0, h1, s0, s1, v0, v1

    def _line_color_for_fg_cluster_boxes(self, grp):
        """Match map line color to SAM click prompt swatches (median RGB under each FG click)."""
        rgbs = []
        for b in grp:
            pi = b.get("prompt_idx")
            if pi is None or pi < 0:
                continue
            if pi >= len(self._prompt_colors):
                continue
            c = self._prompt_colors[pi]
            if c is not None and c.isValid():
                rgbs.append((c.red(), c.green(), c.blue()))
        if not rgbs:
            return QColor(128, 128, 128)
        if len(rgbs) == 1:
            r, g, b = rgbs[0]
            return QColor(r, g, b)
        r = int(round(sum(t[0] for t in rgbs) / len(rgbs)))
        g = int(round(sum(t[1] for t in rgbs) / len(rgbs)))
        b = int(round(sum(t[2] for t in rgbs) / len(rgbs)))
        return QColor(r, g, b)

    def _representative_fg_line_color(self):
        """Single exported layer: average RGB of all FG prompts (one mask, multiple inks)."""
        cols = []
        for i, lb in enumerate(self._labels):
            if lb != 1:
                continue
            if i >= len(self._prompt_colors):
                continue
            c = self._prompt_colors[i]
            if c is not None and c.isValid():
                cols.append(c)
        if not cols:
            return QColor(128, 128, 128)
        if len(cols) == 1:
            return QColor(cols[0])
        r = int(round(sum(c.red() for c in cols) / len(cols)))
        g = int(round(sum(c.green() for c in cols) / len(cols)))
        b = int(round(sum(c.blue() for c in cols) / len(cols)))
        return QColor(r, g, b)

    def _apply_pipeline_line_symbology(self, vl, qc):
        """Avoid QGIS default random palette — lines should match FG prompt colors."""
        if vl is None or not isinstance(qc, QColor) or not qc.isValid():
            return
        try:
            sym = QgsSymbol.defaultSymbol(QgsWkbTypes.LineGeometry)
        except Exception:
            return
        if sym is None:
            return
        sym.setColor(qc)
        try:
            vl.setRenderer(QgsSingleSymbolRenderer(sym))
        except Exception:
            return
        vl.triggerRepaint()

    def _compose_preview(self):
        if self._rgb is None:
            return
        h, w, _ = self._rgb.shape
        disp = self._rgb.astype(np.float64, copy=True)

        if self.chk_show_mask.isChecked():
            cm = self._effective_color_mask()
            if cm is not None:
                cm = morph_cleanup(cm, int(self.sp_morph.value()))
                green = np.array([0.0, 255.0, 0.0])
                m = cm[..., np.newaxis]
                disp = np.where(m, disp * 0.62 + green * 0.38, disp)

        if self._sam_mask is not None:
            orange = np.array([255.0, 72.0, 16.0])
            m = self._sam_mask[..., np.newaxis]
            disp = np.where(m, disp * 0.52 + orange * 0.48, disp)

        disp_u8 = np.ascontiguousarray(np.clip(disp, 0, 255).astype(np.uint8))
        qimg = _qimage_from_rgb888_numpy(disp_u8)
        pm = QPixmap.fromImage(qimg)
        try:
            pm.setDevicePixelRatio(1.0)
        except Exception:
            pass


        if pm.isNull():
            return

        painter = QPainter(pm)
        try:
            for (px, py), col in zip(self._points, self._prompt_colors):
                painter.setPen(QPen(QColor(20, 20, 20), 1))
                painter.setBrush(col)
                ix = int(round(float(px)))
                iy = int(round(float(py)))
                painter.drawEllipse(ix - 5, iy - 5, 10, 10)
        finally:
            painter.end()

        z = 1.0
        sl = getattr(self, "slider_preview_zoom", None)
        if sl is not None:
            z = max(0.5, min(4.0, sl.value() / 100.0))
        self._preview_zoom = z
        if abs(z - 1.0) > 1e-6 and not pm.isNull():
            nw = max(1, int(round(pm.width() * z)))
            nh = max(1, int(round(pm.height() * z)))
            pm = pm.scaled(nw, nh, Qt.KeepAspectRatio, Qt.SmoothTransformation)

        self.preview.setPixmap(pm)
        self.preview.updateGeometry()

    def _on_preview_zoom_slider(self, value):
        self._preview_zoom = max(0.5, min(4.0, value / 100.0))
        self._compose_preview()

    def _on_preview_zoom_out(self):
        sl = getattr(self, "slider_preview_zoom", None)
        if sl is not None:
            sl.setValue(max(sl.minimum(), sl.value() - 25))

    def _on_preview_zoom_in(self):
        sl = getattr(self, "slider_preview_zoom", None)
        if sl is not None:
            sl.setValue(min(sl.maximum(), sl.value() + 25))

    def _on_preview_zoom_reset(self):
        sl = getattr(self, "slider_preview_zoom", None)
        if sl is not None:
            sl.setValue(100)

    def _on_preview_wheel_zoom(self, delta_y):
        sl = getattr(self, "slider_preview_zoom", None)
        if sl is None:
            return
        step = 20 if abs(delta_y) >= 120 else 10
        if delta_y > 0:
            sl.setValue(min(sl.maximum(), sl.value() + step))
        else:
            sl.setValue(max(sl.minimum(), sl.value() - step))

    def _on_preview_click(self, ix, iy, button):
        if self._rgb is None:
            return
        mode = int(self.cmb_click_mode.currentData())
        if button == Qt.RightButton:
            lbl = 0
        else:
            lbl = mode
        self._points.append((ix, iy))
        self._labels.append(lbl)
        self._trace_allow_empty_flush = False
        px = self._rgb[iy, ix]
        spot = QColor(int(px[0]), int(px[1]), int(px[2]))
        self._prompt_colors.append(spot)
        self._sync_prompt_list()
        self._compose_preview()

    def _sync_prompt_list(self):
        lst = getattr(self, "lst_prompts", None)
        if lst is None:
            return
        lst.setUpdatesEnabled(False)
        try:
            lst.clear()
            for i, ((x, y), lb, col) in enumerate(
                zip(self._points, self._labels, self._prompt_colors)
            ):
                role = self.tr("Fg") if lb == 1 else self.tr("Bg")
                xi, yi = int(round(float(x))), int(round(float(y)))
                txt = "#{} {} pixel ({},{})".format(i + 1, role, xi, yi)
                it = QListWidgetItem(txt)
                it.setBackground(col)
                fg = QColor(0, 0, 0) if col.lightness() > 135 else QColor(255, 255, 255)
                it.setForeground(fg)
                lst.addItem(it)
        finally:
            lst.setUpdatesEnabled(True)
        lst.viewport().repaint()

    def _remove_prompt_at_row(self, row):
        if row < 0 or row >= len(self._points):
            return
        del self._points[row]
        del self._labels[row]
        del self._prompt_colors[row]
        if len(self._points) == 0:
            self._trace_allow_empty_flush = True
        self._sync_prompt_list()
        self._compose_preview()

    def _remove_selected_prompt(self):
        self._remove_prompt_at_row(self.lst_prompts.currentRow())

    def _on_prompt_list_context_menu(self, pos):
        vp = self.lst_prompts.viewport()
        vpos = vp.mapFrom(self.lst_prompts, pos)
        item = self.lst_prompts.itemAt(vpos)
        if item is None:
            return
        row = self.lst_prompts.row(item)
        if row < 0 or row >= len(self._points):
            return
        menu = QMenu(self)
        act_remove = QAction(self.tr("Remove prompt"), self)
        act_remove.triggered.connect(lambda checked=False, r=row: self._remove_prompt_at_row(r))
        menu.addAction(act_remove)
        menu.exec_(self.lst_prompts.mapToGlobal(pos))

    def _clear_points(self):
        self._trace_allow_empty_flush = True
        self._points.clear()
        self._labels.clear()
        self._prompt_colors.clear()
        self._auto_sam_fg_xy = []
        self._sync_prompt_list()
        self._compose_preview()

    def _clear_auto_sam_fg(self):
        n = len(getattr(self, "_auto_sam_fg_xy", []) or [])
        self._auto_sam_fg_xy = []
        if n:
            self.lbl_status.setText(
                self.tr("Removed {0} auto-generated SAM foreground point(s).").format(n)
            )

    def _pixel_near_any_fg_reference_color(self, r: int, g: int, b: int, ref_qcolors: list) -> bool:
        """True if RGB lies in the HSV tolerance tube around any reference QColor (uses Extra FG tolerance)."""
        if not ref_qcolors:
            return False
        try:
            import cv2
        except ImportError:
            return True
        extra = 0
        if getattr(self, "sp_fg_bleed", None) is not None:
            extra = int(np.clip(int(self.sp_fg_bleed.value()), 0, 90))
        h_margin = 22 + min(40, (extra * 3) // 4)
        s_margin = 50 + extra
        v_margin = 50 + extra
        pixel_rgb = np.uint8([[[r, g, b]]])
        px_hsv = cv2.cvtColor(pixel_rgb, cv2.COLOR_RGB2HSV)[0, 0]
        hc, sc, vc = int(px_hsv[0]), int(px_hsv[1]), int(px_hsv[2])
        for qc in ref_qcolors:
            if qc is None or not qc.isValid():
                continue
            ref_arr = np.uint8([[[qc.red(), qc.green(), qc.blue()]]])
            rh = cv2.cvtColor(ref_arr, cv2.COLOR_RGB2HSV)[0, 0]
            rc, rs, rv = int(rh[0]), int(rh[1]), int(rh[2])
            if self._hue_circ_dist(hc, rc) > h_margin:
                continue
            s_lo, s_hi = max(0, rs - s_margin), min(255, rs + s_margin)
            v_lo, v_hi = max(0, rv - v_margin), min(255, rv + v_margin)
            if s_lo <= sc <= s_hi and v_lo <= vc <= v_hi:
                return True
        return False

    def _auto_fg_prompts_from_color_mask(self):
        """Store grid samples as hidden SAM-only FG prompts (see ``_auto_sam_fg_xy``)."""
        if self._rgb is None:
            QMessageBox.warning(
                self,
                self.tr("Auto FG prompts"),
                self.tr("Load a raster preview first."),
            )
            return
        ref_qcolors = [
            self._prompt_colors[i]
            for i in range(len(self._labels))
            if self._labels[i] == 1 and i < len(self._prompt_colors)
        ]
        if not ref_qcolors:
            QMessageBox.warning(
                self,
                self.tr("Auto FG prompts"),
                self.tr(
                    "Add one or more foreground clicks on your pipeline colors first — auto-placement uses "
                    "those colors only (paper, ocean, and other hues inside the broad mask are skipped)."
                ),
            )
            return
        eff = self._effective_color_mask()
        if eff is None or not np.any(eff):
            QMessageBox.warning(
                self,
                self.tr("Auto FG prompts"),
                self.tr(
                    "Color mask is empty — widen Hue/Sat/Val, use Auto-tune, or add foreground clicks "
                    "and “Tune mask from foreground prompts” before auto-placement."
                ),
            )
            return
        max_n = int(self.sp_auto_fg_prompts.value()) if self.sp_auto_fg_prompts is not None else 80
        cand_cap = min(2500, max(300, max_n * 60))
        candidates = _sample_fg_points_from_bool_mask(eff, cand_cap)
        sampled = []
        H, W = int(self._rgb.shape[0]), int(self._rgb.shape[1])
        for cx, cy in candidates:
            xi = int(np.clip(int(round(cx)), 0, max(0, W - 1)))
            yi = int(np.clip(int(round(cy)), 0, max(0, H - 1)))
            pr, pg, pb = (
                int(self._rgb[yi, xi, 0]),
                int(self._rgb[yi, xi, 1]),
                int(self._rgb[yi, xi, 2]),
            )
            if not self._pixel_near_any_fg_reference_color(pr, pg, pb, ref_qcolors):
                continue
            sampled.append((float(xi), float(yi)))
        md = max(5.0, min(24.0, 180.0 / max(1.0, np.sqrt(float(max_n)))))
        sampled = _dedupe_points_min_dist(sampled, md)
        if len(sampled) > max_n:
            sampled = sampled[:max_n]
        if not sampled:
            QMessageBox.warning(
                self,
                self.tr("Auto FG prompts"),
                self.tr(
                    "No mask pixels matched your foreground reference colors. "
                    "Raise “Extra FG color tolerance”, add another FG click on a faint line, or widen the mask."
                ),
            )
            return
        self._auto_sam_fg_xy = [(float(x), float(y)) for x, y in sampled]
        self._trace_allow_empty_flush = False
        self._sync_prompt_list()
        self._compose_preview()
        self.lbl_status.setText(
            self.tr(
                "Stored {0} auto FG point(s) for SAM (from {1} reference color(s)); not shown in the list. Run SAM when ready."
            ).format(len(self._auto_sam_fg_xy), len(ref_qcolors))
        )

    def _run_sam(self):
        if self._color_only_mode():
            QMessageBox.information(
                self,
                self.tr("SAM"),
                self.tr(
                    "Turn off “Trace from color mask only” to run Segment Anything, "
                    "or use Vectorize lines for the color mask."
                ),
            )
            return
        if not getattr(self, "_sam_deps_ok", False):
            _, msg = sam_dependencies_available()
            QMessageBox.warning(self, self.tr("SAM dependencies"), msg)
            return
        if self._rgb is None or self._geo is None:
            QMessageBox.warning(self, self.tr("SAM"), self.tr("Load a raster first."))
            return
        auto_xy = getattr(self, "_auto_sam_fg_xy", []) or []
        pts_sam = [(float(x), float(y)) for x, y in self._points]
        lbs_sam = list(self._labels)
        for ax, ay in auto_xy:
            pts_sam.append((float(ax), float(ay)))
            lbs_sam.append(1)
        if len(pts_sam) == 0:
            QMessageBox.warning(
                self,
                self.tr("SAM"),
                self.tr("Add manual prompts or use “Auto FG prompts from color mask”."),
            )
            return
        if not any(int(lb) == 1 for lb in lbs_sam):
            QMessageBox.warning(
                self,
                self.tr("SAM"),
                self.tr("Add at least one foreground prompt (manual or auto)."),
            )
            return
        if not os.path.isfile(self._checkpoint_path):
            QMessageBox.warning(
                self,
                self.tr("SAM"),
                self.tr("Checkpoint missing. Use Download or Browse."),
            )
            return

        self.btn_run_sam.setEnabled(False)
        self.lbl_status.setText(self.tr("Running SAM… (may take a while on CPU)"))

        self._worker = SamPredictWorker(
            self._rgb.copy(),
            pts_sam,
            lbs_sam,
            self._checkpoint_path,
        )
        self._worker.finished_ok.connect(self._on_sam_done)
        self._worker.failed.connect(self._on_sam_fail)
        self._worker.finished.connect(self._on_sam_worker_finished)
        self._worker.start()

    def _on_sam_done(self, mask):
        self._sam_mask = mask
        if self.chk_apply_mask.isChecked():
            cm = self._effective_color_mask()
            if cm is not None:
                cm = morph_cleanup(cm, int(self.sp_morph.value()))
                self._sam_mask = self._sam_mask & cm
        self.lbl_status.setText(self.tr("SAM finished. Use Vectorize lines, then Add to map."))
        self._compose_preview()

    def _on_sam_fail(self, msg):
        QMessageBox.warning(self, self.tr("SAM failed"), msg)
        self.lbl_status.setText("")

    def _on_sam_worker_finished(self):
        self.btn_run_sam.setEnabled(
            getattr(self, "_sam_deps_ok", False) and not self._color_only_mode()
        )

    def _simplify_polyline_xy(self, xy):
        """Reduce stair-steps from pixel skeleton (Douglas–Peucker in map units)."""
        if self._geo is None or len(xy) < 3:
            return xy
        fac = float(self.sp_line_smooth.value())
        if fac <= 0:
            return xy
        gw = abs(float(self._geo["xmax"]) - float(self._geo["xmin"]))
        gh = abs(float(self._geo["ymax"]) - float(self._geo["ymin"]))
        pw = gw / float(max(1, int(self._geo["w"])))
        ph = gh / float(max(1, int(self._geo["h"])))
        tol = fac * max(pw, ph)
        g = QgsGeometry.fromPolylineXY(xy)
        sg = g.simplify(tol)
        if sg.isEmpty() or sg.type() != QgsWkbTypes.LineGeometry:
            return xy
        out = sg.asPolyline()
        return list(out) if len(out) >= 2 else xy

    def _guard_vectorize_mask_heavy(self, mask_bool, *, stage: str):
        nz = int(np.count_nonzero(np.asarray(mask_bool, dtype=bool)))
        if nz > _MAX_VECTORIZE_MASK_PIXELS:
            raise ValueError(
                self.tr(
                    "Traced region is too large to vectorize safely ({0} M pixels). "
                    "After 'Tune mask from foreground', narrow Hue/Sat/Val if hue hit full range, "
                    "add background clicks on map colors, or reduce Max preview side - then Vectorize."
                ).format(round(nz / 1_000_000.0, 2))
            )

    def _extract_polylines_from_mask(self, mask_bool):
        """Skeletonize and trace ``mask_bool``; return list of QgsPointXY chains."""
        if self._geo is None:
            raise ValueError(self.tr("Missing georeferencing for preview raster."))
        mask_bool = np.squeeze(np.asarray(mask_bool))
        if mask_bool.ndim != 2:
            raise ValueError(
                self.tr("Expected a 2D mask for vectorize, got shape {}").format(mask_bool.shape)
            )
        dilate_n = int(self.sp_trace_dilate.value())
        if dilate_n > 0:
            mask_bool = dilate_mask_cross(mask_bool, dilate_n)
        gap_px = int(self.sp_join_gap.value())
        if dilate_n <= 0 and gap_px > 0:
            conn_it = max(1, min(5, (int(gap_px) + 2) // 3))
            mask_bool = dilate_mask_cross(mask_bool, conn_it)
        if gap_px > 0:
            mask_bool = mask_close_short_gaps(mask_bool, gap_px)
        self._guard_vectorize_mask_heavy(mask_bool, stage="mask_after_dilate")
        sk = skeletonize_mask(mask_bool)
        self._guard_vectorize_mask_heavy(sk, stage="skeleton_pixels")
        pix_polys = polylines_from_skeleton(sk)
        if len(pix_polys) > _MAX_SKELETON_POLYLINE_FRAGMENTS:
            raise ValueError(
                self.tr(
                    "Skeleton split into too many pieces ({0}). The mask still covers too much detail - "
                    "tighten the color mask, raise Morph clean, or disable Trace dilate, then Vectorize."
                ).format(len(pix_polys))
            )
        pix_polys = merge_skeleton_polylines(pix_polys, int(self.sp_join_gap.value()))
        fac_smooth = float(self.sp_line_smooth.value())
        px_eps = max(0.0, min(2.8, 0.5 * fac_smooth)) if fac_smooth > 0 else 0.0
        if px_eps > 0:
            pix_polys = [
                _approx_dp_simplify_pixel_path(p, px_eps) if len(p) >= 4 else p
                for p in pix_polys
            ]
        skip_qgs = len(pix_polys) > _MAX_QGS_SIMPLIFY_FRAGMENTS
        dp_tol = None
        if skip_qgs and fac_smooth > 0:
            gw = abs(float(self._geo["xmax"]) - float(self._geo["xmin"]))
            gh = abs(float(self._geo["ymax"]) - float(self._geo["ymin"]))
            pw = gw / float(max(1, int(self._geo["w"])))
            ph = gh / float(max(1, int(self._geo["h"])))
            dp_tol = fac_smooth * max(pw, ph)
        min_px = max(2, int(0.00075 * max(self._geo["w"], self._geo["h"])))
        out = []
        for path in pix_polys:
            if len(path) < min_px:
                continue
            xy = pixel_path_to_xy(path, self._geo)
            if len(xy) >= 2:
                if skip_qgs:
                    if dp_tol is not None:
                        xy = _approx_dp_simplify_polyline_xy(xy, dp_tol)
                    out.append(xy)
                else:
                    out.append(self._simplify_polyline_xy(xy))
        return out

    def _polylines_from_binary_mask(self, mask_bool):
        """Fill ``self._last_polylines`` from boolean H×W mask; return feature count or None on error."""
        try:
            polylines = self._extract_polylines_from_mask(mask_bool)
        except Exception as e:
            QMessageBox.warning(self, self.tr("Vectorize"), str(e))
            return None
        self._last_polylines = polylines
        self._last_vector_layers = None
        return len(polylines)

    def _vectorize(self):
        self._last_single_trace_line_color = None
        if self._color_only_mode():
            if self._rgb is None or self._geo is None:
                QMessageBox.warning(
                    self,
                    self.tr("Vectorize"),
                    self.tr("Load a raster first."),
                )
                return
            eff = self._effective_color_mask()
            if eff is None:
                QMessageBox.warning(self, self.tr("Vectorize"), self.tr("Could not build color mask."))
                return
            morph_n = int(self.sp_morph.value())
            fg_boxes = self._fg_prompt_hsv_boxes()
            self._last_trace_was_color_mask_only = True

            if len(fg_boxes) >= 2:
                clusters = self._merge_fg_hsv_clusters(fg_boxes)
                morph_eff = morph_cleanup(eff, morph_n)
                if not np.any(morph_eff):
                    QMessageBox.warning(
                        self,
                        self.tr("Vectorize"),
                        self.tr(
                            "Color mask is empty — widen Hue/Sat/Val, use Auto-tune, add foreground "
                            "clicks, or turn off Invert. Background clicks remove their colors from the mask."
                        ),
                    )
                    return
                layers_spec = []
                preview_union = np.zeros_like(eff, dtype=bool)
                total_lines = 0
                for ci, c in enumerate(clusters):
                    qc = c.get("line_color")
                    if not isinstance(qc, QColor) or not qc.isValid():
                        qc = self._representative_fg_line_color()
                    bh0, bh1, bs0, bs1, bv0, bv1 = self._expand_cluster_hsv_for_vectorize(c)
                    band = hsv_mask_rgb(
                        self._rgb,
                        bh0,
                        bh1,
                        bs0,
                        bs1,
                        bv0,
                        bv1,
                        False,
                    )
                    cm = eff & band
                    cm = morph_cleanup(cm, morph_n)
                    preview_union |= cm
                    layer_title = self.tr("Pipeline trace (color {})").format(ci + 1)
                    if not np.any(cm):
                        layers_spec.append((layer_title, [], qc))
                        continue
                    try:
                        lines = self._extract_polylines_from_mask(cm)
                    except Exception as e:
                        QMessageBox.warning(self, self.tr("Vectorize"), str(e))
                        return
                    layers_spec.append((layer_title, lines, qc))
                    total_lines += len(lines)
                self._sam_mask = preview_union
                self._last_vector_layers = layers_spec
                self._last_polylines = [ln for _t, ls, _c in layers_spec for ln in ls]
                self._compose_preview()
                self.lbl_status.setText(
                    self.tr(
                        "Extracted {0} line features in {1} color layer(s) (color mask only)."
                    ).format(total_lines, len(clusters))
                )
                return

            cm = morph_cleanup(eff, morph_n)
            if not np.any(cm):
                QMessageBox.warning(
                    self,
                    self.tr("Vectorize"),
                    self.tr(
                        "Color mask is empty — widen Hue/Sat/Val, use Auto-tune, add foreground "
                        "clicks, or turn off Invert. Background clicks remove their colors from the mask."
                    ),
                )
                return
            self._sam_mask = cm
            self._compose_preview()
            n = self._polylines_from_binary_mask(self._sam_mask)
            if n is None:
                return
            self._last_single_trace_line_color = self._representative_fg_line_color()
            self.lbl_status.setText(
                self.tr("Extracted {} line features (color mask only).").format(n)
            )
            return

        self._last_trace_was_color_mask_only = False
        if self._sam_mask is None:
            QMessageBox.warning(self, self.tr("Vectorize"), self.tr("Run SAM first."))
            return
        n = self._polylines_from_binary_mask(self._sam_mask)
        if n is None:
            return
        self._last_single_trace_line_color = self._representative_fg_line_color()
        self.lbl_status.setText(self.tr("Extracted {} line features.").format(n))

    def _add_to_map(self):
        spec = getattr(self, "_last_vector_layers", None)
        if spec is not None:
            chains_flat = [ln for _title, ls, _c in spec for ln in ls]
            if not chains_flat:
                QMessageBox.warning(
                    self,
                    self.tr("Add to map"),
                    self.tr("Vectorize lines first."),
                )
                return
        elif getattr(self, "_last_polylines", None) is None or len(self._last_polylines) == 0:
            QMessageBox.warning(
                self,
                self.tr("Add to map"),
                self.tr("Vectorize lines first."),
            )
            return
        layer = self._resolve_raster_layer_for_processing()
        if layer is None or not layer.isValid():
            QMessageBox.warning(
                self,
                self.tr("Add to map"),
                self.tr("Raster source is missing. Open an image or pick a project layer."),
            )
            return
        crs = layer.crs()
        if not crs.isValid():
            crs = QgsCoordinateReferenceSystem("EPSG:3857")
        crs_id = crs.authid()
        if not crs_id:
            crs_id = "EPSG:3857"

        def _make_line_layer(title, chains):
            vl = QgsVectorLayer("LineString?crs=" + crs_id, title, "memory")
            vl.setCrs(crs)
            pr = vl.dataProvider()
            pr.addAttributes([QgsField("fid", QMetaType.Type.LongLong)])
            vl.updateFields()
            feats = []
            for j, chain in enumerate(chains):
                g = QgsGeometry.fromPolylineXY(chain)
                if g.isEmpty():
                    continue
                f = QgsFeature()
                f.setGeometry(g)
                f.setAttributes([j])
                feats.append(f)
            if feats:
                pr.addFeatures(feats)
            vl.updateExtents()
            return vl, len(feats)

        total_feats = 0
        added_layers = []
        if spec is not None:
            for layer_title, chains, line_color in spec:
                if not chains:
                    continue
                vl, nf = _make_line_layer(layer_title, chains)
                self._apply_pipeline_line_symbology(vl, line_color)
                total_feats += nf
                added_layers.append(vl)
        else:
            layer_title = (
                self.tr("Pipeline trace (color mask)")
                if getattr(self, "_last_trace_was_color_mask_only", False)
                else self.tr("Pipeline trace (SAM)")
            )
            vl, nf = _make_line_layer(layer_title, self._last_polylines)
            qc = getattr(self, "_last_single_trace_line_color", None)
            if not isinstance(qc, QColor) or not qc.isValid():
                qc = self._representative_fg_line_color()
            self._apply_pipeline_line_symbology(vl, qc)
            total_feats = nf
            added_layers.append(vl)

        prj = QgsProject.instance()
        if added_layers:
            try:
                prj.addMapLayers(added_layers, True)
            except (AttributeError, TypeError):
                for vl in added_layers:
                    prj.addMapLayer(vl)

        iface = self._iface
        if iface is not None and added_layers:
            layers_snap = list(added_layers)
            rlayer_ref = layer
            nfeat = total_feats

            def _deferred_add_ui():
                try:
                    iface.setActiveLayer(layers_snap[-1])
                    self._zoom_canvas_to_raster_extent(rlayer_ref)
                    iface.messageBar().pushMessage(
                        "Mapestry",
                        self.tr("Added {} pipeline lines.").format(nfeat),
                        level=Qgis.Success,
                    )
                except Exception:
                    pass

            QTimer.singleShot(0, _deferred_add_ui)

        if self._plugin is not None and hasattr(self._plugin, "register_completed_tool"):
            self._plugin.register_completed_tool("raster_trace")

    def closeEvent(self, event):
        pw = self._pip_worker
        if pw is not None and pw.isRunning():
            QMessageBox.information(
                self,
                self.tr("Installation running"),
                self.tr("Wait until package installation finishes before closing this dialog."),
            )
            event.ignore()
            return
        w = self._worker
        if w is not None:
            for sig, slot in (
                (w.finished_ok, self._on_sam_done),
                (w.failed, self._on_sam_fail),
                (w.finished, self._on_sam_worker_finished),
            ):
                try:
                    sig.disconnect(slot)
                except (TypeError, RuntimeError):
                    pass
        self.flush_trace_state_to_project()
        super().closeEvent(event)

    def accept(self):
        self.flush_trace_state_to_project()
        super().accept()
