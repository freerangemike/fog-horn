# -*- coding: utf-8 -*-
"""Import route connections from Excel, CSV, or delimited text files."""

from __future__ import annotations

import csv
import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
)

from .route_connections_fields import (
    _normalize_field_key,
    preferred_display_field_name,
)

_FILE_FILTER = (
    "Tabular files (*.csv *.txt *.tsv *.tab *.xlsx *.xls);;"
    "CSV (*.csv);;"
    "Text (*.txt *.tsv *.tab);;"
    "Excel (*.xlsx *.xls);;"
    "All files (*.*)"
)

_START_COLUMN_KEYS = (
    "start",
    "from",
    "origin",
    "source",
    "begin",
    "departure",
    "depart",
    "startaddress",
    "startaddr",
    "fromaddress",
)
_END_COLUMN_KEYS = (
    "end",
    "to",
    "destination",
    "dest",
    "target",
    "finish",
    "arrival",
    "arrive",
    "endaddress",
    "endaddr",
    "toaddress",
)


def normalize_match_text(text) -> str:
    return "" if text is None else str(text).strip().casefold()


def _guess_column(headers, key_set):
    for header in headers:
        key = _normalize_field_key(header)
        if key in key_set:
            return header
    return None


def _excel_column_letters(count):
    """A, B, … Z, AA, AB, … for heading-less column labels."""
    labels = []
    for index in range(count):
        n = index
        letters = []
        while True:
            letters.append(chr(ord("A") + (n % 26)))
            n = n // 26 - 1
            if n < 0:
                break
        labels.append("".join(reversed(letters)))
    return labels


def _normalize_matrix(rows):
    rows = [list(row) for row in rows if any(str(cell).strip() for cell in row)]
    if not rows:
        return []
    width = max(len(row) for row in rows)
    out = []
    for row in rows:
        cells = ["" if cell is None else str(cell).strip() for cell in row]
        if len(cells) < width:
            cells.extend([""] * (width - len(cells)))
        else:
            cells = cells[:width]
        out.append(cells)
    return out


def _split_headers_and_data(raw_rows, has_headers):
    matrix = _normalize_matrix(raw_rows)
    if not matrix:
        return [], []
    width = len(matrix[0])
    if has_headers:
        headers = list(matrix[0])
        # Ensure unique, non-empty header labels for combo boxes.
        letters = _excel_column_letters(width)
        seen = {}
        for i, name in enumerate(headers):
            label = name or letters[i]
            if label in seen:
                seen[label] += 1
                label = "{} ({})".format(label, seen[label])
            else:
                seen[label] = 1
            headers[i] = label
        return headers, matrix[1:]
    return _excel_column_letters(width), matrix


def _read_delimited_text(path):
    raw = None
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            with open(path, newline="", encoding=encoding) as handle:
                raw = handle.read()
            break
        except (OSError, UnicodeDecodeError):
            continue
    if raw is None:
        raise OSError("Could not read file with a supported text encoding.")

    sample = raw[:8192]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel
    reader = csv.reader(raw.splitlines(), dialect)
    return _normalize_matrix([[str(cell).strip() for cell in row] for row in reader])


def _read_xlsx(path):
    try:
        from openpyxl import load_workbook
    except ImportError as exc:
        raise ImportError(
            "Reading .xlsx files requires the openpyxl package. "
            "Save the file as CSV or install openpyxl in your QGIS Python environment."
        ) from exc

    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        sheet = workbook.active
        rows = []
        for row in sheet.iter_rows(values_only=True):
            rows.append(["" if cell is None else str(cell).strip() for cell in row])
    finally:
        workbook.close()
    return _normalize_matrix(rows)


def _read_xls(path):
    try:
        import xlrd
    except ImportError as exc:
        raise ImportError(
            "Reading .xls files requires the xlrd package. "
            "Save the file as CSV or install xlrd in your QGIS Python environment."
        ) from exc

    book = xlrd.open_workbook(path)
    sheet = book.sheet_by_index(0)
    rows = []
    for row_idx in range(sheet.nrows):
        row = []
        for col_idx in range(sheet.ncols):
            value = sheet.cell_value(row_idx, col_idx)
            row.append("" if value is None else str(value).strip())
        rows.append(row)
    return _normalize_matrix(rows)


def read_tabular_file(path):
    """Return a raw data matrix (list of rows). Header handling is done in the mapping dialog."""
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx",):
        return _read_xlsx(path)
    if ext in (".xls",):
        return _read_xls(path)
    return _read_delimited_text(path)


class _ImportColumnMappingDialog(QDialog):
    """Pick file start/end columns and the layer field used for matching."""

    def __init__(self, raw_rows, layer_field_names, parent=None):
        super().__init__(parent)
        self.setWindowTitle(self.tr("Import Connections — Column Mapping"))
        self.setMinimumWidth(640)
        self.setMinimumHeight(420)
        self._raw_rows = raw_rows or []
        self._layer_field_names = list(layer_field_names or [])
        self._headers = []
        self._data_rows = []

        layout = QVBoxLayout(self)

        layout.addWidget(
            QLabel(
                self.tr(
                    "Choose which file columns contain start and end addresses, "
                    "and which layer attribute to match against."
                )
            )
        )

        self.has_headers_check = QCheckBox(self.tr("First row has column headings"))
        self.has_headers_check.setChecked(True)
        self.has_headers_check.toggled.connect(self._rebuild_from_header_mode)
        layout.addWidget(self.has_headers_check)

        form = QHBoxLayout()
        self.start_combo = QComboBox()
        self.end_combo = QComboBox()
        self.layer_field_combo = QComboBox()
        for name in self._layer_field_names:
            self.layer_field_combo.addItem(name)
        preferred = preferred_display_field_name(self._layer_field_names)
        if preferred:
            idx = self.layer_field_combo.findText(preferred)
            if idx >= 0:
                self.layer_field_combo.setCurrentIndex(idx)
        form.addWidget(QLabel(self.tr("File Start:")))
        form.addWidget(self.start_combo, 1)
        form.addWidget(QLabel(self.tr("File End:")))
        form.addWidget(self.end_combo, 1)
        form.addWidget(QLabel(self.tr("Layer field:")))
        form.addWidget(self.layer_field_combo, 1)
        layout.addLayout(form)

        layout.addWidget(QLabel(self.tr("Preview (first rows):")))
        self.preview = QTableWidget(self)
        self.preview.setEditTriggers(QTableWidget.NoEditTriggers)
        self.preview.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.preview, 1)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self._rebuild_from_header_mode()

    def _rebuild_from_header_mode(self, *_args):
        has_headers = self.has_headers_check.isChecked()
        self._headers, self._data_rows = _split_headers_and_data(
            self._raw_rows, has_headers
        )
        prev_start = self.start_combo.currentText()
        prev_end = self.end_combo.currentText()

        self.start_combo.blockSignals(True)
        self.end_combo.blockSignals(True)
        try:
            self.start_combo.clear()
            self.end_combo.clear()
            for header in self._headers:
                self.start_combo.addItem(header)
                self.end_combo.addItem(header)
        finally:
            self.start_combo.blockSignals(False)
            self.end_combo.blockSignals(False)

        if has_headers:
            guessed_start = _guess_column(self._headers, _START_COLUMN_KEYS)
            guessed_end = _guess_column(self._headers, _END_COLUMN_KEYS)
            if guessed_start:
                self.start_combo.setCurrentText(guessed_start)
            elif prev_start and self.start_combo.findText(prev_start) >= 0:
                self.start_combo.setCurrentText(prev_start)
            if guessed_end:
                self.end_combo.setCurrentText(guessed_end)
            elif prev_end and self.end_combo.findText(prev_end) >= 0:
                self.end_combo.setCurrentText(prev_end)
        else:
            # Default to A = start, B = end when there are at least two columns.
            if self.start_combo.count() >= 1:
                self.start_combo.setCurrentIndex(0)
            if self.end_combo.count() >= 2:
                self.end_combo.setCurrentIndex(1)

        preview_rows = self._data_rows[:8]
        cols = len(self._headers)
        self.preview.clear()
        self.preview.setColumnCount(cols)
        self.preview.setHorizontalHeaderLabels(self._headers)
        self.preview.setRowCount(len(preview_rows))
        for row_idx, row in enumerate(preview_rows):
            for col_idx in range(cols):
                value = row[col_idx] if col_idx < len(row) else ""
                self.preview.setItem(row_idx, col_idx, QTableWidgetItem(value))

    def mapping(self):
        return (
            self.start_combo.currentText(),
            self.end_combo.currentText(),
            self.layer_field_combo.currentText(),
            list(self._headers),
            list(self._data_rows),
        )


class _AmbiguousFeatureDialog(QDialog):
    """Pick one layer feature when multiple share the same address text."""

    def __init__(self, side, address_text, candidates, parent=None):
        super().__init__(parent)
        self.setWindowTitle(self.tr("Ambiguous Match"))
        self.setMinimumWidth(520)
        self.selected_fid = None
        self.do_for_all = False

        layout = QVBoxLayout(self)
        layout.addWidget(
            QLabel(
                self.tr(
                    "Multiple features match the {side} address “{address}”. "
                    "Choose which feature to use."
                ).format(side=side, address=address_text)
            )
        )

        self.list_widget = QListWidget()
        for fid, label in candidates:
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, fid)
            self.list_widget.addItem(item)
        if self.list_widget.count():
            self.list_widget.setCurrentRow(0)
        layout.addWidget(self.list_widget, 1)

        self.do_for_all_check = QCheckBox(
            self.tr("Do this for all (always use first match for remaining ambiguous rows)")
        )
        layout.addWidget(self.do_for_all_check)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _accept(self):
        item = self.list_widget.currentItem()
        if item is None:
            return
        fid = item.data(Qt.UserRole)
        try:
            fid = int(fid)
        except (TypeError, ValueError):
            pass
        self.selected_fid = fid
        self.do_for_all = self.do_for_all_check.isChecked()
        self.accept()


class _DuplicateConnectionDialog(QDialog):
    """Append or replace when a start/end pair already exists."""

    def __init__(self, start_text, end_text, parent=None):
        super().__init__(parent)
        self.setWindowTitle(self.tr("Duplicate Connection"))
        self.setMinimumWidth(460)
        self.action = None
        self.do_for_all = False

        layout = QVBoxLayout(self)
        layout.addWidget(
            QLabel(
                self.tr(
                    "A connection from “{start}” to “{end}” already exists.\n"
                    "Append another connection or replace the existing one?"
                ).format(start=start_text, end=end_text)
            )
        )

        row = QHBoxLayout()
        append_btn = QPushButton(self.tr("Append"))
        replace_btn = QPushButton(self.tr("Replace"))
        cancel_btn = QPushButton(self.tr("Cancel Import"))
        append_btn.clicked.connect(lambda: self._finish("append"))
        replace_btn.clicked.connect(lambda: self._finish("replace"))
        cancel_btn.clicked.connect(self.reject)
        row.addWidget(append_btn)
        row.addWidget(replace_btn)
        row.addStretch(1)
        row.addWidget(cancel_btn)
        layout.addLayout(row)

        self.do_for_all_check = QCheckBox(self.tr("Do this for all"))
        layout.addWidget(self.do_for_all_check)

    def _finish(self, action):
        self.action = action
        self.do_for_all = self.do_for_all_check.isChecked()
        self.accept()


class _ImportErrorReportDialog(QDialog):
    def __init__(self, failures, parent=None):
        super().__init__(parent)
        self.setWindowTitle(self.tr("Import Error Report"))
        self.resize(760, 480)

        layout = QVBoxLayout(self)
        layout.addWidget(
            QLabel(
                self.tr("The following rows could not be matched and were not imported:")
            )
        )

        table = QTableWidget(len(failures), 4, self)
        table.setHorizontalHeaderLabels(
            [self.tr("Row"), self.tr("Start"), self.tr("End"), self.tr("Reason")]
        )
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        for row_idx, failure in enumerate(failures):
            table.setItem(row_idx, 0, QTableWidgetItem(str(failure.get("row", ""))))
            table.setItem(row_idx, 1, QTableWidgetItem(failure.get("start", "")))
            table.setItem(row_idx, 2, QTableWidgetItem(failure.get("end", "")))
            table.setItem(row_idx, 3, QTableWidgetItem(failure.get("reason", "")))
        layout.addWidget(table, 1)

        close_btn = QDialogButtonBox(QDialogButtonBox.Close)
        close_btn.rejected.connect(self.reject)
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)


class _ImportResultsDialog(QDialog):
    def __init__(self, total, success_count, failures, parent=None):
        super().__init__(parent)
        self.setWindowTitle(self.tr("Import Results"))
        self.setMinimumWidth(460)
        self.apply_requested = False
        self.failures = failures

        layout = QVBoxLayout(self)
        fail_count = len(failures)
        if fail_count == 0:
            layout.addWidget(
                QLabel(
                    self.tr(
                        "All {total} connection(s) matched successfully.\n"
                        "Apply now to draw routes on the map?"
                    ).format(total=total)
                )
            )
        else:
            layout.addWidget(
                QLabel(
                    self.tr(
                        "{fail} of {total} row(s) failed to match.\n"
                        "Apply the {success} successful connection(s) now?"
                    ).format(fail=fail_count, total=total, success=success_count)
                )
            )

        row = QHBoxLayout()
        if fail_count == 0:
            apply_btn = QPushButton(self.tr("Apply Now"))
            cancel_btn = QPushButton(self.tr("Cancel"))
            apply_btn.clicked.connect(self._apply)
            cancel_btn.clicked.connect(self.reject)
            row.addWidget(apply_btn)
            row.addWidget(cancel_btn)
        else:
            apply_btn = QPushButton(self.tr("Ignore Failures && Apply"))
            cancel_btn = QPushButton(self.tr("Cancel"))
            report_btn = QPushButton(self.tr("View Error Report…"))
            apply_btn.clicked.connect(self._apply)
            cancel_btn.clicked.connect(self.reject)
            report_btn.clicked.connect(self._show_report)
            row.addWidget(apply_btn)
            row.addWidget(report_btn)
            row.addWidget(cancel_btn)
        layout.addLayout(row)

    def _apply(self):
        self.apply_requested = True
        self.accept()

    def _show_report(self):
        dlg = _ImportErrorReportDialog(self.failures, self)
        dlg.exec_()


class RouteConnectionsImporter:
    """Orchestrates file pick → mapping → match → prompts → table update."""

    def __init__(self, dialog):
        self.dialog = dialog

    def run(self):
        dlg = self.dialog
        if dlg.current_layer is None:
            QMessageBox.warning(
                dlg,
                dlg.tr("No Layer Selected"),
                dlg.tr("Select a point layer before importing connections."),
            )
            return

        path, _selected = QFileDialog.getOpenFileName(
            dlg,
            dlg.tr("Import Connections"),
            "",
            _FILE_FILTER,
        )
        if not path:
            return

        try:
            raw_rows = read_tabular_file(path)
        except ImportError as exc:
            QMessageBox.warning(dlg, dlg.tr("Import Error"), str(exc))
            return
        except OSError as exc:
            QMessageBox.warning(
                dlg,
                dlg.tr("Import Error"),
                dlg.tr("Could not read file:\n{error}").format(error=exc),
            )
            return

        if not raw_rows:
            QMessageBox.warning(
                dlg,
                dlg.tr("Import Error"),
                dlg.tr("The selected file has no data rows."),
            )
            return

        mapping_dlg = _ImportColumnMappingDialog(
            raw_rows,
            dlg._layer_field_names(),
            dlg,
        )
        if mapping_dlg.exec_() != QDialog.Accepted:
            return

        start_col, end_col, layer_field, headers, rows = mapping_dlg.mapping()
        if not headers or not rows:
            QMessageBox.warning(
                dlg,
                dlg.tr("Import Error"),
                dlg.tr("The selected file has no data rows."),
            )
            return

        col_index = {name: idx for idx, name in enumerate(headers)}
        if start_col not in col_index or end_col not in col_index:
            QMessageBox.warning(dlg, dlg.tr("Import Error"), dlg.tr("Invalid column selection."))
            return
        start_idx = col_index[start_col]
        end_idx = col_index[end_col]

        self._ambiguous_use_first_for_all = False
        resolved, failures, cancelled = self._process_rows(
            rows, start_idx, end_idx, layer_field
        )
        if cancelled:
            return

        total = len(rows)
        success_count = len(resolved)
        if success_count == 0 and failures:
            report = _ImportErrorReportDialog(failures, dlg)
            report.exec_()
            QMessageBox.warning(
                dlg,
                dlg.tr("Import Failed"),
                dlg.tr("No connections could be matched."),
            )
            return

        for item in resolved:
            dlg.insert_connection_row(
                item["start_text"],
                item["end_text"],
                item["start_fid"],
                item["end_fid"],
                replace_existing=item.get("replace_existing", False),
            )

        results_dlg = _ImportResultsDialog(total, success_count, failures, dlg)
        if results_dlg.exec_() != QDialog.Accepted:
            return
        if results_dlg.apply_requested:
            plugin = getattr(dlg, "plugin", None)
            if plugin is not None and hasattr(plugin, "sync_arcs"):
                plugin.sync_arcs()
            else:
                QMessageBox.warning(
                    dlg,
                    dlg.tr("Apply Failed"),
                    dlg.tr(
                        "Connections were added to the list, but routes could not be drawn. "
                        "Click Apply on the Route Connections dialog."
                    ),
                )

    def _process_rows(self, rows, start_idx, end_idx, layer_field):
        dlg = self.dialog
        resolved = []
        failures = []

        self._ambiguous_use_first_for_all = False
        ambiguous_cache = {}
        duplicate_action_for_all = None

        for row_num, row in enumerate(rows, start=2):
            if start_idx >= len(row) or end_idx >= len(row):
                failures.append(
                    {
                        "row": row_num,
                        "start": "",
                        "end": "",
                        "reason": self.dialog.tr("Row is missing start or end column."),
                    }
                )
                continue

            start_text = str(row[start_idx]).strip()
            end_text = str(row[end_idx]).strip()
            if not start_text and not end_text:
                continue
            if not start_text or not end_text:
                failures.append(
                    {
                        "row": row_num,
                        "start": start_text,
                        "end": end_text,
                        "reason": self.dialog.tr("Start or end address is empty."),
                    }
                )
                continue

            start_key = normalize_match_text(start_text)
            end_key = normalize_match_text(end_text)

            start_fid = self._resolve_fid(
                layer_field,
                start_text,
                start_key,
                "start",
                ambiguous_cache,
            )
            if start_fid == "cancelled":
                return [], failures, True
            if start_fid is None:
                failures.append(
                    {
                        "row": row_num,
                        "start": start_text,
                        "end": end_text,
                        "reason": self.dialog.tr("Start address not found in layer."),
                    }
                )
                continue

            end_fid = self._resolve_fid(
                layer_field,
                end_text,
                end_key,
                "end",
                ambiguous_cache,
            )
            if end_fid == "cancelled":
                return [], failures, True
            if end_fid is None:
                failures.append(
                    {
                        "row": row_num,
                        "start": start_text,
                        "end": end_text,
                        "reason": self.dialog.tr("End address not found in layer."),
                    }
                )
                continue

            duplicate_row = dlg.find_connection_row_by_pair(start_text, end_text)
            in_batch = self._pair_in_batch(resolved, start_key, end_key)
            replace_existing = False
            if duplicate_row is not None or in_batch:
                action = duplicate_action_for_all
                if action is None:
                    dup_dlg = _DuplicateConnectionDialog(start_text, end_text, dlg)
                    if dup_dlg.exec_() != QDialog.Accepted:
                        return [], failures, True
                    action = dup_dlg.action
                    if dup_dlg.do_for_all:
                        duplicate_action_for_all = action
                replace_existing = action == "replace"
                if replace_existing and in_batch:
                    resolved = [
                        item
                        for item in resolved
                        if not (
                            normalize_match_text(item["start_text"]) == start_key
                            and normalize_match_text(item["end_text"]) == end_key
                        )
                    ]

            resolved.append(
                {
                    "start_text": start_text,
                    "end_text": end_text,
                    "start_fid": start_fid,
                    "end_fid": end_fid,
                    "replace_existing": replace_existing,
                }
            )

        return resolved, failures, False

    def _pair_in_batch(self, resolved, start_key, end_key):
        for item in resolved:
            if (
                normalize_match_text(item["start_text"]) == start_key
                and normalize_match_text(item["end_text"]) == end_key
            ):
                return True
        return False

    def _resolve_fid(
        self,
        layer_field,
        display_text,
        match_key,
        side,
        ambiguous_cache,
    ):
        if match_key in ambiguous_cache:
            return ambiguous_cache[match_key]

        matches = self.dialog.find_features_by_field_text(layer_field, display_text)
        if not matches:
            return None
        if len(matches) == 1:
            fid = matches[0][0]
            ambiguous_cache[match_key] = fid
            return fid

        if self._ambiguous_use_first_for_all:
            fid = matches[0][0]
            ambiguous_cache[match_key] = fid
            return fid

        amb_dlg = _AmbiguousFeatureDialog(side, display_text, matches, self.dialog)
        if amb_dlg.exec_() != QDialog.Accepted:
            return "cancelled"
        fid = amb_dlg.selected_fid
        ambiguous_cache[match_key] = fid
        if amb_dlg.do_for_all:
            self._ambiguous_use_first_for_all = True
        return fid
