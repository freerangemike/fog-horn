@echo off
REM Fallback installer if the dialog’s “Install SAM stack (automatic)” fails.
REM 1) Find QGIS → Settings → User Profiles → Open active profile folder → python\plugins\map_weaver is nearby;
REM    or open OSGeo4W / QGIS install folder and locate bin\python.exe
REM 2) Edit the line below to that full path, save, double-click this file.

set "PYTHON=C:\Program Files\QGIS 3.34.3\bin\python.exe"

if not exist "%PYTHON%" (
  echo Edit PYTHON= in this script to point at your QGIS bin\python.exe, then run again.
  pause
  exit /b 1
)

echo Using "%PYTHON%"
echo Upgrading pip ^(fixes PyTorch wheel index crashes on older bundled pip^)...
"%PYTHON%" -m pip install --user -U pip setuptools wheel packaging
if errorlevel 1 (
  echo pip upgrade had warnings or errors — continuing anyway.
)

"%PYTHON%" -m pip install --user torch --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 (
  echo Retrying torch from default PyPI...
  "%PYTHON%" -m pip install --user torch
)
if errorlevel 1 (
  echo torch install failed.
  pause
  exit /b 1
)

"%PYTHON%" -m pip install --user torchvision --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 (
  echo Retrying torchvision from default PyPI...
  "%PYTHON%" -m pip install --user torchvision
)
if errorlevel 1 (
  echo torchvision install failed ^(required by segment_anything^).
  pause
  exit /b 1
)

"%PYTHON%" -m pip install --user segment-anything scikit-image opencv-python-headless
if errorlevel 1 (
  echo segment_anything / scikit-image / opencv install failed.
  pause
  exit /b 1
)

echo Done. Restart QGIS, then open the Raster trace ^(SAM^) tool from the Tools tab.
pause
