# Mapestry

A simple to use plugin that speeds up the map-making process and makes QGIS less confusing (TBU)

## 🚀 Features
- **Fast:** Optimized for performance.
- **Easy to Use:** Minimal configuration required.
- **Cross-platform:** Works on Windows, macOS, and Linux.

## Project layout

- Raster/vector UI assets (`.png`, `.svg`, …) live under **`graphics/`**.
- Local datasets for the Library tab live under **`library/`**.
- After editing **`resources.qrc`**, recompile embedded resources from a QGIS-friendly shell, for example: `pyrcc5 resources.qrc -o resources.py`.

## 📦 Installation

Extract the ZIP to %appdata%\QGIS\QGIS3\profiles\default\python\plugins
Install in QGIS from Plugins menu>Manage and Install Plugins... (search for "Mapestry")
Launch Mapesty from Plugins>Mapestry>[click menu item with no text, TBU]

## 🛠 Usage

Release Notes 4/28/2026
- Local maps are opened from the **Library** tab (`library/` folder); the old “Get Local Map” shortcut button was removed.
- UI is created UI in Qt Desginer and promoted to custom classes for limiteless formatting possibilites, and keeping things easy to layout in Qt Designer
- All formatting is to demonstrate what is possible, not actually to suggest this formatting

## 📋 Prerequisites

QGIS 3.44.8-Solothurn (and probably higher versions)

---