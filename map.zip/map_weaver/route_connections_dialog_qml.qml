import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15

/*!
    Pure QML layout mirroring route_connections_dialog_base.ui:
    layer combo, start/end fields, map actions, data preview + connections tables, apply.
    Data and actions are driven by the Python context property `bridge`.
*/
Item {
    id: root
    anchors.fill: parent

    readonly property color accent: "#38bdf8"
    readonly property color accent2: "#a855f7"
    readonly property color surface: "#1e293b"
    readonly property color surface2: "#334155"
    readonly property color textPrimary: "#f1f5f9"
    readonly property color textMuted: "#94a3b8"

    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#0b1220" }
            GradientStop { position: 0.45; color: "#111827" }
            GradientStop { position: 1.0; color: "#0f172a" }
        }
    }

    // Soft vignette
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            orientation: Gradient.Horizontal
            GradientStop { position: 0.0; color: "#40000000" }
            GradientStop { position: 0.5; color: "#00000000" }
            GradientStop { position: 1.0; color: "#40000000" }
        }
    }

    MouseArea {
        anchors.fill: parent
        acceptedButtons: Qt.NoButton
    }

    Item {
        id: content
        anchors.fill: parent
        anchors.margins: 18

        Rectangle {
            id: glow
            anchors.fill: card
            anchors.margins: -2
            radius: card.radius + 2
            color: "#00000000"
            border.width: 1
            border.color: "#35ffffff"
            opacity: 0.35
        }

        Rectangle {
            id: card
            anchors.fill: parent
            radius: 16
            color: surface
            border.width: 1
            border.color: "#55ffffff"

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 20
                spacing: 14

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 12

                    Rectangle {
                        width: 4
                        height: 36
                        radius: 2
                        gradient: Gradient {
                            GradientStop { position: 0; color: accent }
                            GradientStop { position: 1; color: accent2 }
                        }
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 2
                        Label {
                            text: "Route Connections"
                            font.pixelSize: 20
                            font.weight: Font.DemiBold
                            color: textPrimary
                        }
                        Label {
                            text: "Define arcs between point features — QML surface"
                            font.pixelSize: 11
                            color: textMuted
                        }
                    }

                    Button {
                        text: "✕"
                        flat: true
                        font.pixelSize: 16
                        palette.buttonText: textMuted
                        onClicked: bridge.rejectDialog()
                        ToolTip.visible: hovered
                        ToolTip.text: qsTr("Close")
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 10
                    Label {
                        text: qsTr("CSV Layer")
                        color: textMuted
                        font.pixelSize: 12
                    }
                    ComboBox {
                        id: layerCombo
                        Layout.fillWidth: true
                        model: bridge.layerNames
                        currentIndex: bridge.layerIndex
                        onActivated: bridge.selectLayer(index)
                        palette.button: surface2
                        palette.buttonText: textPrimary
                        palette.highlight: accent
                        palette.highlightedText: "#0f172a"
                        background: Rectangle {
                            implicitHeight: 36
                            radius: 8
                            color: surface2
                            border.color: "#55ffffff"
                        }
                        contentItem: Label {
                            leftPadding: 12
                            rightPadding: 36
                            text: layerCombo.displayText
                            font.pixelSize: 13
                            color: textPrimary
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8
                    Label {
                        text: qsTr("Start")
                        color: textMuted
                        font.pixelSize: 12
                    }
                    TextField {
                        id: startField
                        Layout.fillWidth: true
                        text: bridge.startText
                        placeholderText: qsTr("Pick or type start…")
                        color: textPrimary
                        placeholderTextColor: "#64748b"
                        font.pixelSize: 13
                        padding: 10
                        selectByMouse: true
                        background: Rectangle {
                            implicitHeight: 36
                            radius: 8
                            color: "#0f172a"
                            border.color: bridge.selectionPhase === "start" ? accent : "#33ffffff"
                            border.width: bridge.selectionPhase === "start" ? 2 : 1
                        }
                        onTextEdited: bridge.setStartText(text)
                        Connections {
                            target: bridge
                            function onStartTextChanged() { startField.text = bridge.startText }
                        }
                    }
                    Label {
                        text: qsTr("End")
                        color: textMuted
                        font.pixelSize: 12
                    }
                    TextField {
                        id: endField
                        Layout.fillWidth: true
                        text: bridge.endText
                        placeholderText: qsTr("Pick or type end…")
                        color: textPrimary
                        placeholderTextColor: "#64748b"
                        font.pixelSize: 13
                        padding: 10
                        selectByMouse: true
                        background: Rectangle {
                            implicitHeight: 36
                            radius: 8
                            color: "#0f172a"
                            border.color: bridge.selectionPhase === "end" ? accent : "#33ffffff"
                            border.width: bridge.selectionPhase === "end" ? 2 : 1
                        }
                        onTextEdited: bridge.setEndText(text)
                        Connections {
                            target: bridge
                            function onEndTextChanged() { endField.text = bridge.endText }
                        }
                    }
                }

                RowLayout {
                    spacing: 8
                    Layout.fillWidth: true

                    Button {
                        text: qsTr("Select from map")
                        Layout.fillWidth: true
                        flat: false
                        font.pixelSize: 12
                        onClicked: bridge.selectFromMap()
                        background: Rectangle {
                            implicitHeight: 36
                            radius: 8
                            gradient: Gradient {
                                GradientStop { position: 0; color: "#334155" }
                                GradientStop { position: 1; color: "#1e293b" }
                            }
                            border.color: "#55ffffff"
                        }
                        contentItem: Label {
                            text: parent.text
                            font: parent.font
                            color: textPrimary
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                    Button {
                        text: qsTr("Edit curve")
                        Layout.fillWidth: true
                        font.pixelSize: 12
                        onClicked: bridge.editCurve()
                        background: Rectangle {
                            implicitHeight: 36
                            radius: 8
                            color: surface2
                            border.color: "#55ffffff"
                        }
                        contentItem: Label {
                            text: parent.text
                            font: parent.font
                            color: textPrimary
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                    Button {
                        text: "+"
                        implicitWidth: 48
                        font.pixelSize: 18
                        font.bold: true
                        onClicked: bridge.addConnection()
                        background: Rectangle {
                            implicitHeight: 36
                            radius: 8
                            color: "#059669"
                            border.color: "#34d399"
                        }
                        contentItem: Label {
                            text: parent.text
                            font: parent.font
                            color: "#ecfdf5"
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                    Button {
                        text: "−"
                        implicitWidth: 48
                        font.pixelSize: 18
                        font.bold: true
                        onClicked: bridge.removeConnection()
                        background: Rectangle {
                            implicitHeight: 36
                            radius: 8
                            color: "#b91c1c"
                            border.color: "#f87171"
                        }
                        contentItem: Label {
                            text: parent.text
                            font: parent.font
                            color: "#fef2f2"
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                }

                Label {
                    text: qsTr("Next click assigns: %1").arg(bridge.selectionPhase === "start" ? qsTr("Start") : qsTr("End"))
                    font.pixelSize: 11
                    color: accent
                }

                RowLayout {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    spacing: 14

                    ColumnLayout {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        spacing: 6
                        Label {
                            text: qsTr("Layer preview")
                            font.pixelSize: 12
                            font.weight: Font.Medium
                            color: textMuted
                        }
                        Rectangle {
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            radius: 10
                            color: "#0f172a"
                            border.color: "#33ffffff"
                            clip: true

                            Column {
                                anchors.fill: parent
                                anchors.margins: 6
                                spacing: 0

                                Row {
                                    id: previewHeadRow
                                    width: parent.width
                                    height: 28
                                    spacing: 0
                                    Repeater {
                                        model: bridge.previewHeaders
                                        Rectangle {
                                            width: previewHeadRow.width / Math.max(1, bridge.previewColumnCount)
                                            height: 28
                                            color: "#1e293b"
                                            border.color: "#44ffffff"
                                            Label {
                                                anchors.fill: parent
                                                anchors.margins: 4
                                                text: typeof modelData !== "undefined" ? modelData : ""
                                                font.bold: true
                                                font.pixelSize: 11
                                                color: accent
                                                verticalAlignment: Text.AlignVCenter
                                                elide: Text.ElideRight
                                            }
                                        }
                                    }
                                }

                                TableView {
                                    id: previewTable
                                    width: parent.width
                                    height: parent.height - previewHeadRow.height
                                    model: bridge.previewModel
                                    reuseItems: false

                                    columnWidthProvider: function (col) {
                                        return Math.max(72, (width - 8) / Math.max(1, bridge.previewColumnCount))
                                    }

                                    delegate: Rectangle {
                                        implicitWidth: 80
                                        implicitHeight: 28
                                        color: {
                                            var hi = bridge.previewHighlightColumn >= 0 && column === bridge.previewHighlightColumn && row === bridge.previewHighlightRow;
                                            return hi ? "#1e3a5f" : ((row % 2) ? "#0c1424" : "#0f172a");
                                        }
                                        border.color: "#22ffffff"

                                        Label {
                                            anchors.fill: parent
                                            anchors.margins: 4
                                            text: model.display !== undefined ? model.display : ""
                                            font.pixelSize: 11
                                            color: textPrimary
                                            elide: Text.ElideRight
                                            verticalAlignment: Text.AlignVCenter
                                        }

                                        MouseArea {
                                            anchors.fill: parent
                                            onClicked: bridge.previewCellClicked(row, column)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        spacing: 6
                        Label {
                            text: qsTr("Connections")
                            font.pixelSize: 12
                            font.weight: Font.Medium
                            color: textMuted
                        }
                        Rectangle {
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            radius: 10
                            color: "#0f172a"
                            border.color: "#33ffffff"
                            clip: true

                            Column {
                                anchors.fill: parent
                                anchors.margins: 6
                                spacing: 0

                                Row {
                                    id: connHeadRow
                                    width: parent.width
                                    height: 28
                                    Rectangle {
                                        width: parent.width / 2
                                        height: 28
                                        color: "#1e293b"
                                        border.color: "#44ffffff"
                                        Label {
                                            anchors.fill: parent
                                            anchors.margins: 4
                                            text: qsTr("Start")
                                            font.bold: true
                                            font.pixelSize: 11
                                            color: accent2
                                            verticalAlignment: Text.AlignVCenter
                                        }
                                    }
                                    Rectangle {
                                        width: parent.width / 2
                                        height: 28
                                        color: "#1e293b"
                                        border.color: "#44ffffff"
                                        Label {
                                            anchors.fill: parent
                                            anchors.margins: 4
                                            text: qsTr("End")
                                            font.bold: true
                                            font.pixelSize: 11
                                            color: accent2
                                            verticalAlignment: Text.AlignVCenter
                                        }
                                    }
                                }

                                TableView {
                                    id: connTable
                                    width: parent.width
                                    height: parent.height - connHeadRow.height
                                    model: bridge.connectionsModel
                                    reuseItems: false

                                    columnWidthProvider: function (col) {
                                        return (width - 8) / 2
                                    }

                                    delegate: Rectangle {
                                        implicitWidth: 100
                                        implicitHeight: 28
                                        color: {
                                            var sel = bridge.connectionsSelectedRow === row;
                                            return sel ? "#4c1d95" : ((row % 2) ? "#0c1424" : "#0f172a");
                                        }
                                        border.color: "#22ffffff"

                                        Label {
                                            anchors.fill: parent
                                            anchors.margins: 4
                                            text: model.display !== undefined ? model.display : ""
                                            font.pixelSize: 11
                                            color: textPrimary
                                            elide: Text.ElideRight
                                            verticalAlignment: Text.AlignVCenter
                                        }

                                        MouseArea {
                                            anchors.fill: parent
                                            onClicked: bridge.selectConnectionRow(row)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 12
                    Item { Layout.fillWidth: true }
                    Button {
                        text: qsTr("Apply")
                        implicitWidth: 140
                        implicitHeight: 40
                        font.pixelSize: 13
                        font.weight: Font.Medium
                        onClicked: bridge.apply()
                        background: Rectangle {
                            radius: 10
                            gradient: Gradient {
                                GradientStop { position: 0; color: accent }
                                GradientStop { position: 1; color: "#0284c7" }
                            }
                        }
                        contentItem: Label {
                            text: parent.text
                            font: parent.font
                            color: "#0f172a"
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }
                    }
                }
            }
        }
    }
}
